# Theory Lang and Compil
J'ai été jusqu'à **la partie O (améliorations)** des TPs.
Mais je pense qu'il faut que je peaufine le code.
J'ai commencé les tests et j'avais 154 la dernière fois que j'ai eu à les faire à l'école.

Mon fichier de grammaire est appelé **Calcul.g4**, j'ai donc adapté les parties qui s'y relataient dans le fichier **MainCalculette.java**
que j'ai joint à mon archive.

J'ai ajouté ,dans le cadre des améliorations :

- Les expression négatives
  > **Par exemple** => `write(-(x+5))` **ou** `write(-x+5)`

- La possibilité de faire des if, else if, else sans l'obligation des "()"  
  > **Par exemple** => `if i>2 write(x) else if i>0 write(x+1) elif i!=0 write(1) else write(i)` 

- Le statement: `break`

- La possibilité de faire des opérations sur différents types de variables
  > **Par exemple** => `write(x+y)` avec **x int** et **y double**


- Une déclaration un peu plus souple  
  > **Par exemple** => `var x, y, z : double` **;** 
                        `var x, y, z : int = 2` **;** 
                        `var x : int, y : double` **;** 
                        `var x : int = 2, y : int = x` **;** 
                        `int x, y` **;** 
                        `int x, y = 2` **;** 
                        `int x, double y` **;** 
                        `int x = 2, double y = 5.`
  
- Mais pour le type bool, la déclaration de forme 'TYPE IDENTIFIANT' ne fonctionne pas car il fait appel au type natif boolean de java
    > **En faisant donc** => `bool t = true`, **vous aurez une erreur.**

Vous pouvez aussi déclarer des variables un peu partout dans le code mais le fait d'en déclarer dans une fonction fonctionne à moitié.
Je pense que le problème est liée à la table des symboles utilisée dans les fonctions.

- Une assignation un peu plus permissive  
  > **Par exemple** => `x **= n` (avec le **n** qui est **obligé d'être un entier**) **;** 
                        `x *= a` **;** 
                        `x -= a` **;** 
                        `x /= a` **;** 
                        `d OP d++/--` **;** 
                        `d OP d++/--` **;** 
    **Avec _OP = { = , **= , *= , /= , += , -= }_**

- L'affichage de plusieurs valeurs
  > **Par exemple** => `write(a, b)` **;** 
                   `write(5*2, 4*5/6, x)`

J'ai ajouté à cet effet, un fichier benchMark '**my_own_benchmarks.txt**'

Par ailleurs, je commente mes codes le plus souvent en anglais, j'espère que cela ne pose pas de problèmes.
Le fichier **cmd.txt** liste les différentes commandes à exécuter dans le terminal.
