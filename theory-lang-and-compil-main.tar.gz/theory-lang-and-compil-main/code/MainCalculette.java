import java.io.*;
import org.antlr.v4.runtime.*;
public class MainCalculette {
    public static void main(String args[]) throws Exception {
        CalculLexer lex;
        if (args.length == 0)
            lex = new CalculLexer(CharStreams.fromStream(System.in));
        else
            lex = new CalculLexer(CharStreams.fromFileName(args[0]));

        CommonTokenStream tokens = new CommonTokenStream(lex);

        CalculParser parser = new CalculParser(tokens);
        try {
            parser.start();    // start l'axiome de la grammaire
        } catch (RecognitionException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
