/**
 * <b>Package contenant les différentes classes représentants les stratégies d'initialisation du plateau de jeu.</b>
 * 
 * @see InitGridStrategy
 * @see InitGridStrategyA
 * @see InitGridStrategyB
 * @see InitGridStrategyC
 * 
 * @author Melvin Lucchini, Steven Martin, Antoine Morlay, Ahouefa Zounon
 * @version 1.0
 */
package fr.gameProject.game.model.initGridStrategies;