package fr.gameProject.game.model.grids;

import java.util.ArrayList;
import java.util.List;

import fr.gameProject.game.model.initGridStrategies.InitGridStrategy;
import fr.gameProject.game.model.initGridStrategies.InitGridStrategyA;
import fr.gameProject.game.model.players.Player;
import fr.gameProject.game.model.weapons.Bomb;
import fr.gameProject.game.model.weapons.Weapon;
import fr.gameProject.util.AbstractModelListenable;

/**
 * <b>GridConcrete est une classe concrète représentant une grille de jeu.</b>
 * <p>Elle est écoutable et implémente l'interface {@link Grid}.</p>
 * 
 * @see InitGridStrategy
 * @see Player
 * @see Weapon
 * @see AbstractModelListenable
 * 
 * @author Melvin Lucchini, Steven Martin, Antoine Morlay, Ahouefa Zounon
 * @version 1.0
 */
public class GridConcrete extends AbstractModelListenable implements Grid{

    /**La portée d'un tir */
    private final int DISTANCE = 5;
    
    /**La stratégie d'initialisation du plateau de jeu */
    private InitGridStrategy initStrat;

    /**Le plateau de jeu */
    private Case[][] board;

    /**La liste des différents joueurs du jeu */
    private ArrayList<Player> players;

    /**La taille du plateau */
    private int tail;

    /**
     * Constructeur
     * 
     * @param tail -- la taille du plateau de jeu
     */
    public GridConcrete(int tail)
    {
        this.initStrat = new InitGridStrategyA();
        this.tail = tail;
        this.board = new Case[tail][tail];

        for(int i = 0 ; i < this.tail ; i++)
        {
            for(int j = 0 ; j < this.tail ; j++)
            {
                this.board[i][j] = new Case(i, j);
            }
        }

        this.players = new ArrayList<Player>();
    }

//Méthodes héritées ****** METHODES DE BASE
    /**Initialise le plateau de jeu selon la stratégie utilisée */
    @Override
    public void init()
    {
        this.initStrat.init(this);
    }

    @Override
    public void addPlayer(Player p)
    {
        this.players.add(p);
    }

    @Override
    public boolean isOver()
    {
        if(this.getAlivePlayers().size() == 1)
        	return true;

        return false;
    }
    
    @Override
    public void playerPlayed(Player p, int action)
    {
    	switch(action)
    	{
    		case 1:
    			//Le player de déplace
    			this.playerMoved(p, p.move());
    			break;
    		case 2:
    			//Le player tire dans une direction
    			this.playerShot(p.getCurrentCase(), p.shot());
    			break;
    		case 3:
    			//Le player dépose une arme
    			this.playerPutWeapon(p.putWeapon());
    			break;
    		case 4:
    			//Le player prend son bouclier
    			p.takeShield();
    			break;
    		case 5:
    			//Le player ne fait rien
    			p.doNothing();
    			break;
    		default:
    			//Le player ne fait rien
    			p.doNothing();
    			break;
    			//throw new IllegalStateException("Action invalide: " + action);
    	}
    }

    @Override
    public String actionToString(Player p, int action) {
        String string = "";

        switch(action) {
            case 1:
                string = string + "player" + p.getPlayerID() + " s'est déplacer";
                break;

            case 2:
                string = string + "player" + p.getPlayerID() + " a tirer";
                break;

            case 3:
                string = string + "player" + p.getPlayerID() + " a poser une mine ou une bombe";
                break;

            case 4:
                string = string + "player" + p.getPlayerID() + " a pris son bouclier";
                break;

            case 5:
                string = string + "player" + p.getPlayerID() + " n'a rien fait";
                break;

            default:
                string = string + "player" + p.getPlayerID() + " n'a rien fait";
                break;
        }

        return string;
    }

    @Override
    public void playerMoved(Player p, Case c)
    {
        if(c != null)
        {
            //Changer la case courante du joueur
            this.board[p.getCurrentCase().getLine()][p.getCurrentCase().getCol()].removePlayer(p);
            p.setCurrentCase(this.board[c.getLine()][c.getCol()]); //La nouvelle place du joueur
            this.board[c.getLine()][c.getCol()].addPlayer(p);
        	
        	if( (this.board[c.getLine()][c.getCol()].getWeapon() != null) && (!this.board[c.getLine()][c.getCol()].getWeapon().getPlayer().equals(p)) )
        		this.board[c.getLine()][c.getCol()].damaged();
        	
        	if(this.board[c.getLine()][c.getCol()].getEnergyPellet())
            {
            	p.addEnergy();
            	this.board[c.getLine()][c.getCol()].removeEnergyPellet();
            }
        	
        	this.fireChangement();
        }
    }

    @Override
    public void playerShot(Case c, boolean direct)
    {
        if(c != null)
        {
            //true - tir horizontal ; false - tir vertical
            if(direct)
            {
                //Toutes les cases dans c-this.DISTANCE et c+this.DISTANCE
                for(int i = 1 ; i < this.DISTANCE ; i++)
                { 
                    if( (c.getCol()-i) >= 0 )
                    {
                        if(!c.isWall())
                            this.board[c.getLine()][c.getCol()-i].damaged();
                        else
                            break;
                    }
                }

                for(int i = 1 ; i < this.DISTANCE ; i++)
                { 
                    if( (c.getCol()+i) <= (this.tail-1) )
                    {
                        if(!c.isWall())
                            this.board[c.getLine()][c.getCol()+i].damaged();
                        else
                            break;
                    }
                }
            }

            else //false - tir vertical
            {
                //Toutes les cases dans l-this.DISTANCE et l+this.DISTANCE
                for(int i = 1 ; i < this.DISTANCE ; i++)
                { 
                    if( (c.getLine()-i) >= 0 )
                    {
                        if(!c.isWall())
                            this.board[c.getLine()-i][c.getCol()].damaged();
                        else
                            break;
                    }
                }

                for(int i = 1 ; i < this.DISTANCE ; i++)
                { 
                    if( (c.getLine()+i) <= (this.tail-1) )
                    {
                        if(!c.isWall())
                            this.board[c.getLine()+i][c.getCol()].damaged();
                        else
                            break;
                    }
                }
            }

            this.fireChangement();
        }
    }

    @Override
    public void playerPutWeapon(List<Object> vals)
    {
        if( (vals != null) && (vals.size() == 2) )
        {
        	Case c = (Case)vals.get(0);
        	Weapon arm = (Weapon)vals.get(1);
        	
        	if(c != null)
	        {
	        	this.board[c.getLine()][c.getCol()].setWeapon(arm);
	        	if(this.board[c.getLine()][c.getCol()].getPlayers().size() != 0)
	        		this.board[c.getLine()][c.getCol()].damaged();
	        	
	        	this.fireChangement();
	        }
        }
    }

    @Override
    public void bombExplose(Case c)
    { 	
    	if(c != null)
    	{
	    	//on parcourt les 8 cases autour et on fait un damaged()
	        Case top = null, left = null, right = null, bottom = null;
	        Case topLeft = null, topRight = null, bottomLeft = null, bottomRight = null;
	        
	        if(c.getLine() != 0)
	            top = this.board[c.getLine()-1][c.getCol()];
	        if(c.getCol() != 0)
	            left = this.board[c.getLine()][c.getCol()-1];
	        if(c.getCol() != (this.tail-1))
	            right = this.board[c.getLine()][c.getCol()+1];
	        if(c.getLine() != (this.tail-1))
	            bottom = this.board[c.getLine()+1][c.getCol()];
	        
	        if( (c.getLine() != 0) && (c.getCol() != 0) )
	            topLeft = this.board[c.getLine()-1][c.getCol()-1];
	        if( (c.getLine() != 0) && (c.getCol() != (this.tail-1)) )
	            topRight = this.board[c.getLine()-1][c.getCol()+1];
	        if( (c.getLine() != (this.tail-1)) && (c.getCol() != 0) )
	            bottomLeft = this.board[c.getLine()+1][c.getCol()-1];
	        if( (c.getLine() != (this.tail-1)) && (c.getCol() != (this.tail-1)) )
	            bottomRight = this.board[c.getLine()+1][c.getCol()+1];
	
	        if( (top != null) && (!top.isWall()) )
	            top.damaged();
	        if( (left != null) && (!left.isWall()) )
	            left.damaged();
	        if( (right != null) && (!right.isWall()) )
	            right.damaged();
	        if( (bottom != null) && (!bottom.isWall()) )
	            bottom.damaged();
	        
	        if( (topLeft != null) && (!topLeft.isWall()) )
	            topLeft.damaged();
	        if( (topRight != null) && (!topRight.isWall()) )
	            topRight.damaged();
	        if( (bottomLeft != null) && (!bottomLeft.isWall()) )
	            bottomLeft.damaged();
	        if( (bottomRight != null) && (!bottomRight.isWall()) )
	            bottomRight.damaged();
	        
	        this.board[c.getLine()][c.getCol()].setWeapon(null); //On retire l'arme sur la case
	        this.fireChangement();
    	}
    }
    
    /**Vide le plateau de jeu */
    public void emptyBoard()
    {
    	for(int i = 0 ; i < this.tail ; i++)
        {
            for(int j = 0 ; j < this.tail ; j++)
            {
                this.board[i][j].empty();
            }
        }
    }
    
    @Override
    public ArrayList<Bomb> bombs()
    {
    	ArrayList<Bomb> bombs = new ArrayList<Bomb>();
    	
    	for(int i = 0 ; i < this.tail ; i++)
        {
            for(int j = 0 ; j < this.tail ; j++)
            {
                Weapon weapon = this.board[i][j].getWeapon();
            	if( (weapon != null) && (weapon instanceof Bomb) )
                	bombs.add((Bomb) this.board[i][j].getWeapon());
            }
        }
    	
    	return bombs;
    }

//Méthodes ****** GETTERS ET SETTERS
    @Override
    public int getTail()
    {
        return this.tail;
    }

    @Override
    public ArrayList<Player> getPlayers()
    {
        return this.players;
    }
    
    @Override
    public ArrayList<Player> getAlivePlayers()
    {
    	/**La liste des différents joueurs encore vivants sur le plateau */
        ArrayList<Player> alivePlayers = new ArrayList<Player>();
    	
    	for(Player p : this.players)
        {
        	if(!p.isDead())
        		alivePlayers.add(p);
        	else //Si le joueur est mort, on le retire de la case qu'il occupe
        	{
        		Case c = p.getCurrentCase();
        		if(c != null)
        			c.removePlayer(p);
        		p.setCurrentCase(null);
        		
        		this.fireChangement();
        	}
        }
    	
    	return alivePlayers;
    } 

    /**
     * Définit la stratégie d'initialisation du plateau de jeu
     * 
     * @param initStrat -- la nouvelle stratégie d'initialisation du plateau de jeu
     */
    public void setInitStrategy(InitGridStrategy initStrat)
    {
        this.initStrat = initStrat;
    }

//Méthodes ****** METHODES HERITEES
    @Override
    public Case[][] getBoard()
    {
        return this.board;
    }

    //Méthode toString()
    @Override
    public String toString()
    {
        String str = "";

        for(int i = 0 ; i < this.tail ; i++)
        {
            for(int j = 0 ; j < this.tail ; j++)
            {
                if(j != (this.tail - 1) )
                    str += " " + this.board[i][j].toString() + " |";
                else
                    str += " " + this.board[i][j].toString();
            }

            str += "\n";
        }
        
        return str;
    }
}
