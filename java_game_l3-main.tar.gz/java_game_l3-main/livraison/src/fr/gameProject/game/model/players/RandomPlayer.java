package fr.gameProject.game.model.players;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import fr.gameProject.game.model.grids.Case;
import fr.gameProject.game.model.weapons.Weapon;

/**
 * <b>RandomPlayer est une classe qui représente un type de joueur concret.</b>
 * <p>
 * Elle permet de créer un joueur qui agit "aléatoirement".<br>
 * Elle hérite de la classe abstraite {@link Player}.
 * </p>
 * 
 * @see Case
 * @see Weapon
 * 
 * @author Melvin Lucchini, Steven Martin, Antoine Morlay, Ahouefa Zounon
 * @version 1.0
 */
public class RandomPlayer extends Player{

    /**Permet d'avoir un comportement pseudo-aléatoire */
    private Random random = new Random();

    /**
     * Constructeur de base
     * 
     * @param name -- le nom du joueur
     */
    public RandomPlayer(String name)
    {
        super(name);
    }

    /**
     * Constructeur permettant de définir les valeurs des attributs d'un Player
     * 
     * @param name -- le nom du joueur
     * @param energy -- l'énergie du joueur
     * @param munitions -- le nombre de munitions du joueur
     * @param nbrWeapons -- le nombre d'armes du joueur
     */
    public RandomPlayer(String name, int energy, int munitions, int nbrWeapons)
    {
        super(name, energy, munitions, nbrWeapons);
    }

//Méthodes ****** FACTORY METHODS
    /**
     * Un RandomPlayer avec un nom et une énergie définis
     * 
     * @param name -- le nom du joueur
     * @param e -- l'énergie
     * @return un joueur avec un nom et une énergie définis
     */
    public static RandomPlayer createRPfromNameEnergy(String name, int e)
    {
        return new RandomPlayer(name, e, Player.MUNITION, Player.ARMS);
    }

    /**
     * Un RandomPlayer avec un nom et un nombre de munitions définis
     * 
     * @param name -- le nom du joueur
     * @param m -- le nombre de munitions du joueur
     * @return un joueur avec un nom et un nombre de munitions définis
     */
    public static RandomPlayer createRPfromNameMunition(String name, int m)
    {
        return new RandomPlayer(name, Player.ENERGY, m, Player.ARMS);
    }

    /**
     * Un RandomPlayer avec un nom et un nombre d'armes définis
     * 
     * @param name -- le nom du joueur
     * @param w -- le nombre d'armes du joueur
     * @return un joueur avec un nom et un nombre d'armes définis
     */
    public static RandomPlayer createRPfromNameWeapon(String name, int w)
    {
        return new RandomPlayer(name, Player.ENERGY, Player.MUNITION, w);
    }

    /**
     * Un RandomPlayer avec un nom, une énergie et un nombre de munitions définis
     * 
     * @param name -- le nom du joueur
     * @param e -- l'énergie du joueur
     * @param m -- le nombre de munitions du joueur
     * @return un joueur avec un nom, une énergie et un nombre de munitions définis
     */
    public static RandomPlayer createRPfromNameEnergyMunition(String name, int e, int m)
    {
        return new RandomPlayer(name, e, m, Player.ARMS);
    }

    /**
     * Un RandomPlayer avec un nom, une énergie et un nombre d'armes définis
     * 
     * @param name -- le nom du joueur
     * @param e -- l'énergie du joueur
     * @param w -- le nombre d'armes du joueur
     * @return un joueur avec un nom, une énergie et un nombre d'armes définis
     */
    public static RandomPlayer createRPfromNameEnergyWeapon(String name, int e, int w)
    {
        return new RandomPlayer(name, e, Player.MUNITION, w);
    }

    /**
     * Un RandomPlayer avec un nom, un nombre de munitions et un nombre d'armes définis
     * 
     * @param name -- le nom du joueur
     * @param m -- le nombre de munitions du joueur
     * @param w -- le nombre d'armes du joueur
     * @return un joueur avec un nom, un nombre de munitions et un nombre d'armes définis
     */
    public static RandomPlayer createRPfromNameMunitionWeapon(String name, int m, int w)
    {
        return new RandomPlayer(name, Player.ENERGY, m, w);
    }

//Méthodes ****** METHODES HERITEES

    @Override
    public Case move()
    {
        if(this.grid != null)
        {
            if(this.currentCase != null)
            {
                Case top = null, left = null, right = null, bottom = null;
                
                if(this.currentCase.getLine() != 0)
                    top = this.grid.getBoard()[this.currentCase.getLine()-1][this.currentCase.getCol()];
                if(this.currentCase.getCol() != 0)
                    left = this.grid.getBoard()[this.currentCase.getLine()][this.currentCase.getCol()-1];
                if(this.currentCase.getCol() != (this.grid.getTail()-1))
                    right = this.grid.getBoard()[this.currentCase.getLine()][this.currentCase.getCol()+1];
                if(this.currentCase.getLine() != (this.grid.getTail()-1))
                    bottom = this.grid.getBoard()[this.currentCase.getLine()+1][this.currentCase.getCol()];

                ArrayList<Case> direct = new ArrayList<Case>();
                if( (top != null) && (!top.isWall()) )
                    direct.add(top);
                if( (left != null) && (!left.isWall()) )
                    direct.add(left);
                if( (right != null) && (!right.isWall()) )
                    direct.add(right);
                if( (bottom != null) && (!bottom.isWall()) )
                    direct.add(bottom);
                
                if(direct.size() != 0)
                {
                    this.energy -= 5; //Baisser l'énergie de 5xp pour le déplacement                    
                    return direct.get(random.nextInt(direct.size())); //La case du joueur change
                }
            }
        }
        
        return null;
    }

    @Override
    public List<Object> putWeapon()
    {
        if(this.weapons.size() != 0) //S'il a des armes
        {
	    	if(this.grid != null)
	        {
	            if(this.currentCase != null)
	            {
	                Case top = null, left = null, right = null, bottom = null;
	                Case topLeft = null, topRight = null, bottomLeft = null, bottomRight = null;	
	                
	                if(this.currentCase.getLine() != 0)
	                    top = this.grid.getBoard()[this.currentCase.getLine()-1][this.currentCase.getCol()];
	                if(this.currentCase.getCol() != 0)
	                    left = this.grid.getBoard()[this.currentCase.getLine()][this.currentCase.getCol()-1];
	                if(this.currentCase.getCol() != (this.grid.getTail()-1))
	                    right = this.grid.getBoard()[this.currentCase.getLine()][this.currentCase.getCol()+1];
	                if(this.currentCase.getLine() != (this.grid.getTail()-1))
	                    bottom = this.grid.getBoard()[this.currentCase.getLine()+1][this.currentCase.getCol()];
	                
	                if( (this.currentCase.getLine() != 0) && (this.currentCase.getCol() != 0) )
	                    topLeft = this.grid.getBoard()[this.currentCase.getLine()-1][this.currentCase.getCol()-1];
	                if( (this.currentCase.getLine() != 0) && (this.currentCase.getCol() != (this.grid.getTail()-1)) )
	                    topRight = this.grid.getBoard()[this.currentCase.getLine()-1][this.currentCase.getCol()+1];
	                if( (this.currentCase.getLine() != (this.grid.getTail()-1)) && (this.currentCase.getCol() != 0) )
	                    bottomLeft = this.grid.getBoard()[this.currentCase.getLine()+1][this.currentCase.getCol()-1];
	                    if( (this.currentCase.getLine() != (this.grid.getTail()-1)) && (this.currentCase.getCol() != (this.grid.getTail()-1)) )
	                    bottomRight = this.grid.getBoard()[this.currentCase.getLine()+1][this.currentCase.getCol()+1];
	
	                ArrayList<Case> direct = new ArrayList<Case>();
	                if( (top != null) && (!top.isWall()) && (top.getWeapon() == null) )
	                    direct.add(top);
	                if( (left != null) && (!left.isWall()) && (left.getWeapon() == null) )
	                    direct.add(left);
	                if( (right != null) && (!right.isWall()) && (right.getWeapon() == null) )
	                    direct.add(right);
	                if( (bottom != null) && (!bottom.isWall()) && (bottom.getWeapon() == null) )
	                    direct.add(bottom);
	                
	                if( (topLeft != null) && (!topLeft.isWall()) && (topLeft.getWeapon() == null) )
	                    direct.add(topLeft);
	                if( (topRight != null) && (!topRight.isWall()) && (topRight.getWeapon() == null) )
	                    direct.add(topRight);
	                if( (bottomLeft != null) && (!bottomLeft.isWall()) && (bottomLeft.getWeapon() == null) )
	                    direct.add(bottomLeft);
	                if( (bottomRight != null) && (!bottomRight.isWall()) && (bottomRight.getWeapon() == null) )
	                    direct.add(bottomRight);
	                
	                if(direct.size() != 0)
	                {
	                    Weapon arm = this.weapons.get(random.nextInt(this.weapons.size())); //Choisir l'arme à déposer sur la case
	                    Case c = direct.get(random.nextInt(direct.size())); //Choisir l'une des cases voisines libres et y mettre l'arme
	                    this.weapons.remove(arm);
	                    
	                    return Arrays.asList(c, arm);
	                }
	            }
	        }
        }
        return null;
    }

    @Override
    public boolean shot()
    {
        //Tirer horizontalement(true) ou verticalement(false)
        return random.nextBoolean();
    }
}
