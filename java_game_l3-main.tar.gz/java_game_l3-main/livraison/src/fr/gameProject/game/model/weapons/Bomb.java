package fr.gameProject.game.model.weapons;

import fr.gameProject.game.model.players.Player;

/**
 * <b>Bomb est une classe qui représente un type d'arme concret.</b>
 * <p>Elle hérite de la classe abstraite {@link Weapon}.</p>
 * 
 * @author Melvin Lucchini, Steven Martin, Antoine Morlay, Ahouefa Zounon
 * @version 1.0
 */
public class Bomb extends Weapon{
    
    /**Le temps au bout duquel la bombe explose */
    private int countdownTime;

    /**
     * Constructeur 
     * 
     * @param p -- le joueur à qui appartient l'arme
     */
    public Bomb(Player p)
    {
        super(p);
        this.countdownTime = 3; //Au bout de 3 tours de jeu
    }
    
//Méthodes de base
    /**Permet de décompter le temps avant l'explosion */
    public void countdown()
    {
    	this.countdownTime --;
    }

//Méthodes ****** GETTERS ET SETTERS
    /**
     * Retourne le temps restant avant l'explosion de la bombe
     * 
     * @return le temps restant
     */
    public int getCountdownTime()
    {
        return this.countdownTime;
    }

//Méthode héritées ****** Méthode toString()
    @Override
    public String toString()
    {
        return "◖";
    }
}
