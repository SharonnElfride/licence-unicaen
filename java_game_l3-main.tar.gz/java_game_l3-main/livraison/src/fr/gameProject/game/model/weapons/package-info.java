/**
 * <b>Package contenant les différentes classes représentants les armes des joueurs du jeu.</b>
 * 
 * @see Weapon
 * @see Bomb
 * @see Mine
 * 
 * @author Melvin Lucchini, Steven Martin, Antoine Morlay, Ahouefa Zounon
 * @version 1.0
 */
package fr.gameProject.game.model.weapons;