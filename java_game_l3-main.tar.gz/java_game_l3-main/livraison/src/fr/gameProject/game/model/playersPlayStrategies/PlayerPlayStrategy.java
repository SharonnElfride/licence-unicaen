package fr.gameProject.game.model.playersPlayStrategies;

import fr.gameProject.game.model.players.Player;

/**
 * <b>PlayerPlayStrategy est l'interface représentant une stratégie de jeu d'un joueur.</b>
 * <p>Toute stratégie de jeu d'un joueur doit l'implémenter.</p>
 * 
 * @see Player
 * @see PlayerPlayBasicStrategy
 * @see PlayerPlayAdvancedStrategy
 * 
 * @author Melvin Lucchini, Steven Martin, Antoine Morlay, Ahouefa Zounon
 * @version 1.0
 */
public interface PlayerPlayStrategy {
    
    /**
     * L'action du joueur
     * 
     * @param p -- le joueur qui joue
     * @return l'action du joueur
     */
    int action(Player p);
}
