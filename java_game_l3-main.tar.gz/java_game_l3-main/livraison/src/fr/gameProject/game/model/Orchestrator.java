package fr.gameProject.game.model;

import fr.gameProject.game.model.grids.Grid;
import fr.gameProject.game.model.players.Player;
import fr.gameProject.game.view.ViewGrid;

/**
 * <b>Orchestrator est la classe permettant de gérer un tour de jeu.</b>
 * 
 * @see Grid
 * @see Player
 * @see ViewGrid
 * 
 * @author Melvin Lucchini, Steven Martin, Antoine Morlay, Ahouefa Zounon
 * @version 1.0
 *
 */
public class Orchestrator {
    
    /**La grille du plateau de jeu actuel */
    private Grid g;
    
    /**
     * Constructeur
     * 
     * @param g -- La grille de jeu
     */
    public Orchestrator(Grid g)
    {
        this.g = g;
    }

    /**
     * Représente un tour de jeu
     * 
     * @param currentPlayer -- Le joueur courant qui doit jouer
     */
    public void play(Player currentPlayer) {
    	this.g.playerPlayed(currentPlayer, currentPlayer.action());
    	
    	//En commentant cette partie du code, décommenter la ligne de code dans modelUpdate de ViewGrid
    	/**/
    	ViewGrid viewPlayer = new ViewGrid(currentPlayer.getGrid());
    	System.out.println("\nGRILLE DU " + currentPlayer.toString().toUpperCase());
		viewPlayer.display();
    	/**/
		
		if (this.g.isOver())
		{
			ViewGrid view = new ViewGrid(this.g);
	        System.out.println("\nGRILLE FINALE");
			view.display();
			
			System.out.println("Vainqueur: " + this.g.getAlivePlayers().get(0).toString());
		}
	}
}
