package fr.gameProject.game.model.players;

import java.util.ArrayList;
import java.util.List;

import fr.gameProject.game.model.grids.Case;
import fr.gameProject.game.model.grids.Grid;
import fr.gameProject.game.model.playersPlayStrategies.PlayerPlayBasicStrategy;
import fr.gameProject.game.model.playersPlayStrategies.PlayerPlayStrategy;
import fr.gameProject.game.model.weapons.Bomb;
import fr.gameProject.game.model.weapons.Mine;
import fr.gameProject.game.model.weapons.Weapon;

/**
 * <b>Player est la classe représentant un joueur.</b>
 * <p>Tout type de joueur doit en hériter.</p>
 * 
 * @see RandomPlayer
 * @see Case
 * @see Grid
 * @see PlayerPlayStrategy
 * @see Weapon
 * 
 * @author Melvin Lucchini, Steven Martin, Antoine Morlay, Ahouefa Zounon
 * @version 1.0
 */
public abstract class Player {
	
	 	/**Le nombre de joueurs crées */
		protected static int nbrePlayers = 0;
		/**L'énergie de départ d'un joueur dans les paramètres du jeu */
	    protected final static int ENERGY = 100;
	    /**Le nombre de munitions dont dispose initialement un joueur dans les paramètres du jeu */
	    protected final static int MUNITION = 20;
	    /**Le nombre d'armes dont dispose initialement un joueur dans les paramètres du jeu */
	    protected final static int ARMS = 10;
	    
	    /**L'identifiant du joueur */
	    protected int playerID;

	    /**L'énergie d'un joueur */
	    protected int energy;

	    /**Les différentes armes d'un joueur */
	    protected ArrayList<Weapon> weapons;

	    /**Le nombre de munitions d'un joueur */
	    protected int munitions;

	    /**Le nom du joueur */
	    protected String name;

	    /**Le bouclier du joueur */
	    protected boolean shield;

	    /**La grille de jeu */
	    protected Grid grid;

	    /**La case dans laquelle le joueur est positionné */
	    protected Case currentCase;
	    
	    /**La stratégie de jeu d'un joueur -- De base, c'est la stratégie basique */
	    protected PlayerPlayStrategy playStrat;
	    
	    /**
	     * Constructeur de base
	     * 
	     * @param name -- le nom du joueur
	     */
	    public Player(String name)
	    {
	        this.name = name;
	        this.energy = Player.ENERGY;
	        this.munitions = Player.MUNITION;
	        this.weapons  = new ArrayList<Weapon>();

	        for(int i = 0 ; i < Player.ARMS ; i++)
	        {
	            if(i == (Player.ARMS / 2))
	                this.weapons.add(new Bomb(this));
	            else
	                this.weapons.add(new Mine(this));
	        }

	        this.shield = false;
	        this.grid = null;
	        this.currentCase = null;
	        this.playStrat = new PlayerPlayBasicStrategy();
	        
	        Player.nbrePlayers++;
	        this.playerID = Player.nbrePlayers;
	    }

	    /**
	     * Constructeur permettant de définir les valeurs des attributs d'un Player
	     * 
	     * @param name -- le nom du joueur
	     * @param energy -- l'énergie du joueur
	     * @param munitions -- le nombre de munitions du joueur
	     * @param nbrWeapons -- le nombre d'armes du joueur
	     */
	    public Player(String name, int energy, int munitions, int nbrWeapons)
	    {
	        this.name = name;
	        this.energy = energy;
	        this.munitions = munitions;
	        this.weapons  = new ArrayList<Weapon>();

	        //middle définit le nombre initial de mines et de bombes
	        //Le nombre de mines et de bombes est le même initialement, mais si le nombre d'armes demandé est impair, il y a une bombe en plus.
	        int middle = nbrWeapons / 2;
	        if( (nbrWeapons%2) != 0)
	            middle = (nbrWeapons - 1) / 2;

	        for(int i = 0 ; i < nbrWeapons ; i++)
	        {
	            if(i == middle)
	                this.weapons.add(new Bomb(this));
	            else
	                this.weapons.add(new Mine(this));
	        }

	        this.shield = false;
	        this.grid = null;
	        this.currentCase = null;
	        this.playStrat = new PlayerPlayBasicStrategy();
	        
	        Player.nbrePlayers++;
	        this.playerID = Player.nbrePlayers;
	    }

//******* Méthodes à redéfinir pour chaque type de player **************************
    /**
     * Déplacer le joueur sur l'une des 4 cases voisines
     * Gauche [l][c-1], Droite [l][c+1], Haute [l-1][c], Basse [l+1][c]
     * 
     * @return la case dans laquelle le joueur se déplace
     */
    public abstract Case move();

    /**
     * Poser une arme(mine ou bombe) sur l'une des 8 cases voisines
     * Gauche [l][c-1], Droite [l][c+1], Haute [l-1][c], Basse [l+1][c]
     * Haute gauche [l-1][c-1], Haute droite [l-1][c+1], Basse gauche [l+1][c-1], Basse droite [l+1][c+1]
     * 
     * @return la liste composée de la case dans laquelle le joueur pose l'arme et de l'arme à poser
     */
    public abstract List<Object> putWeapon();

    /**
     * La direction dans laquelle le joueur tire
     * Tirer horizontalement(true) ou verticalement(false)
     * 
     * @return {@code true} horizontalement et {@code false} verticalement
     */
    public abstract boolean shot();
    
//Méthodes de base ****** METHODES PARTAGEES PAR TOUS LES PLAYERS

    /**
     * Détermine si le joueur est mort ou pas === s'il a encore de l'énergie ou pas
     * 
     * @return {@code truie} si le joueur est mort et {@code false} sinon.
     */
    public boolean isDead()
    {
    	return (this.energy <= 0);
    }
    
    /**Appelée si le joueur est touché par un tir ou une explosion */
    public void getHurt()
    {
        if(!this.shield)
            this.energy -= 10;
    }

    /**Matérialise le fait que le joueur a de prendre son bouclier */
    public void takeShield()
    {
        this.shield = true;
        this.energy -= 2;
    }

    /**Matérialise le fait que le joueur a de déposer son bouclier */
    public void takeOffShield()
    {
        this.shield = false;
    }

    /**Appelée lorsque le joueur décide de ne rien faire */
    public void doNothing(){ ;}

    /**Appelée lorsqu'un joueur se pose sur une case où il y a une pastille d'énergie */
    public void addEnergy()
    {
        //On incrémente l'énergie du player de 3
        this.energy += 3;
    }
    
    /**
     * L'action du joueur
     * 
     * @return l'action du joueur
     */
    public int action()
    {
    	return this.playStrat.action(this);
    }
    
    @Override
    public String toString()
    {
    	return "Joueur " + this.playerID + " : " + this.name + ", " + this.energy + "xp";
    }
    
    @Override
    public boolean equals(Object player)
    {
    	return ( (this.playerID == ((Player) player).getPlayerID()) && (this.name.equals(((Player) player).getName())) );
    }
    
//Méthodes ****** GETTERS ET SETTERS
    
    /**
     * Retourne le numéro du joueur
     * 
     * @return l'identifiant du joueur
     */
    public int getPlayerID() {
		return this.playerID;
	}
    
    /**
     * Retourne le nom du joueur
     * 
     * @return le nom du joueur
     */
    public String getName()
    {
        return this.name;
    }

    /**
     * L'énergie du joueur
     * 
     * @return l'énergie du joueur
     */
    public int getEnergy()
    {
        return this.energy;
    }

    /**
     * Retourne le nombre de munitions du joueur
     * 
     * @return le nombre de munitions du joueur
     */
    public int getMunitions()
    {
        return this.munitions;
    }

    /**
     * Retourne la liste des armes du joueur
     * 
     * @return la liste des armes du joueur
     */
    public ArrayList<Weapon> getWeapons()
    {
        return this.weapons;
    }

    /**
     * Détermine si le joueur a son bouclier ou pas
     * 
     * @return {@code true} si le joueur a son bouclier et {@code false} sinon.
     */
    public boolean getShield()
    {
        return this.shield;
    }

    /**
     * Retourne la grille de jeu que voit le joueur
     * 
     * @return la grille de jeu du joueur
     */
    public Grid getGrid()
    {
        return this.grid;
    }

    /**
     * Retourne la case dans laquelle le joueur se trouve
     * 
     * @return la case courante du joueur
     */
    public Case getCurrentCase()
    {
        return this.currentCase;
    }
    
    /**
     * Retourne la stratégie de jeu du joueur
     * 
     * @return la stratégie de jeu du joueur
     */
    public PlayerPlayStrategy getPlayerPlayStrategy()
    {
    	return this.playStrat;
    }

    /**
     * Modifie la grille de jeu du joueur
     * 
     * @param g -- la nouvelle grille de jeu du joueur
     */
    public void setGrid(Grid g)
    {
        this.grid = g;
    }

    /**
     * Modifie la case courante du joueur
     * 
     * @param c -- la nouvelle case du joueur
     */
    public void setCurrentCase(Case c)
    {
        this.currentCase = c;
    }
    
    /**
     * Modifie la stratégie de jeu du joueur
     * 
     * @param playStrat -- la nouvelle stratégie de jeu du joueur
     */
    public void setPlayerPlayStrategy(PlayerPlayStrategy playStrat)
    {
    	this.playStrat = playStrat;
    }
}
