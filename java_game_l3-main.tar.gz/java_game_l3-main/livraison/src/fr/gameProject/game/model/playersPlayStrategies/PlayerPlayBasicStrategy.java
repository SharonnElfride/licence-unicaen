package fr.gameProject.game.model.playersPlayStrategies;

import java.util.Random;

import fr.gameProject.game.model.players.Player;

/**
 * <b>PlayerPlayBasicStrategy représente une stratégie basique de jeu d'un joueur.</b>
 * <p>
 * Elle permet au joueur de jouer de façon aléatoire. L'action est choisie aléatoirement.<br>
 * Elle implémente l'interface {@link PlayerPlayStrategy}.
 * </p>
 *
 * @see Player
 * 
 * @author Melvin Lucchini, Steven Martin, Antoine Morlay, Ahouefa Zounon
 * @version 1.0
 */
public class PlayerPlayBasicStrategy implements PlayerPlayStrategy {

	@Override
	public int action(Player p) {
		//Choisir aléatoirement entre 1 et 5. A chaque chiffre correspond une méthode de base d'un Player
		//1 ==> Se déplacer
		//2 ==> Tirer
		//3 ==> Poser une arme
		//4 ==> Prendre le bouclier
		//5 ==> Ne rien faire
		Random random = new Random();
		
		return (1+random.nextInt(5));
	}

}
