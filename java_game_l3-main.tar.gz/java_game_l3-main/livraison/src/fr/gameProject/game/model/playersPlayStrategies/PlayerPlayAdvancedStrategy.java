package fr.gameProject.game.model.playersPlayStrategies;

import java.util.Arrays;
import java.util.Random;

import fr.gameProject.game.model.grids.Case;
import fr.gameProject.game.model.players.Player;

/**
 * <b>PlayerPlayAdvancedStrategy représente une stratégie un peu plus réfléchie de jeu d'un joueur.</b>
 * <p>
 * Elle permet au joueur de jouer un peu plus subilement.<br>
 * Elle implémente l'interface {@link PlayerPlayStrategy}.
 * </p>
 * 
 * @see Case
 * @see Player
 * 
 * @author Melvin Lucchini, Steven Martin, Antoine Morlay, Ahouefa Zounon
 * @version 1.0
 */
public class PlayerPlayAdvancedStrategy implements PlayerPlayStrategy {

	@Override
	public int action(Player p) {
		//Essayer d'être intelligent
		//En premier, choisir entre faire qlq chose et ne rien faire en fonction du niveau d'énergie
		//Puis, choisir quoi faire en fonction de la position des autres joueurs, si on a assez d'énergie
		//1 ==> Se déplacer
		//2 ==> Tirer
		//3 ==> Poser une arme
		//4 ==> Prendre le bouclier
		//5 ==> Ne rien faire
		
		Random random = new Random();

		if(p.getEnergy() < 10)
		{
			if(p.getEnergy() <= 5)
				return 5;
			else
				return 4;
		}
	
		else
		{
			//La position du joueur p qu'on utilisera pour trouver le player le plus proche de lui
			int pos = p.getCurrentCase().getLine() * p.getGrid().getTail();
			//La distance entre la position du joueur p et celle d'un autre joueur
			int distance = 100;
			Player closestPlayer = null;
			
			//Les positions des autres joueurs
			for(Player player : p.getGrid().getAlivePlayers())
			{
				int currentPos = player.getCurrentCase().getLine() * p.getGrid().getTail();
				if(distance <= (pos-currentPos) )
					closestPlayer = player;
			}			
			
			//On agit sur le joueur "le plus proche"
			if(closestPlayer != null)
			{
				Case c = closestPlayer.getCurrentCase();
				if(c.getLine() == p.getCurrentCase().getLine()) //Sur la même ligne
				{
					if(c.getCol() != p.getCurrentCase().getCol()) //Sur la même ligne mais sur une colonne différente
					{
						//Si le player est sur la case à gauche ou à droite
						if( (c.getCol() == (p.getCurrentCase().getCol() - 1)) || (c.getCol() == (p.getCurrentCase().getCol() + 1)) )
						{
							//Case et l'arme
							if(p.getWeapons().size() != 0)
								p.getGrid().playerPutWeapon(Arrays.asList(closestPlayer.getCurrentCase(), p.getWeapons().get(random.nextInt(p.getWeapons().size()))));
						}
						
						else
							p.getGrid().playerShot(p.getCurrentCase(), true);
						
						return 5; //Pour que le joueur ne fasse rien
					}
				}
				
				else //Sur une ligne différente
				{
					if(c.getCol() == p.getCurrentCase().getCol()) //Sur une ligne différente et sur la même colonne
					{
						//Si le player est sur la case du haut ou du bas
						if( (c.getLine() == (p.getCurrentCase().getLine() - 1)) || (c.getLine() == (p.getCurrentCase().getLine() + 1)) )
						{
							//Case et l'arme
							if(p.getWeapons().size() != 0)
								p.getGrid().playerPutWeapon(Arrays.asList(closestPlayer.getCurrentCase(), p.getWeapons().get(random.nextInt(p.getWeapons().size()))));
						}
						
						else
							p.getGrid().playerShot(p.getCurrentCase(), true);
						
						return 5; //Pour que le joueur ne fasse rien
					}
				}
			}
			
			//Essayer de voir le cas où si on est sur la même ligne/col qu'un joueur, prendre le bouclier
			
			return 1 + random.nextInt(5);
		}
	}

}
