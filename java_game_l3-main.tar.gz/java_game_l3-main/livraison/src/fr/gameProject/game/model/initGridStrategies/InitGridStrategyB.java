package fr.gameProject.game.model.initGridStrategies;

import java.util.Random;

import fr.gameProject.game.model.grids.Case;
import fr.gameProject.game.model.grids.GridConcrete;
import fr.gameProject.game.model.players.Player;

/**
 * <b>InitGridStrategyB représente une stratégie concrète d'initialisation d'une grille de jeu.</b>
 * <p>
 * Elle initialise le plateau de jeu uniquement avec des murs.<br>
 * Elle implémente l'interface {@link InitGridStrategy}.
 * </p>
 * 
 * @see GridConcrete
 * @see Case
 * @see Player
 * 
 * @author Melvin Lucchini, Steven Martin, Antoine Morlay, Ahouefa Zounon
 * @version 1.0
 */
public class InitGridStrategyB implements InitGridStrategy{
    
    @Override
    public void init(GridConcrete g) //Le plateau de jeu ne contient pas de pastilles d'énergie
    {
    	//Vider le plateau de jeu
    	g.emptyBoard();
    	
    	Random random = new Random(); //L'attribut utilisé pour "randomisé" les choix
    	
    	int nbreCases = (int)Math.pow(g.getTail(),2); //Le nombre de cases totales du plateau de jeu
    	
    	//On place en premier, les joueurs sur le plateau de jeu, de façon "aléatoire"
    	for(Player p : g.getPlayers())
        {
            int pos = random.nextInt(nbreCases);
            int line = (pos/g.getTail());
            int col = (pos-(line*g.getTail()));
    		
            Case c = g.getBoard()[line][col];
    		g.getBoard()[line][col].addPlayer(p);
            p.setCurrentCase(c);
        }
    	
    	//On choisi la moitié des cases restantes pour l'initialisation
        int nbreCasesInit = (nbreCases - g.getPlayers().size()) / 2;
        int line = g.getTail(), col = g.getTail();
    	
    	//Le nombre de murs est égal au rapport du nombre de cases restantes par 2
        int nbreWalls = nbreCasesInit/2;
        for(int i = nbreWalls ; i > 0 ; i--)
        {
            int x = 0, y = 0;
            
            do
            {
            	do
	            {
	                x = random.nextInt(g.getTail());
	                y = random.nextInt(g.getTail());
	            } while( (x==line) && (y==col) ); //On reprend tant que la case sélectionnée a déjà été choisie
            } while( (g.getBoard()[x][y].getPlayers() == null) || (g.getBoard()[x][y].getPlayers().size() != 0) ); //On reprend tant qu'il y a un joueur sur la case choisie
            
            line = x;
            col = y;
            g.getBoard()[line][col].caseToWall();         
        }
    }
}
