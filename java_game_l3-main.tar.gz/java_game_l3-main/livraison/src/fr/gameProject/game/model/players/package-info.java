/**
 * <b>Package contenant les différentes classes représentants les joueurs du jeu.</b>
 * 
 * @see Player
 * @see RandomPlayer
 * 
 * @author Melvin Lucchini, Steven Martin, Antoine Morlay, Ahouefa Zounon
 * @version 1.0
 */
package fr.gameProject.game.model.players;