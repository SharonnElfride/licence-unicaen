/**
 * <b>Package contenant les différentes classes représentants les stratégies de jeu d'un joueur.</b>
 * 
 * @see PlayerPlayStrategy
 * @see PlayerPlayBasicStrategy
 * @see PlayerPlayAdvancedStrategy
 * 
 * @author Melvin Lucchini, Steven Martin, Antoine Morlay, Ahouefa Zounon
 * @version 1.0
 */
package fr.gameProject.game.model.playersPlayStrategies;