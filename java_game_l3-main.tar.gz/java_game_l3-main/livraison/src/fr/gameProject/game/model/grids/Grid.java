package fr.gameProject.game.model.grids;

import java.util.ArrayList;
import java.util.List;

import fr.gameProject.game.model.initGridStrategies.InitGridStrategy;
import fr.gameProject.game.model.players.Player;
import fr.gameProject.game.model.weapons.Bomb;
import fr.gameProject.game.model.weapons.Weapon;
import fr.gameProject.util.ModelListenable;

/**
 * <b>Grid est l'interface représentant une grille de jeu.</b>
 * <p>Elle est écoutable et toute grille de jeu doit l'implémenter.</p>
 * 
 * @see GridConcrete
 * @see GridProxy
 * @see InitGridStrategy
 * @see Player
 * @see Weapon
 * @see ModelListenable
 * 
 * @author Melvin Lucchini, Steven Martin, Antoine Morlay, Ahouefa Zounon
 * @version 1.0
 */
public interface Grid extends ModelListenable{
    
    /**
     * Retourne plateau de jeu
     * 
     * @return Les cases comportants le plateau de jeu
     */
    Case[][] getBoard();

    /**
     * Retourne la taille du plateau de jeu
     * 
     * @return La taille du plateau de jeu
     */
    int getTail();

    /**
     * Ajoute un joueur à la liste des joueurs
     * 
     * @param p -- Le joueur à ajouter à la liste
     */
    void addPlayer(Player p);
    
    /**
     * Détermine si le jeu est terminé
     * 
     * @return {@code true} si le jeu est terminé et {@code false} sinon.
     */
	boolean isOver();

    /**
     * Modifie la stratégie d'initialisation de la grille de jeu
     * 
     * @param initStrat -- La nouvelle stratégie d'initialisation de la grille
     */
    void setInitStrategy(InitGridStrategy initStrat);

    /**Initialise la grille de jeu */
    void init();

    /**
     * Retourne la liste de tous les joueurs du jeu
     * 
     * @return les joueurs du jeu
     */
    ArrayList<Player> getPlayers();
    
    /**
     * Retourne la liste des joueurs encore vivants et présents sur le plateau de jeu
     * 
     * @return les joueurs encore vivants
     */
    ArrayList<Player> getAlivePlayers();
    
    /**
     * Appelée lorsqu'un joueur fait une action.
     * Elle représente la réaction de la grille de jeu à l'action d'un joueur.
     * 
     * @param p -- le joueur qui joue
     * @param action -- l'action du joueur
     */
    void playerPlayed(Player p, int action);

    /**
     * Appelée lorsqu'un joueur décide de tirer
     * 
     * @param c -- la case actuelle du joueur
     * @param direct -- la direction dans laquelle le joueur décide de tirer
     */
    void playerShot(Case c, boolean direct);

    /**
     * Appelée lorsqu'un joueur décide de se déplacer
     * 
     * @param p -- le joueur qui se déplace
     * @param c -- la case dans laquelle il décide de se déplacer
     */
    void playerMoved(Player p, Case c);

    /**
     * Appelée lorsqu'un joueur décide de poser une arme sur une case
     * 
     * @param vals -- la liste composée de la case sur laquelle il veut poser l'arme et l'arme qu'il veut poser
     */
    void playerPutWeapon(List<Object> vals);

    /**
     * Retourne la liste des bombes présentent sur la grille de jeu
     * 
     * @return la liste des bombes du plateau de jeu
     */
	ArrayList<Bomb> bombs();

	/**
	 * Appelée lorsqu'une bombe explose
	 * 
	 * @param c -- la case où se trouve la bombe
	 */
	void bombExplose(Case c);

	/**
	 * La représentation d'une action
	 * 
	 * @param p -- le joueur qui fait l'action
	 * @param action -- l'action du joueur
	 * @return la représentation de l'action du joueur
	 */
    String actionToString(Player p, int action);
}
