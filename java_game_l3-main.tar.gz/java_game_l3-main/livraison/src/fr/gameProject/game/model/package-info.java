/**
 * <b>Package contenant les différentes classes du modèle.</b>
 * 
 * @see fr.gameProject.game.model.Orchestrator
 * @see fr.gameProject.game.model.grids.Case
 * @see fr.gameProject.game.model.grids.Grid
 * @see fr.gameProject.game.model.initGridStrategies.InitGridStrategy
 * @see fr.gameProject.game.model.players.Player
 * @see fr.gameProject.game.model.playersPlayStrategies.PlayerPlayStrategy
 * @see fr.gameProject.game.model.weapons.Weapon
 * 
 * @author Melvin Lucchini, Steven Martin, Antoine Morlay, Ahouefa Zounon
 * @version 1.0
 */
package fr.gameProject.game.model;