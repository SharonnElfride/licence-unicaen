/**
 * <b>Package contenant les différentes classes représentants des grilles ainsi que les classes relatives à une grille du jeu.</b>
 * 
 * @see Case
 * @see Grid
 * @see GridConcrete
 * @see GridProxy
 * 
 * @author Melvin Lucchini, Steven Martin, Antoine Morlay, Ahouefa Zounon
 * @version 1.0
 */
package fr.gameProject.game.model.grids;