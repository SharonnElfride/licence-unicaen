package fr.gameProject.game.model.grids;

import java.util.ArrayList;

import fr.gameProject.game.model.players.Player;
import fr.gameProject.game.model.weapons.Bomb;
import fr.gameProject.game.model.weapons.Weapon;

/**
 * <b>Case est la classe représentant une case de la grille de jeu.</b>
 * 
 * @see Player
 * @see Weapon
 * 
 * @author Melvin Lucchini, Steven Martin, Antoine Morlay, Ahouefa Zounon
 * @version 1.0
 */
public class Case {
    
    /**Les coordonnées de la case sur le plateau de jeu */
    private int line, col;
    
    /**La liste des joueurs positionnés sur la case*/
    private ArrayList<Player> players;

    /**Une pastille d'énergie */
    private boolean energyPellet;

    /**Le mur */
    private boolean wall;

    /**L'arme posée sur la case -- Une mine ou une bombe */
    private Weapon weapon;

    /** */
    public Case(int l, int c)
    {
        this.line = l;
        this.col = c;
        this.energyPellet = false;
        this.wall = false;
        this.weapon = null;
        this.players = new ArrayList<Player>();
    }

//Méthodes ****** METHODES DE BASE
    /**Appelée lorqu'une case est touchée par un tir ou une explosion */
    public void damaged()
    {
    	if(this.players != null)
    	{
    		if(this.players.size() != 0)
	        {
	        	for(Player p : this.players)
	        		p.getHurt();
	        }
    	}
    	
    	//On retire ce qu'il y avait sur la case
    	this.weapon = null; //arme
    	//this.energyPellet = false; //pastille d'énergie si on décommente la ligne
    }

    /**Ajoute une pastille sur la case */
    public void addEnergyPellet()
    {
        if(!this.energyPellet)
            this.energyPellet = true;
    }
    
    /**Retire la pastille d'énergie de la case */
    public void removeEnergyPellet()
    {
        this.energyPellet = false;
    }
    
    /**Vide la case*/
    public void empty()
    {
        this.players = new ArrayList<Player>();
    	this.energyPellet = false;
        this.wall = false;
        this.weapon = null;
    }
    
    /**
     * Désigne si la case est un mur ou non
     * 
     * @return {@code true} si la case est un mur et {@code false} sinon.
     */
    public boolean isWall()
    {
        return this.wall;
    }

    /**Retire l'arme de la case */
    public void removeWeapon()
    {
        this.weapon = null;
    }
    
    /**
     * Ajoute un joueur à la liste des joueurs présents sur la case
     * 
     * @param p -- Le joueur à ajouter à la liste
     */
    public void addPlayer(Player p)
    {
        this.players.add(p);
    }
    
    /**
     * Retire un joueur de la liste des joueurs présents sur la case
     * 
     * @param p -- Le joueur à retirer de la liste
     */
    public void removePlayer(Player p)
    {
    	this.players.remove(p);
    }
    
    /**Transforme une case en mur */
    public void caseToWall()
    {
        this.wall = true;
        this.players = null;
        this.energyPellet = false;
        this.weapon = null;
    }
    
    /**
     * Copie une case
     * 
     * @return La nouvelle case avec les caractéristiques de la case copiée
     */
    public Case copyCase()
    {
    	Case c = new Case(this.line, this.col);
    	c.setWeapon(this.weapon);
    	c.setEnergyPellet(this.energyPellet);
    	
    	if( (this.players != null) && (this.players.size() != 0) )
	    {
    		for(Player p : this.players)
	    	{
    			c.addPlayer(p);
	    	}
	    }
    	c.setWall(this.wall);
    	
    	return c;
    }

//Méthodes ****** GETTERS ET SETTERS
    /**
     * Retourne le numéro de la ligne de la case
     * 
     * @return La coordonnée de l'abscisse de la case
     */
    public int getLine()
    {
        return this.line;
    }

    /** Retourne le numéro de la colonne de la case
     * 
     * @return La coordonnée de l'ordonnée de la case
     */
    public int getCol()
    {
        return this.col;
    }

    /**
     * Retourne la liste des joueurs présents sur la case
     * 
     * @return Les joueurs sur la case et {@code null} s'il y a aucun joueur.
     */
    public ArrayList<Player> getPlayers()
    {
        return this.players;
    }

    /**
     * Permet de savoir s'il y a une pastille d'énergie sur la case ou non.
     * 
     * @return {@code true} s'il y a une pastille d'énergie sur la case et {@code false} sinon.
     */
    public boolean getEnergyPellet()
    {
        return this.energyPellet;
    }

    /**
     * Retourne l'arme présente sur la case
     * 
     * @return L'arme sur la case et {@code null} s'il y a aucune arme.
     */
    public Weapon getWeapon()
    {
        return this.weapon;
    }

    /**
     * Permet de rendre une case mur ou inversement.
     * 
     * @param wall -- La nouvelle valeur de wall. {@code true} pour rendre la case mur et {@code false} pour l'inverse.
     */
    public void setWall(boolean wall)
    {
    	this.wall = wall;
    }

    /**
     * Modifie l'arme de la case
     * 
     * @param arm -- La nouvelle arme de la case
     */
    public void setWeapon(Weapon arm)
    {
        this.weapon = arm;
        if(this.weapon != null)
        	this.weapon.setCase(this);
    }
    
    /**
     * Permet de mettre une pastille d'énergie sur la case ou de la retirer.
     * 
     * @param pellet -- La nouvelle valeur de energyPellet. {@code true} pour mettre une pastille sur la case mur et {@code false} pour la retirer.
     */
    public void setEnergyPellet(boolean pellet)
    {
    	this.energyPellet = pellet;
    	
    }

    //Méthode toString()
    /**Affiche une case */
    @Override
    public String toString()
    {
        if(this.wall != false) //Si la case est un mur
            return "■";
        else
        {
            if( (this.energyPellet) && (this.weapon == null) ) //S'il y a seulement une pastille d'énergie sur la case
                return "○";
            if( (this.weapon != null) && (!this.energyPellet) ) //S'il y a seulement une arme(mine ou bombe) sur la case
                return weapon.toString();
            
            if(this.players.size() != 0) //S'il y a au moins un joueur sur la case
            {
            	String str = "";
            	for(Player p : this.players)
            	{
            		str += String.valueOf(p.getPlayerID()); //"▲";
            	}
            		
            	return str;
            }
            	
            if( (this.energyPellet) && (this.weapon != null) ) //S'il ya une pastille d'énergie et une arme
            {
                if(this.weapon instanceof Bomb)
                    return "◐"; //Si l'arme est une bombe
                else
                    return "◑"; //Si l'arme est une mine
            }
        }
        
        return " "; //S'il n'y a rien
    }
}
