package fr.gameProject.game.model.weapons;

import fr.gameProject.game.model.players.Player;

/**
 * <b>Mine est une classe qui représente un type d'arme concret.</b>
 * <p>Elle hérite de la classe abstraite {@link Weapon}.</p>
 * 
 * @author Melvin Lucchini, Steven Martin, Antoine Morlay, Ahouefa Zounon
 * @version 1.0
 */
public class Mine extends Weapon{
    
	/**
     * Constructeur 
     * 
     * @param p -- le joueur à qui appartient l'arme
     */
    public Mine(Player p)
    {
        super(p);
    }

    //Méthode toString()
    @Override
    public String toString()
    {
        return "◗";
    }
}
