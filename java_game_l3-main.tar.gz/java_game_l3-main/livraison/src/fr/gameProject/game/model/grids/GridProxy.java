package fr.gameProject.game.model.grids;

import java.util.ArrayList;
import java.util.List;

import fr.gameProject.game.model.initGridStrategies.InitGridStrategy;
import fr.gameProject.game.model.players.Player;
import fr.gameProject.game.model.weapons.Bomb;
import fr.gameProject.util.AbstractModelListenable;
import fr.gameProject.util.ModelListener;

/**
 * <b>GridProxy est une classe représentant une grille de jeu vue par un joueur.</b>
 * <p>
 * Elle permet à un joueur de voir les bombes et les murs qu'il a posé ainsi que les murs du plateau de jeu.<br>
 * Elle est écoutable et implémente l'interface {@link Grid}.
 * </p>
 * 
 * @see InitGridStrategy
 * @see Player
 * @see fr.gameProject.game.model.weapons.Weapon
 * @see AbstractModelListenable
 * @see ModelListener
 * 
 * @author Melvin Lucchini, Steven Martin, Antoine Morlay, Ahouefa Zounon
 * @version 1.0
 */
public class GridProxy extends AbstractModelListenable implements Grid, ModelListener{
    
    /**La grille de jeu */
    private Grid g;

    /**Le joueur pour lequel le proxy est configuré */
    private Player p;

    /**
     * Constructeur
     * 
     * @param g -- la grille concrete modifiée et affichée au joueur
     * @param p -- le joueur pour qui le gridproxy est configuré
     */
    public GridProxy(Grid g, Player p)
    {
        this.g = g;
        this.g.addListener(this);
        this.p = p;
        this.p.setGrid(this);
    }

//Méthodes ****** METHODES HERITEES
    @Override
    public Case[][] getBoard()
    {
        //Retourne la grid avec les el qui appartiennent au player p
        Case[][] boardPlayer = new Case[this.g.getTail()][this.g.getTail()];

        for(int i = 0 ; i < this.g.getTail() ; i++)
        {
            for(int j = 0 ; j < this.g.getTail() ; j++)
            {
                Case c = this.g.getBoard()[i][j].copyCase();
                
                if(c.getEnergyPellet())
                	c.removeEnergyPellet(); //S'il y a une pastille d'énergie on ne l'affiche pas
                
                //System.out.println("Weapon de GridProxy === " + this.g.getBoard()[i][j].getWeapon());
                
            	if(c.getWeapon() != null)
                {
                	if(!c.getWeapon().getPlayer().equals(this.p))
                    	c.removeWeapon(); //S'il y a une arme et qu'elle n'appartient pas au joueur, on ne l'affiche pas
                }
                
                boardPlayer[i][j] = c;
            }
        }   
        return boardPlayer;
    }

    @Override
    public int getTail()
    {
        return this.g.getTail();
    }

    @Override
    public void addPlayer(Player p) {
        //Ne rien faire car le proxy n'intervient que dans l'affichage du board pour chaque joueur
    }
    
    @Override
    public boolean isOver()
    {
    	return this.g.isOver();
    }

    @Override
    public void setInitStrategy(InitGridStrategy initStrat) {
        //Ne rien faire car le proxy n'intervient que dans l'affichage du board pour chaque joueur
    }

    @Override
    public void init() {
        //Ne rien faire car le proxy n'intervient que dans l'affichage du board pour chaque joueur
    }

    @Override
    public ArrayList<Player> getPlayers() {
        return this.g.getPlayers();
    }
    
    @Override
    public ArrayList<Player> getAlivePlayers() {
        return this.g.getAlivePlayers();
    }
    
    @Override
    public void playerPlayed(Player p, int action)
    {
    	//Ne rien faire car le proxy n'intervient que dans l'affichage du board pour chaque joueur
    }

    @Override
    public void playerShot(Case c, boolean direct)
    {
        //To delete
    	this.g.playerShot(c, direct);
    }

    @Override
    public void playerMoved(Player p, Case c)
    {
        //Ne rien faire car le proxy n'intervient que dans l'affichage du board pour chaque joueur
    }

    @Override
    public void playerPutWeapon(List<Object> vals)
    {
        //To delete
    	this.g.playerPutWeapon(vals);
    }
    
    @Override
	public void modelUpdated(Object src) {
		this.fireChangement();
	}

    //Méthode toString()
    @Override
    public String toString()
    {
        String str = "Grille du " + this.p.toString() + "\n";

        for(int i = 0 ; i < this.getTail() ; i++)
        {
            for(int j = 0 ; j < this.getTail() ; j++)
            {
                if(j != (this.getTail() - 1) )
                    str += " " + this.getBoard()[i][j].toString() + " |";
                else
                    str += " " + this.getBoard()[i][j].toString();
            }

            str += "\n";
        }
        
        return str;
    }

	@Override
	public ArrayList<Bomb> bombs()
	{
		ArrayList<Bomb> bombs = new ArrayList<Bomb>();
    	
    	for(Bomb b : this.g.bombs())
    	{
    		if(b.getPlayer().equals(this.p))
    			bombs.add(b);
    	}
    	
    	return bombs;
	}
	
	@Override
    public void bombExplose(Case c)
    {
        //Ne rien faire car le proxy n'intervient que dans l'affichage du board pour chaque joueur
    }

	@Override
    public String actionToString(Player p, int action) {
        return "";
    }
}
