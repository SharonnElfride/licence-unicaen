package fr.gameProject.game.model.weapons;

import fr.gameProject.game.model.grids.Case;
import fr.gameProject.game.model.players.Player;

/**
 * <b>Weapon est la classe représentant une arme d'un joueur.</b>
 * <p>Tout type d'arme d'un joueur doit en hériter.</p>
 * 
 * @see Bomb
 * @see Mine
 * @see Case
 * @see Player
 * 
 * @author Melvin Lucchini, Steven Martin, Antoine Morlay, Ahouefa Zounon
 * @version 1.0
 */
public abstract class Weapon {

    /**Le joueur auquel la mine appartient */
    private Player p;

    /**La case sur laquelle la mine est posée */
    private Case c;

    /**
     * Constructeur 
     * 
     * @param p -- le joueur à qui appartient l'arme
     */
    public Weapon(Player p)
    {
        this.p = p;
        this.c = null;
    }

//Méthodes ****** GETTERS ET SETTERS
    /**
     * Retourne le joueur propriétaire de l'arme
     * 
     * @return le joueur à qui appartient l'arme
     */
    public Player getPlayer()
    {
        return this.p;
    }

    /**
     * Retourne la case dans laquelle l'arme est posée
     * 
     * @return la case dans laquelle l'arme est posée. {@code null} si elle n'est dans aucune case.
     */
    public Case getCase()
    {
        return this.c;
    }

    /**
     * Modifie la case dans laquelle l'arme est posée
     * 
     * @param c -- la nouvelle case dans laquelle poser l'arme
     */
    public void setCase(Case c)
    {
        this.c = c;
    }
}
