package fr.gameProject.game.model.initGridStrategies;

import fr.gameProject.game.model.grids.GridConcrete;

/**
 * <b>InitGridStrategy est l'interface représentant une stratégie d'initialisation d'une grille de jeu.</b>
 * <p>Toute stratégie d'initialisation d'une grille de jeu doit l'implémenter.</p>
 * 
 * @see GridConcrete
 * @see InitGridStrategyA
 * @see InitGridStrategyB
 * @see InitGridStrategyC
 * 
 * @author Melvin Lucchini, Steven Martin, Antoine Morlay, Ahouefa Zounon
 * @version 1.0
 */
public interface InitGridStrategy {
    
    /**
     * Initialise le plateau selon des spécificités
     * 
     * @param g -- la grille de jeu à initialiser
     */
    void init(GridConcrete g);
}
