package fr.gameProject.game.view;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import fr.gameProject.game.model.Orchestrator;
import fr.gameProject.game.model.grids.Grid;
import fr.gameProject.game.model.players.Player;

/**
 * <b>GUI est la classe utilisée pour designer et dessiner l'interface graphique.</b>
 * 
 * @see Orchestrator
 * @see Grid
 * @see Player
 * 
 * @author Melvin Lucchini, Steven Martin, Antoine Morlay, Ahouefa Zounon
 * @version 1.0
 */
public class GUI extends JFrame {

    /* Ordre de passage des joueurs. */
    protected int order;

    /* Orchestrateur */
    protected Orchestrator orchestrator;

    /* Liste des joueurs */
    protected ArrayList<Player> players;

    /**
     * Constructeur
     * 
     * @param grille -- la grille de jeu
     * @param players -- les joueurs
     */
    public GUI(Grid grille, ArrayList<Player> players) {
        super("Jeu de combat");

        this.order = 0;
        this.players = players;
        Collections.shuffle(this.players);

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(new BorderLayout());

        ViewGrid gridView = new ViewGrid(grille);

        Container contentPane = this.getContentPane();
        contentPane.removeAll();
        contentPane.add(gridView, BorderLayout.EAST);

        JPanel panel = new JPanel();
        panel.setPreferredSize(new Dimension(500,0));
        panel.add(new JLabel("Status actuel"));

        JTextArea textArea = new JTextArea();

        JButton button = new JButton("Tour Suivant");
        button.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e) {
            	if (grille.isOver()) {
            		JFrame frame = new JFrame();
            		JOptionPane.showMessageDialog(frame, grille.getAlivePlayers().get(0).toString());
            	} else {
                    textArea.setText("" + onClickButton(grille, gridView));

            	}
            }
        });
        panel.add(button);
        panel.add(textArea);

        contentPane.add(panel, BorderLayout.WEST);
        this.pack();
        this.setVisible(true);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
    }

    /**
     * Représente graphiquement l'action d'un joueur
     * 
     * @param grille -- la grille
     * @param view -- la vue
     * @return -- la représentation d'une action d'un joueur
     */
    private String onClickButton(Grid grille, ViewGrid view) {
            Player currentPlayer = null;

            if (this.order == this.players.size()) {
                this.order = 0;
            }
            currentPlayer = this.players.get(this.order);
            int action = currentPlayer.action();
            grille.playerPlayed(currentPlayer, action);
            this.order++;
            String string = grille.actionToString(currentPlayer, action);
            return string;
    }
}
