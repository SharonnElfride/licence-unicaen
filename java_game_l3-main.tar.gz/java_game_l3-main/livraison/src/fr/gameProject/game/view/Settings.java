package fr.gameProject.game.view;

import java.awt.Color;

/**
 * <b>Settings est la classe qui initialise des paramètres qui seront utilisés pour l'interface graphique.</b>
 * 
 * @author Melvin Lucchini, Steven Martin, Antoine Morlay, Ahouefa Zounon
 * @version 1.0
 */
public class Settings {

    /**
     * Taille d'une case en pixels
     */
    public static final int CASE_SIZE = 40;

    /**
     * Couleur d'une pastille d'énergie
     */
    public static final Color ENERGY_COLOR = new Color(0,0,255);

    /**
     * Couleur d'un mur
     */
    public static final Color WALL_COLOR = new Color(0,0,0);

    /**
     * Couleur d'une arme explosive (Bombe ou mine)
     */
    public static final Color WEAPON_COLOR = new Color(255,0,0);

    /**
     * Couleur d'un joueur
     */
    public static final Color PLAYER_COLOR = new Color(0,255,0);


}