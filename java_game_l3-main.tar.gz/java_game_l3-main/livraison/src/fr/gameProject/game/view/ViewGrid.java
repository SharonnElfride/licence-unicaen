package fr.gameProject.game.view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JPanel;

import fr.gameProject.game.model.grids.Case;
import fr.gameProject.game.model.grids.Grid;
import fr.gameProject.game.model.players.Player;
import fr.gameProject.game.model.weapons.Bomb;
import fr.gameProject.game.model.weapons.Mine;
import fr.gameProject.util.ModelListener;

/**
 * <b>ViewGrid représente la vue d'une grille de jeu.</b>
 * <p>Elle écoute une grille de jeu et se met à jour à chaque fois que la grille est modifiée.</p>
 * 
 * @see Grid
 * @see Player
 * @see ModelListener
 * 
 * @author Melvin Lucchini, Steven Martin, Antoine Morlay, Ahouefa Zounon
 * @version 1.0
 */
public class ViewGrid extends JPanel implements ModelListener {

	/**La grille de jeu à écouter et afficher */
	private Grid grid;
	
	/**Les cases de la grille de jeu */
	private Case[][] board;
	
	/**
	 * Constructeur
	 * 
	 * @param g -- la grille à écouter et à afficher
	 */
	public ViewGrid(Grid g)
	{
		this.grid = g;
		this.board = g.getBoard();
		this.grid.addListener(this);
		this.setPreferredSize(
				new Dimension(10 * Settings.CASE_SIZE, 10* Settings.CASE_SIZE)
		);
		this.setBackground(Color.WHITE);
	}

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		doDrawing(g);
	}

	/**
	 * Dessiner la grille de jeu
	 * 
	 * @param g -- le pinceau de dessin
	 */
	private void doDrawing(Graphics g) {
		g.setColor(Color.BLACK);
		g.fillRect(0,0,1000,1000);
		g.setColor(Color.WHITE);

		for (int i=0; i < this.board.length; i++) {
			for (int j=0; j < this.board[i].length; j++) {
				g.fillRect(i * Settings.CASE_SIZE + 1, j * Settings.CASE_SIZE + 1, Settings.CASE_SIZE - 2, Settings.CASE_SIZE -2);
				g.setColor(Color.WHITE);

				if (this.board[i][j].isWall()) {
					/* Représente les murs sur la grille */
					g.setColor(Settings.WALL_COLOR);
					g.fillRect(i * Settings.CASE_SIZE + 10, j * Settings.CASE_SIZE + 10, Settings.CASE_SIZE - 20, Settings.CASE_SIZE - 20);
				}
				if (this.board[i][j].getWeapon() instanceof Bomb) {
					/* Représente les bombes sur la grille */
					g.setColor(Settings.WEAPON_COLOR);
				}
				if (this.board[i][j].getWeapon() instanceof Mine) {
					/* Représente les mines sur la grille */
					g.setColor(Settings.WEAPON_COLOR);
					g.fillRect(i * Settings.CASE_SIZE + 10, j * Settings.CASE_SIZE + 10, Settings.CASE_SIZE - 20, Settings.CASE_SIZE - 20);
				}
				if (this.board[i][j].getEnergyPellet()) {
					/* Représente les pastilles d'énergies sur la grille */
					g.setColor(Settings.ENERGY_COLOR);
				}

				for (Player p : this.grid.getAlivePlayers()) {
					if (this.board[i][j] == p.getCurrentCase()) {
						/* Représente les joueurs sur la grille */
						g.setColor(Settings.PLAYER_COLOR);
					}
				}
				g.fillOval(i * Settings.CASE_SIZE + 10, j * Settings.CASE_SIZE + 10, Settings.CASE_SIZE - 20, Settings.CASE_SIZE - 20);
				g.setColor(Color.WHITE);
			}
		}

		g.setColor(Color.WHITE);

	}

	@Override
	public void modelUpdated(Object source) {
		this.repaint();
	}
	
	/**Affiche une grille de jeu en mode console */
	public void display()
	{
		String str = "Une case est représentée par:\n";
		str += "■(mur), ○(pastille d'énergie), ◖(bombe), ◗(mine)\n";
		str += "ou ◐(pastille d'énergie et bombe), ◑(pastille d'énergie et mine)\n";
		str += "ou l'identifiant du ou des joueurs sur la case.";

		System.out.println(str);
		System.out.println(this.grid.toString());
	}
}
