/**
 * <b>Package contenant les différentes classes de la vue.</b>
 * 
 * @see GUI
 * @see ViewGrid
 * @see Settings
 * 
 * @author Melvin Lucchini, Steven Martin, Antoine Morlay, Ahouefa Zounon
 * @version 1.0
 */
package fr.gameProject.game.view;