package fr.gameProject.game.main;

import java.util.ArrayList;
import java.util.Collections;

import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.plaf.nimbus.NimbusLookAndFeel;

import fr.gameProject.game.model.grids.Grid;
import fr.gameProject.game.model.grids.GridConcrete;
import fr.gameProject.game.model.grids.GridProxy;
import fr.gameProject.game.model.players.Player;
import fr.gameProject.game.view.GUI;

/**
 * <b>MainGraphic est la classe principale en mode graphique.</b>
 * <p>
 * Elle permet de faire jouer deux RandomPlayer en mode graphique.
 * </p>
 * 
 * @see Grid
 * @see GridConcrete
 * @see GridProxy
 * @see Player
 * @see GUI
 * 
 * @author Melvin Lucchini, Steven Martin, Antoine Morlay, Ahouefa Zounon
 * @version 1.0
 */
public class MainGraphic {

	/**
	 * <b>Méthode principale</b> exécutant le programme en mode graphique.
	 * 
	 * @param grille -- La grille de jeu
	 * @throws UnsupportedLookAndFeelException
	 * 		L'exception lancée lorsque le programme n'arrive pas à appliquer le look'n feel.
	 * 
	 */
	public static void main(Grid grille) throws UnsupportedLookAndFeelException {
		
		//Apply a look'n feel
		UIManager.setLookAndFeel(new NimbusLookAndFeel());
		
		//Les grilles des players
        ArrayList<GridProxy> gridsPlayers = new ArrayList<GridProxy>();
        for(Player p : grille.getPlayers())
        	gridsPlayers.add(new GridProxy(grille, p));

		ArrayList<Player> passageOrder = grille.getAlivePlayers();
		Collections.shuffle(passageOrder); //On randomise la position des players de la grille
		Player currentPlayer = null;

		new GUI(grille, passageOrder);
	}

}
