package fr.gameProject.game.main;

import java.util.ArrayList;
import java.util.Collections;

import fr.gameProject.game.model.Orchestrator;
import fr.gameProject.game.model.grids.Grid;
import fr.gameProject.game.model.grids.GridConcrete;
import fr.gameProject.game.model.grids.GridProxy;
import fr.gameProject.game.model.players.Player;
import fr.gameProject.game.model.players.RandomPlayer;
import fr.gameProject.game.model.weapons.Bomb;
import fr.gameProject.game.view.ViewGrid;

/**
 * <b>MainModel est la classe principale en mode console.</b>
 * <p>
 * 
 * Elle permet de faire jouer deux ou plusieurs RandomPlayer en mode console
 * Le nombre de joueurs et leurs caractéristiques joueurs revient à l'utilisateur.
 * 
 * </p>
 * 
 * @see Orchestrator
 * @see Grid
 * @see GridConcrete
 * @see GridProxy
 * @see Player
 * @see RandomPlayer
 * @see ViewGrid
 * @see Bomb
 * 
 * @author Melvin Lucchini, Steven Martin, Antoine Morlay, Ahouefa Zounon
 * @version 1.0
 */
public class MainModel {

	/**
	 * <b>Méthode principale</b> exécutant le programme en mode console.
	 *  
	 * @param grille -- La grille de jeu
	 */
	public static void main(Grid grille) {
        //Les grilles des players
        ArrayList<GridProxy> gridsPlayers = new ArrayList<GridProxy>();
        for(Player p : grille.getPlayers())
        	gridsPlayers.add(new GridProxy(grille, p));
        
        //Affichage de base
        System.out.println("Grille initiale");
        ViewGrid view = new ViewGrid(grille);
        view.display();

        /**La liste qui gère l'ordre de passage des joueurs */
        int order = 0;
        ArrayList<Player> passageOrder = grille.getAlivePlayers();
        Collections.shuffle(passageOrder); //On randomise la position des players de la grille
        Player currentPlayer = null; //Le premier player de la liste avec order = 0

        //ESSAI DU JEU AVEC LA BOUCLE 
        Orchestrator orchestrator = new Orchestrator(grille);
		
		while(!grille.isOver()){  // Tant que la partie n'est pas finie la boucle s'exécute
			if(order == passageOrder.size())
				order = 0;
			currentPlayer = passageOrder.get(order);
			orchestrator.play(currentPlayer);
			order++;
			
			//Faire baisser les boucliers des autres joueurs
			for(Player player : grille.getAlivePlayers())
            {
         		if(!player.equals(currentPlayer))
                {
         			if(player.getShield())
	         			player.takeOffShield();
         		}
            }
            
            for(Bomb b : grille.bombs()) //Fait exploser toutes les bombes du plateau si le countdown timer est <= 0
            {
            	b.countdown();
            	if(b.getCountdownTime() <= 0)
            		grille.bombExplose(b.getCase());
            }			
		}        
	}

}
