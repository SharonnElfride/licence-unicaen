/**
 * <b>Package contenant les classes principales Main, MainModel et MainGraphic ainsi que la classe de configuration du jeu GameConfig.</b>
 * 
 * @see Main
 * @see MainModel
 * @see MainGraphic
 * @see GameConfig
 * 
 * @author Melvin Lucchini, Steven Martin, Antoine Morlay, Ahouefa Zounon
 * @version 1.0
 */
package fr.gameProject.game.main;