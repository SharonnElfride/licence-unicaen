package fr.gameProject.game.main;

import java.util.InputMismatchException;
import java.util.Scanner;

import fr.gameProject.game.model.grids.Grid;

/**
 * <b>Main est la classe principale du projet.</b>
 * <p>
 * Elle permet une première intéraction avec l'utilisateur en vue de configurer le jeu et de choisir le <span>mode</span> à utiliser pour jouer.<br>
 * Les modes disponibles sont: 
 * <ul>
 * <li>Mode console</li>
 * <li>Mode graphique</li>
 * </ul>
 * 
 * En fonction du choix de l'utilisateur, elle exécute un programme différent.<br>
 * Soit l'utilisateur joue dans la console(quand il saisit 0) soit il joue sur l'interface graphique(quand il saisit 1).<br>
 * Il peut décider de ne pas jouer en saisissant 2.
 * </p>
 * 
 * @see MainModel
 * @see MainGraphic
 * 
 * @author Melvin Lucchini, Steven Martin, Antoine Morlay, Ahouefa Zounon
 * @version 1.0
 *
 */
public class Main {

	/**
	 * <b>Méthode principale</b> exécutant le programme.
	 * 
	 * @param args
	 * 		Les arguments passés en paramètre lors de l'exécution du programme.<br> Ils sont stockés dans un tableau de <code>String</code> et sont utilisés par le programme si besoin.
	 * 
	 * @exception InputMismatchException Déclanchée lorsque l'on saisi autre chose qu'un entier.
	 * @exception NullPointerException Déclanchée lorsque la valeur de l'entier demandé reste inchangée (donc à <code>null</code>).
	 * @exception Exception Déclanchée lorsque l'on rencontre une erreur lors du déroulement du programme de l'une des classes Main des autres packages.
	 * 
	 */
	public static void main(String[] args) {
		
		int x = 2;
		Scanner sc = new Scanner(System.in);
		
		//Introduction
		System.out.println("Bienvenue dans LMMZ!");
		System.out.println("Nous sommes ravis de vous accueillir et espérons que vous vous y plairez!\nNous vous prions de suivre toutes les consignes qui vous serons communiquées au fur et à mesure de votre avancée.");	
		
		//Configuration du jeu
		Grid grille = GameConfig.config(sc);

		//Les modes de jeu
		System.out.println("Vous avez le choix entre 2 modes de jeu: \n0 pour le mode console et 1 pour le mode graphique. \nVous pouvez saisir 2 pour sortir du jeu.");

		do
		{
			System.out.println("Veuillez saisir un chiffre : 0, 1 ou 2");
			
			try {
				x = sc.nextInt();
			} 
			catch (Exception e) {
				System.out.println("Vous avez entrez autre chose qu'un entier. Veuillez relancer le programme.");
				//e.printStackTrace();
			}
			
		} while(x!=0 && x!=1 && x!=2);
				
		if(x == 0)  //Le mode console
		{
			try 
			{
				//MainModel.main(args);
				new Thread() {
					public void run() {
						try 
						{
							MainModel.main(grille);
						} 
						catch (Exception e) {
							System.out.println("Impossible d'exécuter le programme");
							e.printStackTrace();
						}
					}
				}.start();
			}
			catch (Exception e) {
				System.out.println("Impossible d'exécuter le programme");
				//e.printStackTrace();
			}
		}
		
		else if(x == 1) //Le mode graphique
		{
			try 
			{
				//MainView.main(args);
				new Thread() {
					public void run() {
						try 
						{
							MainGraphic.main(grille);
						}
						catch (Exception e) {
							System.out.println("Impossible d'exécuter le programme");
							e.printStackTrace();
						}
					}
				}.start();
			}
			catch (Exception e) {
				System.out.println("Impossible d'exécuter le programme");
				//e.printStackTrace();
			}
		}
		
		else //L'utilisateur a saisit 2
		{
			System.out.println("LMMZ vous remercie d'être venu.");
			System.exit(0);
		}
		
		sc.close();
	}
}
