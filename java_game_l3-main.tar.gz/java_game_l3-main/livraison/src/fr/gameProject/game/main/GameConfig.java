package fr.gameProject.game.main;

import java.util.ArrayList;
import java.util.Scanner;

import fr.gameProject.game.model.grids.Grid;
import fr.gameProject.game.model.grids.GridConcrete;
import fr.gameProject.game.model.initGridStrategies.InitGridStrategyB;
import fr.gameProject.game.model.initGridStrategies.InitGridStrategyC;
import fr.gameProject.game.model.players.Player;
import fr.gameProject.game.model.players.RandomPlayer;
import fr.gameProject.game.model.playersPlayStrategies.PlayerPlayAdvancedStrategy;

/**
 * <b>GameConfig est la classe de configuration du jeu.</b>
 * <p>
 * 
 * Elle permet de paramétrer la grille de jeu ainsi que les différents joueurs qui joueront.
 * 
 * </p>
 * 
 * @see Grid
 * @see GridConcrete
 * @see InitGridStrategyB
 * @see InitGridStrategyC
 * @see Player
 * @see RandomPlayer
 * @see PlayerPlayAdvancedStrategy
 * 
 * @author Melvin Lucchini, Steven Martin, Antoine Morlay, Ahouefa Zounon
 * @version 1.0
 *
 */
public class GameConfig {
	
	//la taille du tableau -- 10
	//le nombre de joueur -- inf ou égale à taille du tab
	//Demander leurs caractéristiques -- le nom, leur stratégie de jeu, le nombre de munitions et autres...
	//Demander la strategie d'initialisation du jeu
	
	/**
	 * La méthode de configuration du jeu
	 * 
	 * @param sc -- L'attribut qui permet de gérer les entrées de l'utilisateur
	 * @return La grille de jeu initialisée avec les joueurs
	 */
	public static Grid config(Scanner sc)
	{
		int tail = 10 ; //taille du tableau -- Comprise entre 3 et 10
		int nbrePlayers = 0; //nombre de joueurs -- Compris entre 2 et la taille du tableau
		ArrayList<Player> players = new ArrayList<Player>(); //Les joueurs
		char response = 'n'; //Gère les réponses
		
		//La taille de la grille de jeu
		System.out.println("\nConfiguration du jeu.");
		/*
		System.out.println("Veuillez saisir la taille du plateau de jeu");
		do 
		{
			System.out.println("Saisissez un entier entre 3 et 10");
			tail = sc.nextInt();
		} while(tail < 3 || tail > 10); 
		*/
		
		//Le nombre de joueurs
		System.out.println("Veuillez saisir le nombre de joueurs");
		do 
		{
			System.out.println("Saisissez un entier entre 2 et " + tail);
			nbrePlayers = sc.nextInt();
		} while(nbrePlayers < 2 || nbrePlayers > tail);
		
		sc.nextLine();
		
		//MANIPULATION DES JOUEURS
		System.out.println("Configuration des joueurs");
		
		for(int i = 0 ; i < nbrePlayers ; i++)
		{
			Player p = null; //Le joueur
			
			System.out.println("Veuillez saisir le nom du player " + (i+1));
			String name = sc.nextLine();
			
			//Demande de personnalisation du joueur
			System.out.println("Voulez-vous personnaliser le joueur ?");
			
			do
			{
				System.out.println("'O' ou 'o' pour oui et 'N' ou 'n' pour non");
				response = sc.nextLine().charAt(0);
			} while(response != 'O' && response != 'o' && response != 'N' && response != 'n');
			
			if(response == 'O' || response == 'o') //Il a accepté de modifier les caractéristiques du joueur
			{
				//L'énergie de départ du joueur
				System.out.println("Voulez-vous personnaliser l'énergie du joueur ?");
				
				do
				{
					System.out.println("'O' ou 'o' pour oui et 'N' ou 'n' pour non");
					response = sc.nextLine().charAt(0);
				} while(response != 'O' && response != 'o' && response != 'N' && response != 'n');
				
				char repEnergy = response;
				
				//Le nombre de munitions du joueur
				System.out.println("Voulez-vous personnaliser le nombre de munitions du joueur ?");
				
				do
				{
					System.out.println("'O' ou 'o' pour oui et 'N' ou 'n' pour non");
					response = sc.nextLine().charAt(0);
				} while(response != 'O' && response != 'o' && response != 'N' && response != 'n');
				
				char repMuni = response;
				
				//Le nombre d'armes du joueur
				System.out.println("Voulez-vous personnaliser le nombre d'armes du joueur ?");
				
				do
				{
					System.out.println("'O' ou 'o' pour oui et 'N' ou 'n' pour non");
					response = sc.nextLine().charAt(0);
				} while(response != 'O' && response != 'o' && response != 'N' && response != 'n');
				
				char repArms = response;
				
				//Les différents types de joueurs créés en fonction des caractéristiques
				if(repEnergy == 'o' || repEnergy == 'O')
				{
					//L'énergie
					System.out.println("Entrez l'énergie du player");
					int energy = 0;
					do
					{
						System.out.println("Entrez un entier compris entre 10 et 100");
						energy = sc.nextInt();
					} while(energy < 10 || energy > 100);
					
					if(repMuni == 'o' || repMuni == 'O')
					{
						//Les munitions
						System.out.println("Entrez le nombre de munitions du player");
						int munitions = 0;
						do
						{
							System.out.println("Entrez un entier compris entre 5 et 20");
							munitions = sc.nextInt();
						} while(munitions < 5 || munitions > 20);
						
						if(repArms == 'o' || repArms == 'O')
						{														
							//Les armes
							System.out.println("Entrez le nombre d'armes du player");
							int arms = 0;
							do
							{
								System.out.println("Entrez un entier compris entre 2 et 10");
								arms = sc.nextInt();
							} while(arms < 2 || arms > 10);
							
							p = new RandomPlayer(name, energy, munitions, arms); //Player avec energie, munitions et armes personnalisés
							sc.nextLine();
						}
						
						else
							p = RandomPlayer.createRPfromNameEnergyMunition(name, energy, munitions); //Player avec energie et munitions personnalisés
					}
					
					else if(repArms == 'o' || repArms == 'O')
					{														
						//Les armes
						System.out.println("Entrez le nombre d'armes du player");
						int arms = 0;
						do
						{
							System.out.println("Entrez un entier compris entre 2 et 10");
							arms = sc.nextInt();
						} while(arms < 2 || arms > 10);
						
						p = RandomPlayer.createRPfromNameEnergyWeapon(name, energy, arms); //Player avec energie et armes personnalisés
						sc.nextLine();
					}
					
					else
						p = RandomPlayer.createRPfromNameEnergy(name, energy); //Player avec energie personnalisée
				}
				
				else if(repMuni == 'o' || repMuni == 'O')
				{
					//Les munitions
					System.out.println("Entrez le nombre de munitions du player");
					int munitions = 0;
					do
					{
						System.out.println("Entrez un entier compris entre 5 et 20");
						munitions = sc.nextInt();
					} while(munitions < 5 || munitions > 20);
					
					if(repArms == 'o' || repArms == 'O')
					{														
						//Les armes
						System.out.println("Entrez le nombre d'armes du player");
						int arms = 0;
						do
						{
							System.out.println("Entrez un entier compris entre 2 et 10");
							arms = sc.nextInt();
						} while(arms < 2 || arms > 10);
						
						p = RandomPlayer.createRPfromNameMunitionWeapon(name, munitions, arms); //Player avec munitions et armes personnalisés
						sc.nextLine();
					}
					
					else
						p = RandomPlayer.createRPfromNameMunition(name, munitions); //Player avec munitions personnalisées
				}
				
				else if(repArms == 'o' || repArms == 'O')
				{														
					//Les armes
					System.out.println("Entrez le nombre d'armes du player");
					int arms = 0;
					do
					{
						System.out.println("Entrez un entier compris entre 2 et 10");
						arms = sc.nextInt();
					} while(arms < 2 || arms > 10);
					
					p = RandomPlayer.createRPfromNameWeapon(name, arms); //Player avec armes personnalisées
					sc.nextLine();
				}
				
				else
					p = new RandomPlayer(name);
				
				//La stratégie du joueur
				sc.nextLine();
				System.out.println("La stratégie par défaut du joueur est la stratégie basique.\nVoulez-vous la changer ?");				
				do
				{
					System.out.println("'O' ou 'o' pour oui et 'N' ou 'n' pour non");
					response = sc.nextLine().charAt(0);
				} while(response != 'O' && response != 'o' && response != 'N' && response != 'n');
				
				if(response == 'O' || response == 'o')
					p.setPlayerPlayStrategy(new PlayerPlayAdvancedStrategy());
			}
			
			else
				p = new RandomPlayer(name);
			
			players.add(p);
		}
		
		//LA GRILLE DE JEU
		Grid grid = new GridConcrete(tail);
		System.out.println("\nConfiguration du plateau de jeu.");
		System.out.println("Il y a 3 stratégies d'initialisation du plateau de jeu.");
		System.out.println("La première place des murs et des pastilles d'énergie sur le plateau de jeu.");
		System.out.println("La seconde place uniquement des murs sur le plateau de jeu.");
		System.out.println("La dernière place uniquement des pastilles d'énergie sur le plateau de jeu.");
		System.out.println("La stratégie par défaut est la première.");
		System.out.println("Voulez-vous changer la stratégie d'initialisation du plateau de jeu ?");
		
		do
		{
			System.out.println("'O' ou 'o' pour oui et 'N' ou 'n' pour non");
			response = sc.nextLine().charAt(0);
		} while(response != 'O' && response != 'o' && response != 'N' && response != 'n');
		
		if(response == 'O' || response == 'o') //Si l'utilisateur veut changer la stratégie d'initialisation du plateau
		{
			int gridStrat = 0;
			System.out.println("Entrez 1 pour la deuxième stratégie et 2 pour la troisième");
			
			do
			{
				System.out.println("Entrez un nombre entre 1 et 2");
				gridStrat = sc.nextInt();
			} while(gridStrat != 1 && gridStrat != 2);
			
			if(gridStrat == 1)
				grid.setInitStrategy(new InitGridStrategyB());
			else
				grid.setInitStrategy(new InitGridStrategyC());
		}
		
		for(Player p : players) //On ajoute les différents joueurs créés à la grille de jeu
			grid.addPlayer(p);
		grid.init(); //On initialise la grille de jeu
		
		return grid; //On retourne la grille initialisée
	}

}
