package fr.gameProject.util;

/**
 * <b>ModelListener est l'interface que devra implémenter tout écouteur d'une classe du modèle.</b>
 * 
 * <p>
 * Cette interface a pour méthode: 
 * <ul>
 * <li> Un void <b> {@link ModelListener#modelUpdated(Object)} </b> qui permet de mettre à jour les écouteurs.</li>
 * </ul>
 * </p>
 * 
 * @author Melvin Lucchini, Steven Martin, Antoine Morlay, Ahouefa Zounon
 * @version 1.0
 *
 */
public interface ModelListener{

	/**
	 * Méthode appelée sur tous les écouteurs de la classe écoutable lorsqu'elle a changé. <br>
	 * Permet de mettre à jour les écouteurs des classes écoutables.
	 * 
	 * @param src
	 */
    void modelUpdated(Object src);
}