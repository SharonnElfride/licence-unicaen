package fr.gameProject.util;

/**
 * <b>ModelListenable est l'interface que devra implémenter toute classe écoutable du modèle.</b>
 * 
 * <p>
 * Cette interface a pour méthode: 
 * <ul>
 * <li> Un void <b> {@link ModelListenable#addListener(ModelListener)} </b> qui permet d'ajouter un écouteur à la liste des écouteurs de la classe écoutable.</li>
 * <li> Un void <b> {@link ModelListenable#removeListener(ModelListener)} </b> qui permet de supprimer un écouteur de la liste des écouteurs de la classe écoutable.</li>
 * </ul>
 * 
 * </p>
 * 
 * @see AbstractModelListenable
 * @see ModelListener
 * 
 * @author Melvin Lucchini, Steven Martin, Antoine Morlay, Ahouefa Zounon
 * @version 1.0
 *
 */
public interface ModelListenable{

	/**
	 * Permet d'ajouter un écouteur à la liste des écouteurs de la classe écoutable.
	 * 
	 * @param ml -- L'écouteur de la classe à ajouter
	 */
    void addListener(ModelListener ml);
    
    /**
     * Permet de supprimer un écouteur de la liste des écouteurs de la classe écoutable.
     * 
     * @param ml -- L'écouteur de la classe à supprimer
     */
    void removeListener(ModelListener ml);
}