package fr.gameProject.util;

import java.util.ArrayList;

/**
 * <b>
 * AbstractModelListenable est une classe abstraite permettant de gérer les classes de la vue écoutant une classe écoutable du modèle. 
 * Elle permet l'ajout et/ou le retrait d'écouteurs et aussi leur mise à jour lors de la modification du modèle qu'ils écoutent.
 * </b>
 * 
 * <p>
 * Cette classe a pour attribut: 
 * <ul>
 * <li> une ArrayList de ModelListener <b>listeners</b> </li>
 * </ul>
 * 
 * Cette classe a pour méthodes: 
 * <ul>
 * <li> Un void <b> {@link AbstractModelListenable#addListener(ModelListener)} </b> </li>
 * <li> Un void <b> {@link AbstractModelListenable#removeListener(ModelListener)} </b> </li>
 * <li> Un void <b> {@link AbstractModelListenable#fireChangement()} </b> </li>
 * </ul>
 * 
 * </p>
 * 
 * @see ModelListenable
 * @see ModelListener
 * 
 * @author Melvin Lucchini, Steven Martin, Antoine Morlay, Ahouefa Zounon
 * @version 1.0
 *
 */
public abstract class AbstractModelListenable implements ModelListenable{

	/**Les écouteurs de la classe écoutable */
    ArrayList<ModelListener> listeners = new ArrayList<ModelListener>();

    @Override
    public void addListener(ModelListener ml)
    {
        this.listeners.add(ml);
    }

    @Override
    public void removeListener(ModelListener ml)
    {
        this.listeners.remove(ml);
    }

    /**
     * Permet de prévenir tous les écouteurs de la classe écoutable qu'elle a changé
     */
    protected void fireChangement()
    {
        for(ModelListener ml : this.listeners)
        {
            ml.modelUpdated(this);
        }
    }

}