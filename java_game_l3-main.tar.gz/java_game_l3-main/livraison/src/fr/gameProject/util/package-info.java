/**
 * <b>Package contenant les différentes classes du controller qui permet de faire le lien entre le modèle et la vue.</b>
 * 
 * @see ModelListener
 * @see ModelListenable
 * @see AbstractModelListenable
 * 
 * @author Melvin Lucchini, Steven Martin, Antoine Morlay, Ahouefa Zounon
 * @version 1.0
 *
 */
package fr.gameProject.util;