CREATE TABLE clients(id SERIAL, name VARCHAR(30), PRIMARY KEY(id));
CREATE TABLE supplier(id SERIAL, name VARCHAR(30), discount INT, PRIMARY KEY(id));
CREATE TABLE products(id SERIAL, name VARCHAR(30), price INT, id_supplier INT REFERENCES supplier, PRIMARY KEY(id));
CREATE TABLE buy(id_client INT REFERENCES clients, id_product INT REFERENCES products, date DATE, nb_prod INT, PRIMARY KEY(id_client, id_product, date));

INSERT INTO clients (name) VALUES ('Alphonse');
INSERT INTO clients (name) VALUES ('Marie');
INSERT INTO clients (name) VALUES ('Claude');

INSERT INTO supplier (name, discount) VALUES ('Auchan', 14);
INSERT INTO supplier (name, discount) VALUES ('Casino', 6);

INSERT INTO products (name, price, id_supplier) VALUES ('pull-over', 9, 1), ('casque', 5, 2), ('pull-over', 13, 2), ('casque', 15, 1);

INSERT INTO buy (date, id_client, nb_prod, id_product) VALUES (DATE '2020-02-21', 1, 5, 1), (DATE '2020-02-17', 2, 10, 2), (DATE '2020-02-28', 2, 9, 3), (DATE '2020-02-20', 1, 4, 4), (DATE '2020-02-25', 2, 5, 1), (DATE '2020-02-17', 3, 6, 4), (DATE '2020-02-17', 3, 5, 2);

