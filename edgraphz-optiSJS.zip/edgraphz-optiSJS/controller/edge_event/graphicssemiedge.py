##Copyright 2019, 2019 DUBETTIER Adrien adriendub@yahoo.fr
##Copyright 2019, 2019 LECLERC Benjamin benjamin.leclerc7@gmail.com
##
##This file is part of EdGraphZ.
##
##    EdGraphZ is free software: you can redistribute it and/or modify
##    it under the terms of the GNU General Public License as published by
##    the Free Software Foundation, either version 3 of the License, or
##    (at your option) any later version.
##
##    EdGraphZ is distributed in the hope that it will be useful,
##    but WITHOUT ANY WARRANTY; without even the implied warranty of
##    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##    GNU General Public License for more details.
##
##    You should have received a copy of the GNU General Public License
##    along with EdGraphZ.  If not, see <https://www.gnu.org/licenses/>.

from math import sqrt

from PyQt5.QtCore import QLineF
from PyQt5.QtWidgets import QGraphicsLineItem

from controller.edge_event.graphicsedgeevent import GraphicsMainEdge, closestPointTo


class GraphicsSemiEdge(QGraphicsLineItem, GraphicsMainEdge):
    """
    This class make a semi-edge. It's the  edge between the starting node and the mouse.
    It's a custom QgraphicsLineItem

    """

    def __init__(self, startNode, endNode, graph):
        """
        Constructor

        @param startNode: a GraphicsNode.
        @param endNode: a GraphicsNode. When directed, the arrow points to the node
        @param current_state: a reference to the model

        """
        super().__init__(startNode, endNode, graph, None, None, None, None)


    def Update(self, p2=None):
        """
        When a change occurs, this method refresh the semi-edge
        Called each time the user moves the mouse while keeps the left click pressed

        """
        if p2 != None:
            startShape = self.startNode.mapToScene(self.startNode.shape())

            self.endNode = p2
            p1 = closestPointTo(self.endNode, startShape)

            self.setLine(QLineF(p1, self.endNode))

            stX = p1.x()
            stY = p1.y()
            endX = self.endNode.x()
            endY = self.endNode.y()
            edgeLength = sqrt((endX - stX) ** 2 + (endY - stY) ** 2)