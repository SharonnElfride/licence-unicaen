##Copyright 2019, 2019 DUBETTIER Adrien adriendub@yahoo.fr
##Copyright 2019, 2019 LECLERC Benjamin benjamin.leclerc7@gmail.com
##
##This file is part of EdGraphZ.
##
##    EdGraphZ is free software: you can redistribute it and/or modify
##    it under the terms of the GNU General Public License as published by
##    the Free Software Foundation, either version 3 of the License, or
##    (at your option) any later version.
##
##    EdGraphZ is distributed in the hope that it will be useful,
##    but WITHOUT ANY WARRANTY; without even the implied warranty of
##    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##    GNU General Public License for more details.
##
##    You should have received a copy of the GNU General Public License
##    along with EdGraphZ.  If not, see <https://www.gnu.org/licenses/>.

from math import sqrt

from PyQt5.QtCore import QLineF, Qt
from PyQt5.QtGui import QPen
from PyQt5.QtWidgets import QGraphicsLineItem, QApplication

from controller.edge_event.graphicsedgeevent import GraphicsMainEdge, closestPointTo


class GraphicsEdge(QGraphicsLineItem, GraphicsMainEdge):
    """
    A custom QGraphicsLineItem. It represent an edge between two different nodes

    """

    def __init__(self, startNode, endNode, graph, map_to_scene, label, color, form):
        """
        Constructor

        @param startNode: a GraphicsNode.
        @param endNode: a GraphicsNode. When directed, the arrow points to the node
        @param current_state: a reference to the model
        @param pair_model_node: a dictionary linking the view and the model
        @param label: the current name of this edge
        @param color: the edge color

        """

        super().__init__(startNode, endNode, graph, map_to_scene, label, color, form)
        super().defineLine(self.form)
        self.head.setPen(QPen(self.color))
        self.head.setBrush(self.pen().brush())


    def Update(self):
        """
        When a change occurs, this method refresh the edge

        """
        self.setPen(QPen(self.color))
        startShape = self.startNode.mapToScene(self.startNode.shape())
        endShape = self.endNode.mapToScene(self.endNode.shape())

        p1 = closestPointTo(endShape.boundingRect().center(), startShape)
        p2 = closestPointTo(startShape.boundingRect().center(), endShape)

        self.setLine(QLineF(p1, p2))

        stX = p1.x()
        stY = p1.y()
        endX = p2.x()
        endY = p2.y()
        edgeLength = sqrt((endX - stX) ** 2 + (endY - stY) ** 2)

        super.drawHead(edgeLength, endX, endY, stX, stY, p2)

    def mousePressEvent(self, e):
        """
        This method is called when the user press a mouse button

        @param e: the mouse event

        """
        modifiers = QApplication.keyboardModifiers()
        # unselect all the selected items only if it's a single left click or if it's a right click on a non-selected item
        if modifiers == Qt.NoModifier and (e.button() == Qt.LeftButton or ( e.button() == Qt.RightButton and self not in self.scene().selectedItems())):
            for item in self.scene().selectedItems():
                item.setSelected(False)
            self.setSelected(True)