from math import sqrt

from PyQt5.QtCore import QPointF
from PyQt5.QtGui import QPen, QPainterPath
from PyQt5.QtWidgets import QGraphicsPathItem

from controller.edge_event.graphicsedgeevent import GraphicsMainEdge, closestPointTo


class GraphicsSelfEdge(QGraphicsPathItem, GraphicsMainEdge):
    isDirected = False

    def __init__(self, startNode, endNode, graph, map_to_scene, label, color, form):

        super().__init__(startNode, endNode, graph, map_to_scene, label, color, form)
        super().defineLine(self.form)
        self.head.setPen(QPen(self.color))
        self.head.setBrush(self.pen().brush())

    def obsUpdate(self):
        startShape = self.startNode.mapToScene(self.startNode.shape())
        endShape = self.endNode.mapToScene(self.endNode.shape())

        p1 = closestPointTo(startShape.boundingRect().center() - QPointF(50, 100), startShape)
        p2 = closestPointTo(startShape.boundingRect().center() - QPointF(-50, 100), startShape)
        mid = (p1 + p2) / 2

        sizeRect = self.textItem.boundingRect()
        self.textItem.setPos(mid.x() - sizeRect.width() / 2, mid.y() - sizeRect.height())

        stX = startShape.boundingRect().center().x() + 50
        stY = startShape.boundingRect().center().y() - 100
        endX = p2.x()
        endY = p2.y()
        edgeLength = sqrt((endX - stX) ** 2 + (endY - stY) ** 2)

        contP1 = QPointF(p1.x() - 30, p1.y() - 50)
        contP2 = QPointF(p2.x() + 30, p2.y() - 50)

        path = QPainterPath()
        path.moveTo(p1)
        path.cubicTo(contP1, contP2, p2)

        self.setPath(path)

        super().drawHead(edgeLength, endX, endY, stX, stY, p2)

    def getAttributs(self):
        attributs = ""
        attributs += 'color="' + self.color + '",'
        attributs += 'style="' + self.form + '"'
        return attributs