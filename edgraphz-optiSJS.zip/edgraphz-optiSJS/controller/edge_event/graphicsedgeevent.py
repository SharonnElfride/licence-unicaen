##Copyright 2019, 2019 DUBETTIER Adrien adriendub@yahoo.fr
##Copyright 2019, 2019 LECLERC Benjamin benjamin.leclerc7@gmail.com
##
##This file is part of EdGraphZ.
##
##    EdGraphZ is free software: you can redistribute it and/or modify
##    it under the terms of the GNU General Public License as published by
##    the Free Software Foundation, either version 3 of the License, or
##    (at your option) any later version.
##
##    EdGraphZ is distributed in the hope that it will be useful,
##    but WITHOUT ANY WARRANTY; without even the implied warranty of
##    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##    GNU General Public License for more details.
##
##    You should have received a copy of the GNU General Public License
##    along with EdGraphZ.  If not, see <https://www.gnu.org/licenses/>.

from math import sqrt

from PyQt5.QtCore import QPointF, Qt, QLineF
from PyQt5.QtGui import QPainterPath, QPolygonF, QPen, QBrush
from PyQt5.QtWidgets import QGraphicsItem, QGraphicsPolygonItem, QApplication

from controller.graphicstextitemevent import GraphicsTextItemEvent


class GraphicsMainEdge(QGraphicsItem):

    def __init__(self, startNode, endNode, graph, map_to_scene, label, color, form):

        super().__init__()

        self.startNode = startNode
        self.endNode = endNode
        self.graph = graph
        self.map_to_scene = map_to_scene
        self.label = label
        self.color = color
        self.form = form

        startShape = self.startNode.mapToScene(self.startNode.shape())
        if isinstance(self.endNode, QPointF) :
            endShape = startShape
        else :
            endShape = self.endNode.mapToScene(self.endNode.shape())


        self.textItem = GraphicsTextItemEvent(self.label, map=self.map_to_scene, graph=self.graph, parent=self)
        self.textItem.setTextInteractionFlags(Qt.TextEditorInteraction)

        if startNode != endNode :
            p1 = closestPointTo(endShape.boundingRect().center(), startShape)
            p2 = closestPointTo(startShape.boundingRect().center(), endShape)
            self.textItem.setPos(((p1.x() + p2.x()) / 2), (((p1.y() + p2.y()) / 2)))

            stX = p1.x()
            stY = p1.y()


        else :
            p1 = closestPointTo(startShape.boundingRect().center() - QPointF(50, 100), startShape)
            p2 = closestPointTo(startShape.boundingRect().center() - QPointF(-50, 100), startShape)
            mid = (p1 + p2) / 2

            sizeRect = self.textItem.boundingRect()
            self.textItem.setPos(mid.x() - sizeRect.width() / 2, mid.y() - 50)

            stX = startShape.boundingRect().center().x() + 50
            stY = startShape.boundingRect().center().y() - 100

            contP1 = QPointF(p1.x() - 30, p1.y() - 50)
            contP2 = QPointF(p2.x() + 30, p2.y() - 50)

            path = QPainterPath()
            path.moveTo(p1)
            path.cubicTo(contP1, contP2, p2)

            self.setPath(path)

        endX = p2.x()
        endY = p2.y()
        edgeLength = sqrt((endX - stX) ** 2 + (endY - stY) ** 2)
        if edgeLength != 0 and startNode != endNode:
            self.setLine(QLineF(p1, p2))
        else :
            pass

        self.drawHead(edgeLength, endX, endY, stX, stY, p2)

        self.setFlag(QGraphicsItem.ItemIsSelectable)


    def drawHead(self, edgeLength, endX, endY, stX, stY, p2):
        if self.graph.is_oriented:
            arrowLength = 12
            arrowWidth = 4
            if edgeLength != 0:
                xC = endX - arrowLength * (endX - stX) / edgeLength
                yC = endY - arrowLength * (endY - stY) / edgeLength

                xD = xC + arrowWidth * -(endY - stY) / edgeLength
                yD = yC + arrowWidth * (endX - stX) / edgeLength
                D = QPointF(xD.real, yD.real)

                xE = xC - arrowWidth * -(endY - stY) / edgeLength
                yE = yC - arrowWidth * (endX - stX) / edgeLength
                E = QPointF(xE.real, yE.real)
                self.head = QGraphicsPolygonItem(QPolygonF([D, E, p2]), parent=self)
                self.head.setFillRule(Qt.WindingFill)
                self.head.setPen(self.pen())
                self.head.setBrush(self.pen().brush())
        else:
            self.head = QGraphicsPolygonItem(QPolygonF([p2, p2, p2]), parent=self)
            self.head.setPen(self.pen())
            self.head.setBrush(self.pen().brush())

    def defineLine(self, style):
        if style == "dashed":
            self.setPen(QPen(QBrush(self.color, Qt.SolidPattern), 1, Qt.DashLine, Qt.SquareCap, Qt.BevelJoin))
        elif style == "dotted":
            self.setPen(QPen(QBrush(self.color, Qt.SolidPattern), 1, Qt.DotLine, Qt.SquareCap, Qt.BevelJoin))
        elif style == "bold" :
            self.setPen(QPen(QBrush(self.color, Qt.SolidPattern), 3, Qt.SolidLine, Qt.SquareCap, Qt.BevelJoin))
        else:
            self.setPen(QPen(QBrush(self.color, Qt.SolidPattern), 1, Qt.SolidLine, Qt.SquareCap, Qt.BevelJoin))


    def mousePressEvent(self, e):
        """
        This method is called when the user press a mouse button

        @param e: the mouse event

        """
        modifiers = QApplication.keyboardModifiers()
        # unselect all the selected items only if it's a single left click or if it's a right click on a non-selected item
        if modifiers == Qt.NoModifier and (e.button() == Qt.LeftButton or ( e.button() == Qt.RightButton and self not in self.scene().selectedItems())):
            for item in self.scene().selectedItems():
                item.setSelected(False)
            self.setSelected(True)


def closestPointTo(point, path):
    """
    This function take a point and a path and return the point on the path which is closest to the point passed in argument

    @param point: a point (must be out of the path)
    @param path: the path that is the shape of an object

    @return: a point (QPointF)
    """
    target = path.boundingRect().center()
    mid = (point + target) / 2.

    if path.contains(mid):
        return mid
    else:
        while (mid - point).manhattanLength() > 1:
            while not path.contains(mid):
                point = mid
                mid = (point + target) / 2.

            while path.contains(mid):
                mid = (point + mid) / 2.

        return mid