##Copyright 2019, 2019 DUBETTIER Adrien adriendub@yahoo.fr
##Copyright 2019, 2019 LECLERC Benjamin benjamin.leclerc7@gmail.com
##
##This file is part of EdGraphZ.
##
##    EdGraphZ is free software: you can redistribute it and/or modify
##    it under the terms of the GNU General Public License as published by
##    the Free Software Foundation, either version 3 of the License, or
##    (at your option) any later version.
##
##    EdGraphZ is distributed in the hope that it will be useful,
##    but WITHOUT ANY WARRANTY; without even the implied warranty of
##    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##    GNU General Public License for more details.
##
##    You should have received a copy of the GNU General Public License
##    along with EdGraphZ.  If not, see <https://www.gnu.org/licenses/>.
from PyQt5.QtCore import QPointF,Qt
from PyQt5.QtGui import QColor
from PyQt5.QtWidgets import QApplication, QGraphicsItem

import view.typenode.graphicsnode as graphicsnodeimp

from controller.graphicstextitemevent import GraphicsTextItemEvent
from controller.edge_event.graphicssemiedge import GraphicsSemiEdge


class GraphicsNodeEvent(QGraphicsItem):

    def __init__(self, graph, map_to_scene, label):

        QGraphicsItem.__init__(self)
        self.edgeInConstruction = None
        self.graph = graph
        self.map_to_scene = map_to_scene
        self.text = label
        self.textItem = GraphicsTextItemEvent(self.text, map=self.map_to_scene, graph=self.graph,
                                              parent=self)




    def mouseReleaseEvent(self, mouse_event):
        super().mouseReleaseEvent(mouse_event)

        nodes = self.map_to_scene
        node = nodes[self]
        Xx = node.position_x
        Yy = node.position_y
        coord = QPointF(Xx, Yy)

        move = self.scenePos() - coord

        for item in self.scene().selectedItems():
            current_node = nodes[item]
            current_node.position_x += move.x()
            current_node.position_y += move.y()

        if self.edgeInConstruction is not None:
            self.scene().removeItem(self.edgeInConstruction)
            self.edgeInConstruction = None
            items = [it for it in self.scene().items(mouse_event.scenePos()) if
                     (isinstance(it, graphicsnodeimp.GraphicsNode or graphicsnodeimp.DiamondNode or graphicsnodeimp.TriangleNode or graphicsnodeimp.SquareNode))]
            if len(items) != 0:
                node1 = self.map_to_scene[self]
                node2 = self.map_to_scene[items[0]]
                self.graph.add_edge_element(None, node1, node2, self.graph.is_oriented, "edge", QColor("#000000"), "solid", self.graph.increment_num_id(), None)
                self.scene().refresh_main_window()

    def mouseMoveEvent(self, mouse_event):
        """
        This method is called whenever the user move the mouse

        :param mouse_event: the mouse event
        """
        super().mouseMoveEvent(mouse_event)
        modifiers = QApplication.keyboardModifiers()
        if modifiers is not Qt.ControlModifier:
            if self.edgeInConstruction is not None:
                self.edgeInConstruction.Update(mouse_event.scenePos())
        self.scene().refresh_edge_window()

    def buildEdge(self, pos):
        """
        This method build a semi-edge between the node and the cursor position

        :param pos: the other extremity of the semi-edge (must be the cursor position)

        """
        self.edgeInConstruction = GraphicsSemiEdge(self, pos, self.graph)
        self.scene().addItem(self.edgeInConstruction)

    def mousePressEvent(self, mouse_event):
        """
        This method is called when the user press a mouse button

        :param mouse_event: the mouse event
        """
        modifiers = QApplication.keyboardModifiers()
        selectedItems = self.scene().selectedItems()
        if self not in selectedItems:
            for item in selectedItems:
                item.setSelected(False)
            self.setSelected(True)
        if modifiers == Qt.NoModifier and mouse_event.button() != Qt.RightButton:
            self.setSelected(True)
            if self.graph.type_action == "edge":
                self.buildEdge(mouse_event.scenePos())
        elif mouse_event.button() == Qt.RightButton:
            self.scene().removeItem(self.edgeInConstruction)
            self.edgeInConstruction = None
        self.scene().refresh_edge_window()