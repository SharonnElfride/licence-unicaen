##Copyright 2019, 2019 DUBETTIER Adrien adriendub@yahoo.fr
##Copyright 2019, 2019 LECLERC Benjamin benjamin.leclerc7@gmail.com
##
##This file is part of EdGraphZ.
##
##    EdGraphZ is free software: you can redistribute it and/or modify
##    it under the terms of the GNU General Public License as published by
##    the Free Software Foundation, either version 3 of the License, or
##    (at your option) any later version.
##
##    EdGraphZ is distributed in the hope that it will be useful,
##    but WITHOUT ANY WARRANTY; without even the implied warranty of
##    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##    GNU General Public License for more details.
##
##    You should have received a copy of the GNU General Public License
##    along with EdGraphZ.  If not, see <https://www.gnu.org/licenses/>.
from PyQt5.QtCore import Qt, QMarginsF, QPointF
from PyQt5.QtGui import QPolygonF
from PyQt5.QtWidgets import QGraphicsEllipseItem, QGraphicsItem, QGraphicsPolygonItem, QGraphicsRectItem
from controller.graphicsnodeevent import GraphicsNodeEvent


class GraphicsNode(QGraphicsEllipseItem,GraphicsNodeEvent):
    """
    A custom QGraphicsEllipseItem. Used when drawing an ellipse-shaped node

    """

    def __init__(self, graph, map_to_scene, label):
        """
        Constructor

        :param current_state: a reference to the model
        :param pair_model_node: a dictionary linking the view and the model
        :param label: the current name of this node

        """
        super().__init__(graph, map_to_scene, label)
        self.textItem.setTextInteractionFlags(Qt.TextEditorInteraction)
        self.setRect(self.textItem.boundingRect().marginsAdded(QMarginsF(10, 10, 10, 10)))
        self.setFlags(QGraphicsItem.ItemIsSelectable)
        self.edgeInConstruction = None


###############################################################################
###############################################################################
class SquareNode(QGraphicsRectItem,GraphicsNodeEvent):
    """
    A custom QGraphicsRectItem. Used when drawing a rectangular node

    """

    def __init__(self, graph, map_to_scene, label):
        """
        Constructor

        :param current_state: a reference to the model
        :param pair_model_node: a dictionary linking the view and the model
        :param label: the current name of this node

        """
        super().__init__(graph, map_to_scene, label)

        self.textItem.setTextInteractionFlags(Qt.TextEditorInteraction)
        self.setRect(self.textItem.boundingRect().marginsAdded(QMarginsF(10, 10, 10, 10)))
        self.setFlags(QGraphicsItem.ItemIsSelectable)
        self.edgeInConstruction = None


###############################################################################
###############################################################################
class DiamondNode(QGraphicsPolygonItem,GraphicsNodeEvent):
    """
    A custom QGraphicsPolygonItem. Used when drawing a diamond-shaped node

    """

    def __init__(self, graph, map_to_scene, label):
        """
        Constructor

        :param current_state: a reference to the model
        :param pair_model_node: a dictionary linking the view and the model
        :param label: the current name of this node

        """
        super().__init__(graph, map_to_scene, label)
        textW = self.textItem.boundingRect().width()
        textH = self.textItem.boundingRect().height()
        pointA = QPointF(textW / 2, -10.)
        pointB = QPointF(textW + 10, textH / 2)
        pointC = QPointF(textW / 2, textH + 10)
        pointD = QPointF(-10., textH / 2)
        self.textItem.setTextInteractionFlags(Qt.TextEditorInteraction)
        self.setPolygon(QPolygonF([pointA, pointB, pointC, pointD]))
        self.setFlags(QGraphicsItem.ItemIsSelectable)
        self.edgeInConstruction = None


###############################################################################
###############################################################################
class TriangleNode(QGraphicsPolygonItem,GraphicsNodeEvent):
    """
    A custom QGraphicsPolygonItem. Used when drawing a triangular node

    """

    def __init__(self, graph, map_to_scene, label):
        """
        Constructor

        :param current_state: a reference to the model
        :param pair_model_node: a dictionary linking the view and the model
        :param label: the current name of this node

        """
        super().__init__(graph, map_to_scene, label)
        textW = self.textItem.boundingRect().width()
        textH = self.textItem.boundingRect().height()
        p1 = QPointF(-0.5 * textW, 1.5 * textH)
        p2 = QPointF(1.5 * textW, 1.5 * textH)
        p3 = QPointF(0.5 * textW, -1.5 * textH)
        self.textItem.setTextInteractionFlags(Qt.TextEditorInteraction)
        self.setPolygon(QPolygonF([p1, p2, p3]))
        self.setFlags(QGraphicsItem.ItemIsSelectable)
        self.edgeInConstruction = None


def graphicsnode(form, graph, map_to_scene, label):
    if form == "ellipse":
        return GraphicsNode(graph, map_to_scene, label)
    elif form == "square":
        return SquareNode(graph, map_to_scene, label)
    elif form == "triangle":
        return TriangleNode(graph, map_to_scene, label)
    elif form == "diamond":
        return DiamondNode(graph, map_to_scene, label)
    else:
        return
