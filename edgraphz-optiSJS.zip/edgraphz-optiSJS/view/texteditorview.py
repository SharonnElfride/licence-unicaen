#Text editor class

from PyQt5.QtWidgets import *

class TextEditorView():

    def __init__(self, dotFile):
        #file = open(dotFile, "r")
        #text = file.read()
        self.textEditor = QPlainTextEdit("text")
        self.textEditor.setObjectName("textEditor")
        self.textEditor.setMinimumSize(400, 700)
