##Copyright 2019, 2019 DUBETTIER Adrien adriendub@yahoo.fr
##Copyright 2019, 2019 LECLERC Benjamin benjamin.leclerc7@gmail.com
##
##This file is part of EdGraphZ.
##
##    EdGraphZ is free software: you can redistribute it and/or modify
##    it under the terms of the GNU General Public License as published by
##    the Free Software Foundation, either version 3 of the License, or
##    (at your option) any later version.
##
##    EdGraphZ is distributed in the hope that it will be useful,
##    but WITHOUT ANY WARRANTY; without even the implied warranty of
##    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##    GNU General Public License for more details.
##
##    You should have received a copy of the GNU General Public License
##    along with EdGraphZ.  If not, see <https://www.gnu.org/licenses/>.

from PyQt5.QtGui import QColor
from pydot import graph_from_dot_file

from controller.mainwindowevent import GraphicsGraph


class ImportDOT(GraphicsGraph):

    def __init__(self, graphEditor, graph, map_to_scene):
        """
        Constructor

        :param graphEditor: The actual window (scene) of the Graph.
        :type graphEditor: MainWindow
        :param current_state: The actual state of the model of the graph
        :type current_state: Graph
        :param pair_model_node: Connects the graphical interface to the model (GuiObjects: id)
        :type pair_model_node: Dictionary
        """
        super().__init__(graph, map_to_scene)
        self.graphEditor = graph_from_dot_file(graphEditor)
        self.graph = graph
        self.map_to_scene = map_to_scene

    def get_DOT(self, num):
        """
        We use pydot to parse dot file
        Read the dot file and add all element in the model
        :param num: Choose the graph you want to read in the dot file (If there are several)
        :type num: Int
        """
        generated_nodes = {}
        if self.graphEditor[num].get_graph_type() == "graph":
            self.graph.is_oriented = False
        else:
            self.graph.is_oriented = True
        nodes = self.graphEditor[num].get_node_list()
        pos_x = 20
        pos_y = 20
        for nod in nodes:
            if pos_x > 400:
                pos_x = 20
                pos_y += 80
            if isinstance(nod.get_name(), int) and int(nod.get_name()) > int(self.graph.id):
                self.graph.num_id = (int(nod.get_name()))
            self.graph.add_node_element(None, pos_x, pos_y, nod.get("label").replace('"', ''), QColor(nod.get("color").replace('"', '')), nod.get("shape").replace('"', ''), self.graph.increment_num_id(), nod.get_name())
            pos_x += 80
        edges = self.graphEditor[num].get_edge_list()
        for edg in edges:
            if isinstance(edg.get_source(), int) and int(edg.get_source()) > self.graph.get_num_id():
                self.graph.num_id = (int(edg.get_source()))
            if isinstance(edg.get_destination(), int) and int(edg.get_destination()) > self.graph.id:
                self.graph.num_id = (int(edg.get_destination()))
            for i in self.graph.all_nodes.keys() :
                if i.old_id == edg.get_source() or i.id == edg.get_source():
                    temp = i
                if i.old_id == edg.get_destination() or i.id == edg.get_destination():
                    temp2 = i
            self.graph.add_edge_element(None, temp, temp2, self.graph.is_oriented, edg.get("label").replace('"', ''), QColor(edg.get("color").replace('"', '')), edg.get("style").replace('"',''),
                        self.graph.increment_num_id(), None)
        
        self.refresh_main_window()
