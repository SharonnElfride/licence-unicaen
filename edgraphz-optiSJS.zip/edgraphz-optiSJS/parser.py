from tree_sitter import Language, Parser

parser = Parser() #creer un parser
dot_language = Language('build/dot_tree.so','dot') #lire doc pour cette ligne
parser.set_language(dot_language)

############# Notre arbre ################
tree = parser.parse(bytes("""
... digraph G{
... 1 -- 2;
... 1 -- 3;
... 3 -- 4;
... }""", "utf-8"))



print(tree.root_node.children[3].children[2].children[0].text)
print("point de départ")
print(tree.root_node.children[3].children[2].children[0].start_point)
print("point d'arriver")
print(tree.root_node.children[3].children[2].children[0].end_point)

print("####################")

print(tree.root_node.children[3].children[2].child[1].text)


