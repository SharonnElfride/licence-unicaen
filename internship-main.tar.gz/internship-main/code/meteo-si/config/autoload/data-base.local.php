<?php

use Doctrine\DBAL\Driver\PDO\PgSQL\Driver;

return [
    'doctrine' => [
        'connection' => [
            'orm_default' => [
                'driverClass' => Driver::class,
                'params' => [
//                    //Versions BD Local
                    'host' => 'db',
                    'dbname' => 'meteosi_db',
                    'port' => '5432',
                    'charset' => 'utf8',
                    'user' => 'admin',     // cf. docker-compose.yml
                    'password' => 'admin',
                ],
            ],
        ],
    ],
];