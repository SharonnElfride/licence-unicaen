<?php

return [
    'unicaen-app' => [
        'app_infos' => [
            'version' => '1.0.0',
            'date' => '05/04/2022',
        ],
    ],
    'comment' => 'Fichier généré le 05/04/2022 à 11:08:50 avec /app/bin/bump-version',
];
