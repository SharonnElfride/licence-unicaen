<?php

/**
 * !! Ce fichier de configuration doit être importé avant les autres
 */

const LDAP_MASTER_HOST = 'ldaps://ldapmaster.unicaen.fr';
const LDAP_MASTER_PORT = 636;
const LDAP_MASTER_USERNAME = 'uid=stage-trek,ou=system,dc=unicaen,dc=fr';
const LDAP_MASTER_PASSWORD = 't2nqAMrivqw3';

const LDAP_REPLICA_HOST = 'ldaps://ldap.unicaen.fr';
//const LDAP_REPLICA_HOST = 'ldaps://127.0.0.1';
//const LDAP_REPLICA_HOST         = 'lldapreplica5.unicaen.fr';
const LDAP_REPLICA_PORT = 389;
const LDAP_REPLICA_USERNAME = "uid=meteo_si,ou=system,dc=unicaen,dc=fr";
const LDAP_REPLICA_PASSWORD = "mLeDtAePo2010";

// Modifié par Sharonn
//const LDAP_REPLICA_USERNAME = "uid=stage-trek,ou=system,dc=unicaen,dc=fr";
//const LDAP_REPLICA_PASSWORD = "t2nqAMrivqw3";

//Mod par unknown
//const LDAP_REPLICA_USERNAME     = "uid=octo-read,ou=system,dc=unicaen,dc=fr";
//const LDAP_REPLICA_PASSWORD     = "APEedBszB7Vm";

const LDAP_BASE_DN = 'dc=unicaen,dc=fr';
const LDAP_BRANCH_PEOPLE = 'ou=people,dc=unicaen,dc=fr';
const LDAP_BRANCH_STRUCTURES = 'ou=structures,dc=unicaen,dc=fr';
const LDAP_BRANCH_GROUPS = 'ou=groups,dc=unicaen,dc=fr';
const LDAP_BRANCH_DEACTIVATED = 'ou=deactivated,dc=unicaen,dc=fr';
const LDAP_BRANCH_BLOCKED = 'ou=blocked,dc=unicaen,dc=fr';


return [
    // Module [Unicaen]App
    'unicaen-app' => [
        // Connexion LDAP
        'ldap' => [
            'connection' => [
                'default' => [
                    'params' => [
                        'host' => LDAP_REPLICA_HOST,
                        'port' => LDAP_REPLICA_PORT,
                        'username' => LDAP_REPLICA_USERNAME,
                        'password' => LDAP_REPLICA_PASSWORD,
                        'baseDn' => LDAP_BRANCH_PEOPLE,
                        'bindRequiresDn' => true,
                        'accountFilterFormat' => "(&(objectClass=supannPerson)(supannAliasLogin=%s))",
//                        'accountFilterFormat'   => "(&(eduPersonAffiliation=member)(!(eduPersonAffiliation=student))(supannAliasLogin=%s))",
                    ]
                ]
            ]
        ],
    ],

    // Module [Unicaen]Ldap
    'unicaen-ldap' => [
        'host' => LDAP_REPLICA_HOST,
        'port' => LDAP_REPLICA_PORT,
        'version' => 3,
        'username' => LDAP_REPLICA_USERNAME,
        'password' => LDAP_REPLICA_PASSWORD,
        'baseDn' => LDAP_BASE_DN,
        'bindRequiresDn' => true,
        'accountFilterFormat' => "(&(objectClass=posixAccount)(supannAliasLogin=%s))",
    ],

    'unicaen-auth' => [
        'local' => [
            'order' => 1,

            'enabled' => true,

            'title' => "Connectez-vous",

            'description' => "",

            /**
             * Mode d'authentification à l'aide d'un compte dans la BDD de l'application.
             */
            'db' => [
                'enabled' => true, // doit être activé pour que l'usurpation fonctionne (cf. Authentication/Storage/Db::read()) :-/
            ],

            /**
             * Mode d'authentification à l'aide d'un compte LDAP.
             */
            'ldap' => [
                'enabled' => true,
            ],
        ],

        /**
         * Configuration de l'authentification Shibboleth.
         */
        'shib' => [
            'order' => 3,
            'enabled' => false,
            'description' =>
                "Cliquez sur le bouton ci-dessous pour accéder à l'authentification via la fédération d'identité.",

            /**
             * URL de déconnexion.
             */
            'logout_url' => '/Shibboleth.sso/Logout?return=', // NB: '?return=' semble obligatoire!

            /**
             * Simulation d'authentification d'un utilisateur.
             */
            //'simulate' => [
            //    'eppn'        => 'eppn@domain.fr',
            //    'supannEmpId' => '00012345',
            //],

            /**
             * Alias éventuels des clés renseignées par Shibboleth dans la variable superglobale $_SERVER
             * une fois l'authentification réussie.
             */
            'aliases' => [
                'eppn' => 'HTTP_EPPN',
                'mail' => 'HTTP_MAIL',
                'eduPersonPrincipalName' => 'HTTP_EPPN',
                'supannEtuId' => 'HTTP_SUPANNETUID',
                'supannEmpId' => 'HTTP_SUPANNEMPID',
                'supannCivilite' => 'HTTP_SUPANNCIVILITE',
                'displayName' => 'HTTP_DISPLAYNAME',
                'sn' => 'HTTP_SN',
                'givenName' => 'HTTP_GIVENNAME',
            ],

            /**
             * Clés dont la présence sera requise par l'application dans la variable superglobale $_SERVER
             * une fois l'authentification réussie.
             */
            'required_attributes' => [
                'eppn',
                'mail',
                'eduPersonPrincipalName',
                'supannCivilite',
                'displayName',
                'sn|surname', // i.e. 'sn' ou 'surname'
                'givenName',
                'supannEtuId|supannEmpId',
            ],

            /**
             * Configuration de la stratégie d'extraction d'un identifiant utile parmi les données d'authentification
             * shibboleth.
             * Ex: identifiant de l'usager au sein du référentiel établissement, transmis par l'IDP via le supannRefId.
             */
            'shib_user_id_extractor' => [
                // domaine (ex: 'unicaen.fr') de l'EPPN (ex: hochonp@unicaen.fr')
//                'unicaen.fr' => [
//                    'supannRefId' => [
//                        // nom du 1er attribut recherché
//                        'name' => 'supannRefId', // ex: '{OCTOPUS:ID}1234;{ISO15693}044D1AZE7A5P80'
//                        // pattern éventuel pour extraire la partie intéressante
//                        'preg_match_pattern' => '|\{OCTOPUS:ID\}(\d+)|', // ex: permet d'extraire '1234'
//                    ],
//                    'supannEmpId' => [
//                        // nom du 2e attribut recherché
//                        'name' => 'supannEmpId',
//                        // pas de pattern donc valeur brute utilisée
//                        'preg_match_pattern' => null,
//                    ],
//                    'supannEtuId' => [
//                        // nom du 3e attribut recherché
//                        'name' => 'supannEtuId',
//                    ],
//                ],
                // config de repli pour tous les autres domaines
                'default' => [
                    'supannEmpId' => [
                        'name' => 'supannEmpId',
                    ],
                    'supannEtuId' => [
                        'name' => 'supannEtuId',
                    ],
                ],
            ],
        ],

        /**
         * Paramètres de connexion au serveur CAS :
         * - pour désactiver l'authentification CAS, le tableau 'cas' doit être vide.
         * - pour l'activer, renseigner les paramètres.
         */
        /**
         * Configuration de l'authentification centralisée (CAS).
         */
        'cas' => [
            /**
             * Ordre d'affichage du formulaire de connexion.
             */
            'order' => 2,

            /**
             * Activation ou non de ce mode d'authentification.
             */
            'enabled' => false,

            /**
             * Description facultative de ce mode d'authentification qui apparaîtra sur la page de connexion.
             */
            'description' => "Cliquez sur le bouton ci-dessous pour accéder à l'authentification centralisée.",
        ],


        /**
         * Identifiants de connexion LDAP autorisés à faire de l'usurpation d'identité.
         * NB: à réserver exclusivement aux tests.
         */
        'usurpation_allowed_usernames' => [
            'valleet01', '22010454',
        ],
    ],
];