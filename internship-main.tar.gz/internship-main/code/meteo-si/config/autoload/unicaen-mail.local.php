<?php
/**
 * Configuration locale du module UnicaenMail.
 */

use UnicaenMail\Entity\Db\Mail;

return [
    'unicaen-mail' => [

        /**
         * Classe de entité
         **/
        'mail_entity_class' => Mail::class,

        /**
         * Options concernant l'envoi de mail par l'application
         */
        'transport_options' => [
            'host' => 'smtp.unicaen.fr',
            'port' => 25,
        ],
        /**
         * Adresses des redirection si do_not_send est à true
         */
        'redirect_to' => ['22010454@etu.unicaen.fr'],
        'do_not_send' => true,

        /**
         * Configuration de l'expéditeur
         */
        'subject_prefix' => 'MeteoSI-Local',
        'from_name' => 'MeteoSI',
        'from_email' => 'ne-pas-repondre@unicaen.fr'
    ],
];