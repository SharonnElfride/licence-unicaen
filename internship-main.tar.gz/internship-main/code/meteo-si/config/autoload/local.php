<?php
return [
    'view_manager' => [
        'display_not_found_reason' => true,
        'display_exceptions'       => true,
    ],

];
