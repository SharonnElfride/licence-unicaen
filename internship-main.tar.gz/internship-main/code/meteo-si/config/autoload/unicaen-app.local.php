<?php
/**
 * Configuration locale du module UnicaenApp.
 *
 * If you have a ./config/autoload/ directory set up for your project,
 * drop this config file in it and change the values as you wish.
 */
return [
    'unicaen-app' => [
        /**
         * Paramétrage pour utilisation pour autorisation ou non à la connexion à
         * une app de l'exterieur de l'établissement
         */
        'hostlocalization' => [
            'activated' => false,

            'proxies' => [
                //xxx.xx.xx.xxx
            ],

            'reverse-proxies' => [
                //xxx.xx.xx.xxx
            ],

            'masque-ip' => '',

        ],
        /**
         * Connexion à l'annuaire LDAP (NB: compte admin requis)
         */
        'ldap' => [
            'connection' => [
                'default' => [
                    'params' => [
                        'host' => 'ldaps://ldap.unicaen.fr',
                        'username' => "uid=meteo_si,ou=system,dc=unicaen,dc=fr",
                        'password' => "mLeDtAePo2010",
                        //'baseDn' => "ou=xxxxxxxxxxx,dc=domain,dc=fr",
                        'baseDn' => "dc=unicaen,dc=fr",
                        'bindRequiresDn' => true,
                        'accountFilterFormat' => "(&(objectClass=posixAccount)(supannAliasLogin=%s))",
                    ]
                ]
            ]
        ],
        /**
         * Options concernant l'envoi de mail par l'application
         */
        'mail' => [
            // transport des mails
            'transport_options' => [
                'host' => 'host.domain.fr',
                'port' => 25,
            ],
            // adresse d'expédition des mails envoyés
            'from' => 'ne_pas_repondre@domain.fr',
            // adresses à substituer à celles des destinataires originaux
            'redirect_to' => ['22010454@etu.unicaen.fr'],
            // désactivation totale de l'envoi de mail par l'application
            'do_not_send' => true,
        ],
        /**
         * Mode maintenance (application indisponible)
         */
        'maintenance' => [
            // activation (TRUE: activé, FALSE: désactivé)
            'enable' => false,
            // message à afficher
            'message' => "L'application est temporairement indisponible pour des raisons de maintenance, veuillez nous excuser pour la gêne occasionnée.",
            // le mode console est-il aussi concerné (TRUE: oui, FALSE: non)
            'include_cli' => false,
            // liste blanche des adresses IP clientes à laisser passer
            'white_list' => [
                // Formats possibles : [ REMOTE_ADDR ] ou [ REMOTE_ADDR, HTTP_X_FORWARDED_FOR ]
                // exemples :
                // ['127.0.0.1'], // localhost
                // ['172.17.0.1'], // Docker container
                // ['195.220.135.97', '194.199.107.33'], // Via proxy
            ],
        ],


    ],
];