<?php

use MeteoSI\Event\ChangeEventState\ChangeEventStateEvent;
use MeteoSI\Event\NotificationToCreatorAfterADelay\NotificationToCreatorAfterADelayEvent;
use MeteoSI\Provider\Event\EventsProvider;
use MeteoSI\Service\CategorieEvenement\CategorieEvenementService;
use MeteoSI\Service\CategorieEvenement\CategorieEvenementServiceFactory;
use MeteoSI\Service\Evenement\EvenementService;
use MeteoSI\Service\Evenement\EvenementServiceFactory;
use UnicaenEvenement\Entity\Db\Type;
use UnicaenEvenement\Service\EvenementCollection\EvenementCollectionService;

return [
    'unicaen-calendar' => [
        'days' => [
            1 => [
                "number" => 1,
                "value" => "Lundi",
                "shortName" => "Lun",
            ],
            2 => [
                "number" => 2,
                "value" => "Mardi",
                "shortName" => "Mar",
            ],
            3 => [
                "number" => 3,
                "value" => "Mercredi",
                "shortName" => "Mer",
            ],
            4 => [
                "number" => 4,
                "value" => "Jeudi",
                "shortName" => "Jeu",
            ],
            5 => [
                "number" => 5,
                "value" => "Vendredi",
                "shortName" => "Ven",
            ],
            6 => [
                "number" => 6,
                "value" => "Samedi",
                "shortName" => "Sam",
            ],
            7 => [
                "number" => 7,
                "value" => "Dimanche",
                "shortName" => "Dim",
            ],
        ],

        'months' => [
            1 => [
                "number" => 1,
                "code" => "janvier",
                "value" => "Janvier",
            ],
            2 => [
                "number" => 2,
                "code" => "fevrier",
                "value" => "Février",
            ],
            3 => [
                "number" => 3,
                "code" => "mars",
                "value" => "Mars",
            ],
            4 => [
                "number" => 4,
                "code" => "avril",
                "value" => "Avril",
            ],
            5 => [
                "number" => 5,
                "code" => "mai",
                "value" => "Mai",
            ],
            6 => [
                "number" => 6,
                "code" => "juin",
                "value" => "Juin",
            ],
            7 => [
                "number" => 7,
                "code" => "juillet",
                "value" => "Juillet",
            ],
            8 => [
                "number" => 8,
                "code" => "aout",
                "value" => "Août",
            ],
            9 => [
                "number" => 9,
                "code" => "septembre",
                "value" => "Septembre",
            ],
            10 => [
                "number" => 10,
                "code" => "octobre",
                "value" => "Octobre",
            ],
            11 => [
                "number" => 11,
                "code" => "novembre",
                "value" => "Novembre",
            ],
            12 => [
                "number" => 12,
                "code" => "decembre",
                "value" => "Décembre",
            ],
        ],

        /** Services */
        'service_manager' => [
            'factories' => [
                CategorieEvenementService::class => CategorieEvenementServiceFactory::class,
                EvenementService::class => EvenementServiceFactory::class,
            ],
        ],
    ],
];