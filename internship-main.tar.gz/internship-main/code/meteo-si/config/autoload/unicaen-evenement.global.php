<?php

use MeteoSI\Event\ChangeEventState\ChangeEventStateEvent;
use MeteoSI\Event\NotificationToCreatorAfterADelay\NotificationToCreatorAfterADelayEvent;
use MeteoSI\Provider\Event\EventsProvider;
use UnicaenEvenement\Entity\Db\Type;
use UnicaenEvenement\Service\EvenementCollection\EvenementCollectionService;

return [
    'unicaen-evenement' => [
        'service' => [
            // Événements de base
            Type::COLLECTION => EvenementCollectionService::class,

            EventsProvider::CHANGE_EVENT_STATE => ChangeEventStateEvent::class,
            EventsProvider::NOTIFICATION_TO_CREATOR_AFTER_A_DELAY => NotificationToCreatorAfterADelayEvent::class,

        ],
    ],
];