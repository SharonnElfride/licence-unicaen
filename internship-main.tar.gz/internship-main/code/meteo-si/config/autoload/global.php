<?php
return [
    'translator' => [
        'locale' => 'fr_FR',
    ],
];
