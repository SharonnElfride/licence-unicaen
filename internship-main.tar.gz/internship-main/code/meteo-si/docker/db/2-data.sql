-- Données

INSERT INTO UNICAEN_UTILISATEUR_ROLE (id, role_id, libelle, is_default)
VALUES (1, 'Standard', 'Standard', true),
       (2, 'Gestionnaire', 'Gestionnaire', false),
       (3, 'Super-gestionnaire', 'Super-gestionnaire', false),
       (4, 'Administrateur', 'Administrateur', false);

INSERT INTO UNICAEN_UTILISATEUR_USER (username, email, display_name, password, state)
VALUES
    -- utilisateur demo/azerty
    ('demo', 'demo@mail.fr', 'Demo Crite', '$2y$10$PxXnVLYnGEzEnfqPqRKJSe9AabocES2H4bBK5VzzJlzuj1rVt7Lwu', true);
INSERT INTO UNICAEN_UTILISATEUR_ROLE_LINKER(user_id, role_id)
values (1, 1);


INSERT INTO UNICAEN_PRIVILEGE_CATEGORIE (code, libelle, namespace, ordre)
VALUES ('utilisateur', 'Gestion des utilisateurs', 'unicaenUtilisateur\Provider\Privilege', 1),
       ('role', 'Gestion des rôles', 'unicaenUtilisateur\Provider\Privilege', 2),
       ('privilege', 'Gestion des privilèges', 'unicaenPrivilege\Provider\Privilege', 3),
       ('evenement', 'Gestion des événements', 'Application\Provider\Privilege', 4);

INSERT INTO UNICAEN_PRIVILEGE_PRIVILEGE (categorie_id, code, libelle, ordre)
VALUES (1, 'utilisateur_afficher', 'Consulter un utilisateur', 1),
       (1, 'utilisateur_ajouter', 'Ajouter un utilisateur', 2),
       (1, 'utilisateur_changerstatus', 'Changer le statut d''un utilisateur', 3),
       (1, 'utilisateur_modifierrole', 'Modifier les rôles attribués à un utilisateur', 4),
       (2, 'role_afficher', 'Consulter les rôles', 1),
       (2, 'role_modifier', 'Modifier un rôle', 2),
       (2, 'role_effacer', 'Supprimer un rôle', 3),
       (3, 'privilege_voir', 'Afficher les privilèges', 1),
       (3, 'privilege_ajouter', 'Ajouter un privilège', 2),
       (3, 'privilege_modifier', 'Modifier un privilège', 3),
       (3, 'privilege_supprimer', 'Supprimer un privilège', 4),
       (3, 'privilege_affecter', 'Attribuer un privilège', 5),

       (4, 'evenement_afficher', 'Afficher les événements', 1),
       (4, 'evenement_ajouter', 'Ajouter un événement', 11),
       (4, 'evenement_modifier', 'Modifier un événement', 12),
       (4, 'evenement_supprimer', 'Supprimer un événement', 13),
       (4, 'categorie_evenement_afficher', 'Afficher les catégories', 2),
       (4, 'categorie_evenement_ajouter', 'Ajouter une catégorie', 21),
       (4, 'categorie_evenement_modifier', 'Modifier une catégorie', 22),
       (4, 'categorie_evenement_supprimer', 'Supprimer une catégorie', 23),
       (4, 'cible_evenement_afficher', 'Afficher les cibles', 3),
       (4, 'cible_evenement_ajouter', 'Ajouter une cible', 31),
       (4, 'cible_evenement_modifier', 'Modifier une cible', 32),
       (4, 'cible_evenement_gerer_dependance', 'Gérer les règles de transition d''une cible', 33),
       (4, 'cible_evenement_supprimer', 'Supprimer une cible', 34);

INSERT INTO unicaen_privilege_privilege_role_linker (role_id, privilege_id) (SELECT 4, p.id
                                                                             FROM unicaen_privilege_privilege p
                                                                             WHERE p.categorie_id in (1, 2, 3, 4)) ON CONFLICT DO NOTHING;

-- -----------------------------------------------------------------------------------------------------------------------------------
-- SHARONN
-- -----------------------------
-- INSERTION DE DONNEES
-- --------------------------------------------------

-- For having an account used for manipulating the events (interventions) with the console (used for managing the events - UnicaenEvenement)
INSERT INTO UNICAEN_UTILISATEUR_USER (id, username, email, display_name, password, state)
VALUES (0, 'meteosi', 'no-reply@unicaen.fr', 'Météo-SI', '$2y$10$PxXnVLYnGEzEnfqPqRKJSe9AabocES2H4bBK5VzzJlzuj1rVt7Lwu', false);

-- My accounts
INSERT INTO UNICAEN_UTILISATEUR_USER (username, email, display_name, password, state)
VALUES ('22010454', '2405kurami@gmail.com', 'Sharonn', 'ldap', true);

-- For having an admin user to work at home
-- utilisateur lolo/azerty
INSERT INTO UNICAEN_UTILISATEUR_USER (username, email, display_name, password, state)
VALUES ('lolo', '2405kurami@gmail.com', 'Lolo Sha', '$2y$10$PxXnVLYnGEzEnfqPqRKJSe9AabocES2H4bBK5VzzJlzuj1rVt7Lwu',
        true);

INSERT INTO UNICAEN_UTILISATEUR_ROLE_LINKER(user_id, role_id)
values (0, 4),
       (2, 4),
       (2, 1),
       (3, 4);

-- CATEGORIES d'événement -- add couleur (uniq)
INSERT INTO categorie_evenement (code, libelle, acronyme, couleur)
VALUES ('indeterminee', 'Indéterminée', '###', '#000'),
       ('arret', 'Arrêt', 'Arrêt', '#dc3545'),
       ('attaque', 'Attaque', 'Attq', '#d63384'),
       ('changementanneeuniversitaire', 'Changement année universitaire', 'CAUni', '#ffc107'),
       ('coupure', 'Coupure', 'Cp', '#0AA3C2'),
       ('dysfonctionnement', 'Dysfonctionnement', 'Dysf', '#157045'),
       ('indisponibilite', 'Indisponibilité', 'Ind', '#9C64F7'),
       ('interruption', 'Intérruption', 'Inter', '#86B6FE'),
       ('maintenance', 'Maintenance', 'M', '#6f42c1'),
       ('migration', 'Migration', 'Mig', '#0d6efd'),
       ('miseajour', 'Mise à jour', 'Maj', '#0dcaf0'),
       ('ouvertureanneeuniversitaire', 'Ouverture année universitaire', 'OAUni', '#adb5bd'),
       ('probleme', 'Problème', 'Prob', '#199F77'),
       ('redemarrage', 'Redémarrage', 'Red', '#fd7e14'),
       ('remplacement', 'Remplacement', 'Rem', '#20c997'),
       ('suppression', 'Suppression', 'Sup', '#DF5D9E'),
       ('test', 'Test', 'test', '#dee2e6');

-- CIBLES d'événement
INSERT INTO categorie_cible (code, libelle)
VALUES ('application', 'Application'),
       ('bdd', 'Base de données'),
       ('groupecible', 'Groupe de cibles'),
       ('infra', 'Infracstructure'),
       ('service', 'Service');

INSERT INTO etat_cible_groupe (code, libelle, niveau_gravite)
VALUES ('normal', 'Normal', 0),
       ('tresimportant', 'Très important', 3),
       ('important', 'Important', 2),
       ('pastresimportant', 'Pas très important', 1);

INSERT INTO etat_cible (code, libelle, acronyme, groupe_priorite)
VALUES ('normal', 'Normal', 'N', (SELECT id FROM etat_cible_groupe WHERE niveau_gravite=0)),
       ('panne', 'Panne', 'P', (SELECT id FROM etat_cible_groupe WHERE code='tresimportant')),
       ('indisponible', 'Indisponible', 'Ind', (SELECT id FROM etat_cible_groupe WHERE code='important')),
       ('perturbe', 'Perturbé', 'Pert', (SELECT id FROM etat_cible_groupe WHERE code='pastresimportant'));

INSERT INTO cible_evenement (libelle, description, categorie_cible, code_source, id_source, date_creation, date_modification)
VALUES ('CodePen', 'Éditeur de code en ligne', (SELECT id FROM categorie_cible WHERE code='application'), 'ctgSvcs', null, CURRENT_DATE, CURRENT_TIMESTAMP),
       ('EMC2', 'Outil de rédaction et de gestion des fiches métiers', (SELECT id FROM categorie_cible WHERE code='application'), 'ctgSvcs', null, CURRENT_DATE, CURRENT_TIMESTAMP),
       ('OSE', 'Saisie des enseignements de l''université', (SELECT id FROM categorie_cible WHERE code='application'), 'ctgSvcs', null, CURRENT_DATE, CURRENT_TIMESTAMP),
       ('SIFAC', 'Système d’information financier analytique et comptable', (SELECT id FROM categorie_cible WHERE code='application'), 'ctgSvcs', null, CURRENT_DATE, CURRENT_TIMESTAMP),
       ('Apogée', 'Application de scolarité', (SELECT id FROM categorie_cible WHERE code='application'), 'ctgSvcs', null, CURRENT_DATE, CURRENT_TIMESTAMP),
       ('Adael', 'Logiciel de gestion des absences et/ou des congés', (SELECT id FROM categorie_cible WHERE code='application'), 'ctgSvcs', null, CURRENT_DATE, CURRENT_TIMESTAMP),
       ('mysql - bdd unicaen', 'Base de données mysql', (SELECT id FROM categorie_cible WHERE code='bdd'), 'meteosi', null, CURRENT_DATE, CURRENT_TIMESTAMP),
       ('pgsql 1', 'Première base de données postgreSQL', (SELECT id FROM categorie_cible WHERE code='bdd'), 'meteosi', null, CURRENT_DATE, CURRENT_TIMESTAMP),
       ('pgsql 2', 'Seconde base de données postgreSQL', (SELECT id FROM categorie_cible WHERE code='bdd'), 'meteosi', null, CURRENT_DATE, CURRENT_TIMESTAMP),
       ('W-Oracle 1', 'Première base de données Oracle Windows', (SELECT id FROM categorie_cible WHERE code='bdd'), 'meteosi', null, CURRENT_DATE, CURRENT_TIMESTAMP),
       ('W-Oracle 2', 'Seconde base de données Oracle Windows', (SELECT id FROM categorie_cible WHERE code='bdd'), 'meteosi', null, CURRENT_DATE, CURRENT_TIMESTAMP),
       ('caen-osd-01', '', (SELECT id FROM categorie_cible WHERE code='infra'), 'netbox', 1195, '2021-06-24', '2021-07-06T11:03:07.123894+02:00'),
       ('kvm01', '', (SELECT id FROM categorie_cible WHERE code='infra'), 'netbox', 66, '2021-04-13', '2022-03-25T15:55:33.944521+01:00'),
       ('esx03', '', (SELECT id FROM categorie_cible WHERE code='infra'), 'netbox', 51, '2021-01-28', '2021-10-25T09:56:35.649695+02:00'),
       ('lxc02', '', (SELECT id FROM categorie_cible WHERE code='infra'), 'netbox', 1214, '2021-09-16', '2022-02-08T14:29:45.302576+01:00'),
       ('lb34-4', '', (SELECT id FROM categorie_cible WHERE code='infra'), 'netbox', 1243, '2022-02-01', '2022-03-24T16:13:54.943355+01:00'),
       ('lassistance-pp', '', (SELECT id FROM categorie_cible WHERE code='infra'), 'netbox', 136, '2022-02-09', '2022-02-09T11:42:42.568552+01:00'),
       ('Sondage', '', (SELECT id FROM categorie_cible WHERE code='service'), 'ctgSvcs', null, CURRENT_DATE, CURRENT_TIMESTAMP),
       ('Service SMTP', 'Envoi de mail', (SELECT id FROM categorie_cible WHERE code='service'), 'ctgSvcs', null, CURRENT_DATE, CURRENT_TIMESTAMP),
       ('BBB', 'Visio-conférence', (SELECT id FROM categorie_cible WHERE code='service'), 'ctgSvcs', null, CURRENT_DATE, CURRENT_TIMESTAMP),
       ('FileSender', 'Partage de fichiers volumineux', (SELECT id FROM categorie_cible WHERE code='service'), 'ctgSvcs', null, CURRENT_DATE, CURRENT_TIMESTAMP),
       ('Groupe Bdd PostgreSQL', '', (SELECT id FROM categorie_cible WHERE code='groupecible'), 'meteosi', null, CURRENT_DATE, CURRENT_TIMESTAMP),
       ('Groupe Bdd Oracle Windows', '', (SELECT id FROM categorie_cible WHERE code='groupecible'), 'meteosi', null, CURRENT_DATE, CURRENT_TIMESTAMP);

UPDATE cible_evenement
SET id_source=id
WHERE id_source is null;

UPDATE cible_evenement
SET code_source='meteosi'
WHERE code_source is null;

UPDATE cible_evenement
SET description='Groupe de bases de données'
WHERE id = 14;

INSERT INTO cible_evenement_application (url)
VALUES ('https://codepen.io/'),
       ('https://emc2.unicaen.fr/'),
       ('https://ose.unicaen.fr/'),
       ('#'),
       ('https://apogee.unicaen.fr:8250/FormsWebAccess/'),
       ('https://adael.unicaen.fr/');

INSERT INTO cible_evenement_application_linker(cible_id, appli_id)
VALUES (1,1), (2,2), (3,3), (4,4), (5,5), (6,6);

INSERT INTO cible_evenement_bdd (server)
VALUES ('serveur ''bdd.unicaen.fr'''),
       ('serveur 1 ''kpgSQL.unicaen.fr'''),
       ('serveur 2 ''kpgSQL.unicaen.fr'''),
       ('serveur 1 ''woracle'''),
       ('serveur 2 ''woracle''');

INSERT INTO cible_evenement_bdd_linker(cible_id, bdd_id)
VALUES (7,1), (8,2), (9,3), (10,4), (11,5);

INSERT INTO categorie_infra (code, libelle, description, total)
VALUES ('ceph', 'Serveur CEPH', 'Stockage', 23),
       ('kvm', 'Serveur KVM', 'Virtualisation peu couteuse, sans haute disponibilité intrinsèque', 13),
       ('esxi', 'Serveur ESXi', 'Virtualisation couteuse, avec haute disponibilité', 31),
       ('lxc', 'Serveur LXC', 'Virtualisation légère', 14),
       ('loadbalancer', 'Répartiteur de charges', 'Load balancer', 2),
       ('vm', 'Machine virtuelle', 'VM', 56);

INSERT INTO cible_evenement_infra (categorie_infra, site, position, status, comments)
VALUES (1, 'DCCAEN-AC5', 41, 'planned', null),
       (2, 'DCCAEN-AC5', 9, 'failed', null),
       (3, 'DCCAEN-AC5', 24, 'active', null),
       (4, 'DCCAEN-PABX', 12, 'active', null),
       (5, 'DCCAEN-PABX', 16, 'active', null),
       (6, null, null, 'active', 'Création de lassistance-pp - Ticket ID 286933');

INSERT INTO cible_evenement_infra_linker(cible_id, infra_id)
VALUES (12,1), (13,2), (14,3), (15,4), (16,5), (17,6);

INSERT INTO cible_evenement_service (details)
VALUES ('details Sondage'), ('details SMTP'), ('details BBB'), ('details FileSender');

INSERT INTO cible_evenement_service_linker(cible_id, service_id)
VALUES (18,1), (19,2), (20,3), (21,4);

INSERT INTO cible_evenement_groupe (code, cible_evenement)
VALUES ('groupebddpgsql', 22),
       ('groupebddworacle', 23);

INSERT INTO cible_evenement_groupe_linker (cible, groupe)
VALUES (8,1), (9,1), (10, 2), (11,2);

INSERT INTO cible_dependance_priorite (code, libelle, niveau_gravite)
VALUES ('forte', 'Dépendance Forte', 1),
       ('moyenne', 'Dépendance Moyenne', 2),
       ('faible', 'Dépendance Faible', 3);

INSERT INTO regle_transition(etat_parent, etat_enfant)
VALUES (1,1), (2,2), (3,3), (4,4),
       (2,1), (2,3), (2,4),
       (3,1), (3,2), (3,4),
       (4,1), (4,2), (4,3);

-- ÉVÉNEMENTS
INSERT INTO etat_evenement (code, libelle, couleur, ordre)
VALUES ('encours', 'En cours', '#dc3545', 1),
       ('avenir', 'À venir', '#fd7e14', 2),
       ('termine', 'Terminé', '#198754', 3);

-- --------------------------------------------------
-- For myself
-- --------------------------------------------------
INSERT INTO pole_utilisateur(code, libelle)
VALUES ('13', 'UFR des Sciences'),
       ('C68', 'Direction du Système d''Information (DSI)'),
       ('C68E', 'Pôle Accompagnement et Usages'),
       ('C68-1', 'Pôle Applications'),
       ('C68F', 'Pôle développement'),
       ('C68F2', 'Pôle développement - CERTIC'),
       ('C68F1', 'Pôle développement - Projets institutionnels'),
       ('C68G', 'Pôle Infrastructures'),
       ('C68G2', 'Pôle Infrastructures - Réseaux'),
       ('C68G3', 'Pôle Infrastructures - Systèmes'),
       ('C68H', 'Pôle Proximité'),
       ('C68H1', 'Pôle Proximité - Audio-visuel'),
       ('C68H-6', 'Pôle Proximité - DSI-Campus 3'),
       ('C68H-5', 'Pôle Proximité - DSI-Campus 5'),
       ('C68H2', 'Pôle Proximité - Ingénierie du poste de travail et infrastructure Microsoft'),
       ('C68H3', 'Pôle Proximité - Support'),
       ('C68H4', 'Pôle Proximité - Téléphonie');

INSERT INTO adresse_collectee (libelle, extra)
VALUES ('dsi.accompagnement@unicaen.fr', 'Nombre d''ayant droit: 4'),
       ('dsi.achat@unicaen.fr', 'Nombre d''ayant droit: 8'),
       ('dsi.direction@unicaen.fr', 'Nombre d''ayant droit: 10'),
       ('dsi.visio@unicaen.fr', 'Nombre d''ayant droit: 6'),
       ('dsi.cloud-ceph@unicaen.fr', 'Adresse collectée'),
       ('dsi.support.c1@unicaen.fr', 'Adresse collectée');

-- ---------------------------------------------------------------------------------------
-- POUR LES MAILS
-- ---------------------------------------------------------------------------------------

INSERT INTO unicaen_privilege_categorie (id ,code, libelle, namespace, ordre)
VALUES (5, 'mail', 'Gestion des mails', 'UnicaenMail\Provider\Privilege', 5)
    ON CONFLICT (id) DO
UPDATE SET
    code=excluded.code,
    libelle=excluded.libelle,
    namespace=excluded.namespace,
    ordre=excluded.ordre;

INSERT INTO unicaen_privilege_privilege (categorie_id, code, libelle, ordre)
VALUES
    (5, 'mail_index', 'Affichage de l''index', 1),
    (5, 'mail_afficher', 'Afficher un mail', 2),
    (5, 'mail_reenvoi', 'Ré-envoi d''un mail', 3),
    (5, 'mail_supprimer', 'Suppression d''un mail', 4),
    (5, 'mail_test', 'Envoi d''un mail de test', 5)
    ON CONFLICT (categorie_id, code) DO
UPDATE SET
    libelle=excluded.libelle,
    ordre=excluded.ordre;
SELECT setval('unicaen_privilege_categorie_id_seq', (
                                                        SELECT case when MAX(id) is null then 0 else MAX(id) end
                                                        FROM unicaen_privilege_categorie
                                                    )+1);
SELECT setval('unicaen_privilege_privilege_id_seq', (
                                                        SELECT case when MAX(id) is null then 0 else MAX(id) end
                                                        FROM unicaen_privilege_privilege
                                                    )+1);


INSERT INTO unicaen_privilege_privilege_role_linker (role_id, privilege_id) (
    SELECT 4, p.id
    FROM unicaen_privilege_privilege p
    WHERE p.categorie_id = 5
) ON CONFLICT DO NOTHING;

INSERT INTO unicaen_privilege_privilege_role_linker (role_id, privilege_id) (
    SELECT 3, p.id
    FROM unicaen_privilege_privilege p
    WHERE p.categorie_id = 5
      and p.code NOT IN ('mail_supprimer')
) ON CONFLICT DO NOTHING;


INSERT INTO unicaen_privilege_categorie (id ,code, libelle, namespace, ordre)
VALUES (6, 'documentmacro', 'UnicaenRenderer - Gestion des macros', 'UnicaenRenderer\Provider\Privilege', 6)
    ON CONFLICT (id) DO
UPDATE SET
    code=excluded.code,
    libelle=excluded.libelle,
    namespace=excluded.namespace,
    ordre=excluded.ordre;

INSERT INTO unicaen_privilege_privilege (categorie_id, code, libelle, ordre)
VALUES
    (6, 'documentmacro_index', 'Afficher l''index des macros', 1),
    (6, 'documentmacro_ajouter', 'Ajouter une macro', 2),
    (6, 'documentmacro_modifier', 'Modifier une macro', 3),
    (6, 'documentmacro_supprimer', 'Supprimer une macro', 4)
    ON CONFLICT (categorie_id, code) DO
UPDATE SET
    libelle=excluded.libelle,
    ordre=excluded.ordre;

-- TEMPLATE

INSERT INTO unicaen_privilege_categorie (id, code, libelle, namespace, ordre)
VALUES (7, 'documenttemplate', 'UnicaenRenderer - Gestion des templates', 'UnicaenRenderer\Provider\Privilege', 7)
    ON CONFLICT (id) DO
UPDATE SET
    code=excluded.code,
    libelle=excluded.libelle,
    namespace=excluded.namespace,
    ordre=excluded.ordre;

INSERT INTO unicaen_privilege_privilege (categorie_id, code, libelle, ordre)
VALUES
    (7, 'documenttemplate_index', 'Afficher l''index des template', 1),
    (7, 'documenttemplate_afficher', 'Afficher un template', 2),
    (7, 'documenttemplate_ajouter', 'Ajouter un template', 3),
    (7, 'documenttemplate_modifier', 'Modifier un template', 4),
    (7, 'documenttemplate_supprimer', 'Supprimer un template', 5)
    ON CONFLICT (categorie_id, code) DO
UPDATE SET
    libelle=excluded.libelle,
    ordre=excluded.ordre;


-- CONTENU
INSERT INTO unicaen_privilege_categorie (id ,code, libelle, namespace, ordre)
VALUES (8, 'documentcontenu', 'UnicaenRenderer - Gestion des contenus', 'UnicaenRenderer\Provider\Privilege', 8)
    ON CONFLICT (id) DO
UPDATE SET
    code=excluded.code,
    libelle=excluded.libelle,
    namespace=excluded.namespace,
    ordre=excluded.ordre;

INSERT INTO unicaen_privilege_privilege (categorie_id, code, libelle, ordre)
VALUES
    (8, 'documentcontenu_index', 'Accès à l''index des contenus', 1),
    (8, 'documentcontenu_afficher', 'Afficher un contenu', 2),
    (8, 'documentcontenu_supprimer', 'Supprimer un contenu', 3)
    ON CONFLICT (id) DO
UPDATE SET
    categorie_id=excluded.categorie_id,
    code=excluded.code,
    libelle=excluded.libelle,
    ordre=excluded.ordre;
SELECT setval('unicaen_privilege_categorie_id_seq', (
                                                        SELECT case when MAX(id) is null then 0 else MAX(id) end
                                                        FROM unicaen_privilege_categorie
                                                    )+1);
SELECT setval('unicaen_privilege_privilege_id_seq', (
                                                        SELECT case when MAX(id) is null then 0 else MAX(id) end
                                                        FROM unicaen_privilege_privilege
                                                    )+1);
--
-- Role linker par défaut
--

INSERT INTO unicaen_privilege_privilege_role_linker (role_id, privilege_id) (
    SELECT 4, p.id
    FROM unicaen_privilege_privilege p
    WHERE p.categorie_id in (6, 7, 8)
) ON CONFLICT DO NOTHING;

INSERT INTO unicaen_privilege_privilege_role_linker (role_id, privilege_id) (
    SELECT 3, p.id
    FROM unicaen_privilege_privilege p
    WHERE p.categorie_id in (6, 7, 8)
      and p.code NOT IN ('documentmacro_supprimer', 'documenttemplate_supprimer', 'documentcontenu_supprimer')
) ON CONFLICT DO NOTHING;

-- Insertion des macros
INSERT INTO unicaen_renderer_macro (id, code, description, variable_name, methode_name)
VALUES  (1, 'CategorieEvenement#libelle', '<p>Libellé de la catégorie d''événement</p>', 'categorieEvenement', 'getLibelle'),
        (2, 'CibleEvenement#libelle', '<p>Libellé de la cible d''événement</p>', 'cibleEvenement', 'getLibelle'),
        (3, 'EtatEvenement#libelle', '<p>L''état de l''événement</p>', 'etatEvenement', 'getLibelle'),
        (4, 'Evenement#actionsPrevues', '<p>Les actions prévues lors de l''événement</p>', 'evenement', 'getActionsPrevues'),
        (5, 'Evenement#commentaireCloture', '<p>Retour d''expérience lors de la clôture de l''événement</p>', 'evenement', 'getCommentaireCloture'),
        (6, 'Evenement#complementInformations', '<p>Les informations rajoutées aux informations de l''événement</p>', 'evenement', 'getComplementInformations'),
        (7, 'Evenement#commentaireDureeInconnue', '<p>Explication sur la durée inconnue de l''événement</p>', 'evenement', 'getCommentaireDureeInconnue'),
        (8, 'Evenement#description', '<p>La description de l''événement</p>', 'evenement', 'getDescription'),
        (9, 'EvenementInfoService#servicesAffectes', '<p>Les services affectés</p>', 'evenementInfoService', 'getServicesAffectes'),
        (10, 'EvenementInfoService#displayCreateur', '<p>Le pôle /nom du créateur à afficher</p>', 'evenementInfoService', 'getDisplayCreateur'),
        (11, 'UrlService#urlPageInformation', '<p>L''url vers la page d''information de l''application</p>', 'urlService', 'getUrlPageInformation'),
        (12, 'DateRendererService#dureePrevueEvenement', '<p>Durée prévue de l''événement</p>', 'dateRendererService', 'getDureePrevueEvenement'),
        (13, 'DateRendererService#dateDebutEvenement', '<p>Date de début de l''événement</p>', 'dateRendererService', 'getDateDebutEvenement'),
        (14, 'DateRendererService#finReelleEvenement', '<p>Date de clôture de l''événement</p>', 'dateRendererService', 'getFinReelleEvenement'),
        (15, 'DateRendererService#dateCreationEvenement', '<p>Date de création et de publication de l''événement</p>', 'dateRendererService', 'getDateCreationEvenement'),
        (16, 'DateRendererService#dateModificationEvenement', '<p>Date de modification/ré-ouverture d''un événement</p>', 'dateRendererService', 'getDateModificationEvenement'),
        (17, 'EvenementInfoService#displayReopener', '<p>Nom du pôle / de la personne qui a réouvert l''événement</p>', 'evenementInfoService', 'getDisplayReopener'),
        (18, 'EtatCible#libelle', '<p>Etat de la cible</p>', 'etatCible', 'getLibelle'),
        (19, 'EvenementInfoService#cibleParent', '<p>La cible parent sur laquelle l''événement se produit (incident/intervention)</p>', 'evenementInfoService', 'getCibleParent'),
        (20, 'Evenement#id', '<p>L''id de l''événement</p>', 'evenement', 'getId'),
        (21, 'DateRendererService#dateFinMailRappel', '<p>Date de fin estimée/au plus tôt</p>', 'dateRendererService', 'getDateFinMailRappel');

insert into unicaen_renderer_template (id, code, description, document_type, document_sujet, document_corps, document_css)
values  (1, 'nouvel-evenement', '<p>Mail envoyé à l''enrégistrement d''un événement</p>', 'mail', 'VAR[CategorieEvenement#libelle] - VAR[CibleEvenement#libelle] - VAR[EtatEvenement#libelle]', '<p>Bonjour,</p>
            <p>Vous êtes informé(e) de l''événement suivant :</p>
            <h2>VAR[CategorieEvenement#libelle] - VAR[CibleEvenement#libelle] - VAR[EtatEvenement#libelle]</h2>
            <p><em>Publié le VAR[DateRendererService#dateCreationEvenement] par VAR[EvenementInfoService#displayCreateur]<br></em></p>
            <dl>
            <dt class="altrow">Début prévu ou constaté</dt>
            <dd class="altrow">VAR[DateRendererService#dateDebutEvenement]</dd>
            <dt>Durée prévue</dt>
            <dd>VAR[DateRendererService#dureePrevueEvenement]</dd>
            <dt class="altrow">Description</dt>
            <dd class="altrow">VAR[Evenement#description]</dd>
            <dt class="altrow">Services affectés</dt>
            <dt class="altrow">VAR[EvenementInfoService#servicesAffectes]</dt>
            <dt class="altrow">Actions prévues</dt>
            <dd class="altrow">VAR[Evenement#actionsPrevues]</dd>
            </dl>
            <dl>
            <dt>Complément d''information</dt>
            <dd>VAR[Evenement#complementInformations]</dd>
            </dl>
            <p>Vous pouvez suivre les incidents et interruptions de service à l''adresse suivante VAR[UrlService#urlPageInformation]</p>', null),
        (2, 'modification-evenement', '<p>Mail envoyé à la modification d''un événement</p>', 'mail', 'VAR[CategorieEvenement#libelle] - VAR[CibleEvenement#libelle] - VAR[EtatEvenement#libelle] [Modification]', '<p>Bonjour,</p>
            <p>Vous êtes informé(e) de la modification de l''événement suivant :</p>
            <h2>VAR[CategorieEvenement#libelle] - VAR[CibleEvenement#libelle] - VAR[EtatEvenement#libelle] [Modification]</h2>
            <p><em>Publié le VAR[DateRendererService#dateCreationEvenement] par VAR[EvenementInfoService#displayCreateur]<br></em></p>
            <dl>
            <dt class="altrow">Début prévu ou constaté</dt>
            <dd class="altrow"><span id="OBJ_PREFIX_DWT56_com_zimbra_date" class="Object" role="link"><span id="OBJ_PREFIX_DWT60_com_zimbra_date" class="Object" role="link">VAR[DateRendererService#dateDebutEvenement]</span></span></dd>
            <dt>Durée prévue</dt>
            <dd>VAR[DateRendererService#dureePrevueEvenement]</dd>
            <dt class="altrow">Description</dt>
            <dd class="altrow">VAR[Evenement#description]</dd>
            <dt class="altrow">Services affectés</dt>
            <dt class="altrow">VAR[EvenementInfoService#servicesAffectes]</dt>
            <dt class="altrow">Actions prévues</dt>
            <dd class="altrow">VAR[Evenement#actionsPrevues]</dd>
            </dl>
            <dl>
            <dt>Complément d''information</dt>
            <dd>VAR[Evenement#complementInformations]</dd>
            </dl>
            <p>Vous pouvez suivre les incidents et interruptions de service à l''adresse suivante VAR[UrlService#urlPageInformation]</p>', null),
        (3, 're-ouverture-evenement', '<p>Mail envoyé à la réouverture d''un événement</p>', 'mail', 'VAR[CategorieEvenement#libelle] - VAR[CibleEvenement#libelle] - VAR[EtatEvenement#libelle] [Réouverture]', '<p>Bonjour,</p>
            <p>Vous êtes informé(e) de la réouverture de l''événement suivant :</p>
            <h2>VAR[CategorieEvenement#libelle] - VAR[CibleEvenement#libelle] - VAR[EtatEvenement#libelle] [Réouverture]</h2>
            <p><em>Publié le VAR[DateRendererService#dateCreationEvenement] par VAR[EvenementInfoService#displayCreateur]<br></em></p>
            <p><em>Réouvert le VAR[DateRendererService#dateModificationEvenement] par VAR[EvenementInfoService#displayReopener]<br></em></p>
            <dl>
            <dt class="altrow">Début prévu ou constaté</dt>
            <dd class="altrow">VAR[DateRendererService#dateDebutEvenement]</dd>
            <dt>Durée prévue</dt>
            <dd>VAR[DateRendererService#dureePrevueEvenement]</dd>
            <dt class="altrow">Description</dt>
            <dd class="altrow">VAR[Evenement#description]</dd>
            <dt class="altrow">Services affectés</dt>
            <dt class="altrow">VAR[EvenementInfoService#servicesAffectes]</dt>
            <dt class="altrow">Actions prévues</dt>
            <dd class="altrow">VAR[Evenement#actionsPrevues]</dd>
            </dl>
            <dl>
            <dt>Complément d''information</dt>
            <dd>VAR[Evenement#complementInformations]</dd>
            </dl>
            <p>Vous pouvez suivre les incidents et interruptions de service à l''adresse suivante VAR[UrlService#urlPageInformation]</p>', null),
        (4, 'fin-evenement', '<p>Mail envoyé à la fin d''un événement</p>', 'mail', 'VAR[CategorieEvenement#libelle] - VAR[CibleEvenement#libelle] - Terminé', '<p>Bonjour,</p>
            <p>Vous êtes informé(e) de la fin de l''événement suivant :</p>
            <h2>VAR[CategorieEvenement#libelle] - VAR[CibleEvenement#libelle] - VAR[EtatEvenement#libelle]</h2>
            <p><em>Publié le VAR[DateRendererService#dateCreationEvenement] par VAR[EvenementInfoService#displayCreateur]<br></em></p>
            <dl>
            <dt class="altrow">Début prévu ou constaté</dt>
            <dd class="altrow">VAR[DateRendererService#dateDebutEvenement]</dd>
            <dt>Date de fin</dt>
            <dd>VAR[DateRendererService#finReelleEvenement]</dd>
            <dt class="altrow">Description</dt>
            <dd class="altrow">VAR[Evenement#description]</dd>
            <dt class="altrow">Services affectés</dt>
            <dt class="altrow">VAR[EvenementInfoService#servicesAffectes]</dt>
            <dt class="altrow">Actions effectuées</dt>
            <dd class="altrow">VAR[Evenement#actionsPrevues]</dd>
            </dl>
            <dl>
            <dt>Retours d''expérience</dt>
            <dd>VAR[Evenement#commentaireCloture]</dd>
            </dl>
            <p>Vous pouvez suivre les incidents et interruptions de service à l''adresse suivante VAR[UrlService#urlPageInformation]</p>', null),
        (5, 'mail-d-enregistrement-envoye-aux-cibles-enfants', '<p>Le mail envoyé aux cibles enfants de la cible de l''événement lors de l''enrégistrement de l''événement</p>', 'mail', 'VAR[CibleEvenement#libelle] - VAR[EtatCible#libelle] - [Enrégistrement]', '<p>Bonjour,</p>
            <p>Nous vous informons de l''événement suivant:</p>
            <h2>VAR[EtatCible#libelle] - VAR[CibleEvenement#libelle] - VAR[EtatEvenement#libelle] - [Dépendance]</h2>
            <p>Un incident  a été signalé ou une intervention est [<strong><em>VAR[EtatEvenement#libelle]</em></strong>] sur <em><strong>VAR[EvenementInfoService#cibleParent]</strong></em>.</p>
            <p>De ce fait, <strong>VAR[CibleEvenement#libelle]</strong> sera en état : <strong>VAR[EtatCible#libelle]</strong><strong>.</strong></p>
            <dl>
            <dt>Durée prévue</dt>
            <dd>VAR[DateRendererService#dureePrevueEvenement]</dd>
            </dl>
            <p>Nous vous informerons lors du retour à la normale de <strong>VAR[CibleEvenement#libelle]</strong>.</p>
            <p>Veuillez nous excuser pour le désagrément et la gêne occasionnée.</p>
            <p>Vous pouvez suivre les incidents et interruptions de service à l''adresse suivante VAR[UrlService#urlPageInformation]</p>', null),
        (6, 'mail-de-modification-envoye-aux-cibles-enfants', '<p>Le mail envoyé aux cibles enfants de la cible de l''événement lors de la modification de l''événement</p>', 'mail', 'VAR[CibleEvenement#libelle] - VAR[EtatCible#libelle] - [Modification]', '<p>Bonjour,</p>
            <p>Nous vous informons de l''événement suivant:</p>
            <h2>VAR[EtatCible#libelle] - VAR[CibleEvenement#libelle] - VAR[EtatEvenement#libelle] - [Dépendance]</h2>
            <p>Modification de l''incident signalé ou de l''intervention [<strong><em>VAR[EtatEvenement#libelle]</em></strong>] sur <em><strong>VAR[EvenementInfoService#cibleParent]</strong></em>.</p>
            <p>De ce fait, <strong>VAR[CibleEvenement#libelle]</strong> sera en état : <strong>VAR[EtatCible#libelle]</strong><strong>.</strong></p>
            <dl>
            <dt>Durée prévue</dt>
            <dd>VAR[DateRendererService#dureePrevueEvenement]</dd>
            </dl>
            <p>Nous vous informerons lors du retour à la normale de <strong>VAR[CibleEvenement#libelle]</strong>.</p>
            <p>Veuillez nous excuser pour le désagrément et la gêne occasionnée.</p>
            <p>Vous pouvez suivre les incidents et interruptions de service à l''adresse suivante VAR[UrlService#urlPageInformation]</p>', null),
        (7, 'mail-de-fin-envoye-aux-cibles-enfants', '<p>Le mail envoyé aux cibles enfants de la cible de l''événement lors de la fin de l''événement</p>', 'mail', 'VAR[CibleEvenement#libelle] - VAR[EtatCible#libelle] - [Rétablissement]', '<p>Bonjour,</p>
            <p>Nous vous informons du retour à la normale de <strong>VAR[CibleEvenement#libelle]</strong>.</p>
            <p>Merci de votre compréhension.</p>
            <p>Vous pouvez suivre les incidents et interruptions de service à l''adresse suivante VAR[UrlService#urlPageInformation]</p>', null),
        (8, 'mail-de-reouverture-envoye-aux-cibles-enfants', '<p>Le mail envoyé aux cibles enfants de la cible de l''événement lors de la réouverture d''un événement</p>', 'mail', 'VAR[CibleEvenement#libelle] - VAR[EtatCible#libelle] - [Réouverture]', '<p>Bonjour,</p>
            <p>Nous vous informons de l''événement suivant:</p>
            <h2>VAR[EtatCible#libelle] - VAR[CibleEvenement#libelle] - VAR[EtatEvenement#libelle] - [Dépendance]</h2>
            <p>Un incident  a été signalé ou une intervention est [<strong><em>VAR[EtatEvenement#libelle]</em></strong>] sur <em><strong>VAR[EvenementInfoService#cibleParent]</strong></em>.</p>
            <p>De ce fait, <strong>VAR[CibleEvenement#libelle]</strong> sera en état : <strong>VAR[EtatCible#libelle]</strong><strong>.</strong></p>
            <dl>
            <dt>Durée prévue</dt>
            <dd>VAR[DateRendererService#dureePrevueEvenement]</dd>
            </dl>
            <p>Nous vous informerons lors du retour à la normale de <strong>VAR[CibleEvenement#libelle]</strong>.</p>
            <p>Veuillez nous excuser pour le désagrément et la gêne occasionnée.</p>
            <p>Vous pouvez suivre les incidents et interruptions de service à l''adresse suivante VAR[UrlService#urlPageInformation]</p>', null),
        (9, 'notification-de-rappel-au-createur-d-un-evenement-pour-sa-cloture', '<p>Mail envoyé au créateur de l''event chaque 1h à compter de la date de fin estimée ou au plus tôt</p>', 'mail', 'Mail de rappel pour la fermeture d''un événement - [VAR[Evenement#id]]', '<p>Bonjour,</p>
            <p>Ceci est un<em> </em><strong>mail de rappel</strong>!</p>
            <p>Vous avez créé un événement Météo-SI <strong>le VAR[DateRendererService#dateCreationEvenement]</strong></p>
            <p>Il s''agit de : <strong>l''événement N°VAR[Evenement#id] de catégorie VAR[CategorieEvenement#libelle] sur VAR[CibleEvenement#libelle]</strong></p>
            <dl>
            <dt>Description de l''événement</dt>
            <dd>VAR[Evenement#description]</dd>
            </dl>
            <dl>
            <dt>Complément d''information</dt>
            <dd>VAR[Evenement#complementInformations]</dd>
            </dl>
            <p>Vous avez renseigné VAR[DateRendererService#dateFinMailRappel]</p>
            <p>Le problème est-il résolu ? N''oubliez pas de clôturer l''événement si c''est le cas!</p>
            <p>Merci de votre compréhension!</p>', null),
        (10, 'test-test', null, 'pdf', 'test-test', '<p>test-test</p>', null),
        (11, 'test-template-textuel', null, 'texte', 'test-template-textuel', '<p>test-template-textuel</p>', null);


-- ---------------------------------------------------------------------------------------
-- POUR LES EVENEMENTS (UnicaenEvenement)
-- ---------------------------------------------------------------------------------------

INSERT INTO unicaen_evenement_etat (id, code, libelle) VALUES (1, 'en_attente', 'En attente');
INSERT INTO unicaen_evenement_etat (id, code, libelle) VALUES (2, 'en_cours', 'En cours');
INSERT INTO unicaen_evenement_etat (id, code, libelle) VALUES (3, 'echec', 'Échec');
INSERT INTO unicaen_evenement_etat (id, code, libelle) VALUES (4, 'succes', 'Succès');

-- EVENEMENT --------------------------------------------------------------------------------------------------

INSERT INTO unicaen_privilege_categorie (code, libelle, ordre, namespace)
VALUES ('evenementetat', 'Gestion des événements - État', 99991, 'UnicaenEvenement\Provider\Privilege');
INSERT INTO unicaen_privilege_privilege(CATEGORIE_ID, CODE, LIBELLE, ORDRE)
WITH d(code, lib, ordre) AS (
    SELECT 'etat_consultation', 'état - consultation', 10 UNION
    SELECT 'etat_ajout', 'état - ajout', 20 UNION
    SELECT 'etat_edition', 'état - édition', 30 UNION
    SELECT 'etat_suppression', 'état - suppression', 40
)
SELECT cp.id, d.code, d.lib, d.ordre
FROM d
         JOIN unicaen_privilege_categorie cp ON cp.CODE = 'evenementetat';

INSERT INTO unicaen_privilege_categorie (code, libelle, ordre, namespace)
VALUES ('evenementinstance', 'Gestion des événements - Instance', 99993, 'UnicaenEvenement\Provider\Privilege');
INSERT INTO unicaen_privilege_privilege(CATEGORIE_ID, CODE, LIBELLE, ORDRE)
WITH d(code, lib, ordre) AS (
    SELECT 'instance_consultation', 'instance - consultation', 10 UNION
    SELECT 'instance_ajout', 'instance - ajout', 20 UNION
    SELECT 'instance_edition', 'instance - édition', 30 UNION
    SELECT 'instance_suppression', 'instance - suppression', 40 UNION
    SELECT 'instance_traitement', 'instance - traitement', 100
)
SELECT cp.id, d.code, d.lib, d.ordre
FROM d
         JOIN unicaen_privilege_categorie cp ON cp.CODE = 'evenementinstance';

INSERT INTO unicaen_privilege_categorie (code, libelle, ordre, namespace)
VALUES ('evenementtype', 'Gestion des événements - Type', 99992, 'UnicaenEvenement\Provider\Privilege');
INSERT INTO unicaen_privilege_privilege(CATEGORIE_ID, CODE, LIBELLE, ORDRE)
WITH d(code, lib, ordre) AS (
    SELECT 'type_consultation', 'type - consultation', 10 UNION
    SELECT 'type_ajout', 'type - ajout', 20 UNION
    SELECT 'type_edition', 'type - édition', 30 UNION
    SELECT 'type_suppression', 'type - suppression', 40
)
SELECT cp.id, d.code, d.lib, d.ordre
FROM d
         JOIN unicaen_privilege_categorie cp ON cp.CODE = 'evenementtype';

-- Pour attribuer les privilèges à l'administrateur
-- INSERT INTO unicaen_privilege_privilege_role_linker (role_id, privilege_id) (
--     SELECT 4, p.id
--     FROM unicaen_privilege_privilege p
--     WHERE p.categorie_id in (6, 7, 8)
-- ) ON CONFLICT DO NOTHING;


-- Ajouter les événements par défauts
insert into unicaen_evenement_type (id, code, libelle, description, parametres, recursion)
values  (1, 'change-event-state', 'Changer l''état de l''événement', ' (incident/intervention) Change l''état de l''événement de "À venir" à "En cours"!', null, 'PT10M'),
        (2, 'notification-to-creator-after-a-delay-event', 'Notification au créateur de l''événement après un certain temps', 'Notification au créateur de l''événement après un certain temps passé après la date de fin estimée ou celle au plus tôt', null, 'PT1H');

insert into public.unicaen_evenement_instance (nom, description, type_id, etat_id, date_creation, date_planification, date_traitement)
values  ('changeState', 'change state', 1, 1, '2022-06-27 17:24:49.000000', '2022-06-27 17:34:49.000000', null),
        ('notificationToCreatorAfterADelay', 'Notifier le créateur d''un événement de le passer en état terminé', 2, 1, '2022-06-27 17:24:54.000000', '2022-06-27 18:24:54.000000', null);

