-- -----------------------------------------------------
-- TABLE UNICAEN_UTILISATEUR_ROLE
-- -----------------------------------------------------
CREATE TABLE UNICAEN_UTILISATEUR_ROLE
(
    ID                   SERIAL PRIMARY KEY,
    ROLE_ID              VARCHAR(64)                NOT NULL,
    LIBELLE              VARCHAR(255)               NOT NULL,
    IS_DEFAULT           BOOLEAN      DEFAULT false NOT NULL,
    IS_AUTO              BOOLEAN      DEFAULT false NOT NULL,
    PARENT_ID            INTEGER,
    LDAP_FILTER          VARCHAR(255) DEFAULT NULL:: character varying,
    ACCESSIBLE_EXTERIEUR BOOLEAN      DEFAULT true  NOT NULL,
    CONSTRAINT FK_UNICAEN_UTILISATEUR_ROLE_PARENT FOREIGN KEY (PARENT_ID) REFERENCES UNICAEN_UTILISATEUR_ROLE (ID) DEFERRABLE INITIALLY IMMEDIATE
);

CREATE UNIQUE INDEX UN_UNICAEN_UTILISATEUR_ROLE_ROLE_ID ON UNICAEN_UTILISATEUR_ROLE (ROLE_ID);
CREATE INDEX IX_UNICAEN_UTILISATEUR_ROLE_PARENT ON UNICAEN_UTILISATEUR_ROLE (PARENT_ID);


-- -----------------------------------------------------
-- TABLE UNICAEN_UTILISATEUR_USER
-- -----------------------------------------------------
CREATE TABLE UNICAEN_UTILISATEUR_USER
(
    ID                   SERIAL PRIMARY KEY,
    USERNAME             VARCHAR(255)              NOT NULL,
    DISPLAY_NAME         VARCHAR(255)              NOT NULL,
    EMAIL                VARCHAR(255),
    PASSWORD             VARCHAR(128) DEFAULT 'application':: character varying NOT NULL,
    STATE                BOOLEAN      DEFAULT true NOT NULL,
    PASSWORD_RESET_TOKEN VARCHAR(256),
    LAST_ROLE_ID         INTEGER,
    CONSTRAINT UN_UNICAEN_UTILISATEUR_USER_USERNAME UNIQUE (USERNAME),
    CONSTRAINT UN_UNICAEN_UTILISATEUR_USER_PASSWORD_RESET_TOKEN UNIQUE (PASSWORD_RESET_TOKEN),
    CONSTRAINT FK_UNICAEN_UTILISATEUR_USER_LAST_ROLE FOREIGN KEY (LAST_ROLE_ID) REFERENCES UNICAEN_UTILISATEUR_ROLE (ID) DEFERRABLE INITIALLY IMMEDIATE
);

-- CREATE UNIQUE INDEX UN_UNICAEN_UTILISATEUR_USER_USERNAME ON UNICAEN_UTILISATEUR_USER(USERNAME);
-- CREATE UNIQUE INDEX UN_UNICAEN_UTILISATEUR_USER_PASSWORD_RESET_TOKEN ON UNICAEN_UTILISATEUR_USER(PASSWORD_RESET_TOKEN);
CREATE INDEX IX_UNICAEN_UTILISATEUR_USER_LAST_ROLE ON UNICAEN_UTILISATEUR_USER (LAST_ROLE_ID);


-- -----------------------------------------------------
-- TABLE UNICAEN_UTILISATEUR_ROLE_LINKER
-- -----------------------------------------------------
CREATE TABLE UNICAEN_UTILISATEUR_ROLE_LINKER
(
    USER_ID INTEGER NOT NULL,
    ROLE_ID INTEGER NOT NULL,
    CONSTRAINT PK_UNICAEN_UTILISATEUR_ROLE_LINKER PRIMARY KEY (USER_ID, ROLE_ID),
    CONSTRAINT FK_UNICAEN_UTILISATEUR_ROLE_LINKER_USER FOREIGN KEY (USER_ID) REFERENCES UNICAEN_UTILISATEUR_USER (ID) DEFERRABLE INITIALLY IMMEDIATE,
    CONSTRAINT FK_UNICAEN_UTILISATEUR_ROLE_LINKER_ROLE FOREIGN KEY (ROLE_ID) REFERENCES UNICAEN_UTILISATEUR_ROLE (ID) DEFERRABLE INITIALLY IMMEDIATE
);

CREATE INDEX IX_UNICAEN_UTILISATEUR_ROLE_LINKER_USER ON UNICAEN_UTILISATEUR_ROLE_LINKER (USER_ID);
CREATE INDEX IX_UNICAEN_UTILISATEUR_ROLE_LINKER_ROLE ON UNICAEN_UTILISATEUR_ROLE_LINKER (ROLE_ID);


-- -----------------------------------------------------
-- TABLE UNICAEN_PRIVILEGE_CATEGORIE
-- -----------------------------------------------------
CREATE TABLE UNICAEN_PRIVILEGE_CATEGORIE
(
    ID        SERIAL PRIMARY KEY,
    CODE      VARCHAR(150) NOT NULL,
    LIBELLE   VARCHAR(200) NOT NULL,
    NAMESPACE VARCHAR(255),
    ORDRE     INTEGER DEFAULT 0
);

CREATE UNIQUE INDEX UN_UNICAEN_PRIVILEGE_CATEGORIE_CODE ON UNICAEN_PRIVILEGE_CATEGORIE (CODE);

-- -----------------------------------------------------
-- TABLE UNICAEN_PRIVILEGE
-- -----------------------------------------------------
CREATE TABLE UNICAEN_PRIVILEGE_PRIVILEGE
(
    ID           SERIAL PRIMARY KEY,
    CATEGORIE_ID INTEGER      NOT NULL,
    CODE         VARCHAR(150) NOT NULL,
    LIBELLE      VARCHAR(200) NOT NULL,
    ORDRE        INTEGER DEFAULT 0,
    CONSTRAINT FK_UNICAEN_PRIVILEGE_CATEGORIE FOREIGN KEY (CATEGORIE_ID) REFERENCES UNICAEN_PRIVILEGE_CATEGORIE (ID) DEFERRABLE INITIALLY IMMEDIATE
);

CREATE UNIQUE INDEX UN_UNICAEN_PRIVILEGE_CODE ON UNICAEN_PRIVILEGE_PRIVILEGE (CATEGORIE_ID, CODE);
CREATE INDEX IX_UNICAEN_PRIVILEGE_CATEGORIE ON UNICAEN_PRIVILEGE_PRIVILEGE (CATEGORIE_ID);


-- -----------------------------------------------------
-- TABLE UNICAEN_ROLE_PRIVILEGE_LINKER
-- -----------------------------------------------------
CREATE TABLE UNICAEN_PRIVILEGE_PRIVILEGE_ROLE_LINKER
(
    ROLE_ID      INTEGER NOT NULL,
    PRIVILEGE_ID INTEGER NOT NULL,
    CONSTRAINT PK_UNICAEN_PRIVILEGE_PRIVILEGE_ROLE_LINKER PRIMARY KEY (ROLE_ID, PRIVILEGE_ID),
    CONSTRAINT FK_UNICAEN_PRIVILEGE_PRIVILEGE_ROLE_LINKER_ROLE FOREIGN KEY (ROLE_ID) REFERENCES UNICAEN_UTILISATEUR_ROLE (ID) DEFERRABLE INITIALLY IMMEDIATE,
    CONSTRAINT FK_UNICAEN_PRIVILEGE_PRIVILEGE_ROLE_LINKER_PRIVILEGE FOREIGN KEY (PRIVILEGE_ID) REFERENCES UNICAEN_PRIVILEGE_PRIVILEGE (ID) DEFERRABLE INITIALLY IMMEDIATE
);

CREATE INDEX IX_UNICAEN_PRIVILEGE_PRIVILEGE_ROLE_LINKER_ROLE ON UNICAEN_PRIVILEGE_PRIVILEGE_ROLE_LINKER (ROLE_ID);
CREATE INDEX IX_UNICAEN_PRIVILEGE_PRIVILEGE_ROLE_LINKER_PRIVILEGE ON UNICAEN_PRIVILEGE_PRIVILEGE_ROLE_LINKER (PRIVILEGE_ID);

-- -----------------------------------------------------------------------------------------------------------------------------------
-- SHARONN
-- -----------------------------
-- CREATION DE TABLES
-- ----------------------------------------------------
-- CIBLES d'événement
CREATE TABLE categorie_cible
(
    id      SERIAL PRIMARY KEY,
    code    VARCHAR(255) UNIQUE NOT NULL,
    libelle VARCHAR(255)        NOT NULL
);

CREATE TABLE etat_cible_groupe
(
    id             SERIAL PRIMARY KEY,
    code           VARCHAR(255) UNIQUE NOT NULL,
    libelle        VARCHAR(255)        NOT NULL,
    niveau_gravite BIGINT              NOT NULL
);

CREATE TABLE etat_cible
(
    id              SERIAL PRIMARY KEY,
    code            VARCHAR(255) UNIQUE                 NOT NULL,
    libelle         VARCHAR(255) UNIQUE                 NOT NULL,
    acronyme        VARCHAR(255) UNIQUE,
    groupe_priorite BIGINT REFERENCES etat_cible_groupe NOT NULL
);

CREATE TABLE cible_evenement
(
    id                          SERIAL PRIMARY KEY,
    libelle                     VARCHAR(255)                           NOT NULL,
    description                 TEXT,
    categorie_cible             BIGINT REFERENCES categorie_cible      NOT NULL,
    etat                        BIGINT REFERENCES etat_cible DEFAULT 1 NOT NULL,
    given_state_by_evenement BIGINT REFERENCES etat_cible DEFAULT NULL,
    code_source                 VARCHAR(255)                 DEFAULT 'meteosi',
    id_source                   BIGINT,
    date_creation               DATE                                   NOT NULL,
    date_modification           TIMESTAMPTZ                            NOT NULL
);

CREATE TABLE cible_evenement_application
(
    id  SERIAL PRIMARY KEY,
    url TEXT
);

CREATE TABLE cible_evenement_application_linker
(
    cible_id BIGINT REFERENCES cible_evenement ON DELETE CASCADE UNIQUE,
    appli_id BIGINT REFERENCES cible_evenement_application ON DELETE CASCADE UNIQUE,
    PRIMARY KEY (cible_id, appli_id)
);

CREATE TABLE cible_evenement_bdd
(
    id     SERIAL PRIMARY KEY,
    server VARCHAR(255)
);

CREATE TABLE cible_evenement_bdd_linker
(
    cible_id BIGINT REFERENCES cible_evenement ON DELETE CASCADE UNIQUE,
    bdd_id   BIGINT REFERENCES cible_evenement_bdd ON DELETE CASCADE UNIQUE,
    PRIMARY KEY (cible_id, bdd_id)
);

CREATE TABLE categorie_infra
(
    id          SERIAL PRIMARY KEY,
    code        VARCHAR(255) UNIQUE NOT NULL,
    libelle     VARCHAR(255)        NOT NULL,
    description TEXT,
    total       BIGINT
);

CREATE TABLE cible_evenement_infra
(
    id              SERIAL PRIMARY KEY,
    categorie_infra BIGINT REFERENCES categorie_infra (id),
    site            VARCHAR(255),
    position        BIGINT,
    status          VARCHAR(255) NOT NULL,
    comments        TEXT
);

CREATE TABLE cible_evenement_infra_linker
(
    cible_id BIGINT REFERENCES cible_evenement ON DELETE CASCADE UNIQUE,
    infra_id BIGINT REFERENCES cible_evenement_infra ON DELETE CASCADE UNIQUE,
    PRIMARY KEY (cible_id, infra_id)
);

CREATE TABLE cible_evenement_service
(
    id      SERIAL PRIMARY KEY,
    details TEXT
);

CREATE TABLE cible_evenement_service_linker
(
    cible_id   BIGINT REFERENCES cible_evenement ON DELETE CASCADE UNIQUE,
    service_id BIGINT REFERENCES cible_evenement_service ON DELETE CASCADE UNIQUE,
    PRIMARY KEY (cible_id, service_id)
);

CREATE TABLE cible_evenement_groupe
(
    id                 SERIAL PRIMARY KEY,
    code               VARCHAR(255) UNIQUE                                    NOT NULL,
    cible_evenement BIGINT REFERENCES cible_evenement ON DELETE CASCADE NOT NULL
);

CREATE TABLE cible_evenement_groupe_linker
(
    cible  BIGINT REFERENCES cible_evenement,
    groupe BIGINT REFERENCES cible_evenement_groupe,
    PRIMARY KEY (cible, groupe)
);

CREATE TABLE cible_dependance_priorite
(
    id             SERIAL PRIMARY KEY,
    code           VARCHAR(255) UNIQUE NOT NULL,
    libelle        VARCHAR(255)        NOT NULL,
    niveau_gravite BIGINT              NOT NULL
);

CREATE TABLE cible_dependance
(
    id              SERIAL PRIMARY KEY,
    parent          BIGINT REFERENCES cible_evenement ON DELETE CASCADE NOT NULL,
    enfant          BIGINT REFERENCES cible_evenement ON DELETE CASCADE NOT NULL,
    parent_priorite BIGINT REFERENCES cible_dependance_priorite            NOT NULL,
    CONSTRAINT parent_enfant_unique UNIQUE (parent, enfant)
);

CREATE TABLE regle_transition
(
    id          SERIAL PRIMARY KEY,
    etat_parent BIGINT REFERENCES etat_cible NOT NULL,
    etat_enfant BIGINT REFERENCES etat_cible NOT NULL
);

CREATE TABLE cible_dependance_regle_transition_linker
(
    dependance       BIGINT REFERENCES cible_dependance ON DELETE CASCADE NOT NULL,
    regle_transition BIGINT REFERENCES regle_transition ON DELETE CASCADE NOT NULL,
    PRIMARY KEY (dependance, regle_transition)
);

-- CATEGORIES d'événement
-- Ajouter dans categorie_evenement 'ordre_affichage INTEGER UNIQUE NOT NULL' si l'on veut ordonner les catégories
CREATE TABLE categorie_evenement
(
    id       SERIAL PRIMARY KEY,
    code     VARCHAR(255) UNIQUE NOT NULL,
    libelle  VARCHAR(255)        NOT NULL,
    acronyme VARCHAR(255) UNIQUE,
    couleur VARCHAR(255)
);

-- For myself
CREATE TABLE pole_utilisateur
(
    id      SERIAL PRIMARY KEY,
    code    VARCHAR(255) UNIQUE NOT NULL,
    libelle VARCHAR(255)        NOT NULL
);

CREATE TABLE adresse_collectee
(
    id      SERIAL PRIMARY KEY,
    libelle VARCHAR(255) NOT NULL,
    extra   TEXT
);

-- ÉVÉNEMENTS
CREATE TABLE etat_evenement
(
    id      SERIAL PRIMARY KEY,
    code    VARCHAR(255) UNIQUE NOT NULL,
    libelle VARCHAR(255) UNIQUE NOT NULL,
    couleur VARCHAR(255),
    ordre   BIGINT UNIQUE       NOT NULL
);

CREATE TABLE evenement
(
    id                         SERIAL PRIMARY KEY,
    evenement_ref           BIGINT REFERENCES evenement DEFAULT NULL,
    categorie                  BIGINT                         DEFAULT 1 REFERENCES categorie_evenement ON DELETE SET DEFAULT NOT NULL,
    cible                      BIGINT REFERENCES cible_evenement ON DELETE RESTRICT                                          NOT NULL,
    description                TEXT,
    actions_prevues            TEXT,
    date_debut                 TIMESTAMP                                                                                        NOT NULL,
    date_fin_estimee           TIMESTAMP,
    date_fin_minimale          TIMESTAMP,
    date_fin_reelle            TIMESTAMP,
    duree_inconnue             BOOLEAN                        DEFAULT false,
    commentaire_duree_inconnue TEXT,
    etat                       BIGINT REFERENCES etat_evenement                                                              NOT NULL,
    publie_intranet            BOOLEAN                        DEFAULT false,
    publie_internet            BOOLEAN                        DEFAULT false,
    display_name_createur      VARCHAR(255),
    envoi_mail                 BOOLEAN                        DEFAULT false,
    destinataires              TEXT,
    complement_informations    TEXT,
    pole                       BIGINT REFERENCES pole_utilisateur,
    clotureur                  BIGINT REFERENCES UNICAEN_UTILISATEUR_USER,
    date_cloture               TIMESTAMP,
    commentaire_cloture        TEXT,
    histo_creation             TIMESTAMP                                                                                        NOT NULL,
    histo_createur             BIGINT REFERENCES UNICAEN_UTILISATEUR_USER                                                       NOT NULL,
    histo_modification         TIMESTAMP                                                                                        NOT NULL,
    histo_modificateur         BIGINT REFERENCES UNICAEN_UTILISATEUR_USER                                                       NOT NULL,
    histo_destruction          TIMESTAMP,
    histo_destructeur          BIGINT REFERENCES UNICAEN_UTILISATEUR_USER,
    CHECK (evenement.date_debut <= evenement.date_fin_estimee),
    CHECK (evenement.date_debut <= evenement.date_fin_minimale),
    CHECK (evenement.date_debut <= evenement.date_fin_reelle)
);

-- ---------------------------------------------------------------------------------------
-- POUR LES MAILS
-- ---------------------------------------------------------------------------------------

create table unicaen_mail_mail
(
    id                     serial
        constraint umail_pkey
            primary key,
    date_envoi             timestamp    not null,
    status_envoi           varchar(256) not null,
    destinataires          text         not null,
    destinataires_initials text,
    sujet                  text,
    corps                  text,
    mots_clefs             text,
    log                    text
);

alter table unicaen_mail_mail
    owner to admin;

create unique index ummail_id_uindex
    on unicaen_mail_mail (id);

create table unicaen_renderer_macro
(
    id            serial       not null
        constraint unicaen_document_macro_pk primary key,
    code          varchar(256) not null,
    description   text,
    variable_name varchar(256) not null,
    methode_name  varchar(256) not null
);
create unique index unicaen_document_macro_code_uindex on unicaen_renderer_macro (code);
create unique index unicaen_document_macro_id_uindex on unicaen_renderer_macro (id);

-- TABLE DES TEMPLATES

create table unicaen_renderer_template
(
    id             serial       not null
        constraint unicaen_document_template_pk primary key,
    code           varchar(256) not null,
    description    text,
    document_type  varchar(256) not null,
    document_sujet text         not null,
    document_corps text         not null,
    document_css   text
);
create unique index unicaen_document_template_code_uindex on unicaen_renderer_template (code);
create unique index unicaen_document_template_id_uindex on unicaen_renderer_template (id);

-- TABLE DES RENDU
create table unicaen_renderer_rendu
(
    id              serial    not null
        constraint unicaen_document_rendu_pk primary key,
    template_id     int default null
        constraint unicaen_document_rendu_template_id_fk
            references unicaen_renderer_template
            on delete set null,
    date_generation timestamp not null,
    sujet           text      not null,
    corps           text      not null
);
create unique index unicaen_document_rendu_id_uindex on unicaen_renderer_template (id);


-- ---------------------------------------------------------------------------------------
-- POUR LES EVENEMENTS (UnicaenEvenement)
-- ---------------------------------------------------------------------------------------
create table unicaen_evenement_etat
(
    id          serial
        constraint pk_evenement_etat
            primary key,
    code        varchar(255) not null
        constraint un_evenement_etat_code
            unique
                deferrable initially deferred,
    libelle     varchar(255) not null,
    description varchar(2047)
);

create table unicaen_evenement_type
(
    id          serial
        constraint pk_evenement_type
            primary key,
    code        varchar(255) not null
        constraint un_evenement_type_code
            unique
                deferrable initially deferred,
    libelle     varchar(255) not null,
    description varchar(2047),
    parametres  varchar(2047),
    recursion   varchar(64)
);


create table unicaen_evenement_instance
(
    id                 serial
        constraint pk_evenement_instance
            primary key,
    nom                varchar(255)  not null,
    description        varchar(1024) not null,
    type_id            integer       not null
        constraint fk_evenement_instance_type
            references unicaen_evenement_type
            deferrable,
    etat_id            integer       not null
        constraint fk_evenement_instance_etat
            references unicaen_evenement_etat
            deferrable,
    parametres         text,
    date_creation      timestamp     not null,
    date_planification timestamp     not null,
    date_traitement    timestamp,
    log                text,
    parent_id          integer
        constraint fk_evenement_instance_parent
            references unicaen_evenement_instance
            deferrable,
    date_fin           timestamp
);

create index ix_evenement_instance_type
    on unicaen_evenement_instance (type_id);

create index ix_evenement_instance_etat
    on unicaen_evenement_instance (etat_id);

create index ix_evenement_instance_parent
    on unicaen_evenement_instance (parent_id);

create table unicaen_evenement_journal
(
    id             serial
        constraint unicaen_evenement_journal_pk
            primary key,
    date_execution timestamp not null,
    log            text,
    etat_id        integer
        constraint unicaen_evenement_journal_unicaen_evenement_etat_id_fk
            references unicaen_evenement_etat
            on delete set null
);


create unique index unicaen_evenement_journal_id_uindex
    on unicaen_evenement_journal (id);

