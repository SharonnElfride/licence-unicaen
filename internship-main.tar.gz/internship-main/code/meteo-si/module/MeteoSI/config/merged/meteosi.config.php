<?php
/**
 * Fichier de configurations vide pour avoir les clés de base
 * Basé sur UnicaenUtilisateur/UnicaenPrivileges
 */

use Application\Provider\Privilege\EvenementPrivileges;
use MeteoSI\Controller\ANoter\ExportICalController;
use MeteoSI\Controller\ANoter\Factory\ExportICalControllerFactory;
use MeteoSI\Controller\ANoter\Factory\PageInformationControllerFactory;
use MeteoSI\Controller\ANoter\Factory\RSSControllerFactory;
use MeteoSI\Controller\ANoter\PageInformationController;
use MeteoSI\Controller\ANoter\RSSController;
use MeteoSI\Controller\CategorieEvenement\CategorieEvenementController;
use MeteoSI\Controller\CategorieEvenement\CategorieEvenementControllerFactory;
use MeteoSI\Controller\CibleEvenement\CibleEvenementController;
use MeteoSI\Controller\CibleEvenement\CibleEvenementControllerFactory;
use MeteoSI\Controller\Evenement\Factory\EvenementControllerFactory;
use MeteoSI\Controller\Evenement\EvenementController;
use MeteoSI\Event\ChangeEventState\ChangeEventStateEvent;
use MeteoSI\Event\ChangeEventState\ChangeEventStateEventFactory;
use MeteoSI\Event\NotificationToCreatorAfterADelay\NotificationToCreatorAfterADelayEvent;
use MeteoSI\Event\NotificationToCreatorAfterADelay\NotificationToCreatorAfterADelayEventFactory;
use MeteoSI\Form\CategorieEvenement\CategorieEvenementFieldset;
use MeteoSI\Form\CategorieEvenement\CategorieEvenementForm;
use MeteoSI\Form\CategorieEvenement\Factory\CategorieEvenementFieldsetFactory;
use MeteoSI\Form\CategorieEvenement\Factory\CategorieEvenementFormFactory;
use MeteoSI\Form\CibleEvenement\Cible\AddParentFieldset;
use MeteoSI\Form\CibleEvenement\Cible\AddParentForm;
use MeteoSI\Form\CibleEvenement\Cible\CibleEvenementFieldset;
use MeteoSI\Form\CibleEvenement\Cible\CibleEvenementForm;
use MeteoSI\Form\CibleEvenement\Cible\Factory\AddParentFieldsetFactory;
use MeteoSI\Form\CibleEvenement\Cible\Factory\AddParentFormFactory;
use MeteoSI\Form\CibleEvenement\Cible\Factory\CibleEvenementFieldsetFactory;
use MeteoSI\Form\CibleEvenement\Cible\Factory\CibleEvenementFormFactory;
use MeteoSI\Form\CibleEvenement\Cible\Hydrator\AddParentHydrator;
use MeteoSI\Form\CibleEvenement\Cible\Hydrator\AddParentHydratorFactory;
use MeteoSI\Form\CibleEvenement\CibleApplication\CibleEvenementApplicationFieldset;
use MeteoSI\Form\CibleEvenement\CibleApplication\CibleEvenementApplicationForm;
use MeteoSI\Form\CibleEvenement\CibleApplication\Factory\CibleEvenementApplicationFieldsetFactory;
use MeteoSI\Form\CibleEvenement\CibleApplication\Factory\CibleEvenementApplicationFormFactory;
use MeteoSI\Form\CibleEvenement\CibleApplication\Hydrator\CibleEvenementApplicationHydrator;
use MeteoSI\Form\CibleEvenement\CibleApplication\Hydrator\Factory\CibleEvenementApplicationHydratorFactory;
use MeteoSI\Form\CibleEvenement\CibleBdd\CibleEvenementBddFieldset;
use MeteoSI\Form\CibleEvenement\CibleBdd\CibleEvenementBddForm;
use MeteoSI\Form\CibleEvenement\CibleBdd\Factory\CibleEvenementBddFieldsetFactory;
use MeteoSI\Form\CibleEvenement\CibleBdd\Factory\CibleEvenementBddFormFactory;
use MeteoSI\Form\CibleEvenement\CibleBdd\Hydrator\CibleEvenementBddHydrator;
use MeteoSI\Form\CibleEvenement\CibleBdd\Hydrator\Factory\CibleEvenementBddHydratorFactory;
use MeteoSI\Form\CibleEvenement\CibleGroupe\AddTargetToGroupFieldset;
use MeteoSI\Form\CibleEvenement\CibleGroupe\AddTargetToGroupForm;
use MeteoSI\Form\CibleEvenement\CibleGroupe\CibleEvenementGroupeFieldset;
use MeteoSI\Form\CibleEvenement\CibleGroupe\CibleEvenementGroupeForm;
use MeteoSI\Form\CibleEvenement\CibleGroupe\Factory\AddTargetToGroupFieldsetFactory;
use MeteoSI\Form\CibleEvenement\CibleGroupe\Factory\AddTargetToGroupFormFactory;
use MeteoSI\Form\CibleEvenement\CibleGroupe\Factory\CibleEvenementGroupeFieldsetFactory;
use MeteoSI\Form\CibleEvenement\CibleGroupe\Factory\CibleEvenementGroupeFormFactory;
use MeteoSI\Form\CibleEvenement\CibleGroupe\Hydrator\CibleEvenementGroupeHydrator;
use MeteoSI\Form\CibleEvenement\CibleGroupe\Hydrator\Factory\CibleEvenementGroupeHydratorFactory;
use MeteoSI\Form\CibleEvenement\CibleInfra\CibleEvenementInfraFieldset;
use MeteoSI\Form\CibleEvenement\CibleInfra\CibleEvenementInfraForm;
use MeteoSI\Form\CibleEvenement\CibleInfra\Factory\CibleEvenementInfraFieldsetFactory;
use MeteoSI\Form\CibleEvenement\CibleInfra\Factory\CibleEvenementInfraFormFactory;
use MeteoSI\Form\CibleEvenement\CibleInfra\Hydrator\CibleEvenementInfraHydrator;
use MeteoSI\Form\CibleEvenement\CibleInfra\Hydrator\Factory\CibleEvenementInfraHydratorFactory;
use MeteoSI\Form\CibleEvenement\CibleService\CibleEvenementServiceFieldset;
use MeteoSI\Form\CibleEvenement\CibleService\CibleEvenementServiceForm;
use MeteoSI\Form\CibleEvenement\CibleService\Factory\CibleEvenementServiceFieldsetFactory;
use MeteoSI\Form\CibleEvenement\CibleService\Factory\CibleEvenementServiceFormFactory;
use MeteoSI\Form\CibleEvenement\CibleService\Hydrator\CibleEvenementServiceHydrator;
use MeteoSI\Form\CibleEvenement\CibleService\Hydrator\Factory\CibleEvenementServiceHydratorFactory;
use MeteoSI\Form\Evenement\Factory\Fieldset\ClotureEvenementFieldsetFactory;
use MeteoSI\Form\Evenement\Factory\Form\ClotureEvenementFormFactory;
use MeteoSI\Form\Evenement\Factory\Fieldset\EvenementFieldsetFactory;
use MeteoSI\Form\Evenement\Factory\Form\EvenementFormFactory;
use MeteoSI\Form\Evenement\Factory\Fieldset\ReOpenEvenementFieldsetFactory;
use MeteoSI\Form\Evenement\Factory\Form\ReOpenEvenementFormFactory;
use MeteoSI\Form\Evenement\Fieldset\AddEditEvenementFieldset;
use MeteoSI\Form\Evenement\Fieldset\ClotureEvenementFieldset;
use MeteoSI\Form\Evenement\Fieldset\ReOpenEvenementFieldset;
use MeteoSI\Form\Evenement\Form\AddEditEvenementForm;
use MeteoSI\Form\Evenement\Form\ClotureEvenementForm;
use MeteoSI\Form\Evenement\Form\ReOpenEvenementForm;
use MeteoSI\Form\Evenement\Hydrator\ClotureEvenementHydrator;
use MeteoSI\Form\Evenement\Hydrator\Factory\ClotureEvenementHydratorFactory;
use MeteoSI\Form\Evenement\Hydrator\Factory\EvenementHydratorFactory;
use MeteoSI\Form\Evenement\Hydrator\Factory\ReOpenEvenementHydratorFactory;
use MeteoSI\Form\Evenement\Hydrator\EvenementHydrator;
use MeteoSI\Form\Evenement\Hydrator\ReOpenEvenementHydrator;
use MeteoSI\Form\Evenement\Validator\AddEditEvenementValidator;
use MeteoSI\Form\Evenement\Validator\ClotureEvenementValidator;
use MeteoSI\Form\Evenement\Validator\DateAnterieureCheckerValidator;
use MeteoSI\Form\Evenement\Validator\DestinatairesListValidator;
use MeteoSI\Form\Evenement\Validator\Factory\AddEditEvenementValidatorFactory;
use MeteoSI\Form\Evenement\Validator\Factory\ClotureEvenementValidatorFactory;
use MeteoSI\Form\Evenement\Validator\Factory\DateAnterieureCheckerValidatorFactory;
use MeteoSI\Form\Evenement\Validator\Factory\DestinatairesListValidatorFactory;
use MeteoSI\Form\Evenement\Validator\Factory\ReopenCibleCheckerValidatorFactory;
use MeteoSI\Form\Evenement\Validator\ReopenCibleCheckerValidator;
use MeteoSI\MeteoSI\Service\Mailing\MailService;
use MeteoSI\MeteoSI\Service\Mailing\MailServiceFactory;
use MeteoSI\Service\CategorieEvenement\CategorieEvenementService;
use MeteoSI\Service\CategorieEvenement\CategorieEvenementServiceFactory;
use MeteoSI\Service\CibleEvenement\CibleApplication\CibleEvenementApplicationService;
use MeteoSI\Service\CibleEvenement\CibleApplication\CibleEvenementApplicationServiceFactory;
use MeteoSI\Service\CibleEvenement\CibleBdd\CibleEvenementBddService;
use MeteoSI\Service\CibleEvenement\CibleBdd\CibleEvenementBddServiceFactory;
use MeteoSI\Service\CibleEvenement\CibleGroupe\CibleEvenementGroupeService;
use MeteoSI\Service\CibleEvenement\CibleGroupe\CibleEvenementGroupeServiceFactory;
use MeteoSI\Service\CibleEvenement\CibleInfra\CibleEvenementInfraService;
use MeteoSI\Service\CibleEvenement\CibleInfra\CibleEvenementInfraServiceFactory;
use MeteoSI\Service\CibleEvenement\CibleEvenementService;
use MeteoSI\Service\CibleEvenement\CibleEvenementServiceFactory;
use MeteoSI\Service\CibleEvenement\CibleService\CibleEvenementServiceService;
use MeteoSI\Service\CibleEvenement\CibleService\CibleEvenementServiceServiceFactory;
use MeteoSI\Service\CibleEvenement\Dependance\CibleDependance\CibleDependanceService;
use MeteoSI\Service\CibleEvenement\Dependance\CibleDependance\CibleDependanceServiceFactory;
use MeteoSI\Service\CibleEvenement\Dependance\EtatCible\EtatCibleService;
use MeteoSI\Service\CibleEvenement\Dependance\EtatCible\EtatCibleServiceFactory;
use MeteoSI\Service\CibleEvenement\Dependance\RegleTransition\RegleTransitionService;
use MeteoSI\Service\CibleEvenement\Dependance\RegleTransition\RegleTransitionServiceFactory;
use MeteoSI\Service\Evenement\EvenementService;
use MeteoSI\Service\Evenement\EvenementServiceFactory;
use MeteoSI\Service\Renderer\Date\DateRendererService;
use MeteoSI\Service\Renderer\Date\DateRendererServiceFactory;
use MeteoSI\Service\Renderer\Evenement\EvenementInfo\EvenementInfoService;
use MeteoSI\Service\Renderer\Evenement\EvenementInfo\EvenementInfoServiceFactory;
use MeteoSI\Service\Renderer\Url\UrlService;
use MeteoSI\Service\Renderer\Url\UrlServiceFactory;
use MeteoSI\View\Helper\Calendar\CalendarViewHelper;
use MeteoSI\View\Helper\Calendar\CalendarViewHelperFactory;
use MeteoSI\View\Helper\CibleEvenement\EtatCibleViewHelper;
use MeteoSI\View\Helper\Evenement\DateFinViewHelper;
use MeteoSI\View\Helper\Evenement\EtatEvenementViewHelper;
use MeteoSI\View\Helper\Evenement\PublieViewHelper;
use MeteoSI\View\Helper\Shared\AcronymeViewHelper;
use UnicaenPrivilege\Guard\PrivilegeController;

return [
    /** Privileges pour les actions */
    'bjyauthorize' => [
        'guards' => [
            PrivilegeController::class => [
                [
                    'controller' => RSSController::class,
                    'action' => [
                        'feed',
                    ],
                ],

//                [
//                    'controller' => ExportICalController::class,
//                    'action' => [
//                        'cal',
//                    ],
//                ],

                [
                    'controller' => PageInformationController::class,
                    'action' => [
                        'index',
                    ],
                ],

            //CATEGORIES D'ÉVÉNEMENT
                [
                    'controller' => CategorieEvenementController::class,
                    'action' => [
                        'index',
                        'show',
                    ],
                    'privileges' => [
                        EvenementPrivileges::CATEGORIE_EVENEMENT_AFFICHER,
                    ],
                    'assertion' => 'Assertion\\CategorieEvenement',
                ],

                [
                    'controller' => CategorieEvenementController::class,
                    'action' => [
                        'add',
                    ],
                    'privileges' => [
                        EvenementPrivileges::CATEGORIE_EVENEMENT_AJOUTER,
                    ],
                    'assertion' => 'Assertion\\CategorieEvenement',
                ],

                [
                    'controller' => CategorieEvenementController::class,
                    'action' => [
                        'edit',
                    ],
                    'privileges' => [
                        EvenementPrivileges::CATEGORIE_EVENEMENT_MODIFIER,
                    ],
                    'assertion' => 'Assertion\\CategorieEvenement',
                ],

                [
                    'controller' => CategorieEvenementController::class,
                    'action' => [
                        'delete',
                    ],
                    'privileges' => [
                        EvenementPrivileges::CATEGORIE_EVENEMENT_SUPPRIMER,
                    ],
                    'assertion' => 'Assertion\\CategorieEvenement',
                ],

            //CIBLES D'ÉVÉNEMENT
                [
                    'controller' => CibleEvenementController::class,
                    'action' => [
                        'index',
                        'show',
                        'showtargetwithoutdetails',
                    ],
                    'privileges' => [
                        EvenementPrivileges::CIBLE_EVENEMENT_AFFICHER,
                    ],
                    'assertion' => 'Assertion\\CibleEvenement',
                ],

                [
                    'controller' => CibleEvenementController::class,
                    'action' => [
                        'add',
                    ],
                    'privileges' => [
                        EvenementPrivileges::CIBLE_EVENEMENT_AJOUTER,
                    ],
                    'assertion' => 'Assertion\\CibleEvenement',
                ],

                [
                    'controller' => CibleEvenementController::class,
                    'action' => [
                        'edit',
                        'addtargettogroup',
                        'removetargetfromgroup',
                        'addparent',
                        'removeparent',
                    ],
                    'privileges' => [
                        EvenementPrivileges::CIBLE_EVENEMENT_MODIFIER,
                    ],
                    'assertion' => 'Assertion\\CibleEvenement',
                ],

                [
                    'controller' => CibleEvenementController::class,
                    'action' => [
                        'changetransitionrule',
                    ],
                    'privileges' => [
                        EvenementPrivileges::CIBLE_EVENEMENT_GERER_DEPENDANCE,
                    ],
                    'assertion' => 'Assertion\\CibleEvenementDependance',
                ],

                [
                    'controller' => CibleEvenementController::class,
                    'action' => [
                        'delete',
                    ],
                    'privileges' => [
                        EvenementPrivileges::CIBLE_EVENEMENT_SUPPRIMER,
                    ],
                    'assertion' => 'Assertion\\CibleEvenement',
                ],

                [
                    'controller' => CibleEvenementController::class,
                    'action' => [
                        'changechildrenlist',
                    ],
                    'privileges' => [
                        EvenementPrivileges::EVENEMENT_AJOUTER,
                    ],
                    'assertion' => 'Assertion\\CibleEvenement',
                ],

                //ÉVÉNEMENTS
                [
                    'controller' => EvenementController::class,
                    'action' => [
                        'index',
                        'show',
                    ],
                    'privileges' => [
                        EvenementPrivileges::EVENEMENT_AFFICHER,
                    ],
                    'assertion' => 'Assertion\\Evenement',
                ],

                [
                    'controller' => EvenementController::class,
                    'action' => [
                        'add',
                        'clone',
                    ],
                    'privileges' => [
                        EvenementPrivileges::EVENEMENT_AJOUTER,
                    ],
                    'assertion' => 'Assertion\\Evenement',
                ],

                [
                    'controller' => EvenementController::class,
                    'action' => [
                        'changeforminput',
                    ],
                    'privileges' => [
                        EvenementPrivileges::EVENEMENT_MODIFIER,
                        EvenementPrivileges::EVENEMENT_AJOUTER,
                    ],
                    'assertion' => 'Assertion\\Evenement',
                ],

                [
                    'controller' => EvenementController::class,
                    'action' => [
                        'edit',
                        'reopen',
                        'close',
                        'unleash',
                    ],
                    'privileges' => [
                        EvenementPrivileges::EVENEMENT_MODIFIER,
                    ],
                    'assertion' => 'Assertion\\Evenement',
                ],

                [
                    'controller' => EvenementController::class,
                    'action' => [
                        'delete',
                    ],
                    'privileges' => [
                        EvenementPrivileges::EVENEMENT_SUPPRIMER,
                    ],
                    'assertion' => 'Assertion\\Evenement',
                ],

                [
                    'controller' => EvenementController::class,
                    'action' => [
                        'changecalendardate',
                        'showdateevents',
                    ],
                    'privileges' => [
                        EvenementPrivileges::EVENEMENT_AFFICHER,
                    ],
                    'assertion' => 'Assertion\\Evenement',
                ],
                // ...
            ],
        ],

        //Definition des ressources utilisées pour les assertions
        'resource_providers' => [
            'BjyAuthorize\Provider\Resource\Config' => [
            ],
        ],
        //Configurations des assertions sur les entités (implique de surcharger derriére la fonction assertEntity
        'rule_providers' => [
            'UnicaenPrivilege\Provider\Rule\PrivilegeRuleProvider' => [
                'allow' => [
                ],
            ],
        ],
    ],

    /** Routes pour les actions */
    'router' => [
        'routes' => [
        ],
    ],

    /** Controlleurs */
    'controllers' => [
        'factories' => [
            CategorieEvenementController::class => CategorieEvenementControllerFactory::class,
            CibleEvenementController::class => CibleEvenementControllerFactory::class,
            EvenementController::class => EvenementControllerFactory::class,

            RSSController::class => RSSControllerFactory::class,
            ExportICalController::class => ExportICalControllerFactory::class,
            PageInformationController::class => PageInformationControllerFactory::class,
        ],
    ],

    /** Services */
    'service_manager' => [
        'factories' => [
            CategorieEvenementService::class => CategorieEvenementServiceFactory::class,
            CibleEvenementService::class => CibleEvenementServiceFactory::class,
            EvenementService::class => EvenementServiceFactory::class,

            CibleEvenementApplicationService::class => CibleEvenementApplicationServiceFactory::class,
            CibleEvenementBddService::class => CibleEvenementBddServiceFactory::class,
            CibleEvenementInfraService::class => CibleEvenementInfraServiceFactory::class,
            CibleEvenementServiceService::class => CibleEvenementServiceServiceFactory::class,
            CibleEvenementGroupeService::class => CibleEvenementGroupeServiceFactory::class,
            CibleDependanceService::class => CibleDependanceServiceFactory::class,
            RegleTransitionService::class => RegleTransitionServiceFactory::class,
            EtatCibleService::class => EtatCibleServiceFactory::class,

            MailService::class => MailServiceFactory::class,
            DateRendererService::class => DateRendererServiceFactory::class,
            EvenementInfoService::class => EvenementInfoServiceFactory::class,
            UrlService::class => UrlServiceFactory::class,
            ChangeEventStateEvent::class => ChangeEventStateEventFactory::class,
            NotificationToCreatorAfterADelayEvent::class => NotificationToCreatorAfterADelayEventFactory::class,
        ],
    ],

    /** Formulaires */
    'form_elements' => [
        'invokables' => [
        ],
        'factories' => [
            CategorieEvenementForm::class => CategorieEvenementFormFactory::class,
            CategorieEvenementFieldset::class => CategorieEvenementFieldsetFactory::class,

            CibleEvenementForm::class => CibleEvenementFormFactory::class,
            CibleEvenementFieldset::class => CibleEvenementFieldsetFactory::class,

            AddParentForm::class => AddParentFormFactory::class,
            AddParentFieldset::class => AddParentFieldsetFactory::class,

            CibleEvenementApplicationForm::class => CibleEvenementApplicationFormFactory::class,
            CibleEvenementApplicationFieldset::class => CibleEvenementApplicationFieldsetFactory::class,

            CibleEvenementBddForm::class => CibleEvenementBddFormFactory::class,
            CibleEvenementBddFieldset::class => CibleEvenementBddFieldsetFactory::class,

            CibleEvenementGroupeForm::class => CibleEvenementGroupeFormFactory::class,
            CibleEvenementGroupeFieldset::class => CibleEvenementGroupeFieldsetFactory::class,

            AddTargetToGroupForm::class => AddTargetToGroupFormFactory::class,
            AddTargetToGroupFieldset::class => AddTargetToGroupFieldsetFactory::class,

            CibleEvenementInfraForm::class => CibleEvenementInfraFormFactory::class,
            CibleEvenementInfraFieldset::class => CibleEvenementInfraFieldsetFactory::class,

            CibleEvenementServiceForm::class => CibleEvenementServiceFormFactory::class,
            CibleEvenementServiceFieldset::class => CibleEvenementServiceFieldsetFactory::class,

            AddEditEvenementForm::class => EvenementFormFactory::class,
            AddEditEvenementFieldset::class => EvenementFieldsetFactory::class,

            ClotureEvenementForm::class => ClotureEvenementFormFactory::class,
            ClotureEvenementFieldset::class => ClotureEvenementFieldsetFactory::class,

            ReOpenEvenementForm::class => ReOpenEvenementFormFactory::class,
            ReOpenEvenementFieldset::class => ReOpenEvenementFieldsetFactory::class,
        ],
    ],

    /** Hydrator */
    'hydrators' => [
        'factories' => [
            EvenementHydrator::class => EvenementHydratorFactory::class,
            ClotureEvenementHydrator::class => ClotureEvenementHydratorFactory::class,
            ReOpenEvenementHydrator::class => ReOpenEvenementHydratorFactory::class,

            AddParentHydrator::class => AddParentHydratorFactory::class,
            CibleEvenementApplicationHydrator::class => CibleEvenementApplicationHydratorFactory::class,
            CibleEvenementBddHydrator::class => CibleEvenementBddHydratorFactory::class,
            CibleEvenementGroupeHydrator::class => CibleEvenementGroupeHydratorFactory::class,
            CibleEvenementInfraHydrator::class => CibleEvenementInfraHydratorFactory::class,
            CibleEvenementServiceHydrator::class => CibleEvenementServiceHydratorFactory::class,
        ],
    ],

    /** Validateur */
    'validators' => [
        'factories' => [
            AddEditEvenementValidator::class => AddEditEvenementValidatorFactory::class,
            ClotureEvenementValidator::class => ClotureEvenementValidatorFactory::class,
            DestinatairesListValidator::class => DestinatairesListValidatorFactory::class,
            ReopenCibleCheckerValidator::class => ReopenCibleCheckerValidatorFactory::class,

            DateAnterieureCheckerValidator::class => DateAnterieureCheckerValidatorFactory::class,
        ],
    ],

    'view_helpers' => [
        'aliases' => [
            'displayEtatCible' => EtatCibleViewHelper::class,
            'displayAcronyme' => AcronymeViewHelper::class,
            'displayPublie' => PublieViewHelper::class,
            'displayDateFinEvenement' => DateFinViewHelper::class,
            'displayEtatEvenement' => EtatEvenementViewHelper::class,
            'calendar' => CalendarViewHelper::class,
        ],
        'invokables' => [
            'displayEtatCible' => EtatCibleViewHelper::class,
            'displayAcronyme' => AcronymeViewHelper::class,
            'displayPublie' => PublieViewHelper::class,
            'displayDateFinEvenement' => DateFinViewHelper::class,
            'displayEtatEvenement' => EtatEvenementViewHelper::class,
        ],
        'factories' => [
            CalendarViewHelper::class => CalendarViewHelperFactory::class,
        ]
    ],

    /** Navigation */
    'navigation' => [
        'default' => [
            'home' => [
                'pages' => [
                    'evenement' => [
                        'label' => "Actualités",
                        'route' => 'evenement',
                        'order' => 15,
                        'pages' => [
                            'index' => [
                                'label' => 'Liste des événements',
                                'route' => 'evenement',
                                'resource' => EvenementPrivileges::getResourceId(EvenementPrivileges::EVENEMENT_AFFICHER),
                                'action' => 'index',
                                'icon' => 'fas fa-list',
                            ],
                            'add' => [
                                'label' => 'Ajouter un événement',
                                'route' => 'evenement/add',
                                'resource' => EvenementPrivileges::getResourceId(EvenementPrivileges::EVENEMENT_AJOUTER),
                                'action' => 'add',
                                'icon' => 'fas fa-circle-plus',
                            ],
                            'page-information' => [
                                'label' => "Page d'information",
                                'route' => 'page-information',
                                'action' => 'index',
                                'icon' => 'fas fa-book-bookmark',
                            ],
                            'rss' => [
                                'label' => "Flux RSS",
                                'route' => 'rss',
                                'action' => 'feed',
                                'icon' => 'fas fa-rss',
                            ],
//                            'export-ical' => [
//                                'label' => "Export iCal",
//                                'route' => 'export-ical',
//                                'action' => 'cal',
//                                'icon' => 'fas fa-download',
//                            ],
                        ],
                    ],

                    'config' => [
                        'label' => 'Configuration',
                        'route' => 'config',
                        'order' => 20,
                        'pages' => [
                            'categorie-evenement' => [
                                'label' => "Categories d'événement",
                                'route' => 'categorie-evenement',
                                'resource' => EvenementPrivileges::getResourceId(EvenementPrivileges::CATEGORIE_EVENEMENT_AFFICHER),
                                'action' => 'index',
                                'icon' => 'fas fa-list',
                            ],

                            'cible-evenement' => [
                                'label' => "Cibles d'événement",
                                'route' => 'cible-evenement',
                                'resource' => EvenementPrivileges::getResourceId(EvenementPrivileges::CIBLE_EVENEMENT_AFFICHER),
                                'action' => 'index',
                                'icon' => 'fas fa-list',
                            ],
                        ],
                    ],
                ],
            ],
        ],
    ],
];
