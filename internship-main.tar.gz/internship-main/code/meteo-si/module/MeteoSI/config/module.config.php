<?php

namespace MeteoSI\config;

use Application\Controller\IndexController;
use Doctrine\Common\Persistence\Mapping\Driver\MappingDriverChain;
use Doctrine\ORM\Mapping\Driver\XmlDriver;
use Laminas\Router\Http\Literal;
use Laminas\Router\Http\Segment;
use MeteoSI\Controller\ANoter\ANoterController;
use MeteoSI\Controller\ANoter\ExportICalController;
use MeteoSI\Controller\ANoter\PageInformationController;
use MeteoSI\Controller\ANoter\RSSController;
use MeteoSI\Controller\CategorieEvenement\CategorieEvenementController;
use MeteoSI\Controller\CibleEvenement\CibleEvenementController;
use MeteoSI\Controller\Evenement\EvenementController;

//use Laminas\ServiceManager\Factory\InvokableFactory;

return [
    //Managing the different routes(url) to each page
    'router' => [
        'routes' => [
            'config' => [
                'type' => Segment::class,
                'options' => [
                    'route' => '/config',
                    'defaults' => [
                        'controller' => IndexController::class,
                        'action' => 'index',
                    ],
                ],
                'may_terminate' => true,
            ],

            'rss' => [
                'type' => Segment::class,
                'options' => [
                    'route' => '/rss/feed.rss',
                    'defaults' => [
                        'controller' => RSSController::class,
                        'action' => 'feed',
                    ],
                ],
            ],

//            'export-ical' => [
//                'type' => Segment::class,
//                'options' => [
//                    'route' => '/export-ical/cal.ics',
//                    'defaults' => [
//                        'controller' => ExportICalController::class,
//                        'action' => 'cal',
//                    ],
//                ],
//            ],

            'page-information' => [
                'type' => Segment::class,
                'options' => [
                    'route' => '/page-information[/:action]',
                    'defaults' => [
                        'controller' => PageInformationController::class,
                        'action' => 'index',
                    ],
                ],
            ],

            //MOST IMPORTANT CONTROLLERS
            'categorie-evenement' => [
                'type' => Segment::class,
                'options' => [
                    'route' => '/categorie-evenement[/:action[/:id]]',
                    'constraints' => [
                        'action' => '[a-zA-Z0-9_-]*',
                        'id' => '[0-9]+',
                    ],
                    'defaults' => [
                        'controller' => CategorieEvenementController::class,
                        'action' => 'index',
                    ],
                ],
            ],

            'cible-evenement' => [
                'type' => Literal::class,
                'options' => [
                    'route' => '/cible-evenement',
                    'defaults' => [
                        'controller' => CibleEvenementController::class,
                        'action' => 'index',
                    ],
                ],
                'may_terminate' => true,
                'child_routes' => [
                    'add' => [
                        'type' => Segment::class,
                        'options' => [
                            'route' => '/add[/:categorie]',
                            'constraints' => [
                                'categorie' => '[a-zA-Z][a-zA-Z0-9_-]*',
                            ],
                            'defaults' => [
                                'controller' => CibleEvenementController::class,
                                'action' => 'add',
                            ],
                        ],
                    ],
                    'edit' => [
                        'type' => Segment::class,
                        'options' => [
                            'route' => '/edit[/:categorie[/:id]]',
                            'constraints' => [
                                'categorie' => '[a-zA-Z][a-zA-Z0-9_-]*',
                                'id' => '[0-9]+',
                            ],
                            'defaults' => [
                                'controller' => CibleEvenementController::class,
                                'action' => 'edit',
                            ],
                        ],
                    ],
                    'show' => [
                        'type' => Segment::class,
                        'options' => [
                            'route' => '/show[/:categorie[/:id]]',
                            'constraints' => [
                                'categorie' => '[a-zA-Z][a-zA-Z0-9_-]*',
                                'id' => '[0-9]+',
                            ],
                            'defaults' => [
                                'controller' => CibleEvenementController::class,
                                'action' => 'show',
                            ],
                        ],
                    ],
                    'show-target-without-details' => [
                        'type' => Segment::class,
                        'options' => [
                            'route' => '/show-target-without-details[/:categorie[/:id]]',
                            'constraints' => [
                                'categorie' => '[a-zA-Z][a-zA-Z0-9_-]*',
                                'id' => '[0-9]+',
                            ],
                            'defaults' => [
                                'controller' => CibleEvenementController::class,
                                'action' => 'showtargetwithoutdetails',
                            ],
                        ],
                    ],
                    'delete' => [
                        'type' => Segment::class,
                        'options' => [
                            'route' => '/delete[/:categorie[/:id]]',
                            'constraints' => [
                                'categorie' => '[a-zA-Z][a-zA-Z0-9_-]*',
                                'id' => '[0-9]+',
                            ],
                            'defaults' => [
                                'controller' => CibleEvenementController::class,
                                'action' => 'delete',
                            ],
                        ],
                    ],
                    'add-target-to-group' => [
                        'type' => Segment::class,
                        'options' => [
                            'route' => '/add-target-to-group[/:categorie[/:id]]',
                            'constraints' => [
                                'categorie' => '[a-zA-Z][a-zA-Z0-9_-]*',
                                'id' => '[0-9]+',
                            ],
                            'defaults' => [
                                'controller' => CibleEvenementController::class,
                                'action' => 'addtargettogroup',
                            ],
                        ],
                    ],
                    'remove-target-from-group' => [
                        'type' => Segment::class,
                        'options' => [
                            'route' => '/remove-target-from-group[/:categorie[/:id[/:categorie2[/:id2]]]]',
                            'constraints' => [
                                'categorie' => '[a-zA-Z][a-zA-Z0-9_-]*',
                                'categorie2' => '[a-zA-Z][a-zA-Z0-9_-]*',
                                'id' => '[0-9]+',
                                'id2' => '[0-9]+',
                            ],
                            'defaults' => [
                                'controller' => CibleEvenementController::class,
                                'action' => 'removetargetfromgroup',
                            ],
                        ],
                    ],
                    'add-parent' => [
                        'type' => Segment::class,
                        'options' => [
                            'route' => '/add-parent[/:categorie[/:id]]',
                            'constraints' => [
                                'categorie' => '[a-zA-Z][a-zA-Z0-9_-]*',
                                'id' => '[0-9]+',
                            ],
                            'defaults' => [
                                'controller' => CibleEvenementController::class,
                                'action' => 'addparent',
                            ],
                        ],
                    ],
                    'remove-parent' => [
                        'type' => Segment::class,
                        'options' => [
                            'route' => '/remove-parent[/:categorie[/:id[/:categorie2[/:id2]]]]',
                            'constraints' => [
                                'categorie' => '[a-zA-Z][a-zA-Z0-9_-]*',
                                'categorie2' => '[a-zA-Z][a-zA-Z0-9_-]*',
                                'id' => '[0-9]+',
                                'id2' => '[0-9]+',
                            ],
                            'defaults' => [
                                'controller' => CibleEvenementController::class,
                                'action' => 'removeparent',
                            ],
                        ],
                    ],
                    'change-transition-rule' => [
                        'type' => Segment::class,
                        'options' => [
                            'route' => '/change-transition-rule[/:categorie/:id[/:categorie2/:id2]][/:idDependance/:idEtatParent/:idEtatEnfant]',
                            'constraints' => [
                                'categorie' => '[a-zA-Z][a-zA-Z0-9_-]*',
                                'categorie2' => '[a-zA-Z][a-zA-Z0-9_-]*',
                                'id' => '[0-9]+',
                                'id2' => '[0-9]+',
                                'idDependance' => '[0-9]+',
                                'idEtatParent' => '[0-9]+',
                                'idEtatEnfant' => '[0-9]+',
                            ],
                            'defaults' => [
                                'controller' => CibleEvenementController::class,
                                'action' => 'changetransitionrule',
                            ],
                        ],
                    ],
                    'change-children-list' => [
                        'type' => Segment::class,
                        'options' => [
                            'route' => '/change-children-list[/:target-state-during-event[/:id]]',
                            'constraints' => [
                                'target-state-during-event' => '[a-zA-Z][a-zA-Z0-9_-]*',
                                'id' => '[0-9]+',
                            ],
                            'defaults' => [
                                'controller' => CibleEvenementController::class,
                                'action' => 'changechildrenlist',
                            ],
                        ],
                    ],
                ],
            ],

            'evenement' => [
                'type' => Literal::class,
                'options' => [
                    'route' => '/evenement',
                    'defaults' => [
                        'controller' => EvenementController::class,
                        'action' => 'index',
                    ],
                ],
                'may_terminate' => true,
                'child_routes' => [
                    'add' => [
                        'type' => Segment::class,
                        'options' => [
                            'route' => '/add[/:day[-:month[-:year]]]',
                            'constraints' => [
                                'day' => '\d{2}',
                                'month' => '[2-9]|1[0-2]?',
                                'year' => '\d{4}',
                            ],
                            'defaults' => [
                                'controller' => EvenementController::class,
                                'action' => 'add',
                            ],
                        ],
                    ],
                    'clone' => [
                        'type' => Segment::class,
                        'options' => [
                            'route' => '/clone[/:id]',
                            'constraints' => [
                                'id' => '[0-9]+',
                            ],
                            'defaults' => [
                                'controller' => EvenementController::class,
                                'action' => 'clone',
                            ],
                        ],
                    ],
                    'edit' => [
                        'type' => Segment::class,
                        'options' => [
                            'route' => '/edit[/:id]',
                            'constraints' => [
                                'id' => '[0-9]+',
                            ],
                            'defaults' => [
                                'controller' => EvenementController::class,
                                'action' => 'edit',
                            ],
                        ],
                    ],
                    're-open' => [
                        'type' => Segment::class,
                        'options' => [
                            'route' => '/re-open[/:id]',
                            'constraints' => [
                                'id' => '[0-9]+',
                            ],
                            'defaults' => [
                                'controller' => EvenementController::class,
                                'action' => 'reopen',
                            ],
                        ],
                    ],
                    'unleash' => [
                        'type' => Segment::class,
                        'options' => [
                            'route' => '/unleash[/:id[/:id2]]',
                            'constraints' => [
                                'id' => '[0-9]+',
                                'id2' => '[0-9]+',
                            ],
                            'defaults' => [
                                'controller' => EvenementController::class,
                                'action' => 'unleash',
                            ],
                        ],
                    ],
                    'show' => [
                        'type' => Segment::class,
                        'options' => [
                            'route' => '/show[/:id]',
                            'constraints' => [
                                'id' => '[0-9]+',
                            ],
                            'defaults' => [
                                'controller' => EvenementController::class,
                                'action' => 'show',
                            ],
                        ],
                    ],
                    'close' => [
                        'type' => Segment::class,
                        'options' => [
                            'route' => '/close[/:id]',
                            'constraints' => [
                                'id' => '[0-9]+',
                            ],
                            'defaults' => [
                                'controller' => EvenementController::class,
                                'action' => 'close',
                            ],
                        ],
                    ],
                    'delete' => [
                        'type' => Segment::class,
                        'options' => [
                            'route' => '/delete[/:id]',
                            'constraints' => [
                                'id' => '[0-9]+',
                            ],
                            'defaults' => [
                                'controller' => EvenementController::class,
                                'action' => 'delete',
                            ],
                        ],
                    ],
                    'change-form-input' => [
                        'type' => Segment::class,
                        'options' => [
                            'route' => '/change-form-input[/:id]',
                            'constraints' => [
                                'id' => '[0-9]+',
                            ],
                            'defaults' => [
                                'controller' => EvenementController::class,
                                'action' => 'changeforminput',
                            ],
                        ],
                    ],
                    'calendar' => [
                        'type' => Segment::class,
                        'options' => [
                            'route' => '/calendar[/:month[/:year]]',
                            'constraints' => [
                                'month' => '[2-9]|1[0-2]?',
                                'year' => '\d{4}',
                            ],
                            'defaults' => [
                                'controller' => EvenementController::class,
                                'action' => 'changecalendardate',
                            ],
                        ],
                    ],
                    'show-date-events' => [
                        'type' => Segment::class,
                        'options' => [
                            'route' => '/show-date-events[/:day[-:month[-:year]]]',
                            'constraints' => [
                                'day' => '\d{2}',
                                'month' => '[2-9]|1[0-2]?',
                                'year' => '\d{4}',
                            ],
                            'defaults' => [
                                'controller' => EvenementController::class,
                                'action' => 'showdateevents',
                            ],
                        ],
                    ],
                ],
            ],
        ],
    ],

    'view_manager' => [
        'template_path_stack' => [
            'meteosi' => __DIR__ . '/../view',
        ],
    ],

    'doctrine' => [
        'driver' => [
            'orm_default' => [
                'class' => MappingDriverChain::class,
                'drivers' => [
                    'MeteoSI\Model' => 'orm_default_xml_driver',
                ],
            ],
            'orm_default_xml_driver' => [
                'class' => XmlDriver::class,
                'cache' => 'apc',
                'paths' => [
                    __DIR__ . '/../src/MeteoSI/Model/Mapping',
                ],
            ],
        ],
        'cache' => [
            'apc' => [
                'namespace' => 'Meteo SI__' . __NAMESPACE__,
            ],
        ],
    ],
];
