<?php

namespace MeteoSI\Form\CibleEvenement\CibleApplication\Hydrator;

use DateTime;
use Doctrine\ORM\OptimisticLockException;
use Doctrine\ORM\ORMException;
use Exception;
use Laminas\Hydrator\AbstractHydrator;
use Laminas\Hydrator\HydratorInterface;
use MeteoSI\Model\CibleEvenementApplication;
use MeteoSI\Model\EtatCible;
use UnicaenApp\Service\EntityManagerAwareTrait;

class CibleEvenementApplicationHydrator extends AbstractHydrator implements HydratorInterface
{
    use EntityManagerAwareTrait;

    /**
     * Converts the given value so that it can be extracted by the hydrator.
     *
     * @param CibleEvenementApplication $entity (optional) The original object for context.
     * @throws ORMException
     * @throws OptimisticLockException
     * @return array Returns the value that should be extracted.
     */
    public function extract($entity): array
    {
        //Avoir la date de début pré-remplie en considérant que l'événement s'effectue maintenant
        if($entity->getDateCreation() === null) {
            $entity->setDateCreation(new DateTime());
        }

        if($entity->getEtat() === null) {
            /** @var EtatCible $etat */
            $etat = $this->getEntityManager()->find(EtatCible::class, 1);
            $entity->setEtat($etat);
        }

        $results = [
            "libelle" => $entity->getLibelle(),
            "description" => $entity->getDescription(),
            "etat" => $entity->getEtat(),
            "url" => $entity->getUrl(),
            "codeSource" => $entity->getCodeSource(),
            "idSource" => $entity->getIdSource(),
            "dateCreation" => $entity->getDateCreation(),
        ];

        return $results;
    }

    /**
     * Hydrate $object with the provided $data.
     *
     * @param CibleEvenementApplication $entity The original value.
     * @param array $data (optional) The original data for context.
     * @return CibleEvenementApplication Returns the value that should be hydrated.
     * @throws Exception
     */
    public function hydrate(array $data, $entity)
    {
        $idEtat = ($data['etat']) ?? 0;

        $libelle = ($data['libelle']) ?? '';
        $desciption = ($data['description']) ?? '';

        /** @var EtatCible $etat */
        $etat = $this->getEntityManager()->getRepository(EtatCible::class)->find($idEtat);

        $url = ($data['url']) ?? '';
        $codeSource = ($data['codeSource']) ?? '';
        $idSource = ($data['idSource']) ?? '';

        //Date de création
        $dateCreation = new DateTime();
        if (isset($data['dateCreation']))
            $dateCreation = new DateTime($data['dateCreation']);

        //Le passage des valeurs récupérées par le form
        $entity->setLibelle($libelle);
        $entity->setDescription($desciption);
        $entity->setEtat($etat);
        $entity->setUrl($url);
        $entity->setCodeSource($codeSource);
        $entity->setIdSource($idSource);
        $entity->setDateCreation($dateCreation);

        return $entity;
    }
}