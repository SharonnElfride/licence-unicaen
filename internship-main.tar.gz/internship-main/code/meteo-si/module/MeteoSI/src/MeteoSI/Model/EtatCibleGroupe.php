<?php

namespace MeteoSI\Model;

use Doctrine\Common\Collections\ArrayCollection;
use Laminas\Permissions\Acl\Resource\ResourceInterface;

class EtatCibleGroupe implements ResourceInterface
{
    const RESOURCE_ID = 'EtatCibleGroupe';

    /** @var int $id */
    private $id;

    /** @var string $code */
    private $code;

    /** @var string $libelle */
    private $libelle;

    /** @var int $niveauGravite */
    private $niveauGravite;

    /** @var ArrayCollection|EtatCible[] */
    private $etats;

    /**
     * Returns the string identifier of the Resource
     *
     * @return string
     */
    public function getResourceId()
    {
        return self::RESOURCE_ID;
    }

    public function __construct()
    {
        $this->etats = new ArrayCollection();
    }

//Les états du groupe
    /**
     * @param EtatCible $etat
     * @return void
     */
    public function addEtat(EtatCible $etat)
    {
        $this->etats->add($etat);
    }

    /**
     * @param EtatCible $etat
     * @return void
     */
    public function removeEtat(EtatCible $etat)
    {
        $this->etats->removeElement($etat);
    }

    /**
     * @return void
     */
    public function removeAllEtats()
    {
        $this->etats->clear();
    }

    /**
     * @return ArrayCollection|EtatCible[]
     */
    public function getEtats()
    {
        return $this->etats;
    }

//GETTERS ET SETTERS
    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return string
     */
    public function getCode(): string
    {
        return $this->code;
    }

    /**
     * @return string
     */
    public function getLibelle(): string
    {
        return $this->libelle;
    }

    /**
     * @return int
     */
    public function getNiveauGravite(): int
    {
        return $this->niveauGravite;
    }

    /**
     * @param int $id
     */
    public function setId(int $id): void
    {
        $this->id = $id;
    }

    /**
     * @param string $code
     */
    public function setCode(string $code): void
    {
        $this->code = $code;
    }

    /**
     * @param string $libelle
     */
    public function setLibelle(string $libelle): void
    {
        $this->libelle = $libelle;
    }

    /**
     * @param int $niveauGravite
     */
    public function setNiveauGravite(int $niveauGravite): void
    {
        $this->niveauGravite = $niveauGravite;
    }
}