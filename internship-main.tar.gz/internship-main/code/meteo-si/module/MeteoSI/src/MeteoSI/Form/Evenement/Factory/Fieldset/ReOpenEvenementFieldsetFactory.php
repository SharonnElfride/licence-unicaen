<?php

namespace MeteoSI\Form\Evenement\Factory\Fieldset;

use Doctrine\ORM\EntityManager;
use Interop\Container\ContainerInterface;
use Laminas\ServiceManager\Factory\FactoryInterface;
use Laminas\Validator\ValidatorPluginManager;
use MeteoSI\Form\Evenement\Fieldset\AddEditEvenementFieldset;
use MeteoSI\Form\Evenement\Fieldset\ReOpenEvenementFieldset;
use MeteoSI\Form\Evenement\Hydrator\EvenementHydrator;
use MeteoSI\Form\Evenement\Hydrator\ReOpenEvenementHydrator;
use MeteoSI\Form\Evenement\Validator\AddEditEvenementValidator;
use MeteoSI\Form\Evenement\Validator\DateAnterieureCheckerValidator;
use MeteoSI\Form\Evenement\Validator\DestinatairesListValidator;
use MeteoSI\Form\Evenement\Validator\ReopenCibleCheckerValidator;
use MeteoSI\Model\Evenement;

/**
 * Class ReOpenEvenementFieldsetFactory
 */
class ReOpenEvenementFieldsetFactory implements FactoryInterface
{
    /**
     * Create fieldset
     *
     * @param ContainerInterface $container
     * @param string $requestedName
     * @param array|null $options
     * @return ReOpenEvenementFieldset|object
     */
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        /** @var ReOpenEvenementFieldset $fieldset */
        $fieldset = new ReOpenEvenementFieldset('evenement');

        /** @var EntityManager $entityManager */
        $entityManager = $container->get(EntityManager::class);
        $fieldset->setEntityManager($entityManager);

        /** @var AddEditEvenementValidator $evenementValidator */
        $evenementValidator = $container->get(ValidatorPluginManager::class)->get(AddEditEvenementValidator::class);
        $fieldset->setEvenementValidator($evenementValidator);

        /** @var DateAnterieureCheckerValidator $evenementValidator */
        $evenementValidator = $container->get(ValidatorPluginManager::class)->get(DateAnterieureCheckerValidator::class);
        $fieldset->setDateAnterieureCheckerValidator($evenementValidator);

        /** @var DestinatairesListValidator $evenementValidator */
        $evenementValidator = $container->get(ValidatorPluginManager::class)->get(DestinatairesListValidator::class);
        $fieldset->setDestinatairesListValidator($evenementValidator);

        /** @var ReopenCibleCheckerValidator $evenementValidator */
        $evenementValidator = $container->get(ValidatorPluginManager::class)->get(ReopenCibleCheckerValidator::class);
        $evenementValidator->setEntityManager($entityManager);
        $fieldset->setReopenCibleCheckerValidator($evenementValidator);

        /** @var ReOpenEvenementHydrator $hydrator */
        $hydrator = $container->get('HydratorManager')->get(ReOpenEvenementHydrator::class);
        $fieldset->setHydrator($hydrator);

        $fieldset->setObject(new Evenement());
        return $fieldset;
    }
}
