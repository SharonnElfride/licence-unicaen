<?php

namespace MeteoSI\Form\CibleEvenement\CibleApplication\Factory;

use Doctrine\Laminas\Hydrator\DoctrineObject;
use Doctrine\ORM\EntityManager;
use Interop\Container\ContainerInterface;
use Laminas\ServiceManager\Factory\FactoryInterface;
use Laminas\View\HelperPluginManager;
use MeteoSI\Form\CibleEvenement\CibleApplication\CibleEvenementApplicationForm;
use MeteoSI\Form\CibleEvenement\CibleApplication\Hydrator\CibleEvenementApplicationHydrator;

/**
 * Class CibleEvenementApplicationFormFactory
 */
class CibleEvenementApplicationFormFactory implements FactoryInterface
{
    /**
     * Create fieldset
     *
     * @param ContainerInterface $container
     * @param string $requestedName
     * @param array|null $options
     * @return CibleEvenementApplicationForm|object
     */
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        /** @var CibleEvenementApplicationForm $form */
        $form = new CibleEvenementApplicationForm();

        /** @var EntityManager $entityManager */
        $entityManager = $container->get(EntityManager::class);
        $form->setEntityManager($entityManager);


        /** @var HelperPluginManager $viewHelperManager */
        $viewHelperManager = $container->get('ViewHelperManager');
        $form->setViewHelperManager($viewHelperManager);

        /** @var CibleEvenementApplicationHydrator $hydrator */
        $hydrator = $container->get('HydratorManager')->get(CibleEvenementApplicationHydrator::class);
        $form->setHydrator($hydrator);

        return $form;
    }
}
