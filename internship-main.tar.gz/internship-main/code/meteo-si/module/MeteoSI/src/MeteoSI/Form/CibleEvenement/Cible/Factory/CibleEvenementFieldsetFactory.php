<?php

namespace MeteoSI\Form\CibleEvenement\Cible\Factory;

use Doctrine\Laminas\Hydrator\DoctrineObject;
use Doctrine\ORM\EntityManager;
use Interop\Container\ContainerInterface;
use Laminas\ServiceManager\Factory\FactoryInterface;
use MeteoSI\Form\CibleEvenement\Cible\CibleEvenementFieldset;
use MeteoSI\Model\CibleEvenement;

/**
 * Class CibleEvenementFieldsetFactory
 */
class CibleEvenementFieldsetFactory implements FactoryInterface
{
    /**
     * Create fieldset
     *
     * @param ContainerInterface $container
     * @param string $requestedName
     * @param array|null $options
     * @return CibleEvenementFieldset|object
     */
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        /** @var CibleEvenementFieldset $fieldset */
        $fieldset = new CibleEvenementFieldset('cible');

        /** @var EntityManager $entityManager */
        $entityManager = $container->get(EntityManager::class);
        $fieldset->setEntityManager($entityManager);

        /** @var DoctrineObject $hydrator */
        $hydrator = $container->get('HydratorManager')->get(DoctrineObject::class);
        $fieldset->setHydrator($hydrator);
        $fieldset->setObject(new CibleEvenement());
        return $fieldset;
    }
}
