<?php

namespace MeteoSI\Form\CategorieEvenement;

use Application\Application\Form\AbstractEntityFieldset;
use Laminas\Filter\StringTrim;
use Laminas\Filter\StripTags;
use Laminas\Filter\ToInt;
use Laminas\Form\Element\Color;
use Laminas\Form\Element\Text;
use Laminas\InputFilter\InputFilterProviderInterface;
use Laminas\Validator\StringLength;
use MeteoSI\Form\Shared\Validator\CodeValidator;
use MeteoSI\Model\CategorieEvenement;
use MeteoSI\Service\CategorieEvenement\CategorieEvenementServiceAwareTrait;

/**
 * Class CategorieEvenementFieldset
 */
class CategorieEvenementFieldset extends AbstractEntityFieldset implements InputFilterProviderInterface
{
    /** @var CodeValidator $codeValidator */
    private $codeValidator;

    /**
     * @return CodeValidator
     */
    public function getCodeValidator(): CodeValidator
    {
        return $this->codeValidator;
    }

    /**
     * @param CodeValidator $validator
     */
    public function setCodeValidator(CodeValidator $validator): void
    {
        $this->codeValidator = $validator;
    }

//INITIALISATION ET CONTROLE DE LA CLASSE
    public function init()
    {
        $this->add([
            'name' => 'id',
            'type' => 'hidden',
        ]);

        $this->add([
            'name' => 'code',
            'type' => Text::class,
            'options' => [
                'label' => 'Code de la catégorie',
                'max' => 255,
            ],
            'attributes' => [
                'placeholder' => 'dysfonctionnement',
            ],
        ]);

        $this->add([
            'name' => 'libelle',
            'type' => Text::class,
            'options' => [
                'label' => 'Libellé de la catégorie',
                'max' => 255,
            ],
            'attributes' => [
                'placeholder' => 'Dysfonctionnement',
            ],
        ]);

        $this->add([
            'name' => 'acronyme',
            'type' => Text::class,
            'options' => [
                'label' => 'Acronyme de la catégorie',
                'max' => 255,
            ],
            'attributes' => [
                'placeholder' => 'Dysf',
            ],
        ]);

        $this->add([
            'name' => 'couleur',
            'type' => Color::class,
            'options' => [
                'label' => 'Couleur de la catégorie',
                'max' => 255,
            ],
//            'attributes' => [
//                'placeholder' => '',
//            ],
        ]);
    }

    public function getInputFilterSpecification()
    {
        $inputFilter = [];

        $inputFilter['id'] = [
            'name' => 'id',
            'required' => true,
            'filters' => [
                ['name' => ToInt::class],
            ],
        ];

        $inputFilter['code'] = [
            'name' => 'code',
            'required' => true,
            'filters' => [
                ['name' => StripTags::class],
                ['name' => StringTrim::class],
            ],
            'validators' => [
                [
                    'name' => StringLength::class,
                    'options' => [
                        'encoding' => 'UTF-8',
                        'min' => 1,
                    ],
                ],
                $this->getCodeValidator(),
            ],
        ];

        $inputFilter['libelle'] = [
            'name' => 'libelle',
            'required' => true,
            'filters' => [
                //StripTags == remove the unwanted html tags
                //StringTrim == remove the unnecessary spaces (\r or \t or \n...) at each line start/end
                ['name' => StripTags::class],
                ['name' => StringTrim::class],
            ],
            'validators' => [
                [
                    'name' => StringLength::class,
                    'options' => [
                        'encoding' => 'UTF-8',
                        'min' => 1,
                    ],
                ],
            ],
        ];

        $inputFilter['acronyme'] = [
            'name' => 'acronyme',
            'required' => false,
            'filters' => [
                //StripTags == remove the unwanted html tags
                //StringTrim == remove the unnecessary spaces (\r or \t or \n...) at each line start/end
                ['name' => StripTags::class],
                ['name' => StringTrim::class],
            ],
            'validators' => [
                [
                    'name' => StringLength::class,
                    'options' => [
                        'encoding' => 'UTF-8',
                        'min' => 1,
                    ],
                ],
            ],
        ];

        $inputFilter['couleur'] = [
            'name' => 'couleur',
            'required' => false,
//            'filters' => [
//                //StripTags == remove the unwanted html tags
//                //StringTrim == remove the unnecessary spaces (\r or \t or \n...) at each line start/end
//                ['name' => StripTags::class],
//                ['name' => StringTrim::class],
//            ],
//            'validators' => [
//                [
//                    'name' => StringLength::class,
//                    'options' => [
//                        'encoding' => 'UTF-8',
//                        'min' => 1,
//                    ],
//                ],
//            ],
        ];

        return $inputFilter;
    }
}
