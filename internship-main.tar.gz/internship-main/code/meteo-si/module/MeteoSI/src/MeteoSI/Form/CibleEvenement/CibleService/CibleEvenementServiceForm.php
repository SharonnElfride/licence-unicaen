<?php

namespace MeteoSI\Form\CibleEvenement\CibleService;

use Application\Application\Form\AbstractEntityForm;

class CibleEvenementServiceForm extends AbstractEntityForm
{
    public function __construct($name = null)
    {
        parent::__construct('cibleService');
    }

    protected function initEntityFieldset()
    {
        $this->entityFieldset = $this->getFormFactory()->getFormElementManager()->get(CibleEvenementServiceFieldset::class);
        $this->entityFieldset->setOptions([
            'use_as_base_fieldset' => true,
        ]);
        $this->add($this->entityFieldset);
    }

    protected function initSubmitInput()
    {
        $this->add([
            'name' => 'submit',
            'type' => 'submit',
            'attributes' => [
                'value' => 'Go',
                'id' => 'submitbutton',
            ],
        ]);
    }
}
