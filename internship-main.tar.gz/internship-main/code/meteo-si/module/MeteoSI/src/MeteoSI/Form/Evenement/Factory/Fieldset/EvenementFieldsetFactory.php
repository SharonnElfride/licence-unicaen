<?php

namespace MeteoSI\Form\Evenement\Factory\Fieldset;

use Doctrine\ORM\EntityManager;
use Interop\Container\ContainerInterface;
use Laminas\ServiceManager\Factory\FactoryInterface;
use Laminas\Validator\ValidatorPluginManager;
use MeteoSI\Form\Evenement\Fieldset\AddEditEvenementFieldset;
use MeteoSI\Form\Evenement\Hydrator\EvenementHydrator;
use MeteoSI\Form\Evenement\Validator\AddEditEvenementValidator;
use MeteoSI\Form\Evenement\Validator\DateAnterieureCheckerValidator;
use MeteoSI\Form\Evenement\Validator\DestinatairesListValidator;
use MeteoSI\Model\Evenement;

/**
 * Class EvenementFieldsetFactory
 */
class EvenementFieldsetFactory implements FactoryInterface
{
    /**
     * Create fieldset
     *
     * @param ContainerInterface $container
     * @param string $requestedName
     * @param array|null $options
     * @return AddEditEvenementFieldset|object
     */
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        /** @var AddEditEvenementFieldset $fieldset */
        $fieldset = new AddEditEvenementFieldset('evenement');

        /** @var EntityManager $entityManager */
        $entityManager = $container->get(EntityManager::class);
        $fieldset->setEntityManager($entityManager);

        /** @var AddEditEvenementValidator $evenementValidator */
        $evenementValidator = $container->get(ValidatorPluginManager::class)->get(AddEditEvenementValidator::class);
        $fieldset->setEvenementValidator($evenementValidator);

        /** @var DateAnterieureCheckerValidator $evenementValidator */
        $evenementValidator = $container->get(ValidatorPluginManager::class)->get(DateAnterieureCheckerValidator::class);
        $fieldset->setDateAnterieureCheckerValidator($evenementValidator);

        /** @var DestinatairesListValidator $evenementValidator */
        $evenementValidator = $container->get(ValidatorPluginManager::class)->get(DestinatairesListValidator::class);
        $fieldset->setDestinatairesListValidator($evenementValidator);

        /** @var EvenementHydrator $hydrator */
        $hydrator = $container->get('HydratorManager')->get(EvenementHydrator::class);
        $fieldset->setHydrator($hydrator);

        $fieldset->setObject(new Evenement());
        return $fieldset;
    }
}
