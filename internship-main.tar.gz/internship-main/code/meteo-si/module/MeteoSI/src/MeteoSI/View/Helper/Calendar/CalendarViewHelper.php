<?php

namespace MeteoSI\View\Helper\Calendar;

use Application\Application\View\Renderer\PhpRenderer;
use Laminas\View\Helper\AbstractHelper;
use Laminas\View\Helper\Partial;
use Laminas\View\Resolver\TemplatePathStack;
use MeteoSI\Service\CategorieEvenement\CategorieEvenementServiceAwareTrait;
use MeteoSI\Service\Evenement\EvenementServiceAwareTrait;

class CalendarViewHelper extends AbstractHelper
{
    use EvenementServiceAwareTrait;
    use CategorieEvenementServiceAwareTrait;

    private $days;
    private $months;

    /**
     * @param array|null $days
     * @return void
     */
    public function setDays(?array $days = null): void
    {
        $this->days = $days;
    }

    /**
     * @param array|null $months
     * @return void
     */
    public function setMonths(?array $months = null): void
    {
        $this->months = $months;
    }

    /**
     * @param array $options
     * @return Partial
     */
    public function __invoke(int $mois, int $annee, array $options = [])
    {
        $evenements = $this->getEvenementService()->findAllByMonthAndYear($mois, $annee);
        $categoriesEvenement = $this->getCategorieService()->findAll();

        /** @var PhpRenderer $view */
        $view = $this->getView();
        $view->resolver()->attach(new TemplatePathStack(['script_paths' => [__DIR__ . "/partial"]]));

        return $view->partial('calendar', [
            'mois' => $mois,
            'annee' => $annee,
            'evenements' => $evenements,
            'categoriesEvenement' => $categoriesEvenement,
            'days' => $this->days,
            'months' => $this->months,
            'options' => $options
        ]);
    }

    public function __toString() {
        return "";
    }
}