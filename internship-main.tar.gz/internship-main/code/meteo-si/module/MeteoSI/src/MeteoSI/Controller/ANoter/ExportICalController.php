<?php

namespace MeteoSI\Controller\ANoter;

use Laminas\Feed\Writer\Feed;
use Laminas\Http\Response;
use Laminas\Mvc\Controller\AbstractActionController;
use MeteoSI\Service\Evenement\EvenementServiceAwareTrait;

class ExportICalController extends AbstractActionController
{
    use EvenementServiceAwareTrait;

    public function calAction()
    {
        $evenementsEnCours = $this->getEvenementService()->findAllByCodeEtat('encours');
        $evenementsAVenir = $this->getEvenementService()->findAllByCodeEtat('avenir');

        $feed = new Feed();

$content = "
BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//ZContent.net//Zap Calendar 1.0//EN
CALSCALE:GREGORIAN
METHOD:PUBLISH
BEGIN:VEVENT
SUMMARY:Abraham Lincoln
UID:c7614cff-3549-4a00-9152-d25cc1fe077d
SEQUENCE:0
STATUS:CONFIRMED
TRANSP:TRANSPARENT
RRULE:FREQ=YEARLY;INTERVAL=1;BYMONTH=2;BYMONTHDAY=12
DTSTART:20080212
DTEND:20080213
DTSTAMP:20150421T141403
CATEGORIES:U.S. Presidents,Civil War People
LOCATION:Hodgenville\, Kentucky
GEO:37.5739497;-85.7399606
DESCRIPTION:Born February 12\, 1809 -- Sixteenth President (1861-1865)
http://AmericanHistoryCalendar.com
URL:http://americanhistorycalendar.com/peoplecalendar/1,328-abraham-lincoln
END:VEVENT
END:VCALENDAR
";

        $feed->setType();

        //Export du fichier .ics
        $out = $content; //$feed->export('rss');
        $response = new Response();
        $response->setStatusCode(Response::STATUS_CODE_200);
        $response->setContent($out);
        $response->getHeaders()->addHeaders([
            'Content-Type' => 'application/text/calendar',
        ]);



        return $response;
    }
}