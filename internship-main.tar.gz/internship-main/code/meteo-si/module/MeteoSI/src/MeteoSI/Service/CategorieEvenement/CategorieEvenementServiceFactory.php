<?php

namespace MeteoSI\Service\CategorieEvenement;

use Doctrine\ORM\EntityManager;
use Interop\Container\ContainerInterface;
use Laminas\ServiceManager\Factory\FactoryInterface;

/**
 * Class CategorieEvenementServiceFactory
 * @package MeteoSI\Service\CategorieEvenement
 */
class CategorieEvenementServiceFactory implements FactoryInterface
{

    /**
     * @param ContainerInterface $container
     * @param string $requestedName
     * @param array|null $options
     * @return CategorieEvenementService|object
     */
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        /** @var CategorieEvenementService $serviceProvider */
        $serviceProvider = new CategorieEvenementService();

        /** @var EntityManager $entityManager */
        $entityManager = $container->get(EntityManager::class);
        $serviceProvider->setEntityManager($entityManager);

        return $serviceProvider;
    }
}
