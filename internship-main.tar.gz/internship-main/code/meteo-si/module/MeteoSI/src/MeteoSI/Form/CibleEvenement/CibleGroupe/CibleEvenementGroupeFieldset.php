<?php

namespace MeteoSI\Form\CibleEvenement\CibleGroupe;

use DoctrineModule\Form\Element\ObjectSelect;
use Laminas\Filter\StringTrim;
use Laminas\Filter\StripTags;
use Laminas\Filter\ToInt;
use Laminas\Filter\ToNull;
use Laminas\Form\Element\Select;
use Laminas\Form\Element\Text;
use Laminas\Validator\StringLength;
use MeteoSI\Form\CibleEvenement\Cible\CibleEvenementFieldset;
use MeteoSI\Form\Shared\Validator\CodeValidator;
use MeteoSI\Model\CategorieEvenement;
use MeteoSI\Model\CibleEvenement;
use MeteoSI\Model\EtatCible;

/**
 * Class CibleEvenementGroupeFieldset
 */
class CibleEvenementGroupeFieldset extends CibleEvenementFieldset
{
    /** @var CodeValidator $codeValidator */
    private $codeValidator;

    /**
     * @return CodeValidator
     */
    public function getCodeValidator(): CodeValidator
    {
        return $this->codeValidator;
    }

    /**
     * @param CodeValidator $validator
     */
    public function setCodeValidator(CodeValidator $validator): void
    {
        $this->codeValidator = $validator;
    }

//INITIALISATION ET CONTROLE DE LA CLASSE
    public function init()
    {
        parent::init();

        $this->add([
            'name' => 'code',
            'type' => Text::class,
            'options' => [
//                'label' => "Code du groupe de cibles",
                'max' => 255,
            ],
            'attributes' => [
                'placeholder' => 'groupedns',
            ],
        ]);

//        $this->add([
//            'type' => ObjectSelect::class,
//            'name' => 'cible',
//            'options' => [
////                'label' => "Cible de l'événement",
//                'empty_option' => 'Sélectionner une cible',
//                'object_manager' => $this->getEntityManager(),
//                'target_class' => CibleEvenement::class,
//                'optgroup_identifier' => 'categorieLibelle',
//                'optgroup_default'    => 'Autres',
//                'find_method' => [
//                    'name' => 'findBy',
//                    'params' => [
//                        'criteria' => [],
//                        'orderBy' => ['categorieCible' => 'ASC'],
//                    ],
//                ],
//                'label_generator' => function(CibleEvenement $taskEntity) {
//                    return $taskEntity->getLibelle();
//                },
//                'disable_inarray_validator' => true,
//            ],
//            'attributes' => [
//                'id' => 'cible',
//            ],
//        ]);
    }

    public function getInputFilterSpecification()
    {
        $inputFilter = parent::getInputFilterSpecification();

        $inputFilter['code'] = [
            'name' => 'code',
            'required' => true,
            'filters' => [
                //StripTags == remove the unwanted html tags
                //StringTrim == remove the unnecessary spaces (\r or \t or \n...) at each line start/end
                ['name' => StripTags::class],
                ['name' => StringTrim::class],
            ],
            'validators' => [
                [
                    'name' => StringLength::class,
                    'options' => [
                        'encoding' => 'UTF-8',
                        'min' => 1,
                    ],
                ],
                $this->getCodeValidator(),
            ],
        ];

//        $inputFilter['cible'] = [
//            'name' => 'cible',
//            'required' => false,
//            'filters' => [
//                ['name' => ToInt::class],
//                [
//                    'name' => ToNull::class,
//                    'options' => [
//                        ToNull::TYPE_INTEGER
//                    ],
//                ],
//            ],
//        ];

        return $inputFilter;
    }
}
