<?php

namespace MeteoSI\Model;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Laminas\Permissions\Acl\Resource\ResourceInterface;

class CibleDependance implements ResourceInterface
{
    const RESOURCE_ID = 'CibleDependance';

    /** @var int $id */
    private $id;

    /** @var CibleEvenement $parent */
    private $parent;

    /** @var CibleEvenement $enfant */
    private $enfant;

    /** @var CibleDependancePriorite $parentPriorite */
    private $parentPriorite;

    /** @var Collection|RegleTransition[] */
    private $regleTransitions;

    /**
     * Retourne l'identifiant de la ressource sous forme de chaîne de caractères
     *
     * @return string
     */
    public function getResourceId(): string
    {
        return self::RESOURCE_ID;
    }

    /** Constructeur */
    public function __construct()
    {
        $this->regleTransitions = new ArrayCollection();
    }

//Règles de transition

    /**
     * @param RegleTransition $regleTransition
     * @return void
     */
    public function addRegleTransition(RegleTransition $regleTransition): void
    {
        $this->regleTransitions->add($regleTransition);
    }

    /**
     * @param RegleTransition $regleTransition
     * @return void
     */
    public function removeRegleTransition(RegleTransition $regleTransition): void
    {
        $this->regleTransitions->removeElement($regleTransition);
    }

    /**
     * @return void
     */
    public function removeAllRegleTransitions(): void
    {
        $this->regleTransitions->clear();
    }

    /**
     * @return Collection|null
     */
    public function getRegleTransitions()
    {
        return $this->regleTransitions;
    }

//GETTERS ET SETTERS
    /**
     * @return int|null
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return CibleEvenement|null
     */
    public function getParent()
    {
        return $this->parent;
    }

    /**
     * @return CibleEvenement|null
     */
    public function getEnfant()
    {
        return $this->enfant;
    }

    /**
     * @return CibleDependancePriorite|null
     */
    public function getParentPriorite()
    {
        return $this->parentPriorite;
    }

    /**
     * @param int $id
     */
    public function setId(int $id): void
    {
        $this->id = $id;
    }

    /**
     * @param CibleEvenement $parent
     */
    public function setParent(CibleEvenement $parent): void
    {
        $this->parent = $parent;
    }

    /**
     * @param CibleEvenement $enfant
     */
    public function setEnfant(CibleEvenement $enfant): void
    {
        $this->enfant = $enfant;
    }

    /**
     * @param CibleDependancePriorite $parentPriorite
     */
    public function setParentPriorite(CibleDependancePriorite $parentPriorite): void
    {
        $this->parentPriorite = $parentPriorite;
    }
}