<?php

namespace MeteoSI\Service\Renderer\Evenement\EvenementInfo;

use Interop\Container\ContainerInterface;
use Laminas\View\Renderer\PhpRenderer;

class EvenementInfoServiceFactory {

    /**
     * @param ContainerInterface $container
     * @return EvenementInfoService
     */
    public function __invoke(ContainerInterface $container) : EvenementInfoService
    {
        /* @var EvenementInfoService $service  */
        $service = new EvenementInfoService();
        return $service;
    }
}
