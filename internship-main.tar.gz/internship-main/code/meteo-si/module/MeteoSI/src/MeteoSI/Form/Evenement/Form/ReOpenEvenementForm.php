<?php

namespace MeteoSI\Form\Evenement\Form;

use Application\Application\Form\AbstractEntityForm;
use MeteoSI\Form\Evenement\Fieldset\ReOpenEvenementFieldset;

class ReOpenEvenementForm extends AbstractEntityForm
{
    public function __construct($name = null)
    {
        parent::__construct('evenement');
    }

    protected function initEntityFieldset()
    {
        $this->entityFieldset = $this->getFormFactory()->getFormElementManager()->get(ReOpenEvenementFieldset::class);
        $this->entityFieldset->setOptions([
            'use_as_base_fieldset' => true,
        ]);
        $this->add($this->entityFieldset);
    }

    protected function initSubmitInput()
    {
        $this->add([
            'name' => 'submit',
            'type' => 'submit',
            'attributes' => [
                'value' => 'Go',
                'id' => 'submitbutton',
            ],
        ]);
    }
}
