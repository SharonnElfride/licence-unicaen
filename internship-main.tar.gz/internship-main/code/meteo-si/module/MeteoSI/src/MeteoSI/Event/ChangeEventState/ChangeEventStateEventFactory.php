<?php

namespace MeteoSI\Event\ChangeEventState;

use Interop\Container\Containerinterface;
use Laminas\ServiceManager\Factory\FactoryInterface;
use MeteoSI\Service\Evenement\EvenementService;

class ChangeEventStateEventFactory implements FactoryInterface
{
    public function __invoke(ContainerInterface $container, $requestedName, ?array $options = null)
    {
        /** @var ChangeEventStateEvent $event */
        $event = new ChangeEventStateEvent();

        /** @var EvenementService $entityService */
        $entityService = $container->get('ServiceManager')->get(EvenementService::class);
        $event->setEvenementService($entityService);

//        $userContextService = $container->get('UnicaenAuthentification\Service\UserContext');
//        $event->setServiceUserContext($userContextService);

        return $event;
    }
}