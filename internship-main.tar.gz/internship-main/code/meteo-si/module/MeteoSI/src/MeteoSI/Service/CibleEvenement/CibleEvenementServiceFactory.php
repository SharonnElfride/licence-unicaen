<?php

namespace MeteoSI\Service\CibleEvenement;

use Doctrine\ORM\EntityManager;
use Interop\Container\ContainerInterface;
use Laminas\ServiceManager\Factory\FactoryInterface;
use MeteoSI\Service\CibleEvenement\Dependance\RegleTransition\RegleTransitionService;

/**
 * Class CibleEvenementServiceFactory
 * @package MeteoSI\Service\CibleEvenement
 */
class CibleEvenementServiceFactory implements FactoryInterface
{

    /**
     * @param ContainerInterface $container
     * @param string $requestedName
     * @param array|null $options
     * @return CibleEvenementService|object
     */
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        /** @var CibleEvenementService $serviceProvider */
        $serviceProvider = new CibleEvenementService();

        /** @var EntityManager $entityManager */
        $entityManager = $container->get(EntityManager::class);
        $serviceProvider->setEntityManager($entityManager);

        /** @var RegleTransitionService $regleTrensitionService */
        $regleTrensitionService = $container->get(RegleTransitionService::class);
        $serviceProvider->setRegleTransitionService($regleTrensitionService);

        return $serviceProvider;
    }
}
