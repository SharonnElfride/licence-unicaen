<?php

namespace MeteoSI\Service\Renderer\Date;

use Interop\Container\ContainerInterface;
use Laminas\View\Renderer\PhpRenderer;

class DateRendererServiceFactory {

    /**
     * @param ContainerInterface $container
     * @return DateRendererService
     */
    public function __invoke(ContainerInterface $container) : DateRendererService
    {
        /* @var DateRendererService $service  */
        $service = new DateRendererService();
        return $service;
    }
}
