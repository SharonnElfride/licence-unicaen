<?php

namespace MeteoSI\Form\CibleEvenement\CibleBdd\Factory;

use Doctrine\Laminas\Hydrator\DoctrineObject;
use Doctrine\ORM\EntityManager;
use Interop\Container\ContainerInterface;
use Laminas\ServiceManager\Factory\FactoryInterface;
use Laminas\Validator\ValidatorPluginManager;
use MeteoSI\Form\CibleEvenement\Cible\Validator\StateEditValidator;
use MeteoSI\Form\CibleEvenement\CibleBdd\CibleEvenementBddFieldset;
use MeteoSI\Form\CibleEvenement\CibleBdd\Hydrator\CibleEvenementBddHydrator;
use MeteoSI\Model\CibleEvenementBdd;

/**
 * Class CibleEvenementBddFieldsetFactory
 */
class CibleEvenementBddFieldsetFactory implements FactoryInterface
{
    /**
     * Create fieldset
     *
     * @param ContainerInterface $container
     * @param string $requestedName
     * @param array|null $options
     * @return CibleEvenementBddFieldset|object
     */
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        /** @var CibleEvenementBddFieldset $fieldset */
        $fieldset = new CibleEvenementBddFieldset('cibleEvenementBdd');

        /** @var EntityManager $entityManager */
        $entityManager = $container->get(EntityManager::class);
        $fieldset->setEntityManager($entityManager);

        /** @var CibleEvenementBddHydrator $hydrator */
        $hydrator = $container->get('HydratorManager')->get(CibleEvenementBddHydrator::class);
        $fieldset->setHydrator($hydrator);
        $fieldset->setObject(new CibleEvenementBdd());
        return $fieldset;
    }
}
