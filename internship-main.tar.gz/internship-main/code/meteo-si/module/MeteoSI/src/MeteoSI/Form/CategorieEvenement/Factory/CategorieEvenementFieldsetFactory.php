<?php

namespace MeteoSI\Form\CategorieEvenement\Factory;

use Laminas\ServiceManager\ServiceManager;
use Laminas\Validator\ValidatorPluginManager;
use MeteoSI\Form\CategorieEvenement\CategorieEvenementFieldset;
use MeteoSI\Form\Shared\Validator\CodeValidator;
use MeteoSI\Model\CategorieEvenement;
use Doctrine\Laminas\Hydrator\DoctrineObject;
use Doctrine\ORM\EntityManager;
use Interop\Container\ContainerInterface;
use Laminas\ServiceManager\Factory\FactoryInterface;
use MeteoSI\Service\CategorieEvenement\CategorieEvenementService;
use MeteoSI\Service\CategorieEvenement\CategorieEvenementServiceAwareTrait;

/**
 * Class CategorieEvenementFieldsetFactory
 */
class CategorieEvenementFieldsetFactory implements FactoryInterface
{
    use CategorieEvenementServiceAwareTrait;
    /**
     * Create fieldset
     *
     * @param ContainerInterface $container
     * @param string $requestedName
     * @param array|null $options
     * @return CategorieEvenementFieldset|object
     */
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        /** @var CategorieEvenementFieldset $fieldset */
        $fieldset = new CategorieEvenementFieldset('categorie');

        /** @var EntityManager $entityManager */
        $entityManager = $container->get(EntityManager::class);
        $fieldset->setEntityManager($entityManager);

        /** @var CodeValidator $codeValidator */
        $codeValidator = $container->get(ValidatorPluginManager::class)->get(CodeValidator::class);
        /** @var CategorieEvenementService $entityService */
        $entityService = $container->get('ServiceManager')->get(CategorieEvenementService::class);
        $codeValidator->setEntiteService($entityService);

        /** @var DoctrineObject $hydrator */
        $hydrator = $container->get('HydratorManager')->get(DoctrineObject::class);
        $fieldset->setHydrator($hydrator);
        $fieldset->setObject(new CategorieEvenement());
        $codeValidator->setEntite($fieldset->getObject());

        $fieldset->setCodeValidator($codeValidator);
        return $fieldset;
    }
}
