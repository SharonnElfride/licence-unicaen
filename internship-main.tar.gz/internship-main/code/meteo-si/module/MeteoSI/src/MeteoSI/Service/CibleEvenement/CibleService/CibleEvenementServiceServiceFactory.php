<?php

namespace MeteoSI\Service\CibleEvenement\CibleService;

use Doctrine\ORM\EntityManager;
use Interop\Container\ContainerInterface;
use Laminas\ServiceManager\Factory\FactoryInterface;

/**
 * Class CibleEvenementServiceServiceFactory
 * @package MeteoSI\Service\CibleEvenement\CibleService
 */
class CibleEvenementServiceServiceFactory implements FactoryInterface
{

    /**
     * @param ContainerInterface $container
     * @param string $requestedName
     * @param array|null $options
     * @return CibleEvenementServiceService|object
     */
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        /** @var CibleEvenementServiceService $serviceProvider */
        $serviceProvider = new CibleEvenementServiceService();

        /** @var EntityManager $entityManager */
        $entityManager = $container->get(EntityManager::class);
        $serviceProvider->setEntityManager($entityManager);

        return $serviceProvider;
    }
}
