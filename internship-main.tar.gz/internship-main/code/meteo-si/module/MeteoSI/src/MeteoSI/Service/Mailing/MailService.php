<?php

namespace MeteoSI\MeteoSI\Service\Mailing;

use DateTime;
use Exception;
use http\Exception\RuntimeException;
use MeteoSI\Model\CategorieEvenement;
use MeteoSI\Model\CibleEvenement;
use MeteoSI\Model\EtatCible;
use MeteoSI\Model\EtatEvenement;
use MeteoSI\Model\Evenement;
use MeteoSI\Provider\Mailing\CodesMailsProvider;
use MeteoSI\Service\Renderer\Date\DateRendererServiceAwareTrait;
use MeteoSI\Service\Renderer\Evenement\EvenementInfo\EvenementInfoServiceAwareTrait;
use MeteoSI\Service\Renderer\Url\UrlServiceAwareTrait;
use UnicaenMail\Entity\Db\Mail;
use UnicaenRenderer\Entity\Db\Template;
use UnicaenRenderer\Service\Macro\MacroService;
use UnicaenRenderer\Service\Macro\MacroServiceAwareTrait;
use UnicaenRenderer\Service\Rendu\RenduServiceAwareTrait;
use UnicaenRenderer\Service\Template\TemplateServiceAwareTrait;

/** Surcouche du module MailService pour gerer les cas spécifique de l'application */
class MailService extends \UnicaenMail\Service\Mail\MailService
{
    //Liens vers les templates
    use MacroServiceAwareTrait;
    use TemplateServiceAwareTrait;
    use DateRendererServiceAwareTrait;
    use EvenementInfoServiceAwareTrait;
    use UrlServiceAwareTrait;

    const CLASS_MACRO = 'macro';
    const CLASS_MACRO_NO_METHODE = 'macro-no-methode';
    const CLASS_MACRO_NO_VARIABLES = 'macro-no-variable';
    const CLASS_MACRO_NOT_NOT_DEFIND = 'macro-not-defind';

    /*************************************************
     * Envoye des mails type
     ************************************************/

    /**
     * @param string $codeMail
     * @param array $data
     * @return Mail
     */
    public function sendMailType(string $codeMail, array $data = []): Mail
    {
        try {
            $modeleMailService = $this->getTemplateService();
            /** @var MacroService $macroService */
            $macroService = $this->getMacroService();
            //Securité : on vérifie que l'on peut bien envoyer le mail type demandé (action a effectuer logiquement en amont mais mise également ici par sécurité pour ne pas faire d'erreur)
            $this->canSendMailType($codeMail, $data);

            $template = $modeleMailService->getTemplateByCode($codeMail);
            $macroData = $this->getMacroVariablesForMailTemplate($template, $data);
            $to = $this->getMailTypeDestinataires($codeMail, $data);
            $sujet = $template->getSujet();
            $corps = $template->getCorps();
            $sujet = $this->replaceMacros($sujet, $macroData);
            $corps = $this->replaceMacros($corps, $macroData);
            $mail = $this->sendMail($to, $sujet, $corps);
            $motsClef = $this->getMailTypeKeyWords($codeMail, $data);
            $mail->setMotsClefs($motsClef);
            $this->update($mail);
            return $mail;
        }
        catch (Exception $e)
        {
            throw new RuntimeException($e->getMessage());
        }
    }

    /**
     * Génération des variables pour les macros
     * Donner le maximum d'entités possible même si a priori elle ne servent pas afin de les prendres en compte si possible en cas de modification d'une macro
     * @param Template $modele //Donnée en cas de besoins. Pour le momment inutile
     * @param array $data
     * @return array
     */
    public function getMacroVariablesForMailTemplate(Template $modele, array $data = [])
    {
        /** @var MacroService $macroService */
        $macroService = $this->getMacroService();
        $variables = [];

        //On met le maximum de donnée possible
    //En relation avec les dépendances entre cibles d'événement
        /** @var Evenement $evenement */
        $evenement = ($data['evenement']) ?? null;

        /** @var CategorieEvenement $categorieEvenement */
        $categorieEvenement = (isset($evenement)) ? $evenement->getCategorie() : null;

        /** @var CibleEvenement $cibleEvenement */
        $cibleEvenement = (isset($evenement)) ? $evenement->getCible() : null;

        /** @var EtatEvenement $etatEvenement */
        $etatEvenement = (isset($evenement)) ? $evenement->getEtat() : null;

        $servicesAffectes = "";
        if (isset($evenement)):
            $cible = $evenement->getCible();
            if ($cible !== null) {
                foreach ($cible->getEnfants() as $enfant):
                    $servicesAffectes .= $enfant->getLibelle() . ", ";
                endforeach;
            }
        endif;

        $dateRendererService = $this->getDateRendererService();
        $dateRendererService->setVariables(['evenement' => $evenement]);

        $evenementInfoService = $this->getEvenementInfoService();
        $evenementInfoService->setVariables(['evenement' => $evenement]);

        $urlService = $this->getUrlService();

        //Gestion des variables
        if (isset($evenement)) $variables['evenement'] = $evenement;
        if (isset($categorieEvenement)) $variables['categorieEvenement'] = $categorieEvenement;
        if (isset($cibleEvenement)) $variables['cibleEvenement'] = $cibleEvenement;
        if (isset($etatEvenement)) $variables['etatEvenement'] = $etatEvenement;

    //En relation avec les dépendances entre cibles d'événement
        /** @var CibleEvenement $cibleEnfant */
        $cibleEnfant = ($data['cibleEnfant']) ?? null;
        if(isset($cibleEnfant)) {
            /** @var EtatCible $etatCibleEnfant */
            $etatCibleEnfant = $cibleEnfant->getEtat();

            $evenementInfoService->setVariables(['cibleParent' => $cibleEvenement]);

            $variables['cibleEvenement'] = $cibleEnfant;
            $variables['etatCible'] = $etatCibleEnfant;
        }

        $variables['evenementInfoService'] = $evenementInfoService;
        $variables['dateRendererService'] = $dateRendererService;
        $variables['urlService'] = $urlService;

        return $variables;
    }

    /**
     * @param string $code
     * @param array $data
     * @return array
     */
    public function getMailTypeDestinataires(string $code, array $data = [])
    {
        //TODO take the list in evenement->getDestinataires()
        $destinataires = [];

        switch ($code) {
            case CodesMailsProvider::NOUVEL_EVENEMENT:
            case CodesMailsProvider::MODIFICATION_EVENEMENT:
            case CodesMailsProvider::RE_OUVERTURE_EVENEMENT:
            case CodesMailsProvider::FIN_EVENEMENT:
                /** @var Evenement $evenement */
                $evenement = ($data['evenement']) ?? null;
                if (!$evenement) break;
                $destinataires = $evenement->getDestinataires();
                $destinataires = explode(',', $destinataires);
                break;
            case CodesMailsProvider::MAIL_D_ENREGISTREMENT_ENVOYE_AUX_CIBLES_ENFANTS:
            case CodesMailsProvider::MAIL_DE_MODIFICATION_ENVOYE_AUX_CIBLES_ENFANTS:
            case CodesMailsProvider::MAIL_DE_REOUVERTURE_ENVOYE_AUX_CIBLES_ENFANTS:
            case CodesMailsProvider::MAIL_DE_FIN_ENVOYE_AUX_CIBLES_ENFANTS:
                /** @var Evenement $evenement */
                $evenement = ($data['evenement']) ?? null;
                $cibleEnfant = ($data['cibleEnfant']) ?? null;
                if (!$evenement) break;
                if (!$cibleEnfant) break;
                $destinataires = $evenement->getDestinataires();
                $destinataires = explode(',', $destinataires);
                break;
            case CodesMailsProvider::NOTIFICATION_DE_RAPPEL_AU_CREATEUR_D_UN_EVENEMENT_POUR_SA_CLOTURE:
                /** @var Evenement $evenement */
                $evenement = ($data['evenement']) ?? null;
                if (!$evenement) break;
                $destinataires = ($data['createurEmail']) ?? null;
                $destinataires = explode(',', $destinataires);
                break;
        }

        return $destinataires;
    }

    public function getMailTypeKeyWords(string $codeMail, array $data = [])
    {
        $motsClef = [];

//        $motsClef[] = sprintf("MailType=%s", $codeMail);
//        /** @var Stage $stage */
//        $stage = ($data['stage']) ?? null;
//        /** @var ContactStage $contactStage */
//        $contactStage = ($data['contactStage']) ?? null;
//
//        switch ($codeMail) {//A priori pas de différences pour les mails types mais celà pourrais changer
//            case CodesMailsProvider::STAGE_DEBUT_CHOIX:
//            case CodesMailsProvider::STAGE_DEBUT_CHOIX_RAPPEL:
//            case CodesMailsProvider::AFFECTATION_STAGE_VALIDEE:
//                $motsClef[] = sprintf("StageId=%s", (isset($stage)) ? $stage->getId() : '-1');
//            case CodesMailsProvider::VALIDATION_STAGE:
//            case CodesMailsProvider::VAlIDATION_STAGE_RAPPEL:
//                $motsClef[] = sprintf("StageId=%s", (isset($stage)) ? $stage->getId() : '-1');
//                $motsClef[] = sprintf("ContactStageId=%s", (isset($contactStage)) ? $contactStage->getId() : '-1');
//                break;
//        }
        return $motsClef;
    }

    // détermine si un mail type correspondant aux données fournis à déjà été envoyée
    public function mailTypeSended($codeMail, $data)
    {
        $keywordList = $this->getMailTypeKeyWords($codeMail, $data);
        $motsClef = implode(Mail::MOTCLEF_SEPARATEUR, $keywordList);
        $mailValidationSend = $this->getEntityManager()->getRepository(Mail::class)->findOneBy(['motsClefs' => $motsClef]);
        return isset($mailValidationSend);
    }

    /** ***************************************************************************************/

    /**
     * Sécurité pour l'envoie des mails types que toutes les conditions sont bien fournies
     * Ces vérification sont faites par sécurité mais doivent théoriquement être vérifier avant
     * Cette fonction ne sert que pour la sécurité juste avant l'envoie du mail
     * Génére des exceptions si impossible à capturer si besoins
     * @param string $codeMail
     * @param array $data
     * @return bool
     */
    public function canSendMailType(string $codeMail, array $data = []): bool
    {
        $template = $this->getTemplateService()->getTemplateByCode($codeMail);
        if (!$template) {
            $msg = sprintf("Impossible d'envoyer le mail de code %s. ", $codeMail);
            $msg .= "<br /> Le modéle n'as pas été trouvé.";
            throw new Exception($msg);
        }

        $destinataires = $this->getMailTypeDestinataires($codeMail, $data);
        if (sizeof($destinataires) == 0) {
            $msg = sprintf("Impossible d'envoyer le mail de code %s. ", $codeMail);
            $msg .= "<br /> Le(s) destinataire(s) ne peuvent pas être défini(s).";
            throw new Exception($msg);
        }
        foreach ($destinataires as $to) {
            if (!$this->adressesMailsAreValides($to)) {
                $msg = sprintf("Impossible d'envoyer le mail de code %s. ", $codeMail);
                $msg .= "<br /> L'un des destinaire n'est pas valide.";
                throw new Exception($msg);
            }
        }

        switch ($codeMail) {
            case CodesMailsProvider::TEST:
                return true;
            case CodesMailsProvider::NOUVEL_EVENEMENT:
                if (!isset($data['evenement'])) {
                    $msg = sprintf("Impossible d'envoyer le mail de code %s. ", $codeMail);
                    $msg .= "<br /> L'événement correspondant n'a pas été trouvé";
                    throw new Exception($msg);
                }
                /** @var Evenement $evenement */
                $evenement = $data['evenement'];
                if (!$evenement instanceof Evenement) {
                    $msg = sprintf("Impossible d'envoyer le mail de code %s. ", $codeMail);
                    $msg .= "<br /> L'objet fourni n'est pas un événement";
                    throw new Exception($msg);
                }
                $destinataires = $this->getMailTypeDestinataires(CodesMailsProvider::NOUVEL_EVENEMENT, $data);
                if (sizeof($destinataires) == 0)
                    return false;
                break;
            case CodesMailsProvider::MODIFICATION_EVENEMENT:
                if (!isset($data['evenement'])) {
                    $msg = sprintf("Impossible d'envoyer le mail de code %s. ", $codeMail);
                    $msg .= "<br /> L'événement correspondant n'a pas été trouvé";
                    throw new Exception($msg);
                }
                /** @var Evenement $evenement */
                $evenement = $data['evenement'];
                if (!$evenement instanceof Evenement) {
                    $msg = sprintf("Impossible d'envoyer le mail de code %s. ", $codeMail);
                    $msg .= "<br /> L'objet fourni n'est pas un événement";
                    throw new Exception($msg);
                }
                $destinataires = $this->getMailTypeDestinataires(CodesMailsProvider::MODIFICATION_EVENEMENT, $data);
                if (sizeof($destinataires) == 0)
                    return false;
                break;
            case CodesMailsProvider::RE_OUVERTURE_EVENEMENT:
                if (!isset($data['evenement'])) {
                    $msg = sprintf("Impossible d'envoyer le mail de code %s. ", $codeMail);
                    $msg .= "<br /> L'événement correspondant n'a pas été trouvé";
                    throw new Exception($msg);
                }
                /** @var Evenement $evenement */
                $evenement = $data['evenement'];
                if (!$evenement instanceof Evenement) {
                    $msg = sprintf("Impossible d'envoyer le mail de code %s. ", $codeMail);
                    $msg .= "<br /> L'objet fourni n'est pas un événement";
                    throw new Exception($msg);
                }
                $destinataires = $this->getMailTypeDestinataires(CodesMailsProvider::RE_OUVERTURE_EVENEMENT, $data);
                if (sizeof($destinataires) == 0)
                    return false;
                break;
            case CodesMailsProvider::FIN_EVENEMENT:
                if (!isset($data['evenement'])) {
                    $msg = sprintf("Impossible d'envoyer le mail de code %s. ", $codeMail);
                    $msg .= "<br /> L'événement correspondant n'a pas été trouvé";
                    throw new Exception($msg);
                }
                /** @var Evenement $evenement */
                $evenement = $data['evenement'];
                if (!$evenement instanceof Evenement) {
                    $msg = sprintf("Impossible d'envoyer le mail de code %s. ", $codeMail);
                    $msg .= "<br /> L'objet fourni n'est pas un événement";
                    throw new Exception($msg);
                }
                $destinataires = $this->getMailTypeDestinataires(CodesMailsProvider::FIN_EVENEMENT, $data);
                if (sizeof($destinataires) == 0)
                    return false;
                break;
            case CodesMailsProvider::MAIL_D_ENREGISTREMENT_ENVOYE_AUX_CIBLES_ENFANTS:
                if (!isset($data['evenement'])) {
                    $msg = sprintf("Impossible d'envoyer le mail de code %s. ", $codeMail);
                    $msg .= "<br /> L'événement correspondant n'a pas été trouvé";
                    throw new Exception($msg);
                }
                /** @var Evenement $evenement */
                $evenement = $data['evenement'];
                if (!$evenement instanceof Evenement) {
                    $msg = sprintf("Impossible d'envoyer le mail de code %s. ", $codeMail);
                    $msg .= "<br /> L'objet fourni n'est pas un événement";
                    throw new Exception($msg);
                }

                if (!isset($data['cibleEnfant'])) {
                    $msg = sprintf("Impossible d'envoyer le mail de code %s. ", $codeMail);
                    $msg .= "<br /> La cible correspondante n'a pas été trouvée";
                    throw new Exception($msg);
                }
                /** @var Evenement $cibleEnfant */
                $cibleEnfant = $data['cibleEnfant'];
                if (!$cibleEnfant instanceof CibleEvenement) {
                    $msg = sprintf("Impossible d'envoyer le mail de code %s. ", $codeMail);
                    $msg .= "<br /> L'objet fourni n'est pas une cible d'événement";
                    throw new Exception($msg);
                }
                $destinataires = $this->getMailTypeDestinataires(CodesMailsProvider::MAIL_D_ENREGISTREMENT_ENVOYE_AUX_CIBLES_ENFANTS, $data);
                if (sizeof($destinataires) == 0)
                    return false;
                break;
            case CodesMailsProvider::MAIL_DE_MODIFICATION_ENVOYE_AUX_CIBLES_ENFANTS:
                if (!isset($data['evenement'])) {
                    $msg = sprintf("Impossible d'envoyer le mail de code %s. ", $codeMail);
                    $msg .= "<br /> L'événement correspondant n'a pas été trouvé";
                    throw new Exception($msg);
                }
                /** @var Evenement $evenement */
                $evenement = $data['evenement'];
                if (!$evenement instanceof Evenement) {
                    $msg = sprintf("Impossible d'envoyer le mail de code %s. ", $codeMail);
                    $msg .= "<br /> L'objet fourni n'est pas un événement";
                    throw new Exception($msg);
                }

                if (!isset($data['cibleEnfant'])) {
                    $msg = sprintf("Impossible d'envoyer le mail de code %s. ", $codeMail);
                    $msg .= "<br /> La cible correspondante n'a pas été trouvée";
                    throw new Exception($msg);
                }
                /** @var Evenement $cibleEnfant */
                $cibleEnfant = $data['cibleEnfant'];
                if (!$cibleEnfant instanceof CibleEvenement) {
                    $msg = sprintf("Impossible d'envoyer le mail de code %s. ", $codeMail);
                    $msg .= "<br /> L'objet fourni n'est pas une cible d'événement";
                    throw new Exception($msg);
                }
                $destinataires = $this->getMailTypeDestinataires(CodesMailsProvider::MAIL_DE_MODIFICATION_ENVOYE_AUX_CIBLES_ENFANTS, $data);
                if (sizeof($destinataires) == 0)
                    return false;
                break;
            case CodesMailsProvider::MAIL_DE_FIN_ENVOYE_AUX_CIBLES_ENFANTS:
                if (!isset($data['evenement'])) {
                    $msg = sprintf("Impossible d'envoyer le mail de code %s. ", $codeMail);
                    $msg .= "<br /> L'événement correspondant n'a pas été trouvé";
                    throw new Exception($msg);
                }
                /** @var Evenement $evenement */
                $evenement = $data['evenement'];
                if (!$evenement instanceof Evenement) {
                    $msg = sprintf("Impossible d'envoyer le mail de code %s. ", $codeMail);
                    $msg .= "<br /> L'objet fourni n'est pas un événement";
                    throw new Exception($msg);
                }

                if (!isset($data['cibleEnfant'])) {
                    $msg = sprintf("Impossible d'envoyer le mail de code %s. ", $codeMail);
                    $msg .= "<br /> La cible correspondante n'a pas été trouvée";
                    throw new Exception($msg);
                }
                /** @var Evenement $cibleEnfant */
                $cibleEnfant = $data['cibleEnfant'];
                if (!$cibleEnfant instanceof CibleEvenement) {
                    $msg = sprintf("Impossible d'envoyer le mail de code %s. ", $codeMail);
                    $msg .= "<br /> L'objet fourni n'est pas une cible d'événement";
                    throw new Exception($msg);
                }
                $destinataires = $this->getMailTypeDestinataires(CodesMailsProvider::MAIL_DE_FIN_ENVOYE_AUX_CIBLES_ENFANTS, $data);
                if (sizeof($destinataires) == 0)
                    return false;
                break;
            case CodesMailsProvider::MAIL_DE_REOUVERTURE_ENVOYE_AUX_CIBLES_ENFANTS:
                if (!isset($data['evenement'])) {
                    $msg = sprintf("Impossible d'envoyer le mail de code %s. ", $codeMail);
                    $msg .= "<br /> L'événement correspondant n'a pas été trouvé";
                    throw new Exception($msg);
                }
                /** @var Evenement $evenement */
                $evenement = $data['evenement'];
                if (!$evenement instanceof Evenement) {
                    $msg = sprintf("Impossible d'envoyer le mail de code %s. ", $codeMail);
                    $msg .= "<br /> L'objet fourni n'est pas un événement";
                    throw new Exception($msg);
                }

                if (!isset($data['cibleEnfant'])) {
                    $msg = sprintf("Impossible d'envoyer le mail de code %s. ", $codeMail);
                    $msg .= "<br /> La cible correspondante n'a pas été trouvée";
                    throw new Exception($msg);
                }
                /** @var Evenement $cibleEnfant */
                $cibleEnfant = $data['cibleEnfant'];
                if (!$cibleEnfant instanceof CibleEvenement) {
                    $msg = sprintf("Impossible d'envoyer le mail de code %s. ", $codeMail);
                    $msg .= "<br /> L'objet fourni n'est pas une cible d'événement";
                    throw new Exception($msg);
                }
                $destinataires = $this->getMailTypeDestinataires(CodesMailsProvider::MAIL_DE_REOUVERTURE_ENVOYE_AUX_CIBLES_ENFANTS, $data);
                if (sizeof($destinataires) == 0)
                    return false;
                break;
            case CodesMailsProvider::NOTIFICATION_DE_RAPPEL_AU_CREATEUR_D_UN_EVENEMENT_POUR_SA_CLOTURE:
                if (!isset($data['evenement'])) {
                    $msg = sprintf("Impossible d'envoyer le mail de code %s. ", $codeMail);
                    $msg .= "<br /> L'événement correspondant n'a pas été trouvé";
                    throw new Exception($msg);
                }
                /** @var Evenement $evenement */
                $evenement = $data['evenement'];
                if (!$evenement instanceof Evenement) {
                    $msg = sprintf("Impossible d'envoyer le mail de code %s. ", $codeMail);
                    $msg .= "<br /> L'objet fourni n'est pas un événement";
                    throw new Exception($msg);
                }
                $destinataires = $this->getMailTypeDestinataires(CodesMailsProvider::NOTIFICATION_DE_RAPPEL_AU_CREATEUR_D_UN_EVENEMENT_POUR_SA_CLOTURE, $data);
                if (sizeof($destinataires) == 0)
                    return false;
                break;
            default:
                $msg = sprintf("Impossible d'envoyer le mail de code %s. ", $codeMail);
                $msg .= sprintf("Le code du modéle n'est pas définie");
                throw new Exception($msg);

        }

        return true;
    }

    /**
     * @param string|null $mails
     * @return boolean
     */
    public function adressesMailsAreValides($mails)
    {
        if ($mails === null) {
            return false;
        }
        if ($mails == "") {
            return false;
        }
        $mails = explode(",", $mails);
        foreach ($mails as $mail) {
            $mail = trim($mail);
            if ($mail == "") {
                return false;
            }
            if (!filter_var($mail, FILTER_VALIDATE_EMAIL)) {
                return false;
            }
        }
        return true;
    }

    /** @desc retourne la liste des macros présente dans un text plus celle non remplacée */
    public function findMacrosInText(string $texteInitial)
    {
        if ($texteInitial === null || $texteInitial == '') {
            return [];
        }
        $matches = [];
        preg_match_all('/VAR\[[a-zA-Z0-9_]*#[a-zA-Z0-9_]*\]/', $texteInitial, $matches);
        $macros = array_unique($matches[0]);
        return $macros;
    }

    /**
     * @param string|null $texteInitial
     * @param array $variables
     * @return string
     */
    public function replaceMacros(?string $texteInitial, array $variables = []): string
    {
        if ($texteInitial === null || $texteInitial == '') return "";
        $macros = $this->findMacrosInText($texteInitial);
        if (sizeof($macros) == 0) {
            return $texteInitial;
        }
        foreach ($macros as $macro) {
            $macroValue = $this->getMacroService()->getTexte($macro, $variables);
            $replacements[$macro] = $macroValue;
        }
        $text = str_replace($macros, $replacements, $texteInitial);
        return $text;
    }

    //Détermine si du text contient une macro qui n'as pas été remplacé (ou qui n'as pas pu l'être)
    public function textContainsMacro($text)
    {
        if ($text === null || $text == '') return false;
        //Macros dont le remplacement a échouée
        $patterns = [
            'VAR\[[a-zA-Z0-9_]*#[a-zA-Z0-9_]*\]',
            self::CLASS_MACRO,
            self::CLASS_MACRO_NO_METHODE,
            self::CLASS_MACRO_NO_VARIABLES,
            self::CLASS_MACRO_NOT_NOT_DEFIND
        ];
        foreach ($patterns as $pattern) {
            $matches = [];
            preg_match_all('/' . $pattern . '/', $text, $matches);
            $patterns_matches = array_unique($matches[0]);
            if (sizeof($patterns_matches) > 0) return true;
        }
        return false;
    }
}