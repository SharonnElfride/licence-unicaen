<?php

namespace MeteoSI\Form\CibleEvenement\CibleService\Hydrator\Factory;

use Doctrine\ORM\EntityManager;
use Interop\Container\Containerinterface;
use Laminas\ServiceManager\Factory\FactoryInterface;
use MeteoSI\Form\CibleEvenement\CibleService\Hydrator\CibleEvenementServiceHydrator;

/**
 * Class CibleEvenementServiceHydratorFactory
 */
class CibleEvenementServiceHydratorFactory implements FactoryInterface
{
    /**
     * Create hydrator
     *
     * @return CibleEvenementServiceHydrator
     */
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        /** @var CibleEvenementServiceHydrator $hydrator */
        $hydrator = new CibleEvenementServiceHydrator();

        /** @var EntityManager $entityManager */
        $entityManager = $container->get(EntityManager::class);
        $hydrator->setEntityManager($entityManager);

//        $userContextService = $container->get('UnicaenAuthentification\Service\UserContext');
//        $hydrator->setServiceUserContext($userContextService);

        return $hydrator;
    }
}