<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace MeteoSI\Controller\ANoter;

use Doctrine\Common\Collections\ArrayCollection;
use Laminas\Mvc\Controller\AbstractActionController;
use Laminas\View\Model\ViewModel;
use MeteoSI\Model\Evenement;
use MeteoSI\Service\Evenement\EvenementServiceAwareTrait;

class PageInformationController extends AbstractActionController
{
    use EvenementServiceAwareTrait;

    /**
     * On sélectionne uniquement les événements à publier dans l'intranet (flus rss, export iCal et Page d'information)
     *
     * @return ViewModel
     */
    public function indexAction()
    {
        //Evenements en cours
        $evenementsEncours = $this->getEvenementService()->findAllByCodeEtat('encours');
        $evenements = new ArrayCollection();
        /** @var Evenement $evenement */
        foreach ($evenementsEncours as $evenement):
            if($evenement->getPublieIntranet())
                $evenements->add($evenement);
        endforeach;
        $evenementsEncours = $evenements;

        //Evenements à venir
        $evenementsAVenir = $this->getEvenementService()->findAllByCodeEtat('avenir');
        $evenements = new ArrayCollection();
        /** @var Evenement $evenement */
        foreach ($evenementsAVenir as $evenement):
            if($evenement->getPublieIntranet())
                $evenements->add($evenement);
        endforeach;
        $evenementsAVenir = $evenements;

        //Evenements terminés
        $evenementsTerminees = $this->getEvenementService()->findAllByCodeEtat('termine');
        $evenements = new ArrayCollection();
        /** @var Evenement $evenement */
        foreach ($evenementsTerminees as $evenement):
            if($evenement->getPublieIntranet())
                $evenements->add($evenement);
        endforeach;
        $evenementsTerminees = $evenements;

        return new ViewModel([
            'evenementsEnCours' => $evenementsEncours,
            'evenementsAVenir' => $evenementsAVenir,
            'evenementsTerminees' => $evenementsTerminees,
        ]);
    }


}