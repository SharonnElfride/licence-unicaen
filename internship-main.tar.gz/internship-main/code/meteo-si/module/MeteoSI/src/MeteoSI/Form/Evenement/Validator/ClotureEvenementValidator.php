<?php

namespace MeteoSI\Form\Evenement\Validator;

use Application\Application\Misc\Util;
use DateTime;
use Laminas\Validator\AbstractValidator;
use MeteoSI\Model\Evenement;

/**
 * Classe ClotureEvenementValidator
 */
class ClotureEvenementValidator extends AbstractValidator
{
    const DUREE_OBLIGATOIRE = 'DUREE_OBLIGATOIRE';
    const DATE_DEBUT_ANTERIEURE_A_FIN_REELLE = 'DATE_DEBUT_ANTERIEURE_A_FIN_REELLE';

    /** @var Evenement $evenement */
    private $evenement;

    //GETTERS ET SETTERS

    /**
     * @return Evenement
     */
    public function getEvenement(): Evenement
    {
        return $this->evenement;
    }

    /**
     * @param Evenement $evenement
     */
    public function setEvenement(Evenement $evenement): void
    {
        $this->evenement = $evenement;
    }

//Suite de la classe
    /**
     * @var array
     */
    protected $messageTemplates = [
        self::DUREE_OBLIGATOIRE => "Vous êtes dans l'obligation de renseigner l'une des valeurs suivantes: Date ou Heure.",
        self::DATE_DEBUT_ANTERIEURE_A_FIN_REELLE => "La date et l'heure de début doivent être antérieures à la date et à l'heure de fin réelle ou constatée.",
    ];

    public function setMessageTemplate($key, $value)
    {
        $this->messageTemplates[$key] = $value;
        $this->abstractOptions['messageTemplates'][$key] = $value;
    }

    /**
     * @var array
     */
    protected $messageVariables = [
    ];

    /**
     * Validation
     *
     * @param mixed $value
     * @param mixed $context Additional context to provide to the callback
     * @return bool
     */
    public function isValid($value, $context = null)
    {
        $ld = 0; //longueur date fin réelle
        $lh = 0; //longueur heure fin réelle

        //Durées estimée et minimale
        if (isset($context['dateFinReelle']))
            $ld = strlen($context['dateFinReelle']);
        if (isset($context['heureFinReelle']))
            $lh = strlen($context['heureFinReelle']);

        if (($ld == 0) && ($lh == 0)) {
            $this->error(self::DUREE_OBLIGATOIRE);
            return false;
        }

        //Date et heure de début
        $dateDeb = $this->evenement->getDateDebut();
        $ldf = $ld + $lh; //longueur totale

        if($ldf !== 0) {
            $finReelle = new DateTime($context['dateFinReelle']);
            $heure = explode(':', $context['heureFinReelle']);
            $finReelle->setTime(intval($heure[0]), intval($heure[1]));

            $deb = Util::formatIntlDateTime($dateDeb, 'dd/MM/yyyy à HH:mm');

            if($dateDeb > $finReelle) {
                $this->error(self::DATE_DEBUT_ANTERIEURE_A_FIN_REELLE);
                return false;
            }
        }

        return true;
    }

}