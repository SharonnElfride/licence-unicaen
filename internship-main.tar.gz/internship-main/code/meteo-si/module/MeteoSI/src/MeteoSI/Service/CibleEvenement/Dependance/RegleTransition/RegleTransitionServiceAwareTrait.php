<?php

namespace MeteoSI\Service\CibleEvenement\Dependance\RegleTransition;

trait RegleTransitionServiceAwareTrait
{
    /** @var RegleTransitionService $regleTransitionService */
    protected $regleTransitionService;

    /**
     * @return RegleTransitionService
     */
    public function getRegleTransitionService(): RegleTransitionService
    {
        return $this->regleTransitionService;
    }

    /**
     * @param RegleTransitionService $regleTransitionService
     */
    public function setRegleTransitionService(RegleTransitionService $regleTransitionService): void
    {
        $this->regleTransitionService = $regleTransitionService;
    }
}