<?php

namespace MeteoSI\Form\Evenement\Validator;

use DateTime;
use Laminas\Validator\AbstractValidator;

/**
 * Classe DateAnterieureCheckerValidator
 */
class DateAnterieureCheckerValidator extends AbstractValidator
{
    const DATE_DEBUT_ANTERIEURE_A_FIN_ESTIMEE = 'DATE_DEBUT_ANTERIEURE_A_FIN_ESTIMEE';
    const DATE_DEBUT_ANTERIEURE_A_FIN_MINIMALE = 'DATE_DEBUT_ANTERIEURE_A_FIN_MINIMALE';

    /**
     * @var array
     */
    protected $messageTemplates = [
        self::DATE_DEBUT_ANTERIEURE_A_FIN_ESTIMEE => "La date et l'heure de début doivent être antérieures à la date et à l'heure de fin estimée.",
        self::DATE_DEBUT_ANTERIEURE_A_FIN_MINIMALE => "La date et l'heure de début doivent être antérieures à la date et à l'heure de fin au plus tôt.",
    ];

    public function setMessageTemplate($key, $value)
    {
        $this->messageTemplates[$key] = $value;
        $this->abstractOptions['messageTemplates'][$key] = $value;
    }

    /**
     * @var array
     */
    protected $messageVariables = [
    ];

    /**
     * Validation
     *
     * @param mixed $value
     * @param mixed $context Additional context to provide to the callback
     * @return bool
     */
    public function isValid($value, $context = null)
    {
        $lde = 0; //longueur date estimée
        $ldm = 0; //longueur date minimale

        //Durées estimée et minimale
        if (isset($context['dateFinEstimee']))
            $lde += strlen($context['dateFinEstimee']);
        if (isset($context['heureFinEstimee']))
            $lde += strlen($context['heureFinEstimee']);

        if (isset($context['dateFinMinimale']))
            $ldm += strlen($context['dateFinMinimale']);
        if (isset($context['heureFinMinimale']))
            $ldm += strlen($context['heureFinMinimale']);

        //Date et heure de début
        $dateDeb = new DateTime($context['dateDebut']);
        $heure = explode(':', $context['heureDebut']);
        $dateDeb->setTime(intval($heure[0]), intval($heure[1]));

        if($lde !== 0) {
            $finEstimee = new DateTime($context['dateFinEstimee']);
            $heure = explode(':', $context['heureFinEstimee']);
            $finEstimee->setTime(intval($heure[0]), intval($heure[1]));

            if($dateDeb > $finEstimee) {
                $this->error(self::DATE_DEBUT_ANTERIEURE_A_FIN_ESTIMEE);
                return false;
            }
        }

        if($ldm !== 0) {
            $finMinimale = new DateTime($context['dateFinMinimale']);
            $heure = explode(':', $context['heureFinMinimale']);
            $finMinimale->setTime(intval($heure[0]), intval($heure[1]));

            if($dateDeb > $finMinimale) {
                $this->error(self::DATE_DEBUT_ANTERIEURE_A_FIN_MINIMALE);
                return false;
            }
        }

        return true;
    }
}