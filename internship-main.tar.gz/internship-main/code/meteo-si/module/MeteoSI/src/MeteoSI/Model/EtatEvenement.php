<?php

namespace MeteoSI\Model;

use Doctrine\Common\Collections\ArrayCollection;
use Laminas\Permissions\Acl\Resource\ResourceInterface;

class EtatEvenement implements ResourceInterface
{
    const RESOURCE_ID = 'EtatEvenement';

    /**
     *  L'identifiant de l'état
     * @var int $id
     */
    private $id;

    /**
     *  Le code de l'état
     * @var string $code
     */
    private $code;

    /**
     *  Le libelle de l'état
     * @var string $libelle
     */
    private $libelle;

    /**
     * La couleur de l'état
     * @var string $couleur
     */
    private $couleur;

    /**
     *  L'ordre d'affichage de l'état
     * @var int $ordre
     */
    private $ordre;

    /**
     * @var ArrayCollection|Evenement[] $evenements
     */
    private $evenements;

    /**
     * Constructeur permettant d'initialiser la liste des événements étant dans cet état particulier
     */
    public function __construct()
    {
        $this->evenements = new ArrayCollection();
    }

    /**
     * Retourne l'identifiant de la ressource sous forme de chaîne de caractères
     *
     * @return string
     */
    public function getResourceId(): string
    {
        return self::RESOURCE_ID;
    }

    /**
     * @param Evenement $evenement
     * @return void
     */
    public function addEvenement(Evenement $evenement): void
    {
        $this->evenements->add($evenement);
    }

    /**
     * @param Evenement $evenement
     * @return void
     */
    public function removeEvenement(Evenement $evenement): void
    {
        $this->evenements->removeElement($evenement);
    }

    /**
     * @return void
     */
    public function removeAll(): void
    {
        $this->evenements->clear();
    }

    /**
     * @return ArrayCollection|Evenement[]
     */
    public function getEvenements()
    {
        return $this->evenements;
    }

//GETTERS AND SETTERS

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return string
     */
    public function getCode(): string
    {
        return $this->code;
    }

    /**
     * @return string
     */
    public function getLibelle()
    {
        return $this->libelle;
    }

    /**
     * @return string
     */
    public function getCouleur()
    {
        return $this->couleur;
    }

    /**
     * @return int
     */
    public function getOrdre()
    {
        return $this->ordre;
    }

    /**
     * @param int $id
     * @return void
     */
    public function setId(int $id): void
    {
        $this->id = $id;
    }

    /**
     * @param string $code
     * @return void
     */
    public function setCode(string $code): void
    {
        $this->code = $code;
    }

    /**
     * @param string $libelle
     * @return void
     */
    public function setLibelle(string $libelle): void
    {
        $this->libelle = $libelle;
    }

    /**
     * @param string $couleur
     */
    public function setCouleur(string $couleur): void
    {
        $this->couleur = $couleur;
    }

    /**
     * @param int $ordre
     * @return void
     */
    public function setOrdre(int $ordre): void
    {
        $this->ordre = $ordre;
    }
}
