<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace MeteoSI\Controller\ANoter\Factory;

use Interop\Container\ContainerInterface;
use Laminas\ServiceManager\Factory\FactoryInterface;
use MeteoSI\Controller\ANoter\PageInformationController;
use MeteoSI\Service\Evenement\EvenementService;

class PageInformationControllerFactory implements FactoryInterface
{
    public function __invoke(ContainerInterface $container, $requestedName, ?array $options = null)
    {
        /** @var PageInformationController $controller */
        $controller = new PageInformationController();

        /** @var EvenementService $entityService */
        $entityService = $container->get('ServiceManager')->get(EvenementService::class);
        $controller->setEvenementService($entityService);

        return $controller;
    }
}