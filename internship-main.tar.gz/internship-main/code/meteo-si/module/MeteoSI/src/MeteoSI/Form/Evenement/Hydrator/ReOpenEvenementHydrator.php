<?php

namespace MeteoSI\Form\Evenement\Hydrator;

use Application\Application\Misc\UserAwaireTrait;
use DateTime;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\OptimisticLockException;
use Doctrine\ORM\ORMException;
use Laminas\Hydrator\AbstractHydrator;
use Laminas\Hydrator\HydratorInterface;
use MeteoSI\Model\CategorieEvenement;
use MeteoSI\Model\CibleEvenement;
use MeteoSI\Model\EtatCible;
use MeteoSI\Model\EtatEvenement;
use MeteoSI\Model\Evenement;
use MeteoSI\Model\PoleUtilisateur;
use UnicaenApp\Service\EntityManagerAwareTrait;

class ReOpenEvenementHydrator extends AbstractHydrator implements HydratorInterface
{
    use EntityManagerAwareTrait;
    use UserAwaireTrait;

    protected $LdapService;

    /**
     * @return mixed
     */
    public function getLdapService()
    {
        return $this->LdapService;
    }

    /**
     * @param mixed $LdapService
     */
    public function setLdapService($LdapService): void
    {
        $this->LdapService = $LdapService;
    }

    /**
     * Converts the given value so that it can be extracted by the hydrator.
     *
     * @param Evenement $entity (optional) The original object for context.
     * @throws ORMException
     * @throws OptimisticLockException
     * @return array Returns the value that should be extracted.
     */
    public function extract($entity): array
    {
        //Avoir directement le nom de la personne qui add l'événement
        $user = $this->getConnectedUser();
        $entity->setDisplayNameCreateur($user->getDisplayName());

        $entity->setDateFinEstimee(null);
        $entity->setDateFinMinimale(null);
        $entity->setPublieIntranet(false);
        $entity->setPublieInternet(false);

        //Avoir le pôle de l'utilisateur connecté
        if($entity->getPole() === null) {
            $user = $this->getConnectedUser();
            $entity->setDisplayNameCreateur($user->getDisplayName());

            if($this->getLdapService() !== null) {
                $ldapUser = $this->getLdapService()->findByUsername($user->getUsername());

                if (isset($ldapUser)) {
                    $poles = new ArrayCollection();
                    foreach ($ldapUser->getPeople()->get('supannAffectation') as $pole):
                        $poles->add(explode(';', $pole)[0]);
                    endforeach;

                    $databasePoles = $this->getEntityManager()->getRepository(PoleUtilisateur::class)->findAll();
                    /** @var PoleUtilisateur $dbPole */
                    foreach ($databasePoles as $dbPole):
                        if($dbPole->getCode() === $poles->get(sizeof($poles)-1)) {
                            $entity->setPole($dbPole);
                            break;
                        }
                    endforeach;
                }
            }
        }

        /** @var EtatEvenement $etat */
        $etat = $this->getEntityManager()->find(EtatEvenement::class, 1);
        $entity->setEtat($etat);

        $etatCible = null;
        if($entity->getCible() !== null) {
            if($entity->getCible()->getGivenStateByEvenement() !== null)
                $etatCible = $entity->getCible()->getGivenStateByEvenement();
        }

        $results = [
            "evenementRef" => $entity->getEvenementRef(),
            "categorie" => $entity->getCategorie(),
            "cible" => ($entity->getCible() !== null) ? $entity->getCible()->getId() : $entity->getCible(),
            "etatCible" => $etatCible,

            "description" => $entity->getDescription(),
            "actionsPrevues" => $entity->getActionsPrevues(),

            "dateDebut" => $entity->getDateDebut(),
            "heureDebut" => ($entity->getDateDebut()) ? $entity->getDateDebut()->format('H:i') : null,

            "dateFinEstimee" => $entity->getDateFinEstimee(),
            "heureFinEstimee" => ($entity->getDateFinEstimee()) ? $entity->getDateFinEstimee()->format('H:i') : null,

            "dateFinMinimale" => $entity->getDateFinMinimale(),
            "heureFinMinimale" => ($entity->getDateFinMinimale()) ? $entity->getDateFinMinimale()->format('H:i') : null,

            "dureeInconnue" => $entity->getDureeInconnue(),
            "commentaireDureeInconnue" => $entity->getCommentaireDureeInconnue(),
            "etat" => ($entity->getEtat() !== null) ? $entity->getEtat()->getId() : null,
            "publieIntranet" => $entity->getPublieIntranet(),
            "publieInternet" => $entity->getPublieInternet(),

            "envoiMail" => $entity->getEnvoiMail(),
            "destinataires" => $entity->getDestinataires(),
            "complementInformations" => $entity->getComplementInformations(),
            "pole" => $entity->getPole(),
            "displayNameCreateur" => $entity->getDisplayNameCreateur(),
        ];

        return $results;
    }


    /**
     * Converts the given value so that it can be hydrated by the hydrator.
     *
     * @param Evenement $entity The original value.
     * @param array $data (optional) The original data for context.
     * @return Evenement Returns the value that should be hydrated.
     */
    public function hydrate(array $data, $entity)
    {
        $idEvenementRef = ($data['evenementRef']) ?? 0;
        $idCategorie = ($data['categorie']) ?? 0;
        $idCible = ($data['cible']) ?? 0;
        $idEtat = ($data['etat']) ?? 0;

        //Evenement de référence, Catégorie et CibleEvenement
        /** @var Evenement $evenementRef */
        $evenementRef = $this->getEntityManager()->getRepository(Evenement::class)->find($idEvenementRef);

        /** @var CategorieEvenement $categorie */
        $categorie = $this->getEntityManager()->getRepository(CategorieEvenement::class)->find($idCategorie);

        /** @var CibleEvenement $cible */
        $cible = $this->getEntityManager()->getRepository(CibleEvenement::class)->find($idCible);

        //Description et Actions Prévues
        $desciption = ($data['description']) ?? '';
        $actionsPrevues = ($data['actionsPrevues']) ?? '';

        //Date de début
        $dateDebut = new DateTime();
        if (isset($data['dateDebut']))
            $dateDebut = new DateTime($data['dateDebut']);
        if (isset($data['heureDebut'])) {
            $heure = explode(':', $data['heureDebut']);
            $dateDebut->setTime(intval($heure[0]), intval($heure[1]));
        }

        //Date de fin estimée
        $dateFinEstimee = new DateTime();
        $ldf = strlen($data['dateFinEstimee']) + strlen($data['heureFinEstimee']); //Longueur date de fin estimée
        if ($ldf !== 0) {
            if (isset($data['dateFinEstimee']))
                $dateFinEstimee = new DateTime($data['dateFinEstimee']);
            if (isset($data['heureFinEstimee'])) {
                $heure = explode(':', $data['heureFinEstimee']);
                $dateFinEstimee->setTime(intval($heure[0]), intval($heure[1]));
            }
        } else $dateFinEstimee = null;

        //Date de fin minimale
        $dateFinMinimale = new DateTime();
        $ldf = strlen($data['dateFinMinimale']) + strlen($data['heureFinMinimale']); //Longueur date de fin au plus tôt
        if ($ldf !== 0) {
            if (isset($data['dateFinMinimale']))
                $dateFinMinimale = new DateTime($data['dateFinMinimale']);
            if (isset($data['heureFinMinimale'])) {
                $heure = explode(':', $data['heureFinMinimale']);
                $dateFinMinimale->setTime(intval($heure[0]), intval($heure[1]));
            }
        } else $dateFinMinimale = null;

        //Durée inconnue
        $dureeInconnue = isset($data['dureeInconnue']) && boolval($data['dureeInconnue']);
        $commentaireDureeInconnue = ($data['commentaireDureeInconnue']) ?? '';

        //Etat
        /** @var EtatEvenement $etat */
        $now = new DateTime();
        if($dateDebut > $now):
            $etat = $this->getEntityManager()->getRepository(EtatEvenement::class)->findOneBy(['code' => 'avenir']);
        else:
            $etat = $this->getEntityManager()->getRepository(EtatEvenement::class)->find($idEtat);
        endif;

        //Publications et nom du créateur
        $publieIntranet = isset($data['publieIntranet']) && boolval($data['publieIntranet']);
        $publieInternet = isset($data['publieInternet']) && boolval($data['publieInternet']);

        $envoiMail = isset($data['envoiMail']) && boolval($data['envoiMail']);
        $destinataires = ($data['destinataires']) ?? '';
        $complementInformations = ($data['complementInformations']) ?? '';
        $idPole = ($data['pole']) ?? 0;
        /** @var PoleUtilisateur $pole */
        $pole = $this->getEntityManager()->getRepository(PoleUtilisateur::class)->find($idPole);
        $displayNameCreateur = ($data['displayNameCreateur']) ?? '';

        //Le passage des valeurs récupérées par le form
        $entity->setEvenementRef($evenementRef);
        $entity->setCategorie($categorie);

        //Managing the target
        $entity->setCible($cible);
        $idEtatCible = ($data['etatCible']) ?? 0;
        /** @var EtatCible $etatCible */
        $etatCible = $this->getEntityManager()->getRepository(EtatCible::class)->find($idEtatCible);
        $entity->getCible()->setGivenStateByEvenement($etatCible);

        $entity->setDescription($desciption);
        $entity->setActionsPrevues($actionsPrevues);
        $entity->setDateDebut($dateDebut);
        $entity->setDateFinEstimee($dateFinEstimee);
        $entity->setDateFinMinimale($dateFinMinimale);
        $entity->setDureeInconnue($dureeInconnue);
        $entity->setCommentaireDureeInconnue($commentaireDureeInconnue);
        $entity->setEtat($etat);
        $entity->setPublieIntranet($publieIntranet);
        $entity->setPublieInternet($publieInternet);

        $entity->setEnvoiMail($envoiMail);
        $entity->setDestinataires($destinataires);
        $entity->setComplementInformations($complementInformations);
        $entity->setPole($pole);
        $entity->setDisplayNameCreateur($displayNameCreateur);

        return $entity;
    }
}