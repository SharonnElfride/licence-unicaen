<?php

namespace MeteoSI\Controller\ANoter;

use Application\Application\Misc\Util;
use Laminas\Feed\Writer\Renderer\Entry\Rss;
use Laminas\Http\Response;
use Laminas\Mvc\Controller\AbstractActionController;
use Laminas\Feed\Writer\Feed;
use MeteoSI\Controller\Evenement\EvenementController;
use MeteoSI\Model\Evenement;
use MeteoSI\Service\Evenement\EvenementServiceAwareTrait;

class RSSController extends AbstractActionController
{
    use EvenementServiceAwareTrait;

    public function feedAction()
    {
        /**
         * Create the parent feed
         */
        $feed = new Feed;
        $feed->setTitle("Incidents et interruptions de service en cours ou à venir");
        $link = $this->url()->fromRoute('home', [], ['force_canonical' => true]);
        $feed->setLink($link);
        $feed->setLanguage('fr-fr');
        $feed->setGenerator('MétéoSI');
        $feed->setDescription("Publication des incidents et interruptions de service pouvant affecter le SI de l'UNICAEN");
        // ...
//        $feed->addAuthor([
//            'name'  => 'Teste',
//            'email' => 'fausse adresse',
//            'uri'   => 'https://www.toto.com',
//        ]);
        $feed->setDateModified(time());
//        $feed->addHub('http://pubsubhubbub.appspot.com/');

        //Exemple écrit en dure:
        $evenementsEnCours = $this->getEvenementService()->findAllByCodeEtat('encours');
        $evenementsAVenir = $this->getEvenementService()->findAllByCodeEtat('avenir');

        /** @var Evenement $evenement */
        foreach ($evenementsEnCours as $evenement):
            $categorie = $evenement->getCategorie()->getLibelle();
            $cible = $evenement->getCible()->getLibelle();
            $link = $this->url()->fromRoute('page-information', ['action' => 'index'], ['force_canonical' => true]);
            //$urlShow = $this->url()->fromRoute('evenement', ['action' => 'show', 'id' => $evenement->getId()], ['force_canonical' => true]);
            $dateDebut = Util::formatIntlDateTime($evenement->getDateDebut(), 'dd/MM/yyyy à HH:mm');
            $servicesAffectes = $evenement->getCible()->getLibelle();
            $tailEnfants = sizeof($evenement->getCible()->getEnfants());
            for($i = 0 ; $i < $tailEnfants ; $i++):
                $cEnfant = $evenement->getCible()->getEnfants()->get($i);
                if($i != ($tailEnfants-1)) {
                    $servicesAffectes .= ", ";
                }
                $servicesAffectes .= $cEnfant->getLibelle();
            endfor;

            $entry = $feed->createEntry();
            $entry->setTitle($categorie . ' - ' . $cible . ' - [En cours]');
            $entry->setLink($link);
            $entry->setId(strval($evenement->getId()));
            $entry->setDescription("Evenement n°" . $evenement->getId() . " -- Début: " . $dateDebut . " -- Services affectés: " . $servicesAffectes . " -- Un mail vous sera envoyé dès la fin de l'événement. Merci de votre compréhension Cordialement");
            $entry->setContent("Description: " . strip_tags($evenement->getDescription()));
            $entry->setDateCreated($evenement->getHistoCreation());
            $entry->setDateModified($evenement->getHistoModification());
            $entry->addAuthor([
                'name'  => $evenement->getDisplayNameCreateur(),
            ]);
            $feed->addEntry($entry);
        endforeach;

        /** @var Evenement $evenement */
        foreach ($evenementsAVenir as $evenement):
            $categorie = $evenement->getCategorie()->getLibelle();
            $cible = $evenement->getCible()->getLibelle();
            $link = $this->url()->fromRoute('page-information', ['action' => 'index'], ['force_canonical' => true]);
            //$urlShow = $this->url()->fromRoute('evenement', ['action' => 'show', 'id' => $evenement->getId()], ['force_canonical' => true]);
            $dateDebut = Util::formatIntlDateTime($evenement->getDateDebut(), 'dd/MM/yyyy à HH:mm');
            $servicesAffectes = $evenement->getCible()->getLibelle();
            $tailEnfants = sizeof($evenement->getCible()->getEnfants());
            for($i = 0 ; $i < $tailEnfants ; $i++):
                $cEnfant = $evenement->getCible()->getEnfants()->get($i);
                if($i != ($tailEnfants-1)) {
                    $servicesAffectes .= ", ";
                }
                $servicesAffectes .= $cEnfant->getLibelle();
            endfor;

            $entry = $feed->createEntry();
            $entry->setTitle($categorie . ' - ' . $cible . ' - [À venir]');
            $entry->setLink($link);
            $entry->setId(strval($evenement->getId()));
            $entry->setDescription("Evenement n°" . $evenement->getId() . " -- Début: " . $dateDebut . " -- Services affectés: " . $servicesAffectes . " -- Un mail vous sera envoyé dès la fin de l'événement. Merci de votre compréhension Cordialement");
            $entry->setContent("Description: " . strip_tags($evenement->getDescription()));
            $entry->setDateCreated($evenement->getHistoCreation());
            $entry->setDateModified($evenement->getHistoModification());
            $entry->addAuthor([
                'name'  => $evenement->getDisplayNameCreateur(),
            ]);
            $feed->addEntry($entry);
        endforeach;

        //Export du fichier .RSS
        $out = $feed->export('rss');
        $response = new Response();
        $response->setStatusCode(Response::STATUS_CODE_200);
        $response->setContent($out);
        $response->getHeaders()->addHeaders([
            'Content-Type' => 'application/rss',
        ]);

        return $response;
    }
}