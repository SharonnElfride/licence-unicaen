<?php

namespace MeteoSI\Form\Evenement\Validator\Factory;

use Interop\Container\Containerinterface;
use Laminas\ServiceManager\Factory\FactoryInterface;
use MeteoSI\Form\Evenement\Validator\AddEditEvenementValidator;

/**
 * Classe AddEditEvenementValidatorFactory
 */
class AddEditEvenementValidatorFactory implements FactoryInterface
{
    /**
     * Create fieldset
     *
     * @param ContainerInterface $container
     * @param string $requestedName
     * @param array|null $options
     * @return AddEditEvenementValidator
     */
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        /** @var AddEditEvenementValidator $validator */
        $validator = new AddEditEvenementValidator();

        return $validator;
    }
}