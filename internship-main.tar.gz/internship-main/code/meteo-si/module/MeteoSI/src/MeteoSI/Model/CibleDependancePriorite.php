<?php

namespace MeteoSI\Model;

use Doctrine\Common\Collections\ArrayCollection;
use Laminas\Permissions\Acl\Resource\ResourceInterface;

class CibleDependancePriorite implements ResourceInterface
{
    const RESOURCE_ID = 'CibleDependancePriorite';

    /** @var int $id */
    private $id;

    /** @var string $code */
    private $code;

    /** @var string $libelle */
    private $libelle;

    /** @var int $niveauGravite */
    private $niveauGravite;

    /** @var ArrayCollection|CibleDependance[] $cibleDependances */
    private $cibleDependances;

    /**
     * Retourne l'identifiant de la ressource sous forme de chaîne de caractères
     *
     * @return string
     */
    public function getResourceId(): string
    {
        return self::RESOURCE_ID;
    }

    public function __construct()
    {
        $this->cibleDependances = new ArrayCollection();
    }

//Les dépendances
    /**
     * @param CibleDependance $cibleDependance
     * @return void
     */
    public function addCibleDependance(CibleDependance $cibleDependance): void
    {
        $this->cibleDependances->add($cibleDependance);
    }

    /**
     * @param CibleDependance $cibleDependance
     * @return void
     */
    public function removeCibleDependance(CibleDependance $cibleDependance): void
    {
        $this->cibleDependances->removeElement($cibleDependance);
    }

    /**
     * @return void
     */
    public function removeAllCibleDependances(): void
    {
        $this->cibleDependances->clear();
    }

    /**
     * @return ArrayCollection|CibleDependance[]
     */
    public function getCibleDependances()
    {
        return $this->cibleDependances;
    }

//GETTERS ET SETTERS

    /**
     * @return int|null
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return string|null
     */
    public function getCode()
    {
        return $this->code;
    }

    /**
     * @return string|null
     */
    public function getLibelle()
    {
        return $this->libelle;
    }

    /**
     * @return int|null
     */
    public function getNiveauGravite()
    {
        return $this->niveauGravite;
    }

    /**
     * @param int $id
     */
    public function setId(int $id): void
    {
        $this->id = $id;
    }

    /**
     * @param string $code
     */
    public function setCode(string $code): void
    {
        $this->code = $code;
    }

    /**
     * @param string $libelle
     */
    public function setLibelle(string $libelle): void
    {
        $this->libelle = $libelle;
    }

    /**
     * @param int $niveauGravite
     */
    public function setNiveauGravite(int $niveauGravite): void
    {
        $this->niveauGravite = $niveauGravite;
    }
}