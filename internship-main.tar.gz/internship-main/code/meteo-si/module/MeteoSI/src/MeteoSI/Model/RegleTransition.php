<?php

namespace MeteoSI\Model;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Laminas\Permissions\Acl\Resource\ResourceInterface;

class RegleTransition implements ResourceInterface
{
    const RESOURCE_ID = 'RegleTransition';

    /** @var int $id */
    private $id;

    /** @var EtatCible $etatParent */
    private $etatParent;

    /** @var EtatCible $etatEnfant */
    private $etatEnfant;

    /** @var Collection|CibleDependance[] */
    private $dependances;

    /**
     * Retourne l'identifiant de la ressource sous forme de chaîne de caractères
     *
     * @return string
     */
    public function getResourceId(): string
    {
        return self::RESOURCE_ID;
    }

    public function __construct()
    {
        $this->dependances = new ArrayCollection();
    }

//Les dépendances

    /**
     * @param CibleDependance $cibleDependance
     * @return void
     */
    public function addDependance(CibleDependance $cibleDependance): void
    {
        $this->dependances->add($cibleDependance);
    }

    /**
     * @param CibleDependance $cibleDependance
     * @return void
     */
    public function removeDependance(CibleDependance $cibleDependance): void
    {
        $this->dependances->removeElement($cibleDependance);
    }

    /**
     * @return void
     */
    public function removeAllDependances(): void
    {
        $this->dependances->clear();
    }

    /**
     * @return Collection|CibleDependance[]
     */
    public function getDependances()
    {
        return $this->dependances;
    }

//GETTERS ET SETTERS

    /**
     * @return int|null
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return EtatCible|null
     */
    public function getEtatParent()
    {
        return $this->etatParent;
    }

    /**
     * @return EtatCible|null
     */
    public function getEtatEnfant()
    {
        return $this->etatEnfant;
    }

    /**
     * @param int $id
     */
    public function setId(int $id): void
    {
        $this->id = $id;
    }

    /**
     * @param EtatCible $etatParent
     */
    public function setEtatParent(EtatCible $etatParent): void
    {
        $this->etatParent = $etatParent;
    }

    /**
     * @param EtatCible $etatEnfant
     */
    public function setEtatEnfant(EtatCible $etatEnfant): void
    {
        $this->etatEnfant = $etatEnfant;
    }
}