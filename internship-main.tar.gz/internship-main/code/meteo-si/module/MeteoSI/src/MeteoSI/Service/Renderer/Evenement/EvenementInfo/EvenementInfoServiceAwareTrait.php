<?php

namespace MeteoSI\Service\Renderer\Evenement\EvenementInfo;

trait EvenementInfoServiceAwareTrait {

    /** @var EvenementInfoService */
    private $evenementInfoService;

    /**
     * @return EvenementInfoService
     */
    public function getEvenementInfoService(): EvenementInfoService
    {
        return $this->evenementInfoService;
    }

    /**
     * @param EvenementInfoService $evenementInfoService
     * @return EvenementInfoService
     */
    public function setEvenementInfoService(EvenementInfoService $evenementInfoService): EvenementInfoService
    {
        $this->evenementInfoService = $evenementInfoService;
        return $this->evenementInfoService;
    }
}
