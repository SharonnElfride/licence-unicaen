<?php

namespace MeteoSI\Model;

use Doctrine\Common\Collections\ArrayCollection;
use Laminas\Permissions\Acl\Resource\ResourceInterface;

class EtatCible implements ResourceInterface
{
    const RESOURCE_ID = 'EtatCible';

    /**
     *  L'identifiant de l'état
     * @var int $id
     */
    private $id;

    /**
     *  Le code de l'état
     * @var string $code
     */
    private $code;

    /**
     *  Le libelle de l'état
     * @var string $libelle
     */
    private $libelle;

    /**
     * L'acronyme de l'état
     * @var string $acronyme
     */
    private $acronyme;

    /**
     * @var EtatCibleGroupe $groupePriorite
     */
    private $groupePriorite;

    /**
     * @var ArrayCollection|CibleEvenement[] $cibles
     */
    private $cibles;

    /** @var ArrayCollection|CibleEvenement[] $targetGivenStatesByEvenement */
    private $targetGivenStatesByEvenement;

    /**
     * Constructeur permettant d'initialiser la liste des cibles étant dans cet état particulier
     */
    public function __construct()
    {
        $this->cibles = new ArrayCollection();
    }

    /**
     * Retourne l'identifiant de la ressource sous forme de chaîne de caractères
     *
     * @return string
     */
    public function getResourceId(): string
    {
        return self::RESOURCE_ID;
    }

//Cibles
    /**
     * @param CibleEvenement $cible
     * @return void
     */
    public function addCible(CibleEvenement $cible): void
    {
        $this->cibles->add($cible);
    }

    /**
     * @param CibleEvenement $cible
     * @return void
     */
    public function removeCible(CibleEvenement $cible): void
    {
        $this->cibles->removeElement($cible);
    }

    /**
     * @return void
     */
    public function removeAll(): void
    {
        $this->cibles->clear();
    }

    /**
     * @return ArrayCollection|CibleEvenement[]
     */
    public function getCibles()
    {
        return $this->cibles;
    }

//Cibles juste pour le mapping au niveau de l'état donné par l'événement pour la fonction de 'guess state'
    /**
     * @param CibleEvenement $cible
     * @return void
     */
    public function addTarget(CibleEvenement $cible): void
    {
        $this->targetGivenStatesByEvenement->add($cible);
    }

    /**
     * @param CibleEvenement $cible
     * @return void
     */
    public function removeTarget(CibleEvenement $cible): void
    {
        $this->targetGivenStatesByEvenement->removeElement($cible);
    }

    /**
     * @return void
     */
    public function removeAllTargets(): void
    {
        $this->targetGivenStatesByEvenement->clear();
    }

    /**
     * @return ArrayCollection|CibleEvenement[]
     */
    public function getTargets()
    {
        return $this->targetGivenStatesByEvenement;
    }

//GETTERS AND SETTERS

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return string
     */
    public function getCode(): string
    {
        return $this->code;
    }

    /**
     * @return string
     */
    public function getLibelle(): string
    {
        return $this->libelle;
    }

    /**
     * @return string|null
     */
    public function getAcronyme(): ?string
    {
        return $this->acronyme;
    }

    /**
     * @return EtatCibleGroupe
     */
    public function getGroupePriorite(): EtatCibleGroupe
    {
        return $this->groupePriorite;
    }

    /**
     * @param int $id
     * @return void
     */
    public function setId(int $id): void
    {
        $this->id = $id;
    }

    /**
     * @param string $code
     * @return void
     */
    public function setCode(string $code): void
    {
        $this->code = $code;
    }

    /**
     * @param string $libelle
     * @return void
     */
    public function setLibelle(string $libelle): void
    {
        $this->libelle = $libelle;
    }

    /**
     * @param string|null $acronyme
     * @return void
     */
    public function setAcronyme(?string $acronyme): void
    {
        $this->acronyme = $acronyme;
    }

    /**
     * @param EtatCibleGroupe $groupePriorite
     * @return void
     */
    public function setGroupePriorite(EtatCibleGroupe $groupePriorite): void
    {
        $this->groupePriorite = $groupePriorite;
    }
}
