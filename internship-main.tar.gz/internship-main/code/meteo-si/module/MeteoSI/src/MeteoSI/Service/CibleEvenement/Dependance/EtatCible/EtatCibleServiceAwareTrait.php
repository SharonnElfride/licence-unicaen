<?php

namespace MeteoSI\Service\CibleEvenement\Dependance\EtatCible;

trait EtatCibleServiceAwareTrait
{
    /** @var EtatCibleService $etatCibleService */
    protected $etatCibleService;

    /**
     * @return EtatCibleService
     */
    public function getEtatCibleService(): EtatCibleService
    {
        return $this->etatCibleService;
    }

    /**
     * @param EtatCibleService $etatCibleService
     * @return void
     */
    public function setEtatCibleService(EtatCibleService $etatCibleService): void
    {
        $this->etatCibleService = $etatCibleService;
    }
}