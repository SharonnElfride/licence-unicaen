<?php

namespace MeteoSI\Service\Evenement;

use Doctrine\ORM\EntityManager;
use Interop\Container\ContainerInterface;
use Laminas\ServiceManager\Factory\FactoryInterface;

/**
 * Class EvenementServiceFactory
 * @package MeteoSI\Service\Evenement
 */
class EvenementServiceFactory implements FactoryInterface
{

    /**
     * @param ContainerInterface $container
     * @param string $requestedName
     * @param array|null $options
     * @return EvenementService|object
     */
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        /** @var EvenementService $serviceProvider */
        $serviceProvider = new EvenementService();

        /** @var EntityManager $entityManager */
        $entityManager = $container->get(EntityManager::class);
        $serviceProvider->setEntityManager($entityManager);

        $userContextService = $container->get('UnicaenAuthentification\Service\UserContext');
        $serviceProvider->setServiceUserContext($userContextService);

        return $serviceProvider;
    }
}
