<?php

namespace MeteoSI\Provider\Event;

class EventsProvider
{
    const CHANGE_EVENT_STATE = "change-event-state";
    const NOTIFICATION_TO_CREATOR_AFTER_A_DELAY = "notification-to-creator-after-a-delay-event";
}