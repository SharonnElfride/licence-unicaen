<?php

namespace MeteoSI\Form\CibleEvenement\CibleInfra\Hydrator;

use DateTime;
use Doctrine\ORM\OptimisticLockException;
use Doctrine\ORM\ORMException;
use Laminas\Hydrator\AbstractHydrator;
use Laminas\Hydrator\HydratorInterface;
use MeteoSI\Model\CategorieInfra;
use MeteoSI\Model\CibleEvenementInfra;
use MeteoSI\Model\EtatCible;
use UnicaenApp\Service\EntityManagerAwareTrait;

class CibleEvenementInfraHydrator extends AbstractHydrator implements HydratorInterface
{
    use EntityManagerAwareTrait;

    /**
     * Extract values from an object
     *
     * @param CibleEvenementInfra $entity (optional) The original object for context.
     * @throws ORMException
     * @throws OptimisticLockException
     * @return array Returns the value that should be extracted.
     */
    public function extract($entity): array
    {
        //Avoir la date de début pré-remplie en considérant que l'événement s'effectue maintenant
        if($entity->getDateCreation() === null) {
            $entity->setDateCreation(new DateTime());
        }

        if($entity->getEtat() === null) {
            /** @var EtatCible $etat */
            $etat = $this->getEntityManager()->find(EtatCible::class, 1);
            $entity->setEtat($etat);
        }

        $results = [
            "libelle" => $entity->getLibelle(),
            "description" => $entity->getDescription(),
            "etat" => $entity->getEtat(),
            "codeSource" => $entity->getCodeSource(),
            "idSource" => $entity->getIdSource(),
            "dateCreation" => $entity->getDateCreation(),
            "categorieInfra" => $entity->getCategorieInfra(),
            "site" => $entity->getSite(),
            "position" => $entity->getPosition(),
            "status" => $entity->getStatus(),
            "comments" => $entity->getComments(),
        ];

        return $results;
    }

    /**
     * Hydrate $object with the provided $data.
     *
     * @param CibleEvenementInfra $entity The original value.
     * @param array $data (optional) The original data for context.
     * @return CibleEvenementInfra Returns the value that should be hydrated.
     */
    public function hydrate(array $data, $entity)
    {
        $idEtat = ($data['etat']) ?? 0;
        $idCategorieInfra = ($data['categorieInfra']) ?? 0;

        $libelle = ($data['libelle']) ?? '';
        $desciption = ($data['description']) ?? '';
        $site = ($data['site']) ?? '';
        $position = ($data['position']) ?? '';
        $status = ($data['status']) ?? '';
        $comments = ($data['comments']) ?? '';
        $codeSource = ($data['codeSource']) ?? '';
        $idSource = ($data['idSource']) ?? '';

        /** @var EtatCible $etat */
        $etat = $this->getEntityManager()->getRepository(EtatCible::class)->find($idEtat);
        /** @var CategorieInfra $categorie */
        $categorie = $this->getEntityManager()->getRepository(CategorieInfra::class)->find($idCategorieInfra);

        //Date de création
        $dateCreation = new DateTime();
        if (isset($data['dateCreation']))
            $dateCreation = new DateTime($data['dateCreation']);

        //Le passage des valeurs récupérées par le form
        $entity->setLibelle($libelle);
        $entity->setDescription($desciption);
        $entity->setEtat($etat);
        $entity->setCodeSource($codeSource);
        $entity->setIdSource($idSource);
        $entity->setDateCreation($dateCreation);

        $entity->setCategorieInfra($categorie);
        $entity->setSite($site);
        $entity->setPosition($position);
        $entity->setStatus($status);
        $entity->setComments($comments);

        return $entity;
    }
}