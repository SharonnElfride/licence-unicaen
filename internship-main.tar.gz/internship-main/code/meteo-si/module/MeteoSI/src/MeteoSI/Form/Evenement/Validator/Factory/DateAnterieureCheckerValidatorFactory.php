<?php

namespace MeteoSI\Form\Evenement\Validator\Factory;

use Interop\Container\Containerinterface;
use Laminas\ServiceManager\Factory\FactoryInterface;
use MeteoSI\Form\Evenement\Validator\DateAnterieureCheckerValidator;

/**
 * Classe DateAnterieureCheckerValidatorFactory
 */
class DateAnterieureCheckerValidatorFactory implements FactoryInterface
{
    /**
     * Create fieldset
     *
     * @param ContainerInterface $container
     * @param string $requestedName
     * @param array|null $options
     * @return DateAnterieureCheckerValidator
     */
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        /** @var DateAnterieureCheckerValidator $validator */
        $validator = new DateAnterieureCheckerValidator();

        return $validator;
    }
}