<?php

namespace MeteoSI\Form\CibleEvenement\Cible\Factory;

use Doctrine\Laminas\Hydrator\DoctrineObject;
use Doctrine\ORM\EntityManager;
use Interop\Container\Containerinterface;
use Laminas\ServiceManager\Factory\FactoryInterface;
use Laminas\View\HelperPluginManager;
use MeteoSI\Form\CibleEvenement\Cible\AddParentForm;
use MeteoSI\Form\CibleEvenement\Cible\Hydrator\AddParentHydrator;

class AddParentFormFactory implements FactoryInterface
{
    /**
     * Create form
     *
     * @param Containerinterface $container
     * @param string $requestedName
     * @param array|null $options
     * @return AddParentForm|object
     */
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        /** @var AddParentForm $form */
        $form = new AddParentForm();

        /** @var EntityManager $entityManager */
        $entityManager = $container->get(EntityManager::class);
        $form->setEntityManager($entityManager);

        /** @var HelperPluginManager $viewHelperManager */
        $viewHelperManager = $container->get('ViewHelperManager');
        $form->setViewHelperManager($viewHelperManager);

        /** @var AddParentHydrator $hydrator */
        $hydrator = $container->get('HydratorManager')->get(AddParentHydrator::class);
        $form->setHydrator($hydrator);

        return $form;
    }
}