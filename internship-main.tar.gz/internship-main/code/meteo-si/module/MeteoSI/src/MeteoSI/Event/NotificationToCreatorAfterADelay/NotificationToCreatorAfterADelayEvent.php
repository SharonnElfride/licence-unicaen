<?php

namespace MeteoSI\Event\NotificationToCreatorAfterADelay;

use Application\Application\Misc\UserAwaireTrait;
use DateTime;
use Exception;
use MeteoSI\MeteoSI\Service\Mailing\MailService;
use MeteoSI\Model\EtatEvenement;
use MeteoSI\Provider\Evenement\EtatEvenementProvider;
use MeteoSI\Provider\Event\EventsProvider;
use MeteoSI\Provider\Mailing\CodesMailsProvider;
use MeteoSI\Service\Evenement\EvenementServiceAwareTrait;
use UnicaenEvenement\Entity\Db\Etat;
use UnicaenEvenement\Entity\Db\Evenement;
use UnicaenEvenement\Service\Evenement\EvenementService;
use UnicaenMail\Service\Mail\MailServiceAwareTrait;

class NotificationToCreatorAfterADelayEvent extends EvenementService
{
    use EvenementServiceAwareTrait;
    use MailServiceAwareTrait;
    use UserAwaireTrait;

    public function creer(?DateTime $dateDebut = null): Evenement
    {
        if($dateDebut === null)
            $dateDebut = new DateTime();

        $typeEvent = $this->getTypeService()->findByCode(EventsProvider::NOTIFICATION_TO_CREATOR_AFTER_A_DELAY);

        $parametres = [];

        $description = "Notifier le créateur d'un événement de le passer en état terminé";
        $event = $this->createEvent('notificationToCreatorAfterADelay', $description, null, $typeEvent, $parametres, $dateDebut);
        $this->ajouter($event);

        return $event;
    }

    public function traiter(Evenement $evenement): string
    {
        $parametres = json_decode($evenement->getParametres(), true);
        $nbEvenement = 0;

        try {
            $evenementsEnCours = $this->getEvenementService()->findAllBy(['etat' => EtatEvenementProvider::ETAT_EVENEMENT_EN_COURS_ID], ['id' => 'ASC']);

            /** @var \MeteoSI\Model\Evenement $event */
            foreach ($evenementsEnCours as $event)
            {
                //TODO getEvenementService peut faire n'importe quoi
                if(!$event->getDureeInconnue()) {
                    if($event->getDateFinMinimale() !== null)
                        $dateFin = $event->getDateFinMinimale();
                    else
                        $dateFin = $event->getDateFinEstimee();

                    $now = new DateTime();
                    $hoursBetweenDateFinAndNow = date_interval_format((date_diff($dateFin, $now)), '%H');
                    if($dateFin < $now) {
                        if (intval($hoursBetweenDateFinAndNow) >= 1) {
                            /** @var MailService $mailService */
                            $mailService = $this->getMailService();
                            $mailService->sendMailType(CodesMailsProvider::NOTIFICATION_DE_RAPPEL_AU_CREATEUR_D_UN_EVENEMENT_POUR_SA_CLOTURE, ['evenement' => $event, 'createurEmail' => $event->getHistoCreateur()->getEmail()]);

                            $nbEvenement++;
                        }
                    }
                }
            }
        }
        catch (Exception $e) {
            $evenement->setLog($e->getMessage());
            $this->update($evenement);
            return Etat::ECHEC;
        }

        $evenement->setLog($nbEvenement . " rappels ont été envoyés!");
        $this->update($evenement);
        return Etat::SUCCES;
    }
}