<?php

namespace MeteoSI\Model;

use Doctrine\Common\Collections\ArrayCollection;
use Laminas\Permissions\Acl\Resource\ResourceInterface;

class CategorieInfra implements ResourceInterface
{
    const RESOURCE_ID = 'CategorieInfra';

    /** @var int $id */
    private $id;

    /** @var string $code */
    private $code;

    /** @var string $libelle */
    private $libelle;

    /** @var string $description */
    private $description;

    /** @var int $total */
    private $total;

    /** @var ArrayCollection|CibleEvenementInfra[] */
    private $infrastructures;

    /**
     * Retourne l'identifiant de la ressource sous forme de chaîne de caractères
     *
     * @return string
     */
    public function getResourceId(): string
    {
        return self::RESOURCE_ID;
    }

    public function __construct()
    {
        $this->infrastructures = new ArrayCollection();
    }

//Infrastructures
    public function addInfrastructure(CibleEvenementInfra $infrastructure)
    {
        $this->infrastructures->add($infrastructure);
    }

    public function removeInfrastructure(CibleEvenementInfra $infrastructure)
    {
        $this->infrastructures->removeElement($infrastructure);
    }

    public function removeAll()
    {
        $this->infrastructures->clear();
    }

    public function getInfrastructures()
    {
        return $this->infrastructures;
    }

    //GETTERS ET SETTERS
    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return string
     */
    public function getLibelle(): string
    {
        return $this->libelle;
    }

    /**
     * @return string
     */
    public function getCode(): string
    {
        return $this->code;
    }

    /**
     * @return string
     */
    public function getDescription(): string
    {
        return $this->description;
    }

    /**
     * @return int
     */
    public function getTotal(): int
    {
        return $this->total;
    }

    /**
     * @param int $id
     */
    public function setId(int $id): void
    {
        $this->id = $id;
    }

    /**
     * @param string $libelle
     */
    public function setLibelle(string $libelle): void
    {
        $this->libelle = $libelle;
    }

    /**
     * @param string $code
     */
    public function setCode(string $code): void
    {
        $this->code = $code;
    }

    /**
     * @param string $description
     */
    public function setDescription(string $description): void
    {
        $this->description = $description;
    }

    /**
     * @param int $total
     */
    public function setTotal(int $total): void
    {
        $this->total = $total;
    }
}