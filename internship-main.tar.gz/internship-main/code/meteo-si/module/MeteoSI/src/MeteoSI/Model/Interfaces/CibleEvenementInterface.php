<?php

namespace MeteoSI\Model\Interfaces;

use DateTime;
use Doctrine\Common\Collections\ArrayCollection;
use MeteoSI\Model\CategorieCible;
use MeteoSI\Model\CibleDependance;
use MeteoSI\Model\CibleEvenement;
use MeteoSI\Model\EtatCible;
use MeteoSI\Model\Evenement;

interface CibleEvenementInterface
{
    //GETTERS
    /** @return int */
    public function getId();

    /** @return string|null */
    public function getLibelle();

    /** @return string|null */
    public function getDescription();

    /** @return CategorieCible|null */
    public function getCategorieCible();

    /** @return EtatCible|null */
    public function getEtat();

    /** @return string|null */
    public function getCodeSource();

    /** @return int|null */
    public function getIdSource();

    /** @return DateTime|null */
    public function getDateCreation();

    /** @return DateTime|null */
    public function getDateModification();

    /** @return ArrayCollection|CibleEvenement[] */
    public function getParents();

    /** @return ArrayCollection|CibleDependance[] */
    public function getDependanceParents();

    /** @return ArrayCollection|CibleEvenement[] */
    public function getEnfants();

    /** @return ArrayCollection|CibleDependance[] */
    public function getDependanceEnfants();

    /** @return ArrayCollection|Evenement[] */
    public function getEvenements();

    //SETTERS

    /**
     * @param int $id
     * @return void
     */
    public function setId(int $id): void;

    /**
     * @param string $libelle
     * @return void
     */
    public function setLibelle(string $libelle): void;

    /**
     * @param string|null $description
     * @return void
     */
    public function setDescription(?string $description): void;

    /**
     * @param CategorieCible $categorieCible
     * @return void
     */
    public function setCategorieCible(CategorieCible $categorieCible): void;

    /**
     * @param EtatCible $etat
     * @return void
     */
    public function setEtat(EtatCible $etat): void;

    /**
     * @param string|null $codeSource
     * @return void
     */
    public function setCodeSource(?string $codeSource): void;

    /**
     * @param int|null $idSource
     * @return void
     */
    public function setIdSource(?int $idSource): void;

    /**
     * @param DateTime $dateCreation
     * @return void
     */
    public function setDateCreation(DateTime $dateCreation): void;

    /**
     * @param DateTime $dateModification
     * @return void
     */
    public function setDateModification(DateTime $dateModification): void;
}