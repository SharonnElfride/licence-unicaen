<?php

namespace MeteoSI\Service\CibleEvenement\CibleApplication;

use Doctrine\ORM\EntityManager;
use Interop\Container\ContainerInterface;
use Laminas\ServiceManager\Factory\FactoryInterface;

/**
 * Class CibleEvenementApplicationServiceFactory
 * @package MeteoSI\Service\CibleEvenement\CibleApplication
 */
class CibleEvenementApplicationServiceFactory implements FactoryInterface
{
    /**
     * @param ContainerInterface $container
     * @param string $requestedName
     * @param array|null $options
     * @return CibleEvenementApplicationService|object
     */
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        /** @var CibleEvenementApplicationService $serviceProvider */
        $serviceProvider = new CibleEvenementApplicationService();

        /** @var EntityManager $entityManager */
        $entityManager = $container->get(EntityManager::class);
        $serviceProvider->setEntityManager($entityManager);

        return $serviceProvider;
    }
}
