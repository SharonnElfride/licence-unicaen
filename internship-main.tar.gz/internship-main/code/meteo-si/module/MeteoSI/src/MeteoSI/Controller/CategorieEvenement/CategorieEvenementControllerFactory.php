<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace MeteoSI\Controller\CategorieEvenement;

use MeteoSI\Service\CategorieEvenement\CategorieEvenementService;
use MeteoSI\Form\CategorieEvenement\CategorieEvenementForm;
use Interop\Container\ContainerInterface;
use Laminas\ServiceManager\Factory\FactoryInterface;

class CategorieEvenementControllerFactory implements FactoryInterface
{
    public function __invoke(ContainerInterface $container, $requestedName, ?array $options = null)
    {
        /** @var CategorieEvenementController $controller */
        $controller = new CategorieEvenementController();

        /** @var CategorieEvenementService $entityService */
        $entityService = $container->get(CategorieEvenementService::class);
        $controller->setCategorieService($entityService);

        /** @var CategorieEvenementForm $categorieForm */
        $categorieForm = $container->get('FormElementManager')->get(CategorieEvenementForm::class);
        $controller->setCategorieForm($categorieForm);

        return $controller;
    }
}
