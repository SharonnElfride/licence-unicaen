<?php

namespace MeteoSI\Form\Evenement\Hydrator\Factory;

use Doctrine\ORM\EntityManager;
use Interop\Container\ContainerInterface;
use Laminas\ServiceManager\Factory\FactoryInterface;
use MeteoSI\Form\Evenement\Hydrator\EvenementHydrator;
use UnicaenUtilisateurLdapAdapter\Service\LdapService;

/**
 * Class EvenementHydratorFactory
 */
class EvenementHydratorFactory implements FactoryInterface
{
    /**
     * Create hydrator
     *
     * @return EvenementHydrator
     */
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        /** @var EvenementHydrator $hydrator */
        $hydrator = new EvenementHydrator();

        /** @var EntityManager $entityManager */
        $entityManager = $container->get(EntityManager::class);
        $hydrator->setEntityManager($entityManager);

        /** @var LdapService $ldapService */
        $ldapService = $container->get('ServiceManager')->get(LdapService::class);
        $hydrator->setLdapService($ldapService);

        $userContextService = $container->get('UnicaenAuthentification\Service\UserContext');
        $hydrator->setServiceUserContext($userContextService);

        return $hydrator;
    }
}
