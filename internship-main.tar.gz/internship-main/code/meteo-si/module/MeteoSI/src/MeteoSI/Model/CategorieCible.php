<?php

namespace MeteoSI\Model;

use Doctrine\Common\Collections\ArrayCollection;
use Laminas\Permissions\Acl\Resource\ResourceInterface;

class CategorieCible implements ResourceInterface
{
    const RESOURCE_ID = 'CategorieCible';

    /** @var int $id */
    private $id;

    /** @var string $code */
    private $code;

    /** @var string $libelle */
    private $libelle;

    /** @var ArrayCollection|CibleEvenement[] $cibles */
    private $cibles;

    public function __construct()
    {
        $this->cibles = new ArrayCollection();
    }

    /**
     * Retourne l'identifiant de la ressource sous forme de chaîne de caractères
     *
     * @return string
     */
    public function getResourceId(): string
    {
        return self::RESOURCE_ID;
    }

    /**
     * @param CibleEvenement $cible
     */
    public function addCible(CibleEvenement $cible): void
    {
        $this->cibles->add($cible);
    }

    /**
     * @param CibleEvenement $cible
     */
    public function removeCible(CibleEvenement $cible): void
    {
        $this->cibles->removeElement($cible);
    }

    /**
     * @return void
     */
    public function removeAll(): void
    {
        $this->cibles->clear();
    }

    /**
     * @return ArrayCollection|CibleEvenement[]
     */
    public function getCibles()
    {
        return $this->cibles;
    }

//GETTERS AND SETTERS

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return string
     */
    public function getCode(): string
    {
        return $this->code;
    }

    /**
     * @return string
     */
    public function getLibelle(): string
    {
        return $this->libelle;
    }

    /**
     * @param mixed $id
     */
    public function setId($id): void
    {
        $this->id = $id;
    }

    /**
     * @param string $code
     */
    public function setCode(string $code): void
    {
        $this->code = $code;
    }

    /**
     * @param string $libelle
     */
    public function setLibelle(string $libelle): void
    {
        $this->libelle = $libelle;
    }
}
