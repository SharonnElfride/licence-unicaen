<?php

namespace MeteoSI\Provider\Evenement;

class EtatEvenementProvider
{
    const ETAT_EVENEMENT_EN_COURS_ID = 1;
    const ETAT_EVENEMENT_A_VENIR_ID = 2;
    const ETAT_EVENEMENT_TERMINE_ID = 3;

    const ETAT_EVENEMENT_EN_COURS_CODE = 'encours';
    const ETAT_EVENEMENT_A_VENIR_CODE = 'avenir';
    const ETAT_EVENEMENT_TERMINE_CODE = 'termine';

    const ETAT_EVENEMENT_EN_COURS_LIBELLE = 'En cours';
    const ETAT_EVENEMENT_A_VENIR_LIBELLE = 'À venir';
    const ETAT_EVENEMENT_TERMINE_LIBELLE = 'Terminé';

    const ETAT_EVENEMENT_EN_COURS_COULEUR = '#dc3545';
    const ETAT_EVENEMENT_A_VENIR_COULEUR = '#fd7e14';
    const ETAT_EVENEMENT_TERMINE_COULEUR = '#198754';
}