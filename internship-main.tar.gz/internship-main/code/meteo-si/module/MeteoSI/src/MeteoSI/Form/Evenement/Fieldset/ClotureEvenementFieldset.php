<?php

namespace MeteoSI\Form\Evenement\Fieldset;

use Application\Application\Form\AbstractEntityFieldset;
use DoctrineModule\Form\Element\ObjectSelect;
use Laminas\Filter\StringTrim;
use Laminas\Filter\StripTags;
use Laminas\Filter\ToInt;
use Laminas\Filter\ToNull;
use Laminas\Form\Element\Checkbox;
use Laminas\Form\Element\Date;
use Laminas\Form\Element\Textarea;
use Laminas\Form\Element\Time;
use Laminas\InputFilter\InputFilterProviderInterface;
use Laminas\Validator\StringLength;
use MeteoSI\Form\Evenement\Validator\ClotureEvenementValidator;
use MeteoSI\Form\Evenement\Validator\DateAnterieureCheckerValidator;
use MeteoSI\Form\Evenement\Validator\DestinatairesListValidator;
use MeteoSI\Model\EtatEvenement;

class ClotureEvenementFieldset extends AbstractEntityFieldset implements InputFilterProviderInterface
{
    /**
     * @var ClotureEvenementValidator $evenementValidator
     */
    protected $evenementValidator;

    /** @var DestinatairesListValidator $destinatairesListValidator */
    protected $destinatairesListValidator;

//GETTERS ET SETTERS
    /**
     * @return ClotureEvenementValidator
     */
    public function getEvenementValidator(): ClotureEvenementValidator
    {
        return $this->evenementValidator;
    }

    /**
     * @param ClotureEvenementValidator $evenementValidator
     */
    public function setEvenementValidator(ClotureEvenementValidator $evenementValidator): void
    {
        $this->evenementValidator = $evenementValidator;
    }

    /**
     * @return DestinatairesListValidator
     */
    public function getDestinatairesListValidator(): DestinatairesListValidator
    {
        return $this->destinatairesListValidator;
    }

    /**
     * @param DestinatairesListValidator $destinatairesListValidator
     */
    public function setDestinatairesListValidator(DestinatairesListValidator $destinatairesListValidator): void
    {
        $this->destinatairesListValidator = $destinatairesListValidator;
    }

//INITIALISATION ET CONTROLE DE LA CLASSE
    public function init()
    {
        $this->add([
            'name' => 'dateFinReelle',
            'type' => Date::class,
            'options' => [
                'label' => 'Date',
            ],
            'attributes' => [
                'id' => 'dateFinReelle',
            ],
        ]);

        $this->add([
            'name' => 'heureFinReelle',
            'type' => Time::class,
            'options' => [
                'label' => 'Heure',
                'format' => 'H:i',
            ],
            'attributes' => [
                'id' => 'heureFinReelle',
            ],
        ]);

        $this->add([
            'name' => 'commentaireCloture',
            'type' => Textarea::class,
            'options' => [
                'label' => "Retours d'expérience",
            ],
            'attributes' => [
                'id' => 'commentaireCloture',
                'rows' => 3,
                'placeholder' => "Souci provoqué par le service DNS Unicaen...",
            ],
        ]);

        $this->add([
            'name' => 'envoiMail',
            'type' => Checkbox::class,
            'options' => [
                'label' => "Oui",
                'use_hidden_element' => true,
                'checked_value' => true,
                'unchecked_value' => false,
            ],
            'attributes' => [
                'id' => 'envoiMail',
                'checked' => true,
            ]
        ]);

        $this->add([
            'name' => 'destinataires',
            'type' => Textarea::class,
            'options' => [
//                'label' => 'Les destinataires',
            ],
            'attributes' => [
                'id' => 'destinataires',
                'rows' => 5,
                'placeholder' => "no-reply@unicaen.fr, ...",
            ],
        ]);
    }

    public function getInputFilterSpecification()
    {
        $inputFilter = [];

        $validator = $this->getEvenementValidator();
        $validator->setEvenement($this->getObject());

        $inputFilter['dateFinReelle'] = [
            'name' => 'dateFinReelle',
            'required' => false,
            'validators' => [
                $validator,
            ],
        ];

        $inputFilter['heureFinReelle'] = [
            'name' => 'heureFinReelle',
            'required' => false,
            'validators' => [
                $validator,
            ],
        ];

        $inputFilter['commentaireCloture'] = [
            'name' => 'commentaireCloture',
            'required' => false,
            'filters' => [
                //StripTags == remove the unwanted html tags
                //StringTrim == remove the unnecessary spaces (\r or \t or \n...) at each line start/end
                ['name' => StringTrim::class],
            ],
            'validators' => [
                [
                    'name' => StringLength::class,
                    'options' => [
                        'encoding' => 'UTF-8',
                        'min' => 1,
                    ],
                ],
            ],
        ];

        //Envoi de mail
        $inputFilter['envoiMail'] = [
            'name' => 'envoiMail',
            'required' => false,
            'filters' => [
                ['name' => ToInt::class],
            ],
            'validators' => [
                $this->getDestinatairesListValidator(),
            ],
        ];

        $inputFilter['destinataires'] = [
            'name' => 'destinataires',
            'required' => false,
            'filters' => [
                //StripTags == remove the unwanted html tags
                //StringTrim == remove the unnecessary spaces (\r or \t or \n...) at each line start/end
                ['name' => StripTags::class],
                ['name' => StringTrim::class],
            ],
            'validators' => [
                [
                    'name' => StringLength::class,
                    'options' => [
                        'encoding' => 'UTF-8',
                        'min' => 1,
                    ],
                ],
                $this->getDestinatairesListValidator(),
            ],
        ];

        return $inputFilter;
    }
}