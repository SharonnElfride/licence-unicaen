<?php

namespace MeteoSI\Service\CibleEvenement\Shared;

use MeteoSI\Model\CategorieCible;
use MeteoSI\Service\CibleEvenement\CibleEvenementService;

/**
 * Trait CibleInterSvcsTrait
 * @package MeteoSI\Service\Shared
 */
trait CibleInterSvcsTrait
{
    /**
     * @param $entityManager
     * @param string $code
     * @param CibleEvenementService $service
     * @return array
     */
    public function findCibleEvenement($entityManager, string $code, CibleEvenementService $service)
    {
        /** @var CategorieCible $cat */
        $cat = $entityManager->getRepository(CategorieCible::class)->findOneBy(['code' => $code]);

       return $service->findAllBy(
            ["categorieCible" => $cat],
            ["libelle" => "ASC"]
        );
    }
}