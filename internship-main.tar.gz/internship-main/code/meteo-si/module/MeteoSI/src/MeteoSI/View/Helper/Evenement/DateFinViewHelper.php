<?php

namespace MeteoSI\View\Helper\Evenement;

use Application\Application\Misc\Util;
use Laminas\View\Helper\AbstractHelper;
use MeteoSI\Model\Evenement;

class DateFinViewHelper extends AbstractHelper
{
    /** @var Evenement $evenement */
    private $evenement;

    /**
     * @param Evenement|null $evenement
     * @return $this
     */
    public function __invoke(?Evenement $evenement)
    {
        $this->evenement = $evenement;
        return $this;
    }

    public function __toString()
    {
        $dateFin = "";
        $padding = 'ps-3';
        $margin = 'ms-3';

        if($this->evenement->getDureeInconnue()):
            $dateFin = "<span class='text-muted'>Inconnue</span>";
        else:
             if ($this->evenement->getDateFinReelle() != null):
                 $dateFin = sprintf(
             "<br/> <span class='%s'> Fin réelle/constatée <span class='%s'> %s </span></span>",
                     $padding,
                     $margin,
                     Util::formatIntlDateTime($this->evenement->getDateFinReelle(), 'dd/MM/yyyy à HH:mm')
                 );
             else:
                if ($this->evenement->getDateFinEstimee() != null){
                    $dateFin = sprintf(
                        "<br/> <span class='%s'> Fin estimée <span class='%s'> %s </span></span>",
                        $padding,
                        $margin,
                        Util::formatIntlDateTime($this->evenement->getDateFinEstimee(), 'dd/MM/yyyy à HH:mm')
                    );
                 }
                if ($this->evenement->getDateFinMinimale() != null) {
                    $dateFin = sprintf(
                        "<br/> <span class='%s'> Fin au plus tôt <span class='%s'> %s </span></span>",
                        $padding,
                        $margin,
                        Util::formatIntlDateTime($this->evenement->getDateFinMinimale(), 'dd/MM/yyyy à HH:mm')
                    );
                 }
            endif;
        endif;
        return $dateFin;
    }

//GETTERS ET SETTERS
    /**
     * @return Evenement|null
     */
    public function getEvenement()
    {
        return $this->evenement;
    }

    /**
     * @param Evenement|null $evenement
     */
    public function setEvenement(?Evenement $evenement): void
    {
        $this->evenement = $evenement;
    }
}