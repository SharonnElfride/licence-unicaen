<?php

namespace MeteoSI\Form\Evenement\Traits;

use MeteoSI\Form\Evenement\Form\AddEditEvenementForm;
use MeteoSI\Form\Evenement\Form\ClotureEvenementForm;
use MeteoSI\Form\Evenement\Form\ReOpenEvenementForm;

/**
 * Trait EvenementFormTrait
 * @package  MeteoSI\Form\Evenement\Traits;
 */
trait EvenementFormTrait
{
    /** @var AddEditEvenementForm */
    protected $evenementForm;

    /** @var ClotureEvenementForm */
    protected $evenementClotureForm;

    /** @var ReOpenEvenementForm */
    protected $reOpenEvenementForm;

    /**
     * @return AddEditEvenementForm
     */
    public function getEvenementForm()
    {
        return $this->evenementForm;
    }

    /**
     * @param AddEditEvenementForm $evenementForm
     */
    public function setEvenementForm($evenementForm): void
    {
        $this->evenementForm = $evenementForm;
    }

    /**
     * @return ClotureEvenementForm
     */
    public function getClotureEvenementForm(): ClotureEvenementForm
    {
        return $this->evenementClotureForm;
    }

    /**
     * @param ClotureEvenementForm $evenementClotureForm
     */
    public function setClotureEvenementForm(ClotureEvenementForm $evenementClotureForm): void
    {
        $this->evenementClotureForm = $evenementClotureForm;
    }

    /**
     * @return ReOpenEvenementForm
     */
    public function getReOpenEvenementForm(): ReOpenEvenementForm
    {
        return $this->reOpenEvenementForm;
    }

    /**
     * @param ReOpenEvenementForm $reOpenEvenementForm
     */
    public function setReOpenEvenementForm(ReOpenEvenementForm $reOpenEvenementForm): void
    {
        $this->reOpenEvenementForm = $reOpenEvenementForm;
    }
}
