<?php

namespace MeteoSI\Form\CibleEvenement\CibleGroupe\Factory;

use Doctrine\ORM\EntityManager;
use Interop\Container\Containerinterface;
use Laminas\ServiceManager\Factory\FactoryInterface;
use Laminas\View\HelperPluginManager;
use MeteoSI\Form\CibleEvenement\CibleGroupe\CibleEvenementGroupeForm;
use MeteoSI\Form\CibleEvenement\CibleGroupe\Hydrator\CibleEvenementGroupeHydrator;

/**
 * Classe CibleEvenementGroupeFormFactory
 */
class CibleEvenementGroupeFormFactory implements FactoryInterface
{
    /**
     * Create fieldset
     *
     * @param ContainerInterface $container
     * @param string $requestedName
     * @param array|null $options
     * @return CibleEvenementGroupeForm|object
     */
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        /** @var CibleEvenementGroupeForm $form */
        $form = new CibleEvenementGroupeForm();

        /** @var EntityManager $entityManager */
        $entityManager = $container->get(EntityManager::class);
        $form->setEntityManager($entityManager);

        /** @var HelperPluginManager $viewHelperManager */
        $viewHelperManager = $container->get('ViewHelperManager');
        $form->setViewHelperManager($viewHelperManager);

        /** @var CibleEvenementGroupeHydrator $hydrator */
        $hydrator = $container->get('HydratorManager')->get(CibleEvenementGroupeHydrator::class);
        $form->setHydrator($hydrator);

        return $form;
    }
}
