<?php

namespace MeteoSI\Service\CibleEvenement\CibleBdd;

use Doctrine\ORM\EntityManager;
use Interop\Container\ContainerInterface;
use Laminas\ServiceManager\Factory\FactoryInterface;

/**
 * Class CibleEvenementBddServiceFactory
 * @package MeteoSI\Service\CibleEvenement\CibleBdd
 */
class CibleEvenementBddServiceFactory implements FactoryInterface
{
    /**
     * @param ContainerInterface $container
     * @param string $requestedName
     * @param array|null $options
     * @return CibleEvenementBddService|object
     */
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        /** @var CibleEvenementBddService $serviceProvider */
        $serviceProvider = new CibleEvenementBddService();

        /** @var EntityManager $entityManager */
        $entityManager = $container->get(EntityManager::class);
        $serviceProvider->setEntityManager($entityManager);

        return $serviceProvider;
    }
}
