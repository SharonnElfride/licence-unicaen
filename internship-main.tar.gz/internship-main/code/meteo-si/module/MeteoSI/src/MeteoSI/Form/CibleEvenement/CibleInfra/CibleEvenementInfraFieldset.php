<?php

namespace MeteoSI\Form\CibleEvenement\CibleInfra;

use Application\Application\Form\AbstractEntityFieldset;
use DoctrineModule\Form\Element\ObjectSelect;
use Laminas\Filter\StringTrim;
use Laminas\Filter\StripTags;
use Laminas\Filter\ToInt;
use Laminas\Filter\ToNull;
use Laminas\Form\Element\Number;
use Laminas\Form\Element\Text;
use Laminas\Form\Element\Textarea;
use Laminas\InputFilter\InputFilterProviderInterface;
use Laminas\Validator\StringLength;
use MeteoSI\Form\CibleEvenement\Cible\CibleEvenementFieldset;
use MeteoSI\Model\CategorieCible;
use MeteoSI\Model\CategorieInfra;
use MeteoSI\Model\EtatCible;

/**
 * Class CibleEvenementInfraFieldset
 */
class CibleEvenementInfraFieldset extends CibleEvenementFieldset
{

    public function init()
    {
        parent::init();

        $this->add([
            'type'    => ObjectSelect::class,
            'name'    => 'categorieInfra',
            'options' => [
//                'label' => "Catégorie de l'infrastructure",
                'empty_option' => 'Sélectionner une catégorie',
                'object_manager' => $this->getEntityManager(),
                'target_class' => CategorieInfra::class,
                'property' => 'libelle',
                'find_method' => [
                    'name' => 'findBy',
                    'params' => [
                        'criteria' => [],
                        'orderBy' => ['libelle' => 'ASC'],
                    ],
                ],
                'disable_inarray_validator' => true,
            ],
            'attributes' => [
                'id' => 'categorieInfra',
            ],
        ]);

        $this->add([
            'type'    => Text::class,
            'name'    => 'site',
            'options' => [
                'max' => 255,
            ],
            'attributes' => [
                'placeholder' => 'site DCCAEN-AC5',
            ],
        ]);

        $this->add([
            'type'    => Number::class,
            'name'    => 'position',
            'options' => [
                'min' => 1,
            ],
            'attributes' => [
                'placeholder' => '45',
            ],
        ]);

        $this->add([
            'type'    => Text::class,
            'name'    => 'status',
            'options' => [
                'max' => 255,
            ],
            'attributes' => [
                'placeholder' => 'active',
            ],
        ]);

        $this->add([
            'type'    => Textarea::class,
            'name'    => 'comments',
            'attributes' => [
                'id' => 'comments',
                'rows' => 2,
                'placeholder' => 'commentaires',
            ],
        ]);
    }

    public function getInputFilterSpecification()
    {
        $inputFilter = parent::getInputFilterSpecification();

        $inputFilter['categorieInfra'] = [
            'name' => 'categorieInfra',
            'required' => true,
            'filters' => [
                ['name' => ToInt::class],
                [
                    'name' => ToNull::class,
                    'options' => [
                        ToNull::TYPE_INTEGER
                    ],
                ],
            ],
        ];

        $inputFilter['site'] = [
            'name' => 'site',
            'required' => false,
            'filters' => [
                ['name' => StripTags::class],
                ['name' => StringTrim::class],
            ],
            'validators' => [
                [
                    'name' => StringLength::class,
                    'options' => [
                        'encoding' => 'UTF-8',
                        'min' => 1,
                    ],
                ],
            ],
        ];

        $inputFilter['position'] = [
            'name' => 'position',
            'required' => true,
            'filters' => [
                ['name' => ToInt::class],
            ],
        ];

        $inputFilter['status'] = [
            'name' => 'status',
            'required' => true,
            'filters' => [
                ['name' => StripTags::class],
                ['name' => StringTrim::class],
            ],
            'validators' => [
                [
                    'name' => StringLength::class,
                    'options' => [
                        'encoding' => 'UTF-8',
                        'min' => 1,
                        'max' => 255,
                    ],
                ],
            ],
        ];

        $inputFilter['comments'] = [
            'name' => 'comments',
            'required' => false,
            'filters' => [
                ['name' => StringTrim::class],
            ],
            'validators' => [
                [
                    'name' => StringLength::class,
                    'options' => [
                        'encoding' => 'UTF-8',
                        'min' => 1,
                    ],
                ],
            ],
        ];

        return $inputFilter;
    }
}
