<?php

namespace MeteoSI\View\Helper\Calendar;

use Interop\Container\Containerinterface;
use Laminas\ServiceManager\Factory\FactoryInterface;
use MeteoSI\Service\CategorieEvenement\CategorieEvenementService;
use MeteoSI\Service\Evenement\EvenementService;

class CalendarViewHelperFactory implements FactoryInterface
{
    public function __invoke(ContainerInterface $container, $requestedName, ?array $options = null)
    {
        $helper = new CalendarViewHelper();

        /** @var EvenementService $eventService */
        $eventService = $container->get(EvenementService::class);
        $helper->setEvenementService($eventService);

        /** @var CategorieEvenementService $eventCategorieService */
        $eventCategorieService = $container->get(CategorieEvenementService::class);
        $helper->setCategorieService($eventCategorieService);

        $config = $container->get('config');
        $days = $config['unicaen-calendar']['days'];
        $months = $config['unicaen-calendar']['months'];
        //Configurer à partir du service
        $helper->setDays($days);
        $helper->setMonths($months);

        return $helper;
    }
}