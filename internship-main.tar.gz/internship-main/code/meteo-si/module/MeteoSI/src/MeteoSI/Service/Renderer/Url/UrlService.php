<?php

namespace MeteoSI\Service\Renderer\Url;

use Laminas\View\Renderer\PhpRenderer;
use MeteoSI\Model\CibleEvenement;
use MeteoSI\Model\CibleEvenementApplication;

class UrlService {

    /** @var PhpRenderer */
    protected $renderer;
    /** @var array */
    protected $variables;

    /**
     * @param PhpRenderer $renderer
     * @return UrlService
     */
    public function setRenderer($renderer): UrlService
    {
        $this->renderer = $renderer;
        return $this;
    }

    /**
     * @param array $variables
     * @return UrlService
     */
    public function setVariables(array $variables): UrlService
    {
        $this->variables = $variables;
        return $this;
    }

    /**
     * @param string
     * @return mixed
     */
    public function getVariable(string $key)
    {
        if (! isset($this->variables[$key])) return null;
        return $this->variables[$key];
    }

    /**
     * @return string
     */
    public function getUrlApp() : string
    {
        $url = $this->renderer->url('home', [], ['force_canonical' => true], true);
        return $url;
    }

    /**
     * @param bool $forceCanonical pour avoir l'url complété
     * @return string
     */
    public function getCurrentUrl($forceCanonical = false)
    {
        $url = $this->renderer->url(null, [], ['force_canonical' => $forceCanonical], true);
        return $url;
    }

    /**
     * @return string
     */
    public function getUrlCibleApplication() : ?string
    {
        /** @var CibleEvenementApplication $application */
        $application = $this->getVariable('cibleApplication');
        if ($application === null) return null;
        $url = $this->renderer->url('cible-evenement', ['action' => 'show'], ['force_canonical' => true], true);
        return "<a class='fw-bold' href='" . $url . "'>" . $application->getLibelle() . "</a>";
    }

    /**
     * @return string
     */
    public function getUrlPageInformation() : ?string
    {
        $url = $this->renderer->url('page-information', ['action' => 'index'], ['force_canonical' => true], true);
        return "<a class='fw-bold' href='" . $url . "'>Page d'information</a>";
    }
}