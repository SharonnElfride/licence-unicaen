<?php

namespace MeteoSI\View\Helper\Evenement;

use Laminas\View\Helper\AbstractHelper;
use MeteoSI\Model\Evenement;

class PublieViewHelper extends AbstractHelper
{
    /** @var Evenement $evenement */
    private $evenement;

    /**
     * @param Evenement|null $evenement
     * @return $this
     */
    public function __invoke(?Evenement $evenement)
    {
        $this->evenement = $evenement;
        return $this;
    }

    public function __toString()
    {
        $visibilite = "";

        if(($this->evenement->getPublieIntranet() === false) && ($this->evenement->getPublieInternet() === false)):
            $visibilite = "<span class='text-muted'>Visible uniquement dans l'application</span>";
        else:
            if(($this->evenement->getPublieIntranet() !== false) && ($this->evenement->getPublieInternet() !== false)):
                $visibilite = "Visible hors de l'application (flux RSS, page d'information) et sur Internet";
            elseif(($this->evenement->getPublieIntranet() !== false) && ($this->evenement->getPublieInternet() === false)):
                $visibilite = "Visible hors de l'application (uniquement flux RSS, page d'information)";
            elseif(($this->evenement->getPublieIntranet() === false) && ($this->evenement->getPublieInternet() !== false)):
                $visibilite = "Visible sur Internet";
            endif;
        endif;

        return $visibilite;
    }

//GETTERS ET SETTERS
    /**
     * @return Evenement|null
     */
    public function getEvenement()
    {
        return $this->evenement;
    }

    /**
     * @param Evenement|null $evenement
     */
    public function setEvenement(?Evenement $evenement): void
    {
        $this->evenement = $evenement;
    }
}