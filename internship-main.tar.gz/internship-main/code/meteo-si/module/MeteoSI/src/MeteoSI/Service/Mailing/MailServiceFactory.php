<?php

namespace MeteoSI\MeteoSI\Service\Mailing;

use Doctrine\ORM\EntityManager;
use Interop\Container\ContainerInterface;
use Laminas\Mail\Transport\Smtp;
use Laminas\Mail\Transport\SmtpOptions;
use Laminas\Mail\Transport\TransportInterface;
use MeteoSI\Service\Renderer\Date\DateRendererService;
use MeteoSI\Service\Renderer\Evenement\EvenementInfo\EvenementInfoService;
use MeteoSI\Service\Renderer\Url\UrlService;
use UnicaenRenderer\Service\Macro\MacroService;
use UnicaenRenderer\Service\Template\TemplateService;
use UnicaenUtilisateur\Service\User\UserService;

class MailServiceFactory
{
    public function __invoke(ContainerInterface $container)
    {

        $config = $container->get('Configuration')['unicaen-mail'];
        /** @var TransportInterface */
        $transport = new Smtp(new SmtpOptions($config['transport_options']));

        /**
         * @var EntityManager $entityManager
         * @var UserService $userService
         */
        $entityManager = $container->get('doctrine.entitymanager.orm_default');

        /** @var MailService $service */
        $serviceProvider = new MailService($transport,
            $config['redirect_to'], $config['do_not_send'],
            $config['from_name'], $config['from_email'], $config['subject_prefix']
        );
        $serviceProvider->setEntityManager($entityManager);
        $serviceProvider->setEntityClass($config['mail_entity_class']);

        /** @var TemplateService $templateService */
        $templateService = $container->get('ServiceManager')->get(TemplateService::class);
        $serviceProvider->setTemplateService($templateService);

        /** @var DateRendererService $dateRendererService */
        $dateRendererService = $container->get(DateRendererService::class);
        $serviceProvider->setDateRendererService($dateRendererService);

        //get('ServiceManager')->
        /** @var EvenementInfoService $evenementInfoService */
        $evenementInfoService = $container->get(EvenementInfoService::class);
        $serviceProvider->setEvenementInfoService($evenementInfoService);

        /** @var UrlService $urlService */
        $urlService = $container->get(UrlService::class);
        $serviceProvider->setUrlService($urlService);

        /** @var MacroService $macroService */
        $macroService = $container->get('ServiceManager')->get(MacroService::class);
        $serviceProvider->setMacroService($macroService);

        return $serviceProvider;
    }
}