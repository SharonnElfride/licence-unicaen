<?php

namespace MeteoSI\Service\CategorieEvenement;

use MeteoSI\Model\CategorieEvenement;
use Application\Application\Service\API\CommonEntityService;
use Doctrine\ORM\OptimisticLockException;
use Doctrine\ORM\ORMException;

/**
 * Class CategorieEvenementService
 * @package MeteoSI\Service\CategorieEvenement
 */
class CategorieEvenementService extends CommonEntityService
{
    /** @return string */
    public function getEntityClass()
    {
        return CategorieEvenement::class;
    }

    //Retourne une nouvelle instance de l'entité courante
    public function getEntityInstance($name = null)
    {
        return $this->getEntityInstance($name);
    }

    //Add a new line to the table db
    /**
     * @override
     * @throws ORMException
     * @throws OptimisticLockException
     */
    public function add($entity, $serviceEntityClass = null)
    {
        return parent::add($entity, $serviceEntityClass);
    }

    //Update a new line to the table db
    /**
     * @override
     * @throws ORMException
     * @throws OptimisticLockException
     */
    public function update($entity, $serviceEntityClass = null)
    {
        return parent::update($entity, $serviceEntityClass);
    }

    //Delete the table line indexed with the id=$id
    /**
     * @override
     * @throws ORMException
     * @throws OptimisticLockException
     */
    public function delete($entity, $serviceEntityClass = null)
    {
        return parent::delete($entity, $serviceEntityClass);
    }

    public function findAll()
    {
        return $this->findAllBy([], ["libelle" => "ASC"]);
    }
}
