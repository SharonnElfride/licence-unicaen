<?php

namespace MeteoSI\Form\CibleEvenement\CibleService\Factory;

use Laminas\Validator\ValidatorPluginManager;
use MeteoSI\Form\CibleEvenement\Cible\Validator\StateEditValidator;
use MeteoSI\Form\CibleEvenement\CibleEvenementFieldset;
use MeteoSI\Form\CibleEvenement\CibleService\CibleEvenementServiceFieldset;
use MeteoSI\Form\CibleEvenement\CibleService\Hydrator\CibleEvenementServiceHydrator;
use MeteoSI\Model\CibleEvenement;
use Doctrine\Laminas\Hydrator\DoctrineObject;
use Doctrine\ORM\EntityManager;
use Interop\Container\ContainerInterface;
use Laminas\ServiceManager\Factory\FactoryInterface;
use MeteoSI\Model\CibleEvenementService;

/**
 * Class CibleEvenementServiceFieldsetFactory
 */
class CibleEvenementServiceFieldsetFactory implements FactoryInterface
{
    /**
     * Create fieldset
     *
     * @param ContainerInterface $container
     * @param string $requestedName
     * @param array|null $options
     * @return CibleEvenementServiceFieldset|object
     */
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        /** @var CibleEvenementServiceFieldset $fieldset */
        $fieldset = new CibleEvenementServiceFieldset('cibleService');

        /** @var EntityManager $entityManager */
        $entityManager = $container->get(EntityManager::class);
        $fieldset->setEntityManager($entityManager);

        /** @var CibleEvenementServiceHydrator $hydrator */
        $hydrator = $container->get('HydratorManager')->get(CibleEvenementServiceHydrator::class);
        $fieldset->setHydrator($hydrator);
        $fieldset->setObject(new CibleEvenementService());
        return $fieldset;
    }
}
