<?php

namespace MeteoSI\Form\CibleEvenement\CibleApplication;

use Application\Application\Form\AbstractEntityForm;

class CibleEvenementApplicationForm extends AbstractEntityForm
{
    public function __construct($name = null)
    {
        parent::__construct('cibleEvenementApplication');
    }

    protected function initEntityFieldset()
    {
        $this->entityFieldset = $this->getFormFactory()->getFormElementManager()->get(CibleEvenementApplicationFieldset::class);
        $this->entityFieldset->setOptions([
            'use_as_base_fieldset' => true,
        ]);
        $this->add($this->entityFieldset);
    }

    protected function initSubmitInput()
    {
        $this->add([
            'name' => 'submit',
            'type' => 'submit',
            'attributes' => [
                'value' => 'Go',
                'id' => 'submitbutton',
            ],
        ]);
    }
}
