<?php

namespace MeteoSI\Service\Evenement;

/**
 * Trait EvenementServiceAwareTrait
 * @package MeteoSI\Service\Evenement
 */
trait EvenementServiceAwareTrait
{
    /** @var EvenementService */
    protected $evenementService;

    /**
     * @return EvenementService
     */
    public function getEvenementService(): EvenementService
    {
        return $this->evenementService;
    }

    /**
     * @param EvenementService $evenementService
     */
    public function setEvenementService(EvenementService $evenementService): void
    {
        $this->evenementService = $evenementService;
    }

}
