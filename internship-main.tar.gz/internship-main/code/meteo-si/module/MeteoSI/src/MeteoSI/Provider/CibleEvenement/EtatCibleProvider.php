<?php

namespace MeteoSI\Provider\CibleEvenement;

class EtatCibleProvider
{
    const ETAT_GROUPE_NORMAL_NIVEAU_GRAVITE = 0;
    const ETAT_GROUPE_TRES_IMPORTANT_NIVEAU_GRAVITE = 3;
    const ETAT_GROUPE_IMPORTANT_NIVEAU_GRAVITE = 2;
    const ETAT_GROUPE_PAS_TRES_IMPORTANT_NIVEAU_GRAVITE = 1;

    const ETAT_CIBLE_NORMAL_CODE = 'normal';
    const ETAT_CIBLE_PANNE_CODE = 'panne';
    const ETAT_CIBLE_INDISPONIBLE_CODE = 'indisponible';
    const ETAT_CIBLE_PERTURBE_CODE = 'perturbe';

    const ETAT_CIBLE_NORMAL_ID = 1;
    const ETAT_CIBLE_PANNE_ID = 2;
    const ETAT_CIBLE_INDISPONIBLE_ID = 3;
    const ETAT_CIBLE_PERTURBE_ID = 4;
}