<?php

namespace MeteoSI\Form\Evenement\Factory\Fieldset;

use Doctrine\ORM\EntityManager;
use Interop\Container\ContainerInterface;
use Laminas\ServiceManager\Factory\FactoryInterface;
use Laminas\Validator\ValidatorPluginManager;
use MeteoSI\Form\Evenement\Fieldset\ClotureEvenementFieldset;
use MeteoSI\Form\Evenement\Hydrator\ClotureEvenementHydrator;
use MeteoSI\Form\Evenement\Validator\ClotureEvenementValidator;
use MeteoSI\Form\Evenement\Validator\DateAnterieureCheckerValidator;
use MeteoSI\Form\Evenement\Validator\DestinatairesListValidator;
use MeteoSI\Model\Evenement;

/**
 * Class ClotureEvenementFieldsetFactory
 */
class ClotureEvenementFieldsetFactory implements FactoryInterface
{
    /**
     * Create fieldset
     *
     * @param ContainerInterface $container
     * @param string $requestedName
     * @param array|null $options
     * @return ClotureEvenementFieldset|object
     */
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        /** @var ClotureEvenementFieldset $fieldset */
        $fieldset = new ClotureEvenementFieldset('evenement');

        /** @var EntityManager $entityManager */
        $entityManager = $container->get(EntityManager::class);
        $fieldset->setEntityManager($entityManager);

        /** @var ClotureEvenementValidator $evenementValidator */
        $evenementValidator = $container->get(ValidatorPluginManager::class)->get(ClotureEvenementValidator::class);
        $fieldset->setEvenementValidator($evenementValidator);

        /** @var DestinatairesListValidator $evenementValidator */
        $evenementValidator = $container->get(ValidatorPluginManager::class)->get(DestinatairesListValidator::class);
        $fieldset->setDestinatairesListValidator($evenementValidator);

        /** @var ClotureEvenementHydrator $hydrator */
        $hydrator = $container->get('HydratorManager')->get(ClotureEvenementHydrator::class);
        $fieldset->setHydrator($hydrator);

        $fieldset->setObject(new Evenement());
        return $fieldset;
    }
}
