<?php

namespace MeteoSI\Form\CibleEvenement\Cible\Traits;

use MeteoSI\Form\CibleEvenement\Cible\AddParentForm;
use MeteoSI\Form\CibleEvenement\CibleApplication\CibleEvenementApplicationForm;
use MeteoSI\Form\CibleEvenement\CibleBdd\CibleEvenementBddForm;
use MeteoSI\Form\CibleEvenement\CibleGroupe\AddTargetToGroupForm;
use MeteoSI\Form\CibleEvenement\CibleGroupe\CibleEvenementGroupeForm;
use MeteoSI\Form\CibleEvenement\CibleInfra\CibleEvenementInfraForm;
use MeteoSI\Form\CibleEvenement\Cible\CibleEvenementForm;
use MeteoSI\Form\CibleEvenement\CibleService\CibleEvenementServiceForm;

/**
 * Trait CibleEvenementFormTrait
 * @package  MeteoSI\Form\CibleEvenement\Traits;
 */
trait CibleEvenementFormTrait
{
    /** @var CibleEvenementForm */
    protected $cibleForm;

    /** @var CibleEvenementApplicationForm */
    protected $cibleApplicationForm;

    /** @var CibleEvenementBddForm */
    protected $cibleBaseDeDonneesForm;

    /** @var CibleEvenementInfraForm */
    protected $cibleInfrastructureForm;

    /** @var CibleEvenementServiceForm */
    protected $cibleServiceForm;

    /** @var CibleEvenementGroupeForm */
    protected $cibleGroupeForm;

    /** @var AddTargetToGroupForm $addTargetToGroupForm */
    protected $addTargetToGroupForm;

    /** @var AddParentForm $addParentForm */
    protected $addParentForm;

    /**
     * @return CibleEvenementForm
     */
    public function getCibleForm(): CibleEvenementForm
    {
        return $this->cibleForm;
    }

    /**
     * @param CibleEvenementForm $cibleForm
     */
    public function setCibleForm(CibleEvenementForm $cibleForm): void
    {
        $this->cibleForm = $cibleForm;
    }

    //APPLICATION
    /**
     * @return CibleEvenementApplicationForm
     */
    public function getCibleApplicationForm(): CibleEvenementApplicationForm
    {
        return $this->cibleApplicationForm;
    }

    /**
     * @param CibleEvenementApplicationForm $cibleApplicationForm
     */
    public function setCibleApplicationForm(CibleEvenementApplicationForm $cibleApplicationForm): void
    {
        $this->cibleApplicationForm = $cibleApplicationForm;
    }

    //BDD
    /**
     * @return CibleEvenementBddForm
     */
    public function getCibleBaseDeDonneesForm(): CibleEvenementBddForm
    {
        return $this->cibleBaseDeDonneesForm;
    }

    /**
     * @param CibleEvenementBddForm $cibleBaseDeDonneesForm
     */
    public function setCibleBaseDeDonneesForm(CibleEvenementBddForm $cibleBaseDeDonneesForm): void
    {
        $this->cibleBaseDeDonneesForm = $cibleBaseDeDonneesForm;
    }

    //INFRA
    /**
     * @return CibleEvenementInfraForm
     */
    public function getCibleInfrastructureForm(): CibleEvenementInfraForm
    {
        return $this->cibleInfrastructureForm;
    }

    /**
     * @param CibleEvenementInfraForm $cibleInfrastructureForm
     */
    public function setCibleInfrastructureForm(CibleEvenementInfraForm $cibleInfrastructureForm): void
    {
        $this->cibleInfrastructureForm = $cibleInfrastructureForm;
    }

    //SERVICE
    /**
     * @return CibleEvenementServiceForm
     */
    public function getCibleServiceForm(): CibleEvenementServiceForm
    {
        return $this->cibleServiceForm;
    }

    /**
     * @param CibleEvenementServiceForm $cibleServiceForm
     */
    public function setCibleServiceForm(CibleEvenementServiceForm $cibleServiceForm): void
    {
        $this->cibleServiceForm = $cibleServiceForm;
    }

    //GROUPE DE CIBLES
    /**
     * @return CibleEvenementGroupeForm
     */
    public function getCibleGroupeForm(): CibleEvenementGroupeForm
    {
        return $this->cibleGroupeForm;
    }

    /**
     * @param CibleEvenementGroupeForm $cibleGroupeForm
     */
    public function setCibleGroupeForm(CibleEvenementGroupeForm $cibleGroupeForm): void
    {
        $this->cibleGroupeForm = $cibleGroupeForm;
    }

    /**
     * @return AddTargetToGroupForm
     */
    public function getAddTargetToGroupForm(): AddTargetToGroupForm
    {
        return $this->addTargetToGroupForm;
    }

    /**
     * @param AddTargetToGroupForm $addTargetToGroupForm
     */
    public function setAddTargetToGroupForm(AddTargetToGroupForm $addTargetToGroupForm): void
    {
        $this->addTargetToGroupForm = $addTargetToGroupForm;
    }

    /**
     * @return AddParentForm
     */
    public function getAddParentForm(): AddParentForm
    {
        return $this->addParentForm;
    }

    /**
     * @param AddParentForm $addParentForm
     */
    public function setAddParentForm(AddParentForm $addParentForm): void
    {
        $this->addParentForm = $addParentForm;
    }
}
