<?php

namespace MeteoSI\Form\CibleEvenement\CibleGroupe;

use Application\Application\Form\AbstractEntityFieldset;
use DoctrineModule\Form\Element\ObjectSelect;
use Laminas\Filter\ToInt;
use Laminas\Filter\ToNull;
use Laminas\Form\Element\Select;
use Laminas\InputFilter\InputFilterProviderInterface;
use MeteoSI\Model\CibleEvenement;
use MeteoSI\Model\CibleEvenementGroupe;

class AddTargetToGroupFieldset extends AbstractEntityFieldset implements InputFilterProviderInterface
{
    /**
     * @param CibleEvenementGroupe $groupe
     * @return void
     */
    public function setGroupe(CibleEvenementGroupe $groupe): void
    {
        //Query for getting all the targets ∉ the group
        $em = $this->getEntityManager();
        $cibles = $em->getRepository(CibleEvenement::class)->findAll();
        $cibles = array_filter($cibles, function (CibleEvenement $c) use($groupe) {
           return (
               $c->getId() != $groupe->getCible()->getId())
               && (!$groupe->getCibles()->contains($c)
               && (!$groupe->getCible()->getParents()->contains($c))
               && (!$groupe->getCible()->getEnfants()->contains($c))
           );
        });

        usort($cibles, function (CibleEvenement $c1, CibleEvenement $c2) {
           if($c1->getCategorieCible()->getId() == $c2->getCategorieCible()->getId())
               return strcmp($c1->getLibelle(), $c2->getLibelle());

           return strcmp($c1->getCategorieLibelle(), $c2->getCategorieLibelle());
        });

        $options = [];
        /** @var CibleEvenement $cible */
        foreach ($cibles as $cible):
            $options[$cible->getCategorieCible()->getCode()]['label'] = $cible->getCategorieLibelle();
            $options[$cible->getCategorieCible()->getCode()]['options'][$cible->getId()] = $cible->getLibelle();
        endforeach;

        $this->get('cible')->setValueOptions($options);
    }

    public function init()
    {
        $this->add([
            'name' => 'id',
            'type' => 'hidden',
        ]);

        $this->add([
            'type' => Select::class,
            'name' => 'cible',
            'options' => [
//                'label' => "Cible à ajouter au groupe",
                'empty_option' => 'Sélectionner une cible',
                'value_options' => [],
                'disable_inarray_validator' => true,
            ],
            'attributes' => [
                'id' => 'cible',
            ],
        ]);
    }

    /**
     * Should return an array specification compatible with
     *
     * @return array
     */
    public function getInputFilterSpecification()
    {
        $inputFilter = [];

        $inputFilter['id'] = [
            'name' => 'id',
            'required' => true,
            'filters' => [
                ['name' => ToInt::class],
            ],
        ];

        $inputFilter['cible'] = [
            'name' => 'cible',
            'required' => true,
            'filters' => [
                ['name' => ToInt::class],
                [
                    'name' => ToNull::class,
                    'options' => [
                        ToNull::TYPE_INTEGER
                    ],
                ],
            ],
        ];

        return $inputFilter;
    }
}