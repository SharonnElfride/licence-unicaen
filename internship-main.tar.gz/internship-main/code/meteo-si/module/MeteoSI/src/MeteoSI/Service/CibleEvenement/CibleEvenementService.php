<?php

namespace MeteoSI\Service\CibleEvenement;

use Application\Application\Service\API\CommonEntityService;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\OptimisticLockException;
use Doctrine\ORM\ORMException;
use Interop\Container\Containerinterface;
use MeteoSI\Model\CategorieCible;
use MeteoSI\Model\CibleDependance;
use MeteoSI\Model\CibleDependancePriorite;
use MeteoSI\Model\CibleEvenement;
use MeteoSI\Model\CibleEvenementApplication;
use MeteoSI\Model\CibleEvenementGroupe;
use MeteoSI\Model\RegleTransition;
use MeteoSI\Service\CibleEvenement\Dependance\CibleDependance\CibleDependanceService;
use MeteoSI\Service\CibleEvenement\Dependance\RegleTransition\RegleTransitionServiceAwareTrait;

/**
 * Class CibleEvenementService
 * @package MeteoSI\Service\CibleEvenement
 */
class CibleEvenementService extends CommonEntityService
{
    use RegleTransitionServiceAwareTrait;

     /** @return string */
    public function getEntityClass()
    {
        return CibleEvenement::class;
    }

    //Retourne une nouvelle instance de l'entité courante
    public function getEntityInstance($name = null)
    {
        return $this->getEntityInstance($name);
    }

    //Add a new line to the table db
    /**
     * @param CibleEvenement $entity
     *
     * @override
     * @throws ORMException
     * @throws OptimisticLockException
     */
    public function add($entity, $serviceEntityClass = null)
    {
        return parent::add($entity, $serviceEntityClass);
    }

    //Update a new line to the table db

    /**
     * @override
     * @throws ORMException
     * @throws OptimisticLockException
     */
    public function update($entity, $serviceEntityClass = null)
    {
        return parent::update($entity, $serviceEntityClass);
    }

    //Delete the table line indexed with the id=$id

    /**
     * @override
     * @throws ORMException
     * @throws OptimisticLockException
     */
    public function delete($entity, $serviceEntityClass = null)
    {
        return parent::delete($entity, $serviceEntityClass);
    }

    public function findAll()
    {
        return $this->findAllBy([], ["libelle" => "ASC"]);
    }

    //For managing Adding target to and Removing target from a group
    /**
     * @param CibleEvenement $enfant
     * @param CibleDependance $dependance
     * @return mixed
     * @throws ORMException
     * @throws OptimisticLockException
     */
    public function addParent(CibleEvenement $enfant, CibleDependanceService $dependanceService, CibleDependance $dependance)
    {
        /** @var ArrayCollection|RegleTransition[] $reglesTransitionsDefault */
        $reglesTransitionsDefault = $this->getRegleTransitionService()->findDefaultRules();
        foreach ($reglesTransitionsDefault as $regleTransition):
            $dependance->addRegleTransition($regleTransition);
        endforeach;

        $dependanceService->add($dependance);
//        $this->update($enfant);
//        $enfant->changeStateByTransitionRule();
        return $this->update($enfant);
    }

    /**
     * @param CibleEvenement $enfant
     * @param CibleEvenement $parent
     * @param CibleDependanceService $dependanceService
     * @return mixed
     * @throws ORMException
     * @throws OptimisticLockException
     */
    public function removeParent(CibleEvenement $enfant, CibleEvenement $parent, CibleDependanceService $dependanceService)
    {
        $depParents = $enfant->getDependanceParents();

        foreach ($depParents as $dep):
            if($dep->getParent()->getId() === $parent->getId()):
                $dependanceService->delete($dep);
                break;
            endif;
        endforeach;

//        if($parent->getCategorieEntite() instanceof CibleEvenementGroupe) {
//
//        }

        return $this->update($enfant);
    }
}
