<?php

namespace MeteoSI\Service\CibleEvenement\Dependance\EtatCible;

use Application\Application\Service\API\CommonEntityService;
use MeteoSI\Model\EtatCible;

class EtatCibleService extends CommonEntityService
{
    /** @return string */
    public function getEntityClass()
    {
        return EtatCible::class;
    }

    //Retourne une nouvelle instance de l'entité courante
    public function getEntityInstance($name = null)
    {
        return $this->getEntityInstance($name);
    }

    public function findAll()
    {
        return $this->findAllBy([], ["id" => "ASC"]);
    }

    public function findAllId()
    {
        $normal = $this->findOneBy(['code' => 'normal']);
        $panne = $this->findOneBy(['code' => 'panne']);
        $indisponible = $this->findOneBy(['code' => 'indisponible']);
        $perturbe = $this->findOneBy(['code' => 'perturbe']);

        return [
            'normal' => $normal->getId(),
            'panne' => $panne->getId(),
            'indisponible' => $indisponible->getId(),
            'perturbe' => $perturbe->getId(),
        ];
    }
}