<?php

namespace MeteoSI\Service\CibleEvenement;

use MeteoSI\Service\CibleEvenement\CibleApplication\CibleEvenementApplicationService;
use MeteoSI\Service\CibleEvenement\CibleBdd\CibleEvenementBddService;
use MeteoSI\Service\CibleEvenement\CibleGroupe\CibleEvenementGroupeService;
use MeteoSI\Service\CibleEvenement\CibleInfra\CibleEvenementInfraService;
use MeteoSI\Service\CibleEvenement\CibleService\CibleEvenementServiceService;
use MeteoSI\Service\CibleEvenement\Dependance\CibleDependance\CibleDependanceService;

/**
 * Trait CibleEvenementServiceAwareTrait
 * @package MeteoSI\Service\CibleEvenement
 */
trait CibleEvenementServiceAwareTrait
{
    /** @var CibleEvenementService $cibleService */
    protected $cibleService;

    /** @var CibleEvenementApplicationService $cibleApplicationService */
    protected $cibleApplicationService;

    /** @var CibleEvenementBddService $cibleBaseDeDonneesService */
    protected $cibleBaseDeDonneesService;

    /** @var CibleEvenementInfraService $cibleInfrastructureService */
    protected $cibleInfrastructureService;

    /** @var CibleEvenementServiceService $cibleServiceService */
    protected $cibleServiceService;

    /** @var CibleEvenementGroupeService $cibleGroupeService */
    protected $cibleGroupeService;

    /** @var CibleDependanceService $cibleDependanceService */
    protected $cibleDependanceService;

    //Cible d'événement
    /**
     * @return CibleEvenementService
     */
    public function getCibleEvenementService(): CibleEvenementService
    {
        return $this->cibleService;
    }

    /**
     * @param CibleEvenementService $cibleService
     */
    public function setCibleEvenementService(CibleEvenementService $cibleService): void
    {
        $this->cibleService = $cibleService;
    }

    //APPLICATION
    /**
     * @return CibleEvenementApplicationService
     */
    public function getCibleApplicationService(): CibleEvenementApplicationService
    {
        return $this->cibleApplicationService;
    }

    /**
     * @param CibleEvenementApplicationService $cibleApplicationService
     */
    public function setCibleApplicationService(CibleEvenementApplicationService $cibleApplicationService): void
    {
        $this->cibleApplicationService = $cibleApplicationService;
    }

    //BASE DE DONNEES
    /**
     * @return CibleEvenementBddService
     */
    public function getCibleBaseDeDonneesService(): CibleEvenementBddService
    {
        return $this->cibleBaseDeDonneesService;
    }

    /**
     * @param CibleEvenementBddService $cibleBaseDeDonneesService
     */
    public function setCibleBaseDeDonneesService(CibleEvenementBddService $cibleBaseDeDonneesService): void
    {
        $this->cibleBaseDeDonneesService = $cibleBaseDeDonneesService;
    }

    //INFRASTRUCTURE
    /**
     * @return CibleEvenementInfraService
     */
    public function getCibleInfrastructureService(): CibleEvenementInfraService
    {
        return $this->cibleInfrastructureService;
    }

    /**
     * @param CibleEvenementInfraService $cibleInfrastructureService
     */
    public function setCibleInfrastructureService(CibleEvenementInfraService $cibleInfrastructureService): void
    {
        $this->cibleInfrastructureService = $cibleInfrastructureService;
    }

    //SERVICE
    /**
     * @return CibleEvenementServiceService
     */
    public function getCibleServiceService(): CibleEvenementServiceService
    {
        return $this->cibleServiceService;
    }

    /**
     * @param CibleEvenementServiceService $cibleServiceService
     */
    public function setCibleServiceService(CibleEvenementServiceService $cibleServiceService): void
    {
        $this->cibleServiceService = $cibleServiceService;
    }

    //GROUPES DE CIBLES
    /**
     * @return CibleEvenementGroupeService
     */
    public function getCibleGroupeService(): CibleEvenementGroupeService
    {
        return $this->cibleGroupeService;
    }

    /**
     * @param CibleEvenementGroupeService $cibleGroupeService
     */
    public function setCibleGroupeService(CibleEvenementGroupeService $cibleGroupeService): void
    {
        $this->cibleGroupeService = $cibleGroupeService;
    }

    //DEPENDANCES ENTRE CIBLES

    /**
     * @return CibleDependanceService
     */
    public function getCibleDependanceService(): CibleDependanceService
    {
        return $this->cibleDependanceService;
    }

    /**
     * @param CibleDependanceService $cibleDependanceService
     */
    public function setCibleDependanceService(CibleDependanceService $cibleDependanceService): void
    {
        $this->cibleDependanceService = $cibleDependanceService;
    }
}
