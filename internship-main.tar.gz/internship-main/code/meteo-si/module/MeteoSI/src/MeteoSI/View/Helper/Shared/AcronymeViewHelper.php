<?php

namespace MeteoSI\View\Helper\Shared;

use Laminas\View\Helper\AbstractHelper;

class AcronymeViewHelper extends AbstractHelper
{
    private $entity;

    public function __invoke($entity)
    {
        $this->entity = $entity;
        return $this;
    }

    public function __toString()
    {
        if ($this->entity->getAcronyme() === null) {
            return "<span class='text-secondary'>Aucun</span>";
        }

        return sprintf("<span class='text-secondary'> %s </span>", $this->entity->getAcronyme());
    }

//GETTERS ET SETTERS
    /**
     * @return mixed
     */
    public function getEntity()
    {
        return $this->entity;
    }

    /**
     * @param mixed $entity
     */
    public function setEntity($entity): void
    {
        $this->entity = $entity;
    }
}