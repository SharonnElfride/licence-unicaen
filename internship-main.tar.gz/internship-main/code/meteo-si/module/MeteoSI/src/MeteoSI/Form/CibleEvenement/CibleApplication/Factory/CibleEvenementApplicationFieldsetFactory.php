<?php

namespace MeteoSI\Form\CibleEvenement\CibleApplication\Factory;

use Doctrine\ORM\EntityManager;
use Interop\Container\ContainerInterface;
use Laminas\ServiceManager\Factory\FactoryInterface;
use MeteoSI\Form\CibleEvenement\CibleApplication\CibleEvenementApplicationFieldset;
use MeteoSI\Form\CibleEvenement\CibleApplication\Hydrator\CibleEvenementApplicationHydrator;
use MeteoSI\Model\CibleEvenementApplication;

/**
 * Class CibleEvenementApplicationFieldsetFactory
 */
class CibleEvenementApplicationFieldsetFactory implements FactoryInterface
{
    /**
     * Create fieldset
     *
     * @param ContainerInterface $container
     * @param string $requestedName
     * @param array|null $options
     * @return CibleEvenementApplicationFieldset|object
     */
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        /** @var CibleEvenementApplicationFieldset $fieldset */
        $fieldset = new CibleEvenementApplicationFieldset('cibleEvenementApplication');

        /** @var EntityManager $entityManager */
        $entityManager = $container->get(EntityManager::class);
        $fieldset->setEntityManager($entityManager);

        /** @var CibleEvenementApplicationHydrator $hydrator */
        $hydrator = $container->get('HydratorManager')->get(CibleEvenementApplicationHydrator::class);
        $fieldset->setHydrator($hydrator);
        $fieldset->setObject(new CibleEvenementApplication());
        return $fieldset;
    }
}
