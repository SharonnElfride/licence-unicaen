<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace MeteoSI\Controller\Evenement\Factory;

use Interop\Container\ContainerInterface;
use Laminas\ServiceManager\Factory\FactoryInterface;
use MeteoSI\Controller\Evenement\EvenementController;
use MeteoSI\Form\Evenement\Form\AddEditEvenementForm;
use MeteoSI\Form\Evenement\Form\ClotureEvenementForm;
use MeteoSI\Form\Evenement\Form\ReOpenEvenementForm;
use MeteoSI\MeteoSI\Service\Mailing\MailService;
use MeteoSI\Service\CategorieEvenement\CategorieEvenementService;
use MeteoSI\Service\CibleEvenement\CibleEvenementService;
use MeteoSI\Service\CibleEvenement\Dependance\EtatCible\EtatCibleService;
use MeteoSI\Service\Evenement\EvenementService;
use MeteoSI\View\Helper\Calendar\CalendarViewHelper;

class EvenementControllerFactory implements FactoryInterface
{
    public function __invoke(ContainerInterface $container, $requestedName, ?array $options = null)
    {
        /** @var EvenementController $controller */
        $controller = new EvenementController();

        /** @var EvenementService $entityService */
        $entityService = $container->get('ServiceManager')->get(EvenementService::class);
        $controller->setEvenementService($entityService);

        /** @var AddEditEvenementForm $evenementForm */
        $evenementForm = $container->get('FormElementManager')->get(AddEditEvenementForm::class);
        $controller->setEvenementForm($evenementForm);

        /** @var ClotureEvenementForm $evenementClotureForm */
        $evenementClotureForm = $container->get('FormElementManager')->get(ClotureEvenementForm::class);
        $controller->setClotureEvenementForm($evenementClotureForm);

        /** @var ReOpenEvenementForm $evenementReOpenForm */
        $evenementReOpenForm = $container->get('FormElementManager')->get(ReOpenEvenementForm::class);
        $controller->setReOpenEvenementForm($evenementReOpenForm);

        /** @var MailService $mailService */
        $mailService = $container->get(MailService::class);
        $controller->setMailService($mailService);

        /** @var EtatCibleService $etatCibleService */
        $etatCibleService = $container->get('ServiceManager')->get(EtatCibleService::class);
        $controller->setEtatCibleService($etatCibleService);

        /** @var CategorieEvenementService $categorieEvenementService */
        $categorieEvenementService = $container->get(CategorieEvenementService::class);
        $controller->setCategorieService($categorieEvenementService);

        $userContextService = $container->get('UnicaenAuthentification\Service\UserContext');
        $controller->setServiceUserContext($userContextService);

        $config = $container->get('config');
        $days = $config['unicaen-calendar']['days'];
        $months = $config['unicaen-calendar']['months'];
        $controller->setDays($days);
        $controller->setMonths($months);

        return $controller;
    }
}
