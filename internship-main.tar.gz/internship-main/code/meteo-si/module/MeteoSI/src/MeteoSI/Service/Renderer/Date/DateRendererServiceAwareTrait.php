<?php

namespace MeteoSI\Service\Renderer\Date;

trait DateRendererServiceAwareTrait {

    /** @var DateRendererService */
    private $dateRendererService;

    /**
     * @return DateRendererService
     */
    public function getDateRendererService(): DateRendererService
    {
        return $this->dateRendererService;
    }

    /**
     * @param DateRendererService $dateRendererService
     * @return DateRendererService
     */
    public function setDateRendererService(DateRendererService $dateRendererService): DateRendererService
    {
        $this->dateRendererService = $dateRendererService;
        return $this->dateRendererService;
    }
}
