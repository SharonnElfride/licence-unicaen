<?php

namespace MeteoSI\Form\CibleEvenement\CibleService;

use Application\Application\Form\AbstractEntityFieldset;
use DoctrineModule\Form\Element\ObjectSelect;
use Laminas\Filter\StringTrim;
use Laminas\Filter\StripTags;
use Laminas\Filter\ToInt;
use Laminas\Filter\ToNull;
use Laminas\Form\Element\Number;
use Laminas\Form\Element\Text;
use Laminas\Form\Element\Textarea;
use Laminas\InputFilter\InputFilterProviderInterface;
use Laminas\Validator\StringLength;
use MeteoSI\Form\CibleEvenement\Cible\CibleEvenementFieldset;
use MeteoSI\Model\CategorieCible;
use MeteoSI\Model\EtatCible;

/**
 * Class CibleEvenementServiceFieldset
 */
class CibleEvenementServiceFieldset extends CibleEvenementFieldset
{

    public function init()
    {
        parent::init();

        $this->add([
            'name' => 'details',
            'type' => Textarea::class,
            'options' => [
//                'label' => "Details sur le service",
            ],
            'attributes' => [
                'id' => 'detailsService',
                'rows' => 2,
                'placeholder' => 'Détails sur le service',
            ],
        ]);
    }

    public function getInputFilterSpecification()
    {
        $inputFilter = parent::getInputFilterSpecification();

        $inputFilter['details'] = [
            'name' => 'details',
            'required' => false,
            'filters' => [
//                ['name' => StripTags::class],
                ['name' => StringTrim::class],
            ],
            'validators' => [
                [
                    'name' => StringLength::class,
                    'options' => [
                        'encoding' => 'UTF-8',
                        'min' => 1,
                    ],
                ],
            ],
        ];

        return $inputFilter;
    }
}
