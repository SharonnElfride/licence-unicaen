<?php

namespace MeteoSI\Form\Evenement\Factory\Form;

use Doctrine\ORM\EntityManager;
use Interop\Container\ContainerInterface;
use Laminas\ServiceManager\Factory\FactoryInterface;
use Laminas\View\HelperPluginManager;
use MeteoSI\Form\Evenement\Form\AddEditEvenementForm;
use MeteoSI\Form\Evenement\Form\ReOpenEvenementForm;
use MeteoSI\Form\Evenement\Hydrator\ReOpenEvenementHydrator;

/**
 * Class ReOpenEvenementFormFactory
 */
class ReOpenEvenementFormFactory implements FactoryInterface
{
    /**
     * Create fieldset
     *
     * @param ContainerInterface $container
     * @param string $requestedName
     * @param array|null $options
     * @return ReOpenEvenementForm|object
     */
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        /** @var ReOpenEvenementForm $form */
        $form = new ReOpenEvenementForm();

        /** @var EntityManager $entityManager */
        $entityManager = $container->get(EntityManager::class);
        $form->setEntityManager($entityManager);


        /** @var HelperPluginManager $viewHelperManager */
        $viewHelperManager = $container->get('ViewHelperManager');
        $form->setViewHelperManager($viewHelperManager);

        /** @var ReOpenEvenementHydrator $hydrator */
        $hydrator = $container->get('HydratorManager')->get(ReOpenEvenementHydrator::class);
        $form->setHydrator($hydrator);

        return $form;
    }
}
