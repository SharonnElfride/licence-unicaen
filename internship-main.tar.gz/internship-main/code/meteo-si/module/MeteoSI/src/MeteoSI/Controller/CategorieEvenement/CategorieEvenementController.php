<?php

namespace MeteoSI\Controller\CategorieEvenement;

use MeteoSI\Form\CategorieEvenement\Traits\CategorieEvenementFormTrait;
use MeteoSI\Model\CategorieEvenement;
use Application\Application\Misc\RouterToolsTrait;
use Doctrine\ORM\OptimisticLockException;
use Doctrine\ORM\ORMException;
use Laminas\Mvc\Controller\AbstractActionController;
use Laminas\View\Model\ViewModel;
use MeteoSI\Service\CategorieEvenement\CategorieEvenementServiceAwareTrait;

class CategorieEvenementController extends AbstractActionController
{

    use CategorieEvenementServiceAwareTrait;
    use CategorieEvenementFormTrait;
    use RouterToolsTrait;

    public function indexAction()
    {
        return new ViewModel([
            'categories' => $this->getCategorieService()->findAll(),
        ]);
    }

    public function showAction() {
        $id = $this->getParamFromRoute('id');
        $categorie = $this->getCategorieService()->find($id);

        return new ViewModel([
            'categorie' => $categorie,
        ]);
    }

    /**
     * @throws OptimisticLockException
     * @throws ORMException
     */
    public function addAction()
    {
        $categorie = new CategorieEvenement();
        $form = $this->getCategorieForm();
        $form->bind($categorie);
        $form->get('submit')->setValue('Ajouter');
        $request = $this->getRequest();

        if (!$request->isPost()) {
            return new ViewModel(['form' => $form]);
        }

        $form->setData($request->getPost());

        if (!$form->isValid()) {
            //If the form is not valid, we'll render/redisplay the same form with the wrong data in the concerned fields with the 'why' they are wrong
            return ['form' => $form];
        }

        $categorie = $form->getObject();
        $this->getCategorieService()->add($categorie);
        $this->flashMessenger()->addSuccessMessage('La catégorie ' . $categorie->getLibelle() . ' a bien été créée!');
        return $this->redirect()->toRoute('categorie-evenement', ['action' => 'index' ]);
    }

    /**
     * @throws OptimisticLockException
     * @throws ORMException
     */
    public function editAction()
    {
        $id = $this->getParamFromRoute('id');
        $categorie = $this->getCategorieService()->find($id);
        $form = $this->getCategorieForm();
        $form->bind($categorie);
        $form->get('submit')->setValue('Enrégistrer');
        $request = $this->getRequest();

        $title = "Modification de la catégorie d'événement " . $categorie->getLibelle();
        $form->getEntityFieldset()->getCodeValidator()->setEntite($categorie);

        if (!$request->isPost()) {
            return new ViewModel(['form' => $form, 'categorie' => $categorie, 'title' => $title]);
        }

        $form->setData($request->getPost());

        if (!$form->isValid()) {
            //If the form is not valid, we'll render/redisplay the same form with the wrong data in the concerned fields with the 'why' they are wrong
            return ['form' => $form, 'categorie' => $categorie, 'title' => $title];
        }

        $categorie = $form->getObject();
        $this->getCategorieService()->update($categorie);
        $this->flashMessenger()->addSuccessMessage('La catégorie ' . $categorie->getLibelle() . ' a bien été modifiée!');
        return $this->redirect()->toRoute('categorie-evenement', ['action' => 'show', 'id' => $id ]);
    }

    /**
     * @throws OptimisticLockException
     * @throws ORMException
     */
    public function deleteAction()
    {
        $id = $this->getParamFromRoute('id');
        /** @var CategorieEvenement $categorie */
        $categorie = $this->getCategorieService()->find($id);
        $libelle = $categorie->getLibelle();
        $nbIntervs = $categorie->getEvenements();

        $request = $this->getRequest();

        if($request->isPost()) {
            $del = $request->getPost('del', 'Non');

            if($del === 'Oui') {
                $this->getCategorieService()->delete($categorie);
                if(sizeof($nbIntervs) !== 0)
                    $this->flashMessenger()->addWarningMessage("Il y avait des événements de catégorie " . $libelle . "! Si ce n'était pas une erreur, veuillez ignorer ce message!");
                $this->flashMessenger()->addSuccessMessage('La catégorie ' . $libelle . ' a bien été supprimée!');
            }

            return $this->redirect()->toRoute('categorie-evenement', ['action' => 'index']);
        }

        return new ViewModel(["categorie" => $categorie]);

//        if ($categorie !== null) {
//            $vm->setTemplate('unicaen-mail/default/confirmation');
//            $vm->setVariables([
//                'title' => "Suppression du mail #" . $categorie->getId(),
//                'text' => "Are you sure that you want to delete '" . $categorie->getTitle() . "' by '" . $categorie->getArtist() . "' ?",
//                'action' => $this->url()->fromRoute('categorie-evenement', ["action" => "delete", "id" => $categorie->getId()], [], true),
//            ]);
//        }
//        return $vm;
    }

}
