<?php

namespace MeteoSI\Form\CibleEvenement\CibleGroupe\Hydrator;

use DateTime;
use Doctrine\ORM\OptimisticLockException;
use Doctrine\ORM\ORMException;
use Exception;
use Laminas\Hydrator\AbstractHydrator;
use Laminas\Hydrator\HydratorInterface;
use MeteoSI\Model\CibleEvenement;
use MeteoSI\Model\CibleEvenementGroupe;
use MeteoSI\Model\EtatCible;
use UnicaenApp\Service\EntityManagerAwareTrait;

class CibleEvenementGroupeHydrator extends AbstractHydrator implements HydratorInterface
{
    use EntityManagerAwareTrait;

    /**
     * Converts the given value so that it can be extracted by the hydrator.
     *
     * @param CibleEvenementGroupe $entity (optional) The original object for context.     *
     * @throws ORMException
     * @throws OptimisticLockException
     * @return array Returns the value that should be extracted.
     */
    public function extract($entity): array
    {
        //Avoir la date de début pré-remplie en considérant que l'événement s'effectue maintenant
        if($entity->getDateCreation() === null) {
            $entity->setDateCreation(new DateTime());
        }

        if($entity->getEtat() === null) {
            /** @var EtatCible $etat */
            $etat = $this->getEntityManager()->find(EtatCible::class, 1);
            $entity->setGroupState($etat);
        }



        $results = [
            "code" => $entity->getCode(),
            "libelle" => $entity->getLibelle(),
            "description" => $entity->getDescription(),
            "etat" => $entity->getEtat(),
            "codeSource" => $entity->getCodeSource(),
            "idSource" => $entity->getIdSource(),
            "dateCreation" => $entity->getDateCreation(),
            //"cible" => $entity->getCibles()->get(0),
        ];

        return $results;
    }

    /**
     * Hydrate $object with the provided $data.
     *
     * @param CibleEvenementGroupe $entity The original value.
     * @param array $data (optional) The original data for context.
     * @return CibleEvenementGroupe Returns the value that should be hydrated.
     * @throws Exception
     */
    public function hydrate(array $data, $entity)
    {
        $idEtat = ($data['etat']) ?? 0;
        $idCible = ($data['cible']) ?? 0;

        $libelle = ($data['libelle']) ?? '';
        $desciption = ($data['description']) ?? '';

        /** @var EtatCible $etat */
        $etat = $this->getEntityManager()->getRepository(EtatCible::class)->find($idEtat);

        /** @var CibleEvenement $cible */
        $cible = $this->getEntityManager()->getRepository(CibleEvenement::class)->find($idCible);

        $code = ($data['code']) ?? '';
        $codeSource = ($data['codeSource']) ?? '';
        $idSource = ($data['idSource']) ?? '';

        //Date de création
        $dateCreation = new DateTime();
        if (isset($data['dateCreation']))
            $dateCreation = new DateTime($data['dateCreation']);

        //Le passage des valeurs récupérées par le form
        $entity->setCode($code);
        //$entity->addCible($cible);

        $entity->setLibelle($libelle);
        $entity->setDescription($desciption);
        $entity->setGroupState($etat);
        $entity->setCodeSource($codeSource);
        $entity->setIdSource($idSource);
        $entity->setDateCreation($dateCreation);

        return $entity;
    }
}