<?php

namespace MeteoSI\Model;

use DateTime;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use http\Exception\RuntimeException;
use Laminas\Permissions\Acl\Resource\ResourceInterface;
use MeteoSI\Model\Interfaces\CibleEvenementInterface;
use Mpdf\Tag\A;

class CibleEvenement implements ResourceInterface, CibleEvenementInterface
{
    const RESOURCE_ID = 'CibleEvenement';

    /**
     *  L'identifiant de la cible
     * @var int $id
     */
    private $id;

    /**
     *  Le libelle de la cible
     * @var string $libelle
     */
    private $libelle;

    /**
     *  La description de la cible
     * @var string $description
     */
    private $description;

    /**
     *  La catégorie de la cible
     * @var CategorieCible $categorieCible
     */
    private $categorieCible;

    /** @var string $categorieLibelle */
    private $categorieLibelle;

    /**
     * @var EtatCible $etat
     */
    private $etat;

    /**
     *  Le code source de la cible
     * @var string $codeSource
     */
    private $codeSource;

    /**
     *  L'identifiant source de la cible
     * @var int $idSource
     */
    private $idSource;

    /**
     *  La date de création de la cible
     * @var DateTime $dateCreation
     */
    private $dateCreation;

    /**
     *  La date de modification de la cible
     * @var DateTime $dateModification
     */
    private $dateModification;

    /** @var Collection $appli */
    private $appli;

    /** @var Collection $bdd */
    private $bdd;

    /** @var Collection $infra */
    private $infra;

    /** @var Collection $service */
    private $service;

    /**
     * Liste des dépendances dans lesquelles je suis enfant
     * @var ArrayCollection|CibleDependance[] $dependanceParents
     */
    private $dependanceParents;

    /**
     * Liste des dépendances dans lesquelles je suis parent
     * @var ArrayCollection|CibleDependance[] $dependanceEnfants */
    private $dependanceEnfants;

    /**
     *  La liste des événements dont cette entité est la cible
     * @var ArrayCollection|Evenement[] $evenements
     */
    private $evenements;

    /** @var CibleEvenementGroupe $groupeEvenement */
    private $groupeEvenement;

    /**
     *  La liste des groupes de la cible
     * @var ArrayCollection|CibleEvenementGroupe[] $groupes
     */
    private $groupes;

    /** @var CibleDependance $dependencyToAdd */
    private $dependencyToAdd;

    /** @var EtatCible $givenStateByEvenement */
    private $givenStateByEvenement;

    /**
     * Constructeur permettant d'initialiser la liste des cibles enfants, des cibles parents et des événements
     */
    public function __construct()
    {
        $this->evenements = new ArrayCollection();
        $this->groupes = new ArrayCollection();
        $this->dependanceParents = new ArrayCollection();
        $this->dependanceEnfants = new ArrayCollection();
    }

    /**
     * Retourne l'identifiant de la ressource sous forme de chaîne de caractères
     *
     * @return string
     */
    public function getResourceId(): string
    {
        return self::RESOURCE_ID;
    }

    /**
     * @return string|null
     */
    public function getCategorieLibelle()
    {
        return $this->categorieCible->getLibelle();
    }

    /**
     * @return CibleDependance
     */
    public function getDependencyToAdd(): CibleDependance
    {
        return $this->dependencyToAdd;
    }

    /**
     * @return EtatCible|null
     */
    public function getGivenStateByEvenement()
    {
        return $this->givenStateByEvenement;
    }

    /**
     * @param EtatCible $givenStateByEvenement
     */
    public function setGivenStateByEvenement(EtatCible $givenStateByEvenement): void
    {
        $this->givenStateByEvenement = $givenStateByEvenement;
        $this->changeStateByTransitionRule();

        if($this->getCategorieEntite() instanceof CibleEvenementGroupe) {
            /** @var CibleEvenementGroupe $groupe */
            $groupe = $this->getCategorieEntite();

            foreach ($groupe->getCibles() as $c) {
                $c->setGivenStateByEvenement($givenStateByEvenement);
            }
        }
    }

    /**
     * @param CibleDependance $dependencyToAdd
     */
    public function setDependencyToAdd(CibleDependance $dependencyToAdd): void
    {
        $this->dependencyToAdd = $dependencyToAdd;
    }

// Function managing the target's state
    public function changeStateByTransitionRule(EtatCible $etatNewParent = null)
    {
        $etatFinal = $this->etat;
        /** @var ArrayCollection|EtatCible[] $childStatesFromDep */
        $childStatesFromDep = new ArrayCollection();

        foreach ($this->getDependanceParents() as $depP):
            $idEtatP = $depP->getParent()->getEtat()->getId();
            $etatE = null;

            foreach ($depP->getRegleTransitions() as $regleT):
                if ($idEtatP === $regleT->getEtatParent()->getId())
                    $etatE = $regleT->getEtatEnfant();
            endforeach;

            if (!$childStatesFromDep->contains($etatE))
                $childStatesFromDep->add($etatE);
        endforeach;

        //Sorting for having the worst state at the first position in the tab
        $childStates = [];
        for ($i = 0 ; $i < sizeof($childStatesFromDep) ; $i++):
            $childStates[$i] = $childStatesFromDep->get($i);
        endfor;

        usort($childStates, function (EtatCible $a, EtatCible $b){
            return $a->getGroupePriorite()->getNiveauGravite() < $b->getGroupePriorite()->getNiveauGravite();
        });

        $stateI = $this->givenStateByEvenement;
        /** @var EtatCible $worstState */
        $worstState = $childStates[0];
        if($etatNewParent !== null) {
            if($worstState !== null)
                $worstState = ($childStates[0]->getGroupePriorite()->getNiveauGravite() > $etatNewParent->getGroupePriorite()->getNiveauGravite()) ? $childStates[0] : $etatNewParent;
            else
                $worstState = $etatNewParent;
        }

        if (sizeof($childStates) !== 0) {
            if($stateI !== null) {
                if($stateI->getGroupePriorite()->getNiveauGravite() > $worstState->getGroupePriorite()->getNiveauGravite()) {
                        $etatFinal = $stateI;
                }
                else if($worstState->getGroupePriorite()->getNiveauGravite() >= $stateI->getGroupePriorite()->getNiveauGravite()) {
                        $etatFinal = $worstState;
                }
            }
            else {
                $etatFinal = $worstState;
            }
        }
        else {
            if($stateI !== null) {
                $etatFinal = $stateI;
            }
        }

        $this->setEtat($etatFinal);
    }

// Différents types de cibles d'événement
    /**
     * @return CibleEvenementApplication|null
     */
    public function getAppli()
    {
        return $this->appli->get(0);
    }

    /**
     * @param CibleEvenementApplication $appli
     * @return void
     */
    public function setAppli(CibleEvenementApplication $appli):void
    {
        $this->appli = new ArrayCollection();
        $this->appli->set(0, $appli);
    }

    /**
     * @return CibleEvenementBdd|null
     */
    public function getBdd()
    {
        return $this->bdd->get(0);
    }

    /**
     * @param CibleEvenementBdd $bdd
     * @return void
     */
    public function setBdd(CibleEvenementBdd $bdd):void
    {
        $this->bdd = new ArrayCollection();
        $this->bdd->set(0, $bdd);
    }

    /**
     * @return CibleEvenementInfra|null
     */
    public function getInfra()
    {
        return $this->infra->get(0);
    }

    /**
     * @param CibleEvenementInfra $infra
     * @return void
     */
    public function setInfra(CibleEvenementInfra $infra):void
    {
        $this->infra = new ArrayCollection();
        $this->infra->set(0, $infra);
    }

    /**
     * @return CibleEvenementService|null
     */
    public function getService()
    {
        return $this->service->get(0);
    }

    /**
     * @param CibleEvenementService $service
     * @return void
     */
    public function setService(CibleEvenementService $service): void
    {
        $this->service = new ArrayCollection();
        $this->service->set(0, $service);
    }

    /**
     * @return CibleEvenementGroupe|null
     */
    public function getGroupeEvenement()
    {
        return $this->groupeEvenement;
    }

    /**
     * @param CibleEvenementGroupe|null $groupeEvenement
     */
    public function setGroupeEvenement(?CibleEvenementGroupe $groupeEvenement): void
    {
        $this->groupeEvenement = $groupeEvenement;
    }

//Renvoie la cible de catégorie qui existe

    /**
     * @return CibleEvenementInterface|void
     */
    public function getCategorieEntite()
    {
        if($this->getAppli() !== null)
            return $this->getAppli();
        elseif($this->getBdd() !== null)
            return $this->getBdd();
        elseif($this->getInfra() !== null)
            return $this->getInfra();
        elseif($this->getService() !== null)
            return $this->getService();
        elseif($this->getGroupeEvenement() !== null)
            return $this->getGroupeEvenement();
        else
            throw new RuntimeException("Aucune cible correspondante.");
    }

// Parents
    /**
     * @return ArrayCollection|CibleEvenement[]
     */
    public function getParents()
    {
        $parents = new ArrayCollection();
        foreach ($this->dependanceParents as $dep):
            $parents->add($dep->getParent());
        endforeach;

        return $parents;
    }

    /**
     * @return ArrayCollection|CibleDependance[]
     */
    public function getDependanceParents()
    {
        return $this->dependanceParents;
    }

// Enfants
    /**
     * @return ArrayCollection|CibleEvenement[]
     */
    public function getEnfants()
    {
        $enfants = new ArrayCollection();
        foreach ($this->dependanceEnfants as $dep):
            $enfants->add($dep->getEnfant());
        endforeach;

        return $enfants;
    }

    /**
     * @return ArrayCollection|CibleDependance[]
     */
    public function getDependanceEnfants()
    {
        return $this->dependanceEnfants;
    }

// Evenements
    /**
     *  Ajout d'un événement à la liste des événements de la cible
     * @param Evenement $evenement
     * @return void
     */
    public function addEvenement(Evenement $evenement): void
    {
        $this->evenements->add($evenement);
    }

    /**
     *  Suppression d'un événement de la liste des événements de la cible
     * @param Evenement $evenement
     * @return void
     */
    public function removeEvenement(Evenement $evenement): void
    {
        $this->evenements->removeElement($evenement);
    }

    /**
     *  Supprime toutes les événements de la cible
     * @return void
     */
    public function removeAllEvenements(): void
    {
        $this->evenements->clear();
    }

    /**
     * @return ArrayCollection|Evenement[]
     */
    public function getEvenements()
    {
        return $this->evenements;
    }

// Groupes
    /**
     *  Ajout d'un groupe à la liste des groupes de la cible
     * @param CibleEvenementGroupe $groupe
     * @return void
     */
    public function addGroupe(CibleEvenementGroupe $groupe): void
    {
        $this->groupes->add($groupe);
    }

    /**
     *  Suppression d'un groupe de la liste des groupes de la cible
     * @param CibleEvenementGroupe $groupe
     * @return void
     */
    public function removeGroupe(CibleEvenementGroupe $groupe): void
    {
        $this->groupes->removeElement($groupe);
    }

    /**
     *  Supprime toutes les groupes de la cible
     * @return void
     */
    public function removeAllGroupes(): void
    {
        $this->groupes->clear();
    }

    /**
     * @return ArrayCollection|CibleEvenementGroupe[]
     */
    public function getGroupes()
    {
        return $this->groupes;
    }

//GETTERS AND SETTERS
    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /** @return string|null */
    public function getLibelle()
    {
        return $this->libelle;
    }

    /** @return string|null */
    public function getDescription()
    {
        return $this->description;
    }

    /** @return CategorieCible|null */
    public function getCategorieCible()
    {
        return $this->categorieCible;
    }

    /** @return EtatCible|null */
    public function getEtat()
    {
        return $this->etat;
    }

    /** @return string|null */
    public function getCodeSource()
    {
        return $this->codeSource;
    }

    /** @return int|null */
    public function getIdSource()
    {
        return $this->idSource;
    }

    /** @return DateTime|null */
    public function getDateCreation()
    {
        return $this->dateCreation;
    }

    /** @return DateTime|null */
    public function getDateModification()
    {
        return $this->dateModification;
    }

    /**
     * @param int $id
     * @return void
     */
    public function setId(int $id): void
    {
        $this->id = $id;
    }

    /**
     * @param string $libelle
     * @return void
     */
    public function setLibelle(string $libelle): void
    {
        $this->libelle = $libelle;
    }

    /**
     * @param string|null $description
     * @return void
     */
    public function setDescription(?string $description): void
    {
        $this->description = $description;
    }

    /**
     * @param CategorieCible $categorieCible
     * @return void
     */
    public function setCategorieCible(CategorieCible $categorieCible): void
    {
        $this->categorieCible = $categorieCible;
    }

    /**
     * @param EtatCible|null $etat
     * @return void
     */
    public function setEtat(?EtatCible $etat): void
    {
        $this->etat = $etat;
        foreach ($this->getEnfants() as $child) {
            $child->changeStateByTransitionRule();
        }

        foreach ($this->getGroupes() as $groupe) {
            $groupe->getGroupStateByItsTargets();
        }
    }

    /**
     * @param string|null $codeSource
     * @return void
     */
    public function setCodeSource(?string $codeSource): void
    {
        $this->codeSource = $codeSource;
    }

    /**
     * @param int|null $idSource
     * @return void
     */
    public function setIdSource(?int $idSource): void
    {
        $this->idSource = $idSource;
    }

    /**
     * @param DateTime $dateCreation
     * @return void
     */
    public function setDateCreation(DateTime $dateCreation): void
    {
        $this->dateCreation = $dateCreation;
    }

    /**
     * @param DateTime $dateModification
     * @return void
     */
    public function setDateModification(DateTime $dateModification): void
    {
        $this->dateModification = $dateModification;
    }
}
