<?php

namespace MeteoSI\Service\Renderer\Date;

use DateInterval;
use DateTime;
use MeteoSI\Model\Evenement;

class DateRendererService
{

    /** @var array */
    protected $variables;

    /**
     * @param array $variables
     * @return DateRendererService
     */
    public function setVariables(array $variables): DateRendererService
    {
        $this->variables = $variables;
        return $this;
    }

    /**
     * @param string
     * @return mixed
     */
    public function getVariable(string $key)
    {
        if (!isset($this->variables[$key])) return null;
        return $this->variables[$key];
    }

    public function formatDateTime(DateTime $date): string
    {
        return $date->format('d/m/Y à H:i');
    }

    public function formatDate(DateTime $date): string
    {
        return $date->format('d/m/Y');
    }

    public function formatTime(DateTime $date): string
    {
        return $date->format('H:i');
    }

    public function formatAnnee(DateTime $date): string
    {
        return $date->format('Y');
    }

    public function formatDuree(DateInterval $date):string
    {
        return $date->format('%d j %h h et %i min(s)');
    }


    /** Evenement */
    public function getDateDebutEvenement(): ?string
    {
        /** @var Evenement $evenement */
        $evenement = $this->getVariable('evenement');
        if ($evenement === null) return null;
        return $this->formatDateTime($evenement->getDateDebut());
    }

    /** Evenement */
    public function getDureePrevueEvenement(): ?string
    {
        /** @var Evenement $evenement */
        $evenement = $this->getVariable('evenement');
        if ($evenement === null) return null;

        $result = null;
        if($evenement->getDureeInconnue()):
            return "Durée Inconnue";
        elseif(($evenement->getDateFinEstimee() !== null) && ($evenement->getDateFinMinimale() !== null)):
            $dureeEstimee = (date_diff($evenement->getDateDebut(), $evenement->getDateFinEstimee()));
            $dureeMinimale = (date_diff($evenement->getDateDebut(), $evenement->getDateFinMinimale()));
            $result = "Durée estimée: <br/>" . $this->formatDuree($dureeEstimee) . "<br/> Durée minimale: <br/>" . $this->formatDuree($dureeMinimale);
        elseif(($evenement->getDateFinEstimee() !== null) && ($evenement->getDateFinMinimale() === null)):
            $dureeEstimee = (date_diff($evenement->getDateDebut(), $evenement->getDateFinEstimee()));
            $result = "Durée estimée: <br/>" . $this->formatDuree($dureeEstimee);
        elseif(($evenement->getDateFinEstimee() === null) && ($evenement->getDateFinMinimale() !== null)):
            $dureeMinimale = (date_diff($evenement->getDateDebut(), $evenement->getDateFinMinimale()));
            $result = "Durée minimale: <br/>" . $this->formatDuree($dureeMinimale);
        endif;
        return $result;
    }

    /** Evenement */
    public function getFinReelleEvenement(): ?string
    {
        /** @var Evenement $evenement */
        $evenement = $this->getVariable('evenement');
        if ($evenement === null) return null;
        return $this->formatDateTime($evenement->getDateFinReelle());
    }

    /** Evenement */
    public function getDateCreationEvenement(): ?string
    {
        /** @var Evenement $evenement */
        $evenement = $this->getVariable('evenement');
        if ($evenement === null) return null;
        return $this->formatDateTime($evenement->getHistoCreation());
    }

    /** Evenement */
    public function getDateModificationEvenement(): ?string
    {
        /** @var Evenement $evenement */
        $evenement = $this->getVariable('evenement');
        if ($evenement === null) return null;
        return $this->formatDateTime($evenement->getHistoModification());
    }

    public function getDateFinMailRappel(): ?string
    {
        /** @var Evenement $evenement */
        $evenement = $this->getVariable('evenement');
        if ($evenement === null) return null;

        $result = "la date de fin ";
        if($evenement->getDateFinMinimale() !== null)
            $result .= "au plus tôt au <span class='fw-bold'>" . $this->formatDateTime($evenement->getDateFinMinimale()) . "</span>";
        else
            $result .= "estimée au <span class='fw-bold'>" . $this->formatDateTime($evenement->getDateFinEstimee()) . "</span>";

        return $result;
    }
}