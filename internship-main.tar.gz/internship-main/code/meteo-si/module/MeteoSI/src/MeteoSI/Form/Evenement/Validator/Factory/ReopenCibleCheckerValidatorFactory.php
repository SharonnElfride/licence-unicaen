<?php

namespace MeteoSI\Form\Evenement\Validator\Factory;

use Interop\Container\Containerinterface;
use Laminas\ServiceManager\Factory\FactoryInterface;
use MeteoSI\Form\Evenement\Validator\ReopenCibleCheckerValidator;

/**
 * Classe ReopenCibleCheckerValidatorFactory
 */
class ReopenCibleCheckerValidatorFactory implements FactoryInterface
{
    /**
     * Create fieldset
     *
     * @param ContainerInterface $container
     * @param string $requestedName
     * @param array|null $options
     * @return ReopenCibleCheckerValidator
     */
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        /** @var ReopenCibleCheckerValidator $validator */
        $validator = new ReopenCibleCheckerValidator();

        return $validator;
    }
}