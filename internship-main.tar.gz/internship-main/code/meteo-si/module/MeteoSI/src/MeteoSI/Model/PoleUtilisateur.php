<?php

namespace MeteoSI\Model;

use Doctrine\Common\Collections\ArrayCollection;
use Laminas\Permissions\Acl\Resource\ResourceInterface;

class PoleUtilisateur implements ResourceInterface
{
    const RESOURCE_ID = 'PoleUtilisateur';

    /** @var int $id */
    private $id;

    /** @var string $code */
    private $code;

    /** @var string $libelle */
    private $libelle;

    /** @var ArrayCollection|Evenement[] */
    private $evenements;

    /**
     * Returns the string identifier of the Resource
     *
     * @return string
     */
    public function getResourceId()
    {
        return self::RESOURCE_ID;
    }

//Evenements

    /**
     * @return ArrayCollection|Evenement[]
     */
    public function getEvenements()
    {
        return $this->evenements;
    }

    /**
     *  Ajout d'un événement à la liste des événements de la cible
     * @param Evenement $evenement
     * @return void
     */
    public function addEvenement(Evenement $evenement): void
    {
        $this->evenements->add($evenement);
    }

    /**
     *  Suppression d'un événement de la liste des événements de la cible
     * @param Evenement $evenement
     * @return void
     */
    public function removeEvenement(Evenement $evenement): void
    {
        $this->evenements->removeElement($evenement);
    }

    /**
     *  Supprime toutes les événements de la cible
     * @return void
     */
    public function removeAllEvenements(): void
    {
        $this->evenements->clear();
    }

//GETTERS AND SETTERS

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return string|null
     */
    public function getCode()
    {
        return $this->code;
    }

    /**
     * @return string|null
     */
    public function getLibelle()
    {
        return $this->libelle;
    }

// SETTERS

    /**
     * @param int|null $id
     */
    public function setId(?int $id): void
    {
        $this->id = $id;
    }

    /**
     * @param string|null $code
     */
    public function setCode(?string $code): void
    {
        $this->code = $code;
    }

    /**
     * @param string|null $libelle
     */
    public function setLibelle(?string $libelle): void
    {
        $this->libelle = $libelle;
    }
}