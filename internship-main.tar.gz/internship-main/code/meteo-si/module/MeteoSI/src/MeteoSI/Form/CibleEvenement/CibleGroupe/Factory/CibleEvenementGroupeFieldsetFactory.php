<?php

namespace MeteoSI\Form\CibleEvenement\CibleGroupe\Factory;

use Doctrine\Laminas\Hydrator\DoctrineObject;
use Doctrine\ORM\EntityManager;
use Interop\Container\ContainerInterface;
use Laminas\ServiceManager\Factory\FactoryInterface;
use Laminas\Validator\ValidatorPluginManager;
use MeteoSI\Form\CibleEvenement\Cible\Validator\StateEditValidator;
use MeteoSI\Form\CibleEvenement\CibleGroupe\CibleEvenementGroupeFieldset;
use MeteoSI\Form\CibleEvenement\CibleGroupe\Hydrator\CibleEvenementGroupeHydrator;
use MeteoSI\Form\Shared\Validator\CodeValidator;
use MeteoSI\Model\CibleEvenementGroupe;
use MeteoSI\Service\CibleEvenement\CibleGroupe\CibleEvenementGroupeService;

/**
 * Class CibleEvenementGroupeFieldsetFactory
 */
class CibleEvenementGroupeFieldsetFactory implements FactoryInterface
{
    /**
     * Create fieldset
     *
     * @param ContainerInterface $container
     * @param string $requestedName
     * @param array|null $options
     * @return CibleEvenementGroupeFieldset|object
     */
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        /** @var CibleEvenementGroupeFieldset $fieldset */
        $fieldset = new CibleEvenementGroupeFieldset('cibleEvenementGroupe');

        /** @var EntityManager $entityManager */
        $entityManager = $container->get(EntityManager::class);
        $fieldset->setEntityManager($entityManager);

        /** @var CodeValidator $codeValidator */
        $codeValidator = $container->get(ValidatorPluginManager::class)->get(CodeValidator::class);
        /** @var CibleEvenementGroupeService $entityService */
        $entityService = $container->get('ServiceManager')->get(CibleEvenementGroupeService::class);
        $codeValidator->setEntiteService($entityService);

        /** @var CibleEvenementGroupeHydrator $hydrator */
        $hydrator = $container->get('HydratorManager')->get(CibleEvenementGroupeHydrator::class);
        $fieldset->setHydrator($hydrator);
        $fieldset->setObject(new CibleEvenementGroupe());
        $codeValidator->setEntite($fieldset->getObject());

        $fieldset->setCodeValidator($codeValidator);
        return $fieldset;
    }
}
