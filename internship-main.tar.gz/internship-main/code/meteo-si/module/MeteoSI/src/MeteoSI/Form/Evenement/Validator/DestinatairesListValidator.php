<?php

namespace MeteoSI\Form\Evenement\Validator;

use Laminas\Validator\AbstractValidator;

/**
 * Classe DestinatairesListValidator
 */
class DestinatairesListValidator extends AbstractValidator
{
    const DESTINATAIRES_LIST_OBLIGATOIRE = 'DESTINATAIRES_LIST_OBLIGATOIRE';

    /**
     * @var array $messageTemplates
     */
    protected $messageTemplates = [
        self::DESTINATAIRES_LIST_OBLIGATOIRE => "Vous êtes dans l'obligation de renseigner au moins un destinataire.",
    ];

    public function setMessageTemplate($key, $value)
    {
        $this->messageTemplates[$key] = $value;
        $this->abstractOptions['messageTemplates'][$key] = $value;
    }

    /**
     * @var array
     */
    protected $messageVariables = [
    ];

    /**
     * Validation
     *
     * @param mixed $value
     * @param mixed $context Additional context to provide to the callback
     * @return bool
     */
    public function isValid($value, $context = null)
    {
        $envoiMail = $context['envoiMail'];
        $destinataires = $context['destinataires'];

        //Vérification du champ d'xplications si la durée est inconnue
        if ($envoiMail === '1') {
            if (isset($destinataires)) {
                if ($destinataires === '') {
                    $this->error(self::DESTINATAIRES_LIST_OBLIGATOIRE);
                    return false;
                }
            }
            else {
                $this->error(self::DESTINATAIRES_LIST_OBLIGATOIRE);
                return false;
            }
        }

        return true;
    }
}