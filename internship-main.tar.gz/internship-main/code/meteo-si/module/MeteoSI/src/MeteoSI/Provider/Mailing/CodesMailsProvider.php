<?php

namespace MeteoSI\Provider\Mailing;

/**
 * Contient la liste des codes pour les templates des mails automatiques
 * @package MeteoSI\Provider\Mailing
 */
class CodesMailsProvider
{
    const TEST = 'testtemplate';
    const NOUVEL_EVENEMENT = 'nouvel-evenement';
    const MODIFICATION_EVENEMENT = 'modification-evenement';
    const RE_OUVERTURE_EVENEMENT = 're-ouverture-evenement';
    const FIN_EVENEMENT = 'fin-evenement';
    const MAIL_D_ENREGISTREMENT_ENVOYE_AUX_CIBLES_ENFANTS = 'mail-d-enregistrement-envoye-aux-cibles-enfants';
    const MAIL_DE_FIN_ENVOYE_AUX_CIBLES_ENFANTS = 'mail-de-fin-envoye-aux-cibles-enfants';
    const MAIL_DE_MODIFICATION_ENVOYE_AUX_CIBLES_ENFANTS = 'mail-de-modification-envoye-aux-cibles-enfants';
    const MAIL_DE_REOUVERTURE_ENVOYE_AUX_CIBLES_ENFANTS = 'mail-de-reouverture-envoye-aux-cibles-enfants';
//    const SUPPRESSION_EVENEMENT = 'suppression-evenement'; -- TODO Lors de la suppression envoyé un mail de clôture
    const NOTIFICATION_DE_RAPPEL_AU_CREATEUR_D_UN_EVENEMENT_POUR_SA_CLOTURE = 'notification-de-rappel-au-createur-d-un-evenement-pour-sa-cloture';
    const TEST_FICHIER_PDF = 'test-test';
    const TEST_TEMPLATE_TEXTUEL = 'test-template-textuel';
}
