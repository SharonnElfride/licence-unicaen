<?php

namespace MeteoSI\Form\CategorieEvenement\Traits;

use MeteoSI\Form\CategorieEvenement\CategorieEvenementForm;

/**
 * Trait CategorieEvenementFormTrait
 * @package  MeteoSI\Form\CategorieEvenement\Traits;
 */
trait CategorieEvenementFormTrait
{
    /** @var CategorieEvenementForm */
    protected $categorieForm;

    /**
     * @return CategorieEvenementForm
     */
    public function getCategorieForm(): CategorieEvenementForm
    {
        return $this->categorieForm;
    }

    /**
     * @param CategorieEvenementForm $categorieForm
     */
    public function setCategorieForm(CategorieEvenementForm $categorieForm): void
    {
        $this->categorieForm = $categorieForm;
    }

}
