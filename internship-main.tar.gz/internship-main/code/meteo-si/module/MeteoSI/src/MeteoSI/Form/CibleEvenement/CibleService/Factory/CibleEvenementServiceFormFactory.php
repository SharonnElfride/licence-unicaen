<?php

namespace MeteoSI\Form\CibleEvenement\CibleService\Factory;

use Doctrine\Laminas\Hydrator\DoctrineObject;
use Doctrine\ORM\EntityManager;
use Interop\Container\ContainerInterface;
use Laminas\ServiceManager\Factory\FactoryInterface;
use Laminas\View\HelperPluginManager;
use MeteoSI\Form\CibleEvenement\CibleEvenementForm;
use MeteoSI\Form\CibleEvenement\CibleService\CibleEvenementServiceForm;
use MeteoSI\Form\CibleEvenement\CibleService\Hydrator\CibleEvenementServiceHydrator;

/**
 * Class CibleEvenementServiceFormFactory
 */
class CibleEvenementServiceFormFactory implements FactoryInterface
{
    /**
     * Create fieldset
     *
     * @param ContainerInterface $container
     * @param string $requestedName
     * @param array|null $options
     * @return CibleEvenementServiceForm|object
     */
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        /** @var CibleEvenementServiceForm $form */
        $form = new CibleEvenementServiceForm();

        /** @var EntityManager $entityManager */
        $entityManager = $container->get(EntityManager::class);
        $form->setEntityManager($entityManager);


        /** @var HelperPluginManager $viewHelperManager */
        $viewHelperManager = $container->get('ViewHelperManager');
        $form->setViewHelperManager($viewHelperManager);

        /** @var CibleEvenementServiceHydrator $hydrator */
        $hydrator = $container->get('HydratorManager')->get(CibleEvenementServiceHydrator::class);
        $form->setHydrator($hydrator);

        return $form;
    }
}
