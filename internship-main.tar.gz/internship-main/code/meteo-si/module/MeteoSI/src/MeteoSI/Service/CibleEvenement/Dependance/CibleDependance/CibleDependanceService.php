<?php

namespace MeteoSI\Service\CibleEvenement\Dependance\CibleDependance;

use Application\Application\Service\API\CommonEntityService;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\OptimisticLockException;
use Doctrine\ORM\ORMException;
use MeteoSI\Model\CibleDependance;

class CibleDependanceService extends CommonEntityService
{
    /** @return string */
    public function getEntityClass()
    {
        return CibleDependance::class;
    }

    //Retourne une nouvelle instance de l'entité courante
    public function getEntityInstance($name = null)
    {
        return $this->getEntityInstance($name);
    }

    //Add a new line to the table db
    /**
     * @var CibleDependance $entity
     *
     * @override
     * @throws ORMException
     * @throws OptimisticLockException
     */
    public function add($entity, $serviceEntityClass = null)
    {
        return parent::add($entity, $serviceEntityClass);
    }

    //Update a new line to the table db
    /**
     * @override
     * @throws ORMException
     * @throws OptimisticLockException
     */
    public function update($entity, $serviceEntityClass = null)
    {
        return parent::update($entity, $serviceEntityClass);
    }

    //Delete the table line indexed with the id=$id
    /**
     * @override
     * @throws ORMException
     * @throws OptimisticLockException
     */
    public function delete($entity, $serviceEntityClass = null)
    {
        return parent::delete($entity, $serviceEntityClass);
    }

    public function findAll()
    {
        return $this->findAllBy([], ["id" => "ASC"]);
    }
}