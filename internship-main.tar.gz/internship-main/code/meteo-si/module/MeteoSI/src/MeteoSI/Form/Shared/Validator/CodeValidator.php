<?php

namespace MeteoSI\Form\Shared\Validator;

use Application\Application\Service\API\CommonEntityService;
use Doctrine\ORM\NonUniqueResultException;
use Laminas\Validator\AbstractValidator;
use Laminas\Validator\Exception;
use RuntimeException;

class CodeValidator extends AbstractValidator
{
    const CODE_DEJA_UTILISE = 'CODE_DEJA_UTILISE';

    /** @var CommonEntityService $entityService */
    private $entityService;

    /** @var mixed|null $entity */
    private $entity;

    /**
     * @var array
     */
    protected $messageTemplates = [
        self::CODE_DEJA_UTILISE => "Ce code est déjà utilisé en base de donnée.",
    ];

    /**
     * @var array
     */
    protected $messageVariables = [
    ];

//GETTERS ET SETTERS
    /**
     * @param CommonEntityService $entityService
     * @return void
     */
    public function setEntiteService(CommonEntityService $entityService): void
    {
        $this->entityService = $entityService;
    }

    /**
     * @param mixed|null $entity
     * @return void
     */
    public function setEntite($entity): void
    {
        if($entity !== null) {
            if (method_exists($entity, 'getCode()')) {
                throw new RuntimeException("L'entité fournise doit implémentée la fonction getCode().");
            }
        }

        $this->entity = $entity;
    }

    /**
     * Returns true if and only if $value meets the validation requirements
     *
     * If $value fails validation, then this method returns false, and
     * getMessages() will return an array of messages that explain why the
     * validation failed.
     *
     * @param mixed $value
     * @return bool
     * @throws Exception\RuntimeException If validation of $value is impossible.
     * @throws NonUniqueResultException
     */
    public function isValid($value, $context = null)
    {
        $code = $value;

        if ($this->entityService === null) {
            throw new RuntimeException("Aucun service n'as été fournis pour déterminer si le code est valide.");
        }

        /** @var mixed $entityCorrespondante */
        $entityCorrespondante = $this->entityService->findByAttribute($value, 'code', false);

        if ($entityCorrespondante) {
            if($entityCorrespondante->getId() !== intval($this->entity->getId())) {
                $this->error(self::CODE_DEJA_UTILISE);
                return false;
            }
        }

        return true;
    }
}