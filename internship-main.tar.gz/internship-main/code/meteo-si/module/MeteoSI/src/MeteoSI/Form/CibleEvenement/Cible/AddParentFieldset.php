<?php

namespace MeteoSI\Form\CibleEvenement\Cible;

use Application\Application\Form\AbstractEntityFieldset;
use Doctrine\Common\Collections\ArrayCollection;
use DoctrineModule\Form\Element\ObjectSelect;
use Laminas\Filter\ToInt;
use Laminas\Filter\ToNull;
use Laminas\Form\Element\Select;
use Laminas\InputFilter\InputFilterProviderInterface;
use MeteoSI\Model\CibleDependancePriorite;
use MeteoSI\Model\CibleEvenement;
use MeteoSI\Model\CibleEvenementGroupe;

class AddParentFieldset extends AbstractEntityFieldset implements InputFilterProviderInterface
{
    /**
     * @param CibleEvenement $cibleRecu
     * @return void
     */
    public function setCibles(CibleEvenement $cibleRecu): void
    {
        //Query for getting all the targets ∉ the group
        $em = $this->getEntityManager();
        $gpComposantes = new ArrayCollection();

        $cibles = $em->getRepository(CibleEvenement::class)->findAll();
        $cibles = array_filter($cibles, function (CibleEvenement $c) use($cibleRecu, $gpComposantes) {
            if($cibleRecu->getParents()->contains($c) || $cibleRecu->getEnfants()->contains($c)):
                if($c->getCategorieEntite() instanceof CibleEvenementGroupe) {
                    foreach ($c->getCategorieEntite()->getCibles() as $gpC) {
                        $gpComposantes->add($gpC);
                    }
                }
            endif;

            if($cibleRecu->getCategorieEntite() instanceof CibleEvenementGroupe):
                return (
                    $c->getId() != $cibleRecu->getId())
                    && (!$cibleRecu->getCategorieEntite()->getCibles()->contains($c))
                    && (!$gpComposantes->contains($c))
                    && (!$cibleRecu->getParents()->contains($c))
                    && (!$cibleRecu->getEnfants()->contains($c)
                );
            endif;

            return ($c->getId() != $cibleRecu->getId()) && (!$cibleRecu->getParents()->contains($c)) && (!$cibleRecu->getEnfants()->contains($c) && (!$gpComposantes->contains($c)));
        });

        usort($cibles, function (CibleEvenement $c1, CibleEvenement $c2) {
            if($c1->getCategorieCible()->getId() == $c2->getCategorieCible()->getId())
                return strcmp($c1->getLibelle(), $c2->getLibelle());

            return strcmp($c1->getCategorieLibelle(), $c2->getCategorieLibelle());
        });

        $options = [];
        /** @var CibleEvenement $cible */
        foreach ($cibles as $cible):
            $options[$cible->getCategorieCible()->getCode()]['label'] = $cible->getCategorieLibelle();
            $options[$cible->getCategorieCible()->getCode()]['options'][$cible->getId()] = $cible->getLibelle();
        endforeach;

        $this->get('cible')->setValueOptions($options);
    }

    public function init()
    {
        $this->add([
            'name' => 'id',
            'type' => 'hidden',
        ]);

        $this->add([
            'type' => Select::class,
            'name' => 'cible',
            'options' => [
//                'label' => "Cible à ajouter comme parent",
                'empty_option' => 'Sélectionner une cible',
                'value_options' => [],
                'disable_inarray_validator' => true,
            ],
            'attributes' => [
                'id' => 'cible',
            ],
        ]);

        $this->add([
            'type' => ObjectSelect::class,
            'name' => 'parentPriorite',
            'options' => [
                //'label' => 'Priorité du parent',
                'empty_option' => 'Sélectionner une priorité',
                'object_manager' => $this->getEntityManager(),
                'target_class' => CibleDependancePriorite::class,
                'property' => 'libelle',
                'find_method' => [
                    'name' => 'findBy',
                    'params' => [
                        'criteria' => [],
                        'orderBy' => ['libelle' => 'ASC'],
                    ],
                ],
                'disable_inarray_validator' => true,
            ],
            'attributes' => [
                'id' => 'parentPriorite',
            ],
        ]);
    }

    /**
     * Should return an array specification compatible with
     *
     * @return array
     */
    public function getInputFilterSpecification()
    {
        $inputFilter = [];

        $inputFilter['id'] = [
            'name' => 'id',
            'required' => true,
            'filters' => [
                ['name' => ToInt::class],
            ],
        ];

        $inputFilter['cible'] = [
            'name' => 'cible',
            'required' => true,
            'filters' => [
                ['name' => ToInt::class],
                [
                    'name' => ToNull::class,
                    'options' => [
                        ToNull::TYPE_INTEGER
                    ],
                ],
            ],
        ];

        $inputFilter['parentPriorite'] = [
            'name' => 'parentPriorite',
            'required' => true,
            'filters' => [
                ['name' => ToInt::class],
                [
                    'name' => ToNull::class,
                    'options' => [
                        ToNull::TYPE_INTEGER
                    ],
                ],
            ],
        ];

        return $inputFilter;
    }
}