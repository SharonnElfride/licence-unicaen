<?php

namespace MeteoSI\Form\CibleEvenement\Cible\Hydrator;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\OptimisticLockException;
use Doctrine\ORM\ORMException;
use Laminas\Hydrator\AbstractHydrator;
use Laminas\Hydrator\HydratorInterface;
use MeteoSI\Model\CibleDependance;
use MeteoSI\Model\CibleDependancePriorite;
use MeteoSI\Model\CibleEvenement;
use MeteoSI\Model\CibleEvenementGroupe;
use MeteoSI\Model\CibleEvenementInfra;
use MeteoSI\Model\Interfaces\CibleEvenementInterface;
use MeteoSI\Model\RegleTransition;
use MeteoSI\Service\CibleEvenement\Dependance\RegleTransition\RegleTransitionServiceAwareTrait;
use UnicaenApp\Service\EntityManagerAwareTrait;

class AddParentHydrator extends AbstractHydrator implements HydratorInterface
{
    use EntityManagerAwareTrait;
    use RegleTransitionServiceAwareTrait;

    /**
     * Converts the given value so that it can be extracted by the hydrator.
     *
     * @param CibleEvenement $entity (optional) The original object for context.     *
     * @throws ORMException
     * @throws OptimisticLockException
     * @return array Returns the value that should be extracted.
     */
    public function extract($entity): array
    {
        $results = [];

        return $results;
    }

    /**
     * Hydrate $object with the provided $data.
     *
     * @param CibleEvenement $entity The original value.
     * @param array $data (optional) The original data for context.
     * @return CibleEvenement Returns the value that should be hydrated.
     */
    public function hydrate(array $data, $entity)
    {
        $idCible = ($data['cible']) ?? 0;
        $idParentPriorite = ($data['parentPriorite']) ?? 0;

        /** @var CibleEvenement $cible */
        $cible = $this->getEntityManager()->getRepository(CibleEvenement::class)->find($idCible);

        /** @var CibleDependancePriorite $parentPriorite */
        $parentPriorite = $this->getEntityManager()->getRepository(CibleDependancePriorite::class)->find($idParentPriorite);

        $dependance = new CibleDependance();
        $dependance->setParent($cible);
        $dependance->setEnfant($entity);
        $dependance->setParentPriorite($parentPriorite);

//        /** @var ArrayCollection|RegleTransition[] $reglesTransitionsDefault */
//        $reglesTransitionsDefault = $this->getRegleTransitionService()->findDefaultRules();
//        foreach ($reglesTransitionsDefault as $regleTransition):
//            $dependance->addRegleTransition($regleTransition);
//        endforeach;

        $entity->setDependencyToAdd($dependance);

//        if($entity->getCategorieEntite() instanceof CibleEvenementGroupe):
//            foreach ($entity->getCategorieEntite()->getCibles() as $c) {
//                $dep = new CibleDependance();
//                $dep->setParent($cible);
//                $dep->setEnfant($c);
//                $dep->setParentPriorite($parentPriorite);
//
//                /** @var ArrayCollection|RegleTransition[] $reglesTransitionsDefault */
//                $reglesTransitionsDefault = $this->getRegleTransitionService()->findDefaultRules();
//                foreach ($reglesTransitionsDefault as $regleTransition):
//                    $dep->addRegleTransition($regleTransition);
//                endforeach;
//
//                $c->setDependencyToAdd($dep);
//            }
//        endif;

        return $entity;
    }
}