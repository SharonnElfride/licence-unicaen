<?php

namespace MeteoSI\Event\ChangeEventState;

use DateTime;
use Exception;
use MeteoSI\Model\EtatEvenement;
use MeteoSI\Provider\Evenement\EtatEvenementProvider;
use MeteoSI\Provider\Event\EventsProvider;
use MeteoSI\Service\Evenement\EvenementServiceAwareTrait;
use UnicaenEvenement\Entity\Db\Etat;
use UnicaenEvenement\Entity\Db\Evenement;
use UnicaenEvenement\Service\Evenement\EvenementService;

class ChangeEventStateEvent extends EvenementService
{
    use EvenementServiceAwareTrait;

    public function creer(?DateTime $dateDebut = null): Evenement
    {
        if($dateDebut === null)
            $dateDebut = new DateTime();

        $typeEvent = $this->getTypeService()->findByCode(EventsProvider::CHANGE_EVENT_STATE);

        $parametres = [];

        $description = "Changer l'état d'un événement d'à venir à en cours";
        $event = $this->createEvent('changeEventState', $description, null, $typeEvent, $parametres, $dateDebut);
        $this->ajouter($event);

        return $event;
    }

    public function traiter(Evenement $evenement): string
    {
        $parametres = json_decode($evenement->getParametres(), true);
        $nbEvenement = 0;

        try {
            $evenementsAVenir = $this->getEvenementService()->findAllBy(['etat' => EtatEvenementProvider::ETAT_EVENEMENT_A_VENIR_ID], ['id' => 'ASC']);

            /** @var \MeteoSI\Model\Evenement $event */
            foreach ($evenementsAVenir as $event)
            {
                //TODO getEvenementService peut faire n'importe quoi
                if ($event->getDateDebut() <= (new DateTime())) {
                    /** @var EtatEvenement $enCours */
                    $enCours = $this->getEntityManager()->getRepository(EtatEvenement::class)->findOneBy(['code' => 'encours']);
                    $event->setEtat($enCours);
                    $this->getEvenementService()->update($event);
                    $nbEvenement++;
                }
            }
        }
        catch (Exception $e) {
            $evenement->setLog($e->getMessage());
            $this->update($evenement);
            return Etat::ECHEC;
        }

        $evenement->setLog($nbEvenement . " événements ont changé d'état!");
        $this->update($evenement);
        return Etat::SUCCES;
    }
}