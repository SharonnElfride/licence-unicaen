<?php

namespace MeteoSI\Model;

use DateTime;
use Doctrine\Common\Collections\ArrayCollection;
use Laminas\Permissions\Acl\Resource\ResourceInterface;
use MeteoSI\Model\Interfaces\CibleEvenementInterface;

class CibleEvenementGroupe implements ResourceInterface, CibleEvenementInterface
{
    const RESOURCE_ID = 'CibleEvenementGroupe';

    /** @var int $id */
    private $id;

    /** @var string $code */
    private $code;

    /** @var CibleEvenement $cibleEvenement */
    private CibleEvenement $cibleEvenement;

    /** @var ArrayCollection|CibleEvenement[] $cibles */
    private $cibles;

    /**
     * Retourne l'identifiant de la ressource sous forme de chaîne de caractères
     *
     * @return string
     */
    public function getResourceId(): string
    {
        return self::RESOURCE_ID;
    }

    /** Constructeur */
    public function __construct()
    {
        $this->cibleEvenement = new CibleEvenement();
        $this->cibles = new ArrayCollection();
    }

// Cibles composantes le groupe
    /**
     * Ajout d'une cible
     * @param CibleEvenement $cible
     * @return void
     */
    public function addCible(CibleEvenement $cible): void
    {
        $this->cibles->add($cible);
    }

    /**
     * Suppression d'une cible
     * @param CibleEvenement $cible
     * @return void
     */
    public function removeCible(CibleEvenement $cible): void
    {
        $this->cibles->removeElement($cible);
    }

    /**
     * Suppression de toutes les cibles
     * @return void
     */
    public function removeAllCibles(): void
    {
        $this->cibles->clear();
    }

    /**
     * @return ArrayCollection|CibleEvenement[]
     */
    public function getCibles()
    {
        return $this->cibles;
    }

    //Fonction pour déterminer l'état du groupe en fonction de l'état des cibles composantes
    public function getGroupStateByItsTargets()
    {
        //Sorting for having the best state at the first position in the tab
        $targetsStates = [];
        for ($i = 0 ; $i < sizeof($this->getCibles()) ; $i++):
            $targetsStates[$i] = $this->getCibles()->get($i)->getEtat();
        endfor;

        usort($targetsStates, function (EtatCible $a, EtatCible $b){
            return $a->getGroupePriorite()->getNiveauGravite() > $b->getGroupePriorite()->getNiveauGravite();
        });

        //Best state
        /** @var EtatCible $bestState */
        $bestState = $targetsStates[0];

        $this->setGroupState($bestState);
    }

    /**
     * @return ArrayCollection|Evenement[]
     */
    public function getEvenements()
    {
        return $this->getCible()->getEvenements();
    }

//GETTERS & SETTERS
    /**
     * @return string|null
     */
    public function getCode()
    {
        return $this->code;
    }

    /**
     * @param string $code
     * @return void
     */
    public function setCode(string $code): void
    {
        $this->code = $code;
    }

    /**
     * @return CibleEvenement|null
     */
    public function getCible()
    {
        return $this->cibleEvenement;
    }

    /**
     * @param CibleEvenement|null $cibleEvenement
     */
    public function setCibleEvenement(?CibleEvenement $cibleEvenement): void
    {
        $this->cibleEvenement = $cibleEvenement;
    }

//Parents et Enfants de la cible
    // Parents
    /**
     * @return ArrayCollection|CibleEvenement[]
     */
    public function getParents()
    {
        return $this->getCible()->getParents();
    }

    /**
     * @return ArrayCollection|CibleDependance[]
     */
    public function getDependanceParents()
    {
        return $this->getCible()->getDependanceParents();
    }

    // Enfants
    /**
     * @return ArrayCollection|CibleEvenement[]
     */
    public function getEnfants()
    {
        return $this->getCible()->getEnfants();
    }

    /**
     * @return ArrayCollection|CibleDependance[]
     */
    public function getDependanceEnfants()
    {
        return $this->getCible()->getDependanceEnfants();
    }

//Méthodes de CibleEvenementInterface
    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /** @return string */
    public function getLibelle()
    {
        return $this->cibleEvenement->getLibelle();
    }

    /** @return string|null */
    public function getDescription()
    {
        return $this->cibleEvenement->getDescription();
    }

    /** @return CategorieCible */
    public function getCategorieCible()
    {
        return $this->cibleEvenement->getCategorieCible();
    }

    /** @return EtatCible */
    public function getEtat()
    {
        return $this->cibleEvenement->getEtat();
    }

    /** @return string|null */
    public function getCodeSource()
    {
        return $this->cibleEvenement->getCodeSource();
    }

    /** @return int|null */
    public function getIdSource()
    {
        return $this->cibleEvenement->getIdSource();
    }

    /** @return DateTime */
    public function getDateCreation()
    {
        return $this->cibleEvenement->getDateCreation();
    }

    /** @return DateTime */
    public function getDateModification()
    {
        return $this->cibleEvenement->getDateModification();
    }

    /**
     * @param int $id
     * @return void
     */
    public function setId(int $id): void
    {
        $this->id = $id;
    }

    /**
     * @param string $libelle
     * @return void
     */
    public function setLibelle(string $libelle): void
    {
        $this->cibleEvenement->setLibelle($libelle);
    }

    /**
     * @param string|null $description
     * @return void
     */
    public function setDescription(?string $description): void
    {
        $this->cibleEvenement->setDescription($description);
    }

    /**
     * @param CategorieCible $categorieCible
     * @return void
     */
    public function setCategorieCible(CategorieCible $categorieCible): void
    {
        $this->cibleEvenement->setCategorieCible($categorieCible);
    }

    //Set the state of the group

    /**
     * @param EtatCible $etat
     * @return void
     */
    public function setGroupState(EtatCible  $etat): void
    {
        $this->cibleEvenement->setEtat($etat);
    }

    /**
     * @param EtatCible $etat
     * @return void
     */
    public function setEtat(EtatCible $etat): void
    {
        foreach ($this->getCibles() as $cible):
            //TODO choose the worst between the state here and the given state by trans rule
            $cible->setEtat($etat);
        endforeach;
        $this->getGroupStateByItsTargets();
    }

    /**
     * @param string|null $codeSource
     * @return void
     */
    public function setCodeSource(?string $codeSource): void
    {
        $this->cibleEvenement->setCodeSource($codeSource);
    }

    /**
     * @param int|null $idSource
     * @return void
     */
    public function setIdSource(?int $idSource): void
    {
        $this->cibleEvenement->setIdSource($idSource);
    }

    /**
     * @param DateTime $dateCreation
     * @return void
     */
    public function setDateCreation(DateTime $dateCreation): void
    {
        $this->cibleEvenement->setDateCreation($dateCreation);
    }

    /**
     * @param DateTime $dateModification
     * @return void
     */
    public function setDateModification(DateTime $dateModification): void
    {
        $this->cibleEvenement->setDateModification($dateModification);
    }
}
