<?php

namespace MeteoSI\Form\Evenement\Validator\Factory;

use Interop\Container\Containerinterface;
use Laminas\ServiceManager\Factory\FactoryInterface;
use MeteoSI\Form\Evenement\Validator\ClotureEvenementValidator;

/**
 * Classe ClotureEvenementValidatorFactory
 */
class ClotureEvenementValidatorFactory implements FactoryInterface
{
    /**
     * Create fieldset
     *
     * @param ContainerInterface $container
     * @param string $requestedName
     * @param array|null $options
     * @return ClotureEvenementValidator
     */
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        /** @var ClotureEvenementValidator $validator */
        $validator = new ClotureEvenementValidator();

        return $validator;
    }
}