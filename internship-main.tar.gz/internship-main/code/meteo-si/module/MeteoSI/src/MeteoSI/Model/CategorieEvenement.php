<?php

namespace MeteoSI\Model;

use Doctrine\Common\Collections\ArrayCollection;
use Laminas\Permissions\Acl\Resource\ResourceInterface;

class CategorieEvenement implements ResourceInterface
{
    const RESOURCE_ID = 'CategorieEvenement';

    /**
     * L'identifiant de la catégorie
     * @var int $id
     */
    private $id;

    /**
     * Le code de la catégorie
     * @var string $code
     */
    private $code;

    /**
     * Le libelle de la catégorie
     * @var string $libelle
     */
    private $libelle;

    /**
     * L'acronyme de la catégorie
     * @var string $acronyme
     */
    private $acronyme;

    /**
     * La couleur de la catégorie
     * @var string $couleur
     */
    private $couleur;

    /**
     * La liste des événements de cette catégorie
     * @var ArrayCollection|Evenement[] $evenements
     */
    private $evenements;

    /**
     * Constructeur permettant d'initialiser la liste des événements
     */
    public function __construct()
    {
        $this->evenements = new ArrayCollection();
    }

    /**
     * Retourne l'identifiant de la ressource sous forme de chaîne de caractères
     *
     * @return string
     */
    public function getResourceId(): string
    {
        return self::RESOURCE_ID;
    }

    /**
     *  Ajout d'un événement à la liste des événements de la catégorie
     * @param Evenement $evenement
     * @return void
     */
    public function addEvenements(Evenement $evenement): void
    {
        $this->evenements->add($evenement);
    }

    /**
     *  Suppression d'un événement de la liste des événements de la catégorie
     * @param Evenement $evenement
     * @return void
     */
    public function removeEvenements(Evenement $evenement): void
    {
        $this->evenements->removeElement($evenement);
    }

    /**
     *  Suppression de toutes les événements de la catégorie
     * @return void
     */
    public function removeAll(): void
    {
        $this->evenements->clear();
    }

    /**
     * @return ArrayCollection|Evenement[]
     */
    public function getEvenements()
    {
        return $this->evenements;
    }

//GETTERS AND SETTERS
    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return string
     */
    public function getCode()
    {
        return $this->code;
    }

    /**
     * @return string
     */
    public function getLibelle()
    {
        return $this->libelle;
    }

    /**
     * @return string
     */
    public function getAcronyme()
    {
        return $this->acronyme;
    }

    /**
     * @return string
     */
    public function getCouleur()
    {
        return $this->couleur;
    }

    /**
     * @param int $id
     * @return void
     */
    public function setId(int $id): void
    {
        $this->id = $id;
    }

    /**
     * @param string $code
     * @return void
     */
    public function setCode(string $code): void
    {
        $this->code = $code;
    }

    /**
     * @param string $libelle
     * @return void
     */
    public function setLibelle(string $libelle): void
    {
        $this->libelle = $libelle;
    }

    /**
     * @param string $acronyme
     * @return void
     */
    public function setAcronyme(string $acronyme): void
    {
        $this->acronyme = $acronyme;
    }

    /**
     * @param string $couleur
     */
    public function setCouleur(string $couleur): void
    {
        $this->couleur = $couleur;
    }
}
