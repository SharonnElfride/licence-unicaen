<?php

namespace MeteoSI\Form\Evenement\Validator\Factory;

use Interop\Container\Containerinterface;
use Laminas\ServiceManager\Factory\FactoryInterface;
use MeteoSI\Form\Evenement\Validator\AddEditEvenementValidator;
use MeteoSI\Form\Evenement\Validator\DestinatairesListValidator;

/**
 * Classe DestinatairesListValidatorFactory
 */
class DestinatairesListValidatorFactory implements FactoryInterface
{
    /**
     * Create fieldset
     *
     * @param ContainerInterface $container
     * @param string $requestedName
     * @param array|null $options
     * @return DestinatairesListValidator
     */
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        /** @var DestinatairesListValidator $validator */
        $validator = new DestinatairesListValidator();

        return $validator;
    }
}