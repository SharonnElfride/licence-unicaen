<?php

namespace MeteoSI\Form\Evenement\Validator;

use Doctrine\ORM\EntityManager;
use Laminas\Validator\AbstractValidator;
use MeteoSI\Model\CibleEvenement;
use MeteoSI\Model\Evenement;

class ReopenCibleCheckerValidator extends AbstractValidator
{
    const EVENEMENT_SUR_CIBLE = 'EVENEMENT_SUR_CIBLE';

    /** @var EntityManager $entityManager */
    private $entityManager;

    /** @var int $idReopeningEvenement */
    private $idReopeningEvenement;

    /**
     * @param EntityManager|null $entityManager
     * @return void
     */
    public function setEntityManager(?EntityManager $entityManager): void
    {
        $this->entityManager = $entityManager;
    }

    /**
     * @param int|null $id
     * @return void
     */
    public function setIdReopeningEvenement(?int $id): void
    {
        $this->idReopeningEvenement = $id;
    }

    /**
     * @var array $messageTemplates
     */
    protected $messageTemplates = [
        self::EVENEMENT_SUR_CIBLE => "Vous ne pouvez pas réouvrir cet événement car il y a déjà un événement sur la cible choisie. Veuillez, dans un premier temps, terminer l'événement en cours sur celle-ci.",
    ];

    public function setMessageTemplate($key, $value)
    {
        $this->messageTemplates[$key] = $value;
        $this->abstractOptions['messageTemplates'][$key] = $value;
    }

    /**
     * @var array
     */
    protected $messageVariables = [
    ];

    /**
     * Validation
     *
     * @param mixed $value
     * @param mixed $context Additional context to provide to the callback
     * @return bool
     */
    public function isValid($value, $context = null)
    {
        $idCibleEvenement = intval($value);
        /** @var CibleEvenement $cible */
        $cible = $this->entityManager->getRepository(CibleEvenement::class)->find($idCibleEvenement);

        /** @var Evenement $evenement */
        foreach ($cible->getEvenements() as $evenement):
            if($evenement->getId() !== $this->idReopeningEvenement) {
                if ($evenement->getEtat()->getCode() === "encours") {
                    $this->error(self::EVENEMENT_SUR_CIBLE);
                    return false;
                }
            }
        endforeach;

        return true;
    }
}