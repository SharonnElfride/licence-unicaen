<?php

namespace MeteoSI\Form\CibleEvenement\CibleInfra\Factory;

use Doctrine\Laminas\Hydrator\DoctrineObject;
use Doctrine\ORM\EntityManager;
use Interop\Container\ContainerInterface;
use Laminas\ServiceManager\Factory\FactoryInterface;
use Laminas\View\HelperPluginManager;
use MeteoSI\Form\CibleEvenement\CibleInfra\CibleEvenementInfraForm;
use MeteoSI\Form\CibleEvenement\CibleInfra\Hydrator\CibleEvenementInfraHydrator;

/**
 * Class CibleEvenementInfraFormFactory
 */
class CibleEvenementInfraFormFactory implements FactoryInterface
{
    /**
     * Create fieldset
     *
     * @param ContainerInterface $container
     * @param string $requestedName
     * @param array|null $options
     * @return CibleEvenementInfraForm|object
     */
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        /** @var CibleEvenementInfraForm $form */
        $form = new CibleEvenementInfraForm();

        /** @var EntityManager $entityManager */
        $entityManager = $container->get(EntityManager::class);
        $form->setEntityManager($entityManager);


        /** @var HelperPluginManager $viewHelperManager */
        $viewHelperManager = $container->get('ViewHelperManager');
        $form->setViewHelperManager($viewHelperManager);

        /** @var CibleEvenementInfraHydrator $hydrator */
        $hydrator = $container->get('HydratorManager')->get(CibleEvenementInfraHydrator::class);
        $form->setHydrator($hydrator);

        return $form;
    }
}
