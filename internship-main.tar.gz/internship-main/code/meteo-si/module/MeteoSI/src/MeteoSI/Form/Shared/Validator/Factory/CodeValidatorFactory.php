<?php

namespace MeteoSI\Form\Shared\Validator\Factory;

use Interop\Container\Containerinterface;
use Laminas\ServiceManager\Factory\FactoryInterface;
use MeteoSI\Form\Shared\Validator\CodeValidator;

class CodeValidatorFactory implements FactoryInterface
{
    /**
     * Create fieldset
     *
     * @param ContainerInterface $container
     * @param string $requestedName
     * @param array|null $options
     * @return CodeValidator
     */
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        /** @var CodeValidator $validator */
        $validator = new CodeValidator();

        return $validator;
    }
}