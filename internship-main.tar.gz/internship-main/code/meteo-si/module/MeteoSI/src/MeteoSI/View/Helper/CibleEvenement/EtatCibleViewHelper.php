<?php

namespace MeteoSI\View\Helper\CibleEvenement;

use Laminas\View\Helper\AbstractHelper;
use MeteoSI\Model\EtatCible;
use MeteoSI\Provider\CibleEvenement\EtatCibleProvider;

class EtatCibleViewHelper extends AbstractHelper
{
    /** @var EtatCible $etatCible */
    private $etatCible;

    /**
     * @param EtatCible|null $etatCible
     * @return EtatCibleViewHelper
     */
    public function __invoke(?EtatCible $etatCible)
    {
        $this->etatCible = $etatCible;
        return $this;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        if (!isset($this->etatCible)) {
            return "<span class='badge badge-muted'>Aucun</span>";
        }

        switch ($this->etatCible->getGroupePriorite()->getNiveauGravite()) {
            case EtatCibleProvider::ETAT_GROUPE_NORMAL_NIVEAU_GRAVITE :
                $badge_class = 'badge-success';
                break;
            case EtatCibleProvider::ETAT_GROUPE_TRES_IMPORTANT_NIVEAU_GRAVITE :
                $badge_class = 'badge-danger';
                break;
            case EtatCibleProvider::ETAT_GROUPE_IMPORTANT_NIVEAU_GRAVITE :
                $badge_class = 'badge-warning';
                break;
            case EtatCibleProvider::ETAT_GROUPE_PAS_TRES_IMPORTANT_NIVEAU_GRAVITE :
                $badge_class = 'badge-not-really-important';
                break;
            default:
                $badge_class = 'badge-muted';
                break;
        }

        return sprintf("<span class='badge %s'> %s </span>",
            $badge_class,
            $this->etatCible->getLibelle()
        );
    }

//GETTERS ET SETTERS

    /**
     * @return EtatCible|null
     */
    public function getEtatCible()
    {
        return $this->etatCible;
    }

    /**
     * @param EtatCible|null $etatCible
     */
    public function setEtatCible(?EtatCible $etatCible): void
    {
        $this->etatCible = $etatCible;
    }
}