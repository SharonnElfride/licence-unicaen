<?php

namespace MeteoSI\Form\CibleEvenement\CibleApplication;

use Laminas\Filter\StringTrim;
use Laminas\Filter\StripTags;
use Laminas\Form\Element\Text;
use Laminas\Validator\StringLength;
use MeteoSI\Form\CibleEvenement\Cible\CibleEvenementFieldset;

/**
 * Class CibleEvenementApplicationFieldset
 */
class CibleEvenementApplicationFieldset extends CibleEvenementFieldset
{

    public function init()
    {
        parent::init();

        $this->add([
            'name' => 'url',
            'type' => Text::class,
            'options' => [
//                'label' => "URL de l'application",
            ],
            'attributes' => [
                'placeholder' => 'https://gest.unicaen.fr/meteo-si/',
            ],
        ]);
    }

    public function getInputFilterSpecification()
    {
        $inputFilter = parent::getInputFilterSpecification();

        $inputFilter['url'] = [
            'name' => 'url',
            'required' => false,
            'filters' => [
                //StripTags == remove the unwanted html tags
                //StringTrim == remove the unnecessary spaces (\r or \t or \n...) at each line start/end
                ['name' => StripTags::class],
                ['name' => StringTrim::class],
            ],
            'validators' => [
                [
                    'name' => StringLength::class,
                    'options' => [
                        'encoding' => 'UTF-8',
                        'min' => 1,
                    ],
                ],
            ],
        ];

        return $inputFilter;
    }
}
