<?php

namespace MeteoSI\Service\Renderer\Evenement\EvenementInfo;

use MeteoSI\Model\CibleEvenement;
use MeteoSI\Model\Evenement;

class EvenementInfoService
{
    /** @var array */
    protected $variables;

    /**
     * @param array $variables
     * @return EvenementInfoService
     */
    public function setVariables(array $variables): EvenementInfoService
    {
        $this->variables = $variables;
        return $this;
    }

    /**
     * @param string
     * @return mixed
     */
    public function getVariable(string $key)
    {
        if (!isset($this->variables[$key])) return null;
        return $this->variables[$key];
    }

    /** Evenement */
    public function getServicesAffectes(): ?string
    {
        /** @var Evenement $evenement */
        $evenement = $this->getVariable('evenement');
        if ($evenement === null):
            return null;
        else:
            $result = sprintf("<ul class='fw-bold'><li>%s</li>",$evenement->getCible()->getLibelle());
            foreach ($evenement->getCible()->getEnfants() as $enfant):
                $result .= sprintf("<li>%s</li>", $enfant->getLibelle());
            endforeach;
            $result .= "</ul>" ;
            return $result;
        endif;
    }

    /** Evenement */
    public function getDisplayCreateur(): ?string
    {
        /** @var Evenement $evenement */
        $evenement = $this->getVariable('evenement');
        if ($evenement === null):
            return null;
        else:
            if($evenement->getPole() !== null)
                $displayName = $evenement->getPole()->getLibelle();
            else
                $displayName = $evenement->getDisplayNameCreateur();
            return $displayName;
        endif;
    }

    /** Evenement */
    public function getDisplayReopener(): ?string
    {
        /** @var Evenement $evenement */
        $evenement = $this->getVariable('evenement');
        if ($evenement !== null)
            return $evenement->getHistoModificateur()->getDisplayName();
        
//            if($evenement->getPole() !== null)
//                $displayName = $evenement->getPole()->getLibelle();
//            else
//                $displayName = $evenement->getHistoModificateur()->getDisplayName();
//            return $displayName;

        return null;
    }

    public function getCibleParent(): ?string
    {
        /** @var CibleEvenement $cibleParent */
        $cibleParent = $this->getVariable('cibleParent');
        if($cibleParent !== null)
            return $cibleParent->getLibelle();

        return null;
    }
}