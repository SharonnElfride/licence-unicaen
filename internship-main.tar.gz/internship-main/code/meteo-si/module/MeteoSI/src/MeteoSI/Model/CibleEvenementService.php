<?php

namespace MeteoSI\Model;

use DateTime;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Laminas\Permissions\Acl\Resource\ResourceInterface;
use MeteoSI\Model\Interfaces\CibleEvenementInterface;

class CibleEvenementService implements ResourceInterface, CibleEvenementInterface
{
    const RESOURCE_ID = 'CibleEvenementService';

    /** @var int $id */
    private $id;

    /** @var Collection $cible */
    private $cible;

    /** @var string $details */
    private $details;

    /**
     * Retourne l'identifiant de la ressource sous forme de chaîne de caractères
     *
     * @return string
     */
    public function getResourceId(): string
    {
        return self::RESOURCE_ID;
    }

    public function __construct()
    {
        $this->cible = new ArrayCollection([0 => new CibleEvenement(),]);
    }

//Cible d'événement liée
    /**
     * @return CibleEvenement
     */
    public function getCible()
    {
        return $this->cible->get(0);
    }

    /**
     * @param CibleEvenement $cible
     * @return void
     */
    public function setCible(CibleEvenement $cible): void
    {
        $this->cible->set(0, $cible);
    }

    /**
     * @return ArrayCollection|Evenement[]
     */
    public function getEvenements()
    {
        return $this->getCible()->getEvenements();
    }

//Parents et Enfants de la cible
    // Parents
    /**
     * @return ArrayCollection|CibleEvenement[]
     */
    public function getParents()
    {
        return $this->getCible()->getParents();
    }

    /**
     * @return ArrayCollection|CibleDependance[]
     */
    public function getDependanceParents()
    {
        return $this->getCible()->getDependanceParents();
    }

    // Enfants
    /**
     * @return ArrayCollection|CibleEvenement[]
     */
    public function getEnfants()
    {
        return $this->getCible()->getEnfants();
    }

    /**
     * @return ArrayCollection|CibleDependance[]
     */
    public function getDependanceEnfants()
    {
        return $this->getCible()->getDependanceEnfants();
    }

//GETTERS ET SETTERS
    /**
     * @return string|null
     */
    public function getDetails()
    {
        return $this->details;
    }

    /**
     * @param string $details
     */
    public function setDetails(string $details): void
    {
        $this->details = $details;
    }

//Méthodes de CibleEvenementInterface
    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /** @return string|null */
    public function getLibelle()
    {
        return $this->getCible()->getLibelle();
    }

    /** @return string|null */
    public function getDescription()
    {
        return $this->getCible()->getDescription();
    }

    /** @return CategorieCible|null */
    function getCategorieCible()
    {
        return $this->getCible()->getCategorieCible();
    }

    /** @return EtatCible|null */
    public function getEtat()
    {
        return $this->getCible()->getEtat();
    }

    /** @return string|null */
    public function getCodeSource()
    {
        return $this->getCible()->getCodeSource();
    }

    /** @return int|null */
    public function getIdSource()
    {
        return $this->getCible()->getIdSource();
    }

    /** @return DateTime|null */
    function getDateCreation()
    {
        return $this->getCible()->getDateCreation();
    }

    /** @return DateTime|null */
    function getDateModification()
    {
        return $this->getCible()->getDateModification();
    }

    /**
     * @param int $id
     * @return void
     */
    public function setId(int $id): void
    {
        $this->id = $id;
    }

    /**
     * @param string $libelle
     * @return void
     */
    public function setLibelle(string $libelle): void
    {
        $this->getCible()->setLibelle($libelle);
    }

    /**
     * @param string|null $description
     * @return void
     */
    function setDescription(?string $description): void
    {
        $this->getCible()->setDescription($description);
    }

    /**
     * @param CategorieCible $categorieCible
     * @return void
     */
    function setCategorieCible(CategorieCible $categorieCible): void
    {
        $this->getCible()->setCategorieCible($categorieCible);
    }

    /**
     * @param EtatCible $etat
     * @return void
     */
    public function setEtat(EtatCible $etat): void
    {
        $this->getCible()->setEtat($etat);
    }

    /**
     * @param string|null $codeSource
     * @return void
     */
    public function setCodeSource(?string $codeSource): void
    {
        $this->getCible()->setCodeSource($codeSource);
    }

    /**
     * @param int|null $idSource
     * @return void
     */
    public function setIdSource(?int $idSource): void
    {
        $this->getCible()->setIdSource($idSource);
    }

    /**
     * @param DateTime $dateCreation
     * @return void
     */
    function setDateCreation(DateTime $dateCreation): void
    {
        $this->getCible()->setDateCreation($dateCreation);
    }

    /**
     * @param DateTime $dateModification
     * @return void
     */
    function setDateModification(DateTime $dateModification): void
    {
        $this->getCible()->setDateModification($dateModification);
    }
}
