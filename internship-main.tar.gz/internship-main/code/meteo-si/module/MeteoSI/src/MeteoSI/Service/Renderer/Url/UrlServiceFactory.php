<?php

namespace MeteoSI\Service\Renderer\Url;

use Laminas\View\Renderer\PhpRenderer;
use Interop\Container\ContainerInterface;

class UrlServiceFactory {

    /**
     * @param ContainerInterface $container
     * @return UrlService
     */
    public function __invoke(ContainerInterface $container) : UrlService
    {
        /* @var PhpRenderer $renderer  */
        $renderer = $container->get('ViewRenderer');

        $service = new UrlService();
        $service->setRenderer($renderer);
        return $service;
    }
}
