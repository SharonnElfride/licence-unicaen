<?php

namespace MeteoSI\Service\CibleEvenement\CibleInfra;

use Doctrine\ORM\EntityManager;
use Interop\Container\ContainerInterface;
use Laminas\ServiceManager\Factory\FactoryInterface;

/**
 * Class CibleEvenementInfraServiceFactory
 * @package MeteoSI\Service\CibleEvenement\CibleInfra
 */
class CibleEvenementInfraServiceFactory implements FactoryInterface
{

    /**
     * @param ContainerInterface $container
     * @param string $requestedName
     * @param array|null $options
     * @return CibleEvenementInfraService|object
     */
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        /** @var CibleEvenementInfraService $serviceProvider */
        $serviceProvider = new CibleEvenementInfraService();

        /** @var EntityManager $entityManager */
        $entityManager = $container->get(EntityManager::class);
        $serviceProvider->setEntityManager($entityManager);

        return $serviceProvider;
    }
}
