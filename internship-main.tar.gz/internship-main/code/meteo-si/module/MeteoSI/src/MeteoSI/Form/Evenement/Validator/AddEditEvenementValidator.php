<?php

namespace MeteoSI\Form\Evenement\Validator;

use DateTime;
use Laminas\Validator\AbstractValidator;

/**
 * Classe AddEditEvenementValidator
 */
class AddEditEvenementValidator extends AbstractValidator
{
    const DUREE_OBLIGATOIRE = 'DUREE_OBLIGATOIRE';
    const EXPLICATIONS_DUREE_INCONNUE = 'EXPLICATIONS_DUREE_INCONNUE';

    /**
     * @var array $messageTemplates
     */
    protected $messageTemplates = [
        self::DUREE_OBLIGATOIRE => "Vous êtes dans l'obligation de renseigner l'une des valeurs suivantes: Fin estimée, Fin au plus tôt ou Durée inconnue.",
        self::EXPLICATIONS_DUREE_INCONNUE => "Vous êtes dans l'obligation d'expliquer pourquoi la durée est inconnue.",
    ];

    public function setMessageTemplate($key, $value)
    {
        $this->messageTemplates[$key] = $value;
        $this->abstractOptions['messageTemplates'][$key] = $value;
    }

    /**
     * @var array
     */
    protected $messageVariables = [
    ];

    /**
     * Validation
     *
     * @param mixed $value
     * @param mixed $context Additional context to provide to the callback
     * @return bool
     */
    public function isValid($value, $context = null)
    {
        $lde = 0; //longueur date estimée
        $ldm = 0; //longueur date minimale

        //Durées estimée et minimale
        if (isset($context['dateFinEstimee'])) {
            $lde += strlen($context['dateFinEstimee']);

        }
        if (isset($context['heureFinEstimee'])) {
            $lde += strlen($context['heureFinEstimee']);
        }

        if (isset($context['dateFinMinimale'])) {
            $ldm += strlen($context['dateFinMinimale']);
        }
        if (isset($context['heureFinMinimale'])) {
            $ldm += strlen($context['heureFinMinimale']);
        }

        //Durée inconnue et commentaire durée inconnue
        $dureeInconnue = $context['dureeInconnue'];
        $commentaireDureeInconnue = $context['commentaireDureeInconnue'];

        //Vérification des champs fin estimée, fin au plus tôt et durée inconnue
        if (($lde == 0) && ($ldm == 0) && (($dureeInconnue === 'false') || ($dureeInconnue === ''))) {
            $this->error(self::DUREE_OBLIGATOIRE);
            return false;
        }

       //Vérification du champ d'xplications si la durée est inconnue
        if ($dureeInconnue === '1') {
            if (isset($commentaireDureeInconnue)) {
                if ($commentaireDureeInconnue === '') {
                    $this->error(self::EXPLICATIONS_DUREE_INCONNUE);
                    return false;
                }
            }
            else {
                $this->error(self::EXPLICATIONS_DUREE_INCONNUE);
                return false;
            }
        }

        return true;
    }
}