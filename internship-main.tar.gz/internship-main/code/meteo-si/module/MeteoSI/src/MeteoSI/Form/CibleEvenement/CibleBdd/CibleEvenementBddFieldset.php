<?php

namespace MeteoSI\Form\CibleEvenement\CibleBdd;

use Application\Application\Form\AbstractEntityFieldset;
use DoctrineModule\Form\Element\ObjectSelect;
use Laminas\Filter\StringTrim;
use Laminas\Filter\StripTags;
use Laminas\Filter\ToInt;
use Laminas\Filter\ToNull;
use Laminas\Form\Element\Number;
use Laminas\Form\Element\Text;
use Laminas\InputFilter\InputFilterProviderInterface;
use Laminas\Validator\StringLength;
use MeteoSI\Form\CibleEvenement\Cible\CibleEvenementFieldset;
use MeteoSI\Model\CategorieCible;
use MeteoSI\Model\EtatCible;

/**
 * Class CibleEvenementBddFieldset
 */
class CibleEvenementBddFieldset extends CibleEvenementFieldset
{

    public function init()
    {
        parent::init();

        $this->add([
            'name' => 'server',
            'type' => Text::class,
            'options' => [
//                'label' => 'Serveur hébergeur de la base de données',
                'max' => 255,
            ],
            'attributes' => [
                'placeholder' => 'serveur kimetsu no yaiba',
            ],
        ]);
    }

    public function getInputFilterSpecification()
    {
        $inputFilter = parent::getInputFilterSpecification();

        $inputFilter['server'] = [
            'name' => 'server',
            'required' => true,
            'filters' => [
                //StripTags == remove the unwanted html tags
                //StringTrim == remove the unnecessary spaces (\r or \t or \n...) at each line start/end
                ['name' => StripTags::class],
                ['name' => StringTrim::class],
            ],
            'validators' => [
                [
                    'name' => StringLength::class,
                    'options' => [
                        'encoding' => 'UTF-8',
                        'min' => 1,
                    ],
                ],
            ],
        ];

        return $inputFilter;
    }
}
