<?php

namespace MeteoSI\Event\NotificationToCreatorAfterADelay;

use Interop\Container\Containerinterface;
use Laminas\ServiceManager\Factory\FactoryInterface;
use MeteoSI\MeteoSI\Service\Mailing\MailService;
use MeteoSI\Service\Evenement\EvenementService;

class NotificationToCreatorAfterADelayEventFactory implements FactoryInterface
{
    public function __invoke(Containerinterface $container, $requestedName, ?array $options = null)
    {
        /** @var NotificationToCreatorAfterADelayEvent $event */
        $event = new NotificationToCreatorAfterADelayEvent();

        /** @var EvenementService $entityService */
        $entityService = $container->get('ServiceManager')->get(EvenementService::class);
        $event->setEvenementService($entityService);

        /** @var MailService $mailService */
        $mailService = $container->get(MailService::class);
        $event->setMailService($mailService);

        $userContextService = $container->get('UnicaenAuthentification\Service\UserContext');
        $event->setServiceUserContext($userContextService);

        return $event;
    }
}