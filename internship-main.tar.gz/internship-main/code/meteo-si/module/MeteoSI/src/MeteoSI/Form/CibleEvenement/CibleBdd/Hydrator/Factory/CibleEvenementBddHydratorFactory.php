<?php

namespace MeteoSI\Form\CibleEvenement\CibleBdd\Hydrator\Factory;

use Doctrine\ORM\EntityManager;
use Interop\Container\Containerinterface;
use Laminas\ServiceManager\Factory\FactoryInterface;
use MeteoSI\Form\CibleEvenement\CibleBdd\Hydrator\CibleEvenementBddHydrator;

/**
 * Class CibleEvenementBddHydratorFactory
 */
class CibleEvenementBddHydratorFactory implements FactoryInterface
{
    /**
     * Create hydrator
     *
     * @return CibleEvenementBddHydrator
     */
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        /** @var CibleEvenementBddHydrator $hydrator */
        $hydrator = new CibleEvenementBddHydrator();

        /** @var EntityManager $entityManager */
        $entityManager = $container->get(EntityManager::class);
        $hydrator->setEntityManager($entityManager);

        return $hydrator;
    }
}