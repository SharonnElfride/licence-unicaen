<?php

namespace MeteoSI\Form\Evenement\Hydrator;

use Application\Application\Misc\UserAwaireTrait;
use DateTime;
use Laminas\Hydrator\AbstractHydrator;
use Laminas\Hydrator\HydratorInterface;
use MeteoSI\Model\CibleEvenementGroupe;
use MeteoSI\Model\Evenement;
use UnicaenApp\Service\EntityManagerAwareTrait;

class ClotureEvenementHydrator extends AbstractHydrator implements HydratorInterface
{
    use EntityManagerAwareTrait;
    use UserAwaireTrait;

    /**
     * Converts the given value so that it can be extracted by the hydrator.
     *
     * @param Evenement $entity (optional) The original object for context.
     * @return array Returns the value that should be extracted.
     */
    public function extract($entity): array
    {
        //Avoir la date de début pré-remplie en considérant que l'événement se termine maintenant
        if ($entity->getDateFinReelle() === null) {
            $entity->setDateFinReelle(new DateTime());
        }

        $results = [
            "dateFinReelle" => $entity->getDateFinReelle(),
            "heureFinReelle" => ($entity->getDateFinReelle()) ? $entity->getDateFinReelle()->format('H:i') : null,
            "commentaireCloture" => $entity->getCommentaireCloture(),
            "envoiMail" => $entity->getEnvoiMail(),
            "destinataires" => $entity->getDestinataires(),
        ];

        return $results;
    }


    /**
     * Converts the given value so that it can be hydrated by the hydrator.
     *
     * @param Evenement $entity The original value.
     * @param array $data (optional) The original data for context.
     * @return Evenement Returns the value that should be hydrated.
     */
    public function hydrate(array $data, $entity)
    {
        //Date de fin réelle/constatée
        $dateFinReelle = new DateTime();
        if (isset($data['dateFinReelle']))
            $dateFinReelle = new DateTime($data['dateFinReelle']);
        if (isset($data['heureFinReelle'])) {
            $heure = explode(':', $data['heureFinReelle']);
            $dateFinReelle->setTime(intval($heure[0]), intval($heure[1]));
        }

        $commentaireCloture = ($data['commentaireCloture']) ?? '';
        $envoiMail = isset($data['envoiMail']) && boolval($data['envoiMail']);
        $destinataires = ($data['destinataires']) ?? '';

        //Le passage des valeurs récupérées par le form
        $entity->setDateFinReelle($dateFinReelle);
        $entity->setCommentaireCloture($commentaireCloture);
        $entity->setEnvoiMail($envoiMail);
        $entity->setDestinataires($destinataires);

        return $entity;
    }
}