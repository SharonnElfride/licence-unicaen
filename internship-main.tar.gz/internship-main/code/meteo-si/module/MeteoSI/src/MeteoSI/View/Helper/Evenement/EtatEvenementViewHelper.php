<?php

namespace MeteoSI\View\Helper\Evenement;

use Laminas\View\Helper\AbstractHelper;
use MeteoSI\Model\Evenement;
use MeteoSI\Provider\Evenement\EtatEvenementProvider;

class EtatEvenementViewHelper extends AbstractHelper
{
    /** @var Evenement $evenement */
    private $evenement;

    /**
     * @param Evenement|null $evenement
     * @return $this
     */
    public function __invoke(?Evenement $evenement)
    {
        $this->evenement = $evenement;
        return $this;
    }

    public function __toString()
    {
        switch($this->evenement->getEtat()->getCode()) {
            case EtatEvenementProvider::ETAT_EVENEMENT_EN_COURS_CODE:
                $badge_class = "badge-danger";
                break;
            case EtatEvenementProvider::ETAT_EVENEMENT_A_VENIR_CODE:
                $badge_class = "badge-warning";
                break;
            case EtatEvenementProvider::ETAT_EVENEMENT_TERMINE_CODE:
                $badge_class = "badge-success";
                break;
            default:
                $badge_class = 'badge-muted';
                break;
        }

        return sprintf("<span class='badge %s'> %s </span>",
            $badge_class,
            $this->evenement->getEtat()->getLibelle()
        );
    }

//GETTERS ET SETTERS
    /**
     * @return Evenement|null
     */
    public function getEvenement()
    {
        return $this->evenement;
    }

    /**
     * @param Evenement|null $evenement
     */
    public function setEvenement(?Evenement $evenement): void
    {
        $this->evenement = $evenement;
    }
}