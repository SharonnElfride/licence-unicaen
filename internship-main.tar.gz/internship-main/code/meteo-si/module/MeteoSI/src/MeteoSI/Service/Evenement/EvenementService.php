<?php

namespace MeteoSI\Service\Evenement;


use Application\Application\Misc\UserAwaireTrait;
use Application\Application\Service\API\CommonEntityService;
use DateTime;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\OptimisticLockException;
use Doctrine\ORM\ORMException;
use MeteoSI\Model\CategorieEvenement;
use MeteoSI\Model\EtatCible;
use MeteoSI\Model\EtatEvenement;
use MeteoSI\Model\Evenement;
use MeteoSI\Provider\CibleEvenement\EtatCibleProvider;
use MeteoSI\Provider\Evenement\EtatEvenementProvider;
use phpDocumentor\Reflection\Types\Boolean;
use UnicaenUtilisateur\Entity\Db\User;

/**
 * Class EvenementService
 * @package MeteoSI\Service\Evenement
 */
class EvenementService extends CommonEntityService
{
    use UserAwaireTrait;

    /** @return string */
    public function getEntityClass()
    {
        return Evenement::class;
    }

    /**
     * Retourne une nouvelle instance de l'entité courante
     *
     * @param $name
     * @return mixed
     */
    public function getEntityInstance($name = null)
    {
        return $this->getEntityInstance($name);
    }

    /**
     * Add a new event to the table
     *
     * @param Evenement $entity
     *
     * @override
     * @throws ORMException
     * @throws OptimisticLockException
     */
    public function add($entity, $serviceEntityClass = null)
    {
        $user = $this->getConnectedUser() ?? $this->getEntityManager()->getRepository(User::class)->find(0);
        $entity->setHistoCreateur($user);
        $entity->setHistoModificateur($user);
        $entity->setHistoCreation(new DateTime());
        $entity->setHistoModification(new DateTime());

        return parent::add($entity, $serviceEntityClass);
    }

    /**
     * @param Evenement $entity
     *
     * @throws OptimisticLockException
     * @throws ORMException
     */
    public function clone(Evenement $entity, $serviceEntityClass = null)
    {
        $entity->setDateFinReelle(null);
        $entity->setClotureur(null);
        $entity->setDateCloture(null);
        $entity->setCommentaireCloture(null);
        $entity->setHistoDestructeur(null);
        $entity->setHistoDestruction(null);

        return $this->add($entity, $serviceEntityClass);
    }

    /**
     * Update a new line to the event table
     *
     * @override
     * @throws ORMException
     * @throws OptimisticLockException
     */
    public function update($entity, $serviceEntityClass = null)
    {
        $user = $this->getConnectedUser() ?? $this->getEntityManager()->getRepository(User::class)->find(0);
        $entity->setHistoModificateur($user);
        $entity->setHistoModification(new DateTime());
        return parent::update($entity, $serviceEntityClass);
    }

    /**
     * Remove the link between 2 evenements
     *
     * @param Evenement $enfant
     *
     * @return void
     * @throws OptimisticLockException
     * @throws ORMException
     */
    public function unleash(Evenement $enfant)
    {
        $enfant->setEvenementRef(null);
        return $this->update($enfant);
    }

    /**
     * Re-open an evenement
     *
     * @param Evenement $entity
     *
     * @override
     * @throws ORMException
     * @throws OptimisticLockException
     */
    public function reopen(Evenement $entity)
    {
        $entity->setClotureur(null);
        $entity->setDateCloture(null);
        $entity->setCommentaireCloture(null);
        $entity->setDateFinReelle(null);

        return $this->update($entity);
    }

    /**
     * Close an evenement
     *
     * @throws ORMException
     * @throws OptimisticLockException
     */
    public function close(Evenement $entity, $serviceEntityClass = null)
    {
        $user = $this->getConnectedUser() ?? $this->getEntityManager()->getRepository(User::class)->find(0);
        $entity->setClotureur($user);
        $entity->setDateCloture(new DateTime());

        /** @var EtatEvenement $etat */
        $etat = $this->getEntityManager()->getRepository(EtatEvenement::class)->findOneBy(['code' => EtatEvenementProvider::ETAT_EVENEMENT_TERMINE_CODE]);
        $entity->setEtat($etat);

        /** @var EtatCible $etatCible */
        $etatCible = $this->getEntityManager()->getRepository(EtatCible::class)->findOneBy(['code' => EtatCibleProvider::ETAT_CIBLE_NORMAL_CODE]);
        $entity->getCible()->setGivenStateByEvenement($etatCible);

        return $this->update($entity, $serviceEntityClass);
    }

    /**
     * Delete one evenement
     *
     * @param Evenement $entity
     *
     * @override
     * @throws ORMException
     * @throws OptimisticLockException
     */
    public function delete($entity, $serviceEntityClass = null)
    {
        foreach ($entity->getEvenementsEnfants() as $enfant):
            $enfant->setEvenementRef(null);
        endforeach;

        /** @var EtatCible $etatCible */
        $etatCible = $this->getEntityManager()->getRepository(EtatCible::class)->findOneBy(['code' => EtatCibleProvider::ETAT_CIBLE_NORMAL_CODE]);
        $entity->getCible()->setGivenStateByEvenement($etatCible);

        if ($entity->getEtat()->getCode() === "encours") {
            $entity->setDateFinReelle(new DateTime());
            $this->close($entity);
        }

        $user = $this->getConnectedUser() ?? $this->getEntityManager()->getRepository(User::class)->find(0);
        $entity->setHistoDestructeur($user);
        $entity->setHistoDestruction(new DateTime());
        return parent::delete($entity, $serviceEntityClass);
    }

    public function findAll()
    {
        return $this->findAllBy([], ["etat" => "ASC"]);
    }

    public function findAllByCodeEtat(string $etat)
    {
        switch ($etat):
            case 'encours':
            case 'avenir':
            case 'termine':
            $etatCorrespondant = $this->getEntityManager()->getRepository(EtatEvenement::class)->findOneBy(['code' => $etat]);
            return $this->findAllBy(
                ['etat' => $etatCorrespondant],
                ['dateDebut' => 'DESC']
            );
            default:
                throw new \RuntimeException("Aucun état de code : " . $etat);
        endswitch;
    }

    public function findAllByDate(DateTime $date, bool $groupByCategory = false)
    {
        $date = $date->format('d-m-Y');
        $events = $this->findAll();
        $res = [];
        $dateEvents = [];

        /** @var Evenement $event */
        foreach ($events as $event) {
            $eventDate = $event->getDateDebut()->format('d-m-Y');
            if ($eventDate === $date)
                $dateEvents[] = $event;
        }

        if(!$groupByCategory) {
            return $dateEvents;
        }
        else {
            $categories = new ArrayCollection();
            /** @var Evenement $event */
            foreach ($dateEvents as $event) {
                $category = $event->getCategorie();
                if(!$categories->contains($category))
                    $categories->add($category);
            }

            $eventsByCategory = [];
            /** @var CategorieEvenement $category */
            foreach($categories as $category) {
                $categoryEvents = [];
                foreach($dateEvents as $event) {
                    if($event->getCategorie()->getId() === $category->getId())
                        $categoryEvents[$event->getId()] = $event;
                }

                $eventsByCategory[] = [
                    'category' => $category,
                    'categoryEvents' => $categoryEvents,
                ];
            }

            $res['eventsByCategory'] = $eventsByCategory;

            if($dateEvents !== null)
                $res['numberDayEvents'] = sizeof($dateEvents);
            return $res;
        }
    }

    public function findAllByMonthAndYear(int $month, int $year)
    {
        $events = $this->findAll();
        $date = $month . "-" . $year;

        $dateEvents = [];

        /** @var Evenement $event */
        foreach($events as $event) {
            $eventDate = $event->getDateDebut()->format('n-Y');
            if($eventDate === $date)
                $dateEvents[$event->getId()] = $event;
        }

        return $dateEvents;
    }
}
