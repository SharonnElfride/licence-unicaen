<?php

namespace MeteoSI\Model;

use Application\Application\Misc\Util;
use DateTime;
use Doctrine\Common\Collections\ArrayCollection;
use Laminas\Permissions\Acl\Resource\ResourceInterface;
use UnicaenUtilisateur\Entity\Db\HistoriqueAwareInterface;
use UnicaenUtilisateur\Entity\Db\HistoriqueAwareTrait;
use UnicaenUtilisateur\Entity\Db\User;
use UnicaenUtilisateur\Entity\Db\UserInterface;

class Evenement implements ResourceInterface, HistoriqueAwareInterface
{
    use HistoriqueAwareTrait;

    const RESOURCE_ID = 'Evenement';

    /** @var int $id */
    private $id;

    /** @var Evenement $evenementRef */
    private $evenementRef;

    /** @var CategorieEvenement $categorie */
    private $categorie;

    /** @var CibleEvenement $cible */
    private $cible;

//    /** @var string $libelle */
//    private $libelle;

    /** @var string $description */
    private $description;

    /** @var string $actionsPrevues */
    private $actionsPrevues;

    /** @var DateTime $dateDebut */
    private $dateDebut;

    /**
     * @var DateTime $dateFinEstimee
     */
    private $dateFinEstimee;

    /**
     * @var DateTime $dateFinMinimale
     */
    private $dateFinMinimale;

    /**
     * @var DateTime $dateFinReelle
     */
    private $dateFinReelle;

    /**
     * @var boolean $dureeInconnue
     */
    private $dureeInconnue;

    /**
     * @var string $commentaireDureeInconnue
     */
    private $commentaireDureeInconnue;

    /**
     * @var EtatEvenement $etat
     */
    private $etat;

    /**
     * @var boolean $publieIntranet
     */
    private $publieIntranet;

    /**
     * @var boolean $publieInternet
     */
    private $publieInternet;

    /**
     * @var string $displayNameCreateur
     */
    private $displayNameCreateur;

    //Gestion mails
    /**
     * @var boolean $envoiMail
     */
    private $envoiMail;
    /**
     * @var string $destinataires
     */
    private $destinataires;
    /**
     * @var string $complementInformations
     */
    private $complementInformations;

    //Classe normale continuité
    /**
     * @var User $clotureur
     */
    private $clotureur;

    /**
     * @var DateTime $dateCloture
     */
    private $dateCloture;

    /**
     * @var string $commentaireCloture
     */
    private $commentaireCloture;

    /**
     * @var ArrayCollection|Evenement[] $evenementsEnfants
     */
    private $evenementsEnfants;

    /** @var PoleUtilisateur $pole */
    private $pole;

    /**
     * Constructeur permettant d'initialiser la liste des événements et contacts rattachés à cet événement
     */
    public function __construct()
    {
        $this->evenementsEnfants = new ArrayCollection();
    }

    /**
     * Returns the string identifier of the Resource
     *
     * @return string
     */
    public function getResourceId()
    {
        return self::RESOURCE_ID;
    }

//Pôle utilisateur

    /**
     * @return PoleUtilisateur|null
     */
    public function getPole()
    {
        return $this->pole;
    }

    /**
     * @param PoleUtilisateur|null $pole
     */
    public function setPole(?PoleUtilisateur $pole): void
    {
        $this->pole = $pole;
    }

// Evenements enfants
    /**
     * @param Evenement $evenement
     * @return void
     */
    public function addEvenementEnfant(Evenement $evenement)
    {
        $this->evenementsEnfants->add($evenement);
    }

    /**
     * @param Evenement $evenement
     * @return void
     */
    public function removeEvenementEnfant(Evenement $evenement)
    {
        $this->evenementsEnfants->removeElement($evenement);
    }

    /**
     * @return void
     */
    public function removeAllEvenementsEnfants()
    {
        $this->evenementsEnfants->clear();
    }

    /**
     * @return ArrayCollection|Evenement[]
     */
    public function getEvenementsEnfants()
    {
        return $this->evenementsEnfants;
    }

//GETTERS AND SETTERS

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return Evenement
     */
    public function getEvenementRef()
    {
        return $this->evenementRef;
    }

    /**
     * @return CategorieEvenement
     */
    public function getCategorie()
    {
        return $this->categorie;
    }

    /**
     * @return CibleEvenement
     */
    public function getCible()
    {
        return $this->cible;
    }

    /**
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * @return string
     */
    public function getActionsPrevues()
    {
        return $this->actionsPrevues;
    }

    /**
     * @return DateTime
     */
    public function getDateDebut()
    {
        return $this->dateDebut;
    }

    /**
     * @return DateTime
     */
    public function getDateFinEstimee()
    {
        return $this->dateFinEstimee;
    }

    /**
     * @return DateTime
     */
    public function getDateFinMinimale()
    {
        return $this->dateFinMinimale;
    }

    /**
     * @return DateTime
     */
    public function getDateFinReelle()
    {
        return $this->dateFinReelle;
    }

    /**
     * @return boolean
     */
    public function getDureeInconnue()
    {
        return $this->dureeInconnue;
    }

    /**
     * @return string
     */
    public function getCommentaireDureeInconnue()
    {
        return $this->commentaireDureeInconnue;
    }

    /**
     * @return EtatEvenement
     */
    public function getEtat()
    {
        return $this->etat;
    }

    /**
     * @return boolean
     */
    public function getPublieIntranet()
    {
        return $this->publieIntranet;
    }

    /**
     * @return boolean
     */
    public function getPublieInternet()
    {
        return $this->publieInternet;
    }

    /**
     * @return string
     */
    public function getDisplayNameCreateur()
    {
        return $this->displayNameCreateur;
    }

    //Gestion mails
    /**
     * @return boolean|null
     */
    public function getEnvoiMail()
    {
        return $this->envoiMail;
    }

    /**
     * @return string|null
     */
    public function getDestinataires()
    {
        return $this->destinataires;
    }

    /**
     * @return string|null
     */
    public function getComplementInformations()
    {
        return $this->complementInformations;
    }

    //Continuité
    /**
     * @return User
     */
    public function getClotureur()
    {
        return $this->clotureur;
    }

    /**
     * @return DateTime
     */
    public  function getDateCloture() {
        return $this->dateCloture;
    }

    /**
     * @return string
     */
    public function getCommentaireCloture()
    {
        return $this->commentaireCloture;
    }

    /**
     * @return DateTime
     */
    public function getHistoCreation()
    {
        return $this->histoCreation;
    }

    /**
     * User ?
     * @return UserInterface
     */
    public function getHistoCreateur()
    {
        return $this->histoCreateur;
    }

    /**
     * @return DateTime
     */
    public function getHistoModification()
    {
        return $this->histoModification;
    }

    /**
     * @return UserInterface
     */
    public function getHistoModificateur()
    {
        return $this->histoModificateur;
    }

    /**
     * @return DateTime
     */
    public function getHistoDestruction()
    {
        return $this->histoDestruction;
    }

    /**
     * @return UserInterface
     */
    public function getHistoDestructeur()
    {
        return $this->histoDestructeur;
    }

// SETTERS

    /**
     * @param int|null $id
     */
    public function setId(?int $id): void
    {
        $this->id = $id;
    }

    /**
     * @param Evenement|null $evenementRef
     */
    public function setEvenementRef(?Evenement $evenementRef): void
    {
        $this->evenementRef = $evenementRef;
    }

    /**
     * @param CategorieEvenement|null $categorie
     */
    public function setCategorie(?CategorieEvenement $categorie): void
    {
        $this->categorie = $categorie;
    }

    /**
     * @param CibleEvenement|null $cible
     */
    public function setCible(?CibleEvenement $cible): void
    {
        $this->cible = $cible;
    }

    /**
     * @param string $description
     */
    public function setDescription(string $description): void
    {
        $this->description = $description;
    }

    /**
     * @param string $actionsPrevues
     */
    public function setActionsPrevues(string $actionsPrevues): void
    {
        $this->actionsPrevues = $actionsPrevues;
    }

    /**
     * @param DateTime $dateDebut
     */
    public function setDateDebut(DateTime $dateDebut): void
    {
        $this->dateDebut = $dateDebut;
    }

    /**
     * @param DateTime|null $dateFinEstimee
     */
    public function setDateFinEstimee(?DateTime $dateFinEstimee): void
    {
        $this->dateFinEstimee = $dateFinEstimee;
    }

    /**
     * @param DateTime|null $dateFinMinimale
     */
    public function setDateFinMinimale(?DateTime $dateFinMinimale): void
    {
        $this->dateFinMinimale = $dateFinMinimale;
    }

    /**
     * @param DateTime|null $dateFinReelle
     */
    public function setDateFinReelle(?DateTime $dateFinReelle): void
    {
        $this->dateFinReelle = $dateFinReelle;
    }

    /**
     * @param bool $dureeInconnue
     */
    public function setDureeInconnue(bool $dureeInconnue): void
    {
        $this->dureeInconnue = $dureeInconnue;
    }

    /**
     * @param string $commentaireDureeInconnue
     */
    public function setCommentaireDureeInconnue(string $commentaireDureeInconnue): void
    {
        $this->commentaireDureeInconnue = $commentaireDureeInconnue;
    }

    /**
     * @param EtatEvenement|null $etat
     */
    public function setEtat(?EtatEvenement $etat): void
    {
        $this->etat = $etat;
    }

    /**
     * @param bool $publieIntranet
     */
    public function setPublieIntranet(bool $publieIntranet): void
    {
        $this->publieIntranet = $publieIntranet;
    }

    /**
     * @param bool $publieInternet
     */
    public function setPublieInternet(bool $publieInternet): void
    {
        $this->publieInternet = $publieInternet;
    }

    /**
     * @param string $displayNameCreateur
     */
    public function setDisplayNameCreateur(string $displayNameCreateur): void
    {
        $this->displayNameCreateur = $displayNameCreateur;
    }

    //Gestion mails
    /**
     * @param boolean|null $envoiMail
     * @return void
     */
    public function setEnvoiMail(?bool $envoiMail): void
    {
        $this->envoiMail = $envoiMail;
    }

    /**
     * @param string|null $destinataires
     * @return void
     */
    public function setDestinataires(?string $destinataires): void
    {
        $this->destinataires = $destinataires;
    }

    /**
     * @param string|null $complementInformations
     * @return void
     */
    public function setComplementInformations(?string $complementInformations): void
    {
        $this->complementInformations = $complementInformations;
    }

    //Continuité

    /**
     * @param User|null $clotureur
     */
    public function setClotureur(?User $clotureur): void
    {
        $this->clotureur = $clotureur;
    }

    /**
     * @param DateTime|null $dateCloture
     */
    public function setDateCloture(?DateTime $dateCloture): void
    {
        $this->dateCloture = $dateCloture;
    }

    /**
     * @param mixed $commentaireCloture
     */
    public function setCommentaireCloture($commentaireCloture): void
    {
        $this->commentaireCloture = $commentaireCloture;
    }

    /**
     * @param UserInterface|null $histoCreateur
     */
    public function setHistoCreateur(UserInterface $histoCreateur = null): void
    {
        $this->histoCreateur = $histoCreateur;
    }

    /**
     * @param UserInterface|null $histoModificateur
     */
    public function setHistoModificateur(UserInterface $histoModificateur = null): void
    {
        $this->histoModificateur = $histoModificateur;
    }

    /**
     * @param User|null $histoDestructeur
     */
    public function setHistoDestructeur(UserInterface $histoDestructeur = null): void
    {
        $this->histoDestructeur = $histoDestructeur;
    }
}