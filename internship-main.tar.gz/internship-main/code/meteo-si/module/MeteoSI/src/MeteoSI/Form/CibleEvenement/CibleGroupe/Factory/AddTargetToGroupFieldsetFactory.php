<?php

namespace MeteoSI\Form\CibleEvenement\CibleGroupe\Factory;

use Doctrine\Laminas\Hydrator\DoctrineObject;
use Doctrine\ORM\EntityManager;
use Interop\Container\Containerinterface;
use Laminas\ServiceManager\Factory\FactoryInterface;
use MeteoSI\Form\CibleEvenement\CibleGroupe\AddTargetToGroupFieldset;
use MeteoSI\Model\CibleEvenementGroupe;

class AddTargetToGroupFieldsetFactory implements FactoryInterface
{
    /**
     * Create fieldset
     *
     * @param ContainerInterface $container
     * @param string $requestedName
     * @param array|null $options
     * @return AddTargetToGroupFieldset|object
     */
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        /** @var AddTargetToGroupFieldset $fieldset */
        $fieldset = new AddTargetToGroupFieldset('addTargetToGroup');

        /** @var EntityManager $entityManager */
        $entityManager = $container->get(EntityManager::class);
        $fieldset->setEntityManager($entityManager);

        /** @var DoctrineObject $hydrator */
        $hydrator = $container->get('HydratorManager')->get(DoctrineObject::class);
        $fieldset->setHydrator($hydrator);

        $fieldset->setObject(new CibleEvenementGroupe());
        return $fieldset;
    }
}
