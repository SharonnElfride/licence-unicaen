<?php

namespace MeteoSI\Form\Evenement\Fieldset;

use Application\Application\Form\AbstractEntityFieldset;
use DoctrineModule\Form\Element\ObjectSelect;
use Laminas\Filter\StringTrim;
use Laminas\Filter\StripTags;
use Laminas\Filter\ToInt;
use Laminas\Filter\ToNull;
use Laminas\Form\Element\Checkbox;
use Laminas\Form\Element\Date;
use Laminas\Form\Element\Select;
use Laminas\Form\Element\Text;
use Laminas\Form\Element\Textarea;
use Laminas\Form\Element\Time;
use Laminas\InputFilter\InputFilterProviderInterface;
use Laminas\Validator\StringLength;
use MeteoSI\Form\Evenement\Validator\AddEditEvenementValidator;
use MeteoSI\Form\Evenement\Validator\DateAnterieureCheckerValidator;
use MeteoSI\Form\Evenement\Validator\DestinatairesListValidator;
use MeteoSI\Form\Evenement\Validator\ReopenCibleCheckerValidator;
use MeteoSI\Model\CategorieEvenement;
use MeteoSI\Model\CibleEvenement;
use MeteoSI\Model\CibleEvenementGroupe;
use MeteoSI\Model\EtatCible;
use MeteoSI\Model\EtatEvenement;
use MeteoSI\Model\Evenement;
use MeteoSI\Model\PoleUtilisateur;
use MeteoSI\Provider\Evenement\CategorieEvenementProvider;

/**
 * Class ReOpenEvenementFieldset
 */
class ReOpenEvenementFieldset extends AbstractEntityFieldset implements InputFilterProviderInterface
{
    /**
     * @var AddEditEvenementValidator $evenementValidator
     */
    protected $evenementValidator;

    /** @var DateAnterieureCheckerValidator $dateAnterieureCheckerValidator */
    protected $dateAnterieureCheckerValidator;

    /** @var DestinatairesListValidator $destinatairesListValidator */
    protected $destinatairesListValidator;

    /** @var ReopenCibleCheckerValidator $reopenCibleCheckerValidator */
    protected $reopenCibleCheckerValidator;

    //GETTERS ET SETTERS
    /**
     * @return AddEditEvenementValidator
     */
    public function getEvenementValidator(): AddEditEvenementValidator
    {
        return $this->evenementValidator;
    }

    /**
     * @param AddEditEvenementValidator $evenementValidator
     */
    public function setEvenementValidator(AddEditEvenementValidator $evenementValidator): void
    {
        $this->evenementValidator = $evenementValidator;
    }

    /**
     * @return DateAnterieureCheckerValidator
     */
    public function getDateAnterieureCheckerValidator(): DateAnterieureCheckerValidator
    {
        return $this->dateAnterieureCheckerValidator;
    }

    /**
     * @param DateAnterieureCheckerValidator $dateAnterieureCheckerValidator
     */
    public function setDateAnterieureCheckerValidator(DateAnterieureCheckerValidator $dateAnterieureCheckerValidator): void
    {
        $this->dateAnterieureCheckerValidator = $dateAnterieureCheckerValidator;
    }

    /**
     * @return DestinatairesListValidator
     */
    public function getDestinatairesListValidator(): DestinatairesListValidator
    {
        return $this->destinatairesListValidator;
    }

    /**
     * @param DestinatairesListValidator $destinatairesListValidator
     */
    public function setDestinatairesListValidator(DestinatairesListValidator $destinatairesListValidator): void
    {
        $this->destinatairesListValidator = $destinatairesListValidator;
    }

    /**
     * @return ReopenCibleCheckerValidator
     */
    public function getReopenCibleCheckerValidator(): ReopenCibleCheckerValidator
    {
        return $this->reopenCibleCheckerValidator;
    }

    /**
     * @param ReopenCibleCheckerValidator $reopenCibleCheckerValidator
     */
    public function setReopenCibleCheckerValidator(ReopenCibleCheckerValidator $reopenCibleCheckerValidator): void
    {
        $this->reopenCibleCheckerValidator = $reopenCibleCheckerValidator;
    }

//For having only the targets without any ongoing evenement
    /**
     * @param Evenement $evenement
     * @return void
     */
    public function setCibles(Evenement $evenement): void
    {
        //Query for getting all the targets ∉ the group
        $em = $this->getEntityManager();
        $cibles = $em->getRepository(CibleEvenement::class)->findAll();
        usort($cibles, function (CibleEvenement $c1, CibleEvenement $c2) {
            if($c1->getCategorieCible()->getId() == $c2->getCategorieCible()->getId())
                return strcmp($c1->getLibelle(), $c2->getLibelle());

            return strcmp($c1->getCategorieLibelle(), $c2->getCategorieLibelle());
        });

        $options = [];
        /** @var CibleEvenement $cible */
        foreach ($cibles as $cible):
            $options[$cible->getCategorieCible()->getCode()]['label'] = $cible->getCategorieLibelle();
            $options[$cible->getCategorieCible()->getCode()]['options'][$cible->getId()] = $cible->getLibelle();
        endforeach;

        $this->get('cible')->setValueOptions($options);
    }

    /**
     * @return void
     */
    public function setEtats(): void
    {
        $em = $this->getEntityManager();
        $etats = $em->getRepository(EtatEvenement::class)->findAll();
        $etats = array_filter($etats, function (EtatEvenement $e){
            return ($e->getCode() !== 'termine');
        });

        $options = [];
        /** @var EtatEvenement $etat */
        foreach ($etats as $etat):
            $options[$etat->getId()] = $etat->getLibelle();
        endforeach;

        $this->get('etat')->setValueOptions($options);
    }

    /**
     * @return void
     */
    public function setCategories(): void
    {
        $em = $this->getEntityManager();
        $categories = $em->getRepository(CategorieEvenement::class)->findAll();
        $categories = array_filter($categories, function (CategorieEvenement $c){
            return ($c->getCode() !== CategorieEvenementProvider::CATEGORIE_EVENEMENT_INDETERMINEE_CODE);
        });

        $options = [];
        /** @var CategorieEvenement $categorie */
        foreach ($categories as $categorie):
            $options[$categorie->getId()] = $categorie->getLibelle();
        endforeach;

        $this->get('categorie')->setValueOptions($options);
    }

//INITIALISATION ET CONTROLE DE LA CLASSE

    public function init()
    {
        $this->add([
            'type' => ObjectSelect::class,
            'name' => 'evenementRef',
            'options' => [
//                'label' => 'Evenement référente',
                'empty_option' => 'Sélectionner un événement',
                'object_manager' => $this->getEntityManager(),
                'target_class' => Evenement::class,
                'property' => 'id',
                'find_method' => [
                    'name' => 'findBy',
                    'params' => [
                        'criteria' => [],
                        'orderBy' => ['id' => 'ASC'],
                    ],
                ],
                'disable_inarray_validator' => true,
            ],
            'attributes' => [
                'id' => 'evenementRef',
            ],
        ]);

        $this->add([
            'type' => ObjectSelect::class,
            'name' => 'categorie',
            'options' => [
//                'label' => "Catégorie de l'événement",
                'empty_option' => 'Sélectionner une catégorie',
                'object_manager' => $this->getEntityManager(),
                'target_class' => CategorieEvenement::class,
                'property' => 'libelle',
                'find_method' => [
                    'name' => 'findBy',
                    'params' => [
                        'criteria' => [],
                        'orderBy' => ['libelle' => 'ASC'],
                    ],
                ],
                'disable_inarray_validator' => true,
            ],
            'attributes' => [
                'id' => 'categorie',
            ],
        ]);

        $this->add([
            'type' => Select::class,
            'name' => 'cible',
            'options' => [
//                'label' => "Cible de l'événement",
                'empty_option' => 'Sélectionner une cible',
                'value_options' => [],
                'disable_inarray_validator' => true,
            ],
            'attributes' => [
                'id' => 'cible',
            ],
        ]);

        //For managing the target state when there's an event on it
        $this->add([
            'type' => ObjectSelect::class,
            'name' => 'etatCible',
            'options' => [
//                'label' => "Etat de la cible de l'événement",
                'empty_option' => "Sélectionner l'état de la cible",
                'object_manager' => $this->getEntityManager(),
                'target_class' => EtatCible::class,
                'property' => 'libelle',
                'find_method' => [
                    'name' => 'findBy',
                    'params' => [
                        'criteria' => [],
                        'orderBy' => ['libelle' => 'ASC'],
                    ],
                ],
                'disable_inarray_validator' => true,
            ],
            'attributes' => [
                'id' => 'etatCible',
            ],
        ]);

        $this->add([
            'name' => 'description',
            'type' => Textarea::class,
            'options' => [
                'label' => 'Description',
            ],
            'attributes' => [
                'id' => 'description',
                'rows' => 3,
                'placeholder' => "Mise à jour des serveurs...",
            ],
        ]);

        $this->add([
            'name' => 'actionsPrevues',
            'type' => Textarea::class,
            'options' => [
                'label' => 'Actions à réaliser',
            ],
            'attributes' => [
                'id' => 'actionsPrevues',
                'rows' => 3,
                'placeholder' => "Intervention du fournisseur internet dans la matinée",
            ],
        ]);

        $this->add([
            'name' => 'dateDebut',
            'type' => Date::class,
            'options' => [
                'label' => 'Date',
            ],
            'attributes' => [
                'id' => 'dateDebut',
            ],
        ]);

        $this->add([
            'name' => 'heureDebut',
            'type' => Time::class,
            'options' => [
                'label' => 'Heure',
                'format' => 'H:i',
            ],
            'attributes' => [
                'id' => 'heureDebut',
            ],
        ]);

        $this->add([
            'name' => 'dateFinEstimee',
            'type' => Date::class,
            'options' => [
                'label' => 'Date',
            ],
            'attributes' => [
                'id' => 'dateFinEstimee',
            ],
        ]);

        $this->add([
            'name' => 'heureFinEstimee',
            'type' => Time::class,
            'options' => [
                'label' => 'Heure',
                'format' => 'H:i',
            ],
            'attributes' => [
                'id' => 'heureFinEstimee',
            ],
        ]);

        $this->add([
            'name' => 'dateFinMinimale',
            'type' => Date::class,
            'options' => [
                'label' => 'Date',
            ],
            'attributes' => [
                'id' => 'dateFinMinimale',
            ],
        ]);

        $this->add([
            'name' => 'heureFinMinimale',
            'type' => Time::class,
            'options' => [
                'label' => 'Heure',
                'format' => 'H:i',
            ],
            'attributes' => [
                'id' => 'heureFinMinimale',
            ],
        ]);

        $this->add([
            'name' => 'dureeInconnue',
            'type' => Checkbox::class,
            'options' => [
                'label' => "Oui",
                'use_hidden_element' => true,
                'checked_value' => true,
                'unchecked_value' => false,
            ],
            'attributes' => [
                'id' => 'dureeInconnue',
            ]
        ]);

        $this->add([
            'name' => 'commentaireDureeInconnue',
            'type' => Textarea::class,
            'options' => [
                'label' => 'Explications',
            ],
            'attributes' => [
                'id' => 'commentaireDureeInconnue',
                'rows' => 3,
                'placeholder' => "Problème à grande échelle: serveur ldap HS",
            ],
        ]);

        $this->add([
            'type' => Select::class,
            'name' => 'etat',
            'options' => [
//                'label' => "État de l'événement",
                'empty_option' => 'Sélectionner un état',
                'value_options' => [],
                'disable_inarray_validator' => true,
            ],
            'attributes' => [
                'id' => 'etat',
            ],
        ]);

        $this->add([
            'name' => 'publieIntranet',
            'type' => Checkbox::class,
            'options' => [
                'label' => "Visible hors de l'application (flux RSS, page d'information)",
                'use_hidden_element' => true,
                'checked_value' => true,
                'unchecked_value' => false,
            ],
            'attributes' => [
                'id' => 'publieIntranet',
                'checked' => true,
            ],
        ]);

        $this->add([
            'name' => 'publieInternet',
            'type' => Checkbox::class,
            'options' => [
                'label' => "Visible sur Internet",
                'use_hidden_element' => true,
                'checked_value' => true,
                'unchecked_value' => false,
            ],
            'attributes' => [
                'id' => 'publieInternet',
            ],
        ]);

        $this->add([
            'name' => 'envoiMail',
            'type' => Checkbox::class,
            'options' => [
                'label' => "Oui",
                'use_hidden_element' => true,
                'checked_value' => true,
                'unchecked_value' => false,
            ],
            'attributes' => [
                'id' => 'envoiMail',
                'checked' => true,
            ]
        ]);

        $this->add([
            'name' => 'destinataires',
            'type' => Textarea::class,
            'options' => [
//                'label' => 'Les destinataires',
            ],
            'attributes' => [
                'id' => 'destinataires',
                'rows' => 5,
                'placeholder' => "no-reply@unicaen.fr, ...",
            ],
        ]);

        $this->add([
            'name' => 'complementInformations',
            'type' => Textarea::class,
            'options' => [
//                'label' => 'Complément d'informations',
            ],
            'attributes' => [
                'id' => 'complementInformations',
                'placeholder' => "complément d'informations...",
            ],
        ]);

        $this->add([
            'name' => 'displayNameCreateur',
            'type' => Text::class,
            'options' => [
//                'label' => 'Nom à afficher',
            ],
            'attributes' => [
                'id' => 'displayNameCreateur',
                'placeholder' => "Jean-Philippe",
            ],
        ]);

        $this->add([
            'type' => ObjectSelect::class,
            'name' => 'pole',
            'options' => [
//                'label' => "Pôle à afficher",
                'empty_option' => 'Sélectionner un pôle',
                'object_manager' => $this->getEntityManager(),
                'target_class' => PoleUtilisateur::class,
                'property' => 'libelle',
                'find_method' => [
                    'name' => 'findBy',
                    'params' => [
                        'criteria' => [],
                        'orderBy' => ['libelle' => 'ASC'],
                    ],
                ],
                'disable_inarray_validator' => true,
            ],
            'attributes' => [
                'id' => 'pole',
            ],
        ]);

        $this->add([
            'name' => 'checkbox-mail-cibles-enfants',
            'type' => Checkbox::class,
            'options' => [
                'label' => "Oui informer les autres",
                'use_hidden_element' => true,
                'checked_value' => true,
                'unchecked_value' => false,
            ],
            'attributes' => [
                'id' => 'checkbox-mail-cibles-enfants',
            ]
        ]);
    }

    public function getInputFilterSpecification()
    {
        $inputFilter = [];

        $inputFilter['evenementRef'] = [
            'name' => 'evenementRef',
            'required' => false,
            'filters' => [
                ['name' => ToInt::class],
            ],
        ];

        $inputFilter['categorie'] = [
            'name' => 'categorie',
            'required' => true,
            'filters' => [
                ['name' => ToInt::class],
                [
                    'name' => ToNull::class,
                    'options' => [
                        ToNull::TYPE_INTEGER
                    ],
                ],
            ],
        ];

        $inputFilter['cible'] = [
            'name' => 'cible',
            'required' => true,
            'filters' => [
                ['name' => ToInt::class],
                [
                    'name' => ToNull::class,
                    'options' => [
                        ToNull::TYPE_INTEGER
                    ],
                ],
            ],
            'validators' => [
                $this->getReopenCibleCheckerValidator(),
            ],
        ];

        $inputFilter['etatCible'] = [
            'name' => 'etatCible',
            'required' => true,
            'filters' => [
                ['name' => ToInt::class],
                [
                    'name' => ToNull::class,
                    'options' => [
                        ToNull::TYPE_INTEGER
                    ],
                ],
            ],
        ];

        $inputFilter['description'] = [
            'name' => 'description',
            'required' => true,
            'filters' => [
                //StringTrim == remove the unnecessary spaces (\r or \t or \n...) at each line start/end
                ['name' => StringTrim::class],
            ],
            'validators' => [
                [
                    'name' => StringLength::class,
                    'options' => [
                        'encoding' => 'UTF-8',
                        'min' => 1,
                    ],
                ],
            ],
        ];

        $inputFilter['actionsPrevues'] = [
            'name' => 'actionsPrevues',
            'required' => false,
            'filters' => [
                //StringTrim == remove the unnecessary spaces (\r or \t or \n...) at each line start/end
                ['name' => StringTrim::class],
            ],
            'validators' => [
                [
                    'name' => StringLength::class,
                    'options' => [
                        'encoding' => 'UTF-8',
                        'min' => 1,
                    ],
                ],
            ],
        ];

        $inputFilter['dateDebut'] = [
            'name' => 'dateDebut',
            'required' => true,
            'validators' => [
                $this->getDateAnterieureCheckerValidator(),
            ],
        ];

        $inputFilter['heureDebut'] = [
            'name' => 'heureDebut',
            'required' => true,
            'validators' => [
                $this->getDateAnterieureCheckerValidator(),
            ],
        ];

        //Durée estimée
        $inputFilter['dateFinEstimee'] = [
            'name' => 'dateFinEstimee',
            'required' => false,
            'validators' => [
                $this->getDateAnterieureCheckerValidator(),
                $this->getEvenementValidator(),
            ],
        ];

        $inputFilter['heureFinEstimee'] = [
            'name' => 'heureFinEstimee',
            'required' => false,
            'validators' => [
                $this->getDateAnterieureCheckerValidator(),
                $this->getEvenementValidator(),
            ],
        ];

        //Durée min
        $inputFilter['dateFinMinimale'] = [
            'name' => 'dateFinMinimale',
            'required' => false,
            'validators' => [
                $this->getDateAnterieureCheckerValidator(),
                $this->getEvenementValidator(),
            ],
        ];

        $inputFilter['heureFinMinimale'] = [
            'name' => 'heureFinMinimale',
            'required' => false,
            'validators' => [
                $this->getDateAnterieureCheckerValidator(),
                $this->getEvenementValidator(),
            ],
        ];

        //Durée inconnue
        $inputFilter['dureeInconnue'] = [
            'name' => 'dureeInconnue',
            'required' => false,
            'filters' => [
                ['name' => ToInt::class],
            ],
            'validators' => [
                $this->getEvenementValidator(),
            ],
        ];

        $inputFilter['commentaireDureeInconnue'] = [
            'name' => 'commentaireDureeInconnue',
            'required' => false,
            'filters' => [
                //StripTags == remove the unwanted html tags
                //StringTrim == remove the unnecessary spaces (\r or \t or \n...) at each line start/end
                ['name' => StringTrim::class],
            ],
            'validators' => [
                [
                    'name' => StringLength::class,
                    'options' => [
                        'encoding' => 'UTF-8',
                        'min' => 1,
                    ],
                ],
                $this->getEvenementValidator(),
            ],
        ];

        $inputFilter['etat'] = [
            'name' => 'etat',
            'required' => true,
            'filters' => [
                ['name' => ToInt::class],
                [
                    'name' => ToNull::class,
                    'options' => [
                        ToNull::TYPE_INTEGER
                    ],
                ],
            ],
        ];

        $inputFilter['publieIntranet'] = [
            'name' => 'publieIntranet',
            'required' => false,
            'filters' => [
                ['name' => ToInt::class],
            ],
        ];

        $inputFilter['publieInternet'] = [
            'name' => 'publieInternet',
            'required' => false,
            'filters' => [
                ['name' => ToInt::class],
            ],
        ];

        //Envoi de mail
        $inputFilter['envoiMail'] = [
            'name' => 'envoiMail',
            'required' => false,
            'filters' => [
                ['name' => ToInt::class],
            ],
            'validators' => [
                //TODO Validator pour envoiMail et destinataires + Mail
                $this->getDestinatairesListValidator(),
            ],
        ];

        $inputFilter['destinataires'] = [
            'name' => 'destinataires',
            'required' => false,
            'filters' => [
                //StripTags == remove the unwanted html tags
                //StringTrim == remove the unnecessary spaces (\r or \t or \n...) at each line start/end
                ['name' => StripTags::class],
                ['name' => StringTrim::class],
            ],
            'validators' => [
                [
                    'name' => StringLength::class,
                    'options' => [
                        'encoding' => 'UTF-8',
                        'min' => 1,
                    ],
                ],
                $this->getDestinatairesListValidator(),
            ],
        ];

        $inputFilter['complementInformations'] = [
            'name' => 'complementInformations',
            'required' => false,
            'filters' => [
                //StripTags == remove the unwanted html tags
                //StringTrim == remove the unnecessary spaces (\r or \t or \n...) at each line start/end
                ['name' => StringTrim::class],
            ],
            'validators' => [
                [
                    'name' => StringLength::class,
                    'options' => [
                        'encoding' => 'UTF-8',
                        'min' => 1,
                    ],
                ],
                //$this->getEvenementValidator(),
            ],
        ];

        $inputFilter['pole'] = [
            'name' => 'pole',
            'required' => false,
            'filters' => [
                ['name' => ToInt::class],
                [
                    'name' => ToNull::class,
                    'options' => [
                        ToNull::TYPE_INTEGER
                    ],
                ],
            ],
        ];

        $inputFilter['displayNameCreateur'] = [
            'name' => 'displayNameCreateur',
            'required' => false,
            'filters' => [
                //StripTags == remove the unwanted html tags
                //StringTrim == remove the unnecessary spaces (\r or \t or \n...) at each line start/end
                ['name' => StripTags::class],
                ['name' => StringTrim::class],
            ],
            'validators' => [
                [
                    'name' => StringLength::class,
                    'options' => [
                        'encoding' => 'UTF-8',
                        'min' => 1,
                        'max' => 255,
                    ],
                ],
            ],
        ];

        $inputFilter['checkbox-mail-cibles-enfants'] = [
            'name' => 'checkbox-mail-cibles-enfants',
            'required' => false,
            'filters' => [
                ['name' => ToInt::class],
            ],
            'validators' => [
                //TODO Validator pour envoiMail et destinataires + Mail
                //$this->getDestinatairesListValidator(),
            ],
        ];

        return $inputFilter;
    }
}
