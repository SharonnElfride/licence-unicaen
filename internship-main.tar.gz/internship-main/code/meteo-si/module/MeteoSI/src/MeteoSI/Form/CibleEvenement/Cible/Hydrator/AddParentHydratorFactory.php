<?php

namespace MeteoSI\Form\CibleEvenement\Cible\Hydrator;

use Doctrine\ORM\EntityManager;
use Interop\Container\Containerinterface;
use Laminas\ServiceManager\Factory\FactoryInterface;
use MeteoSI\Service\CibleEvenement\Dependance\RegleTransition\RegleTransitionService;

class AddParentHydratorFactory implements FactoryInterface
{
    /**
     * Create hydrator
     *
     * @return AddParentHydrator
     */
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        /** @var AddParentHydrator $hydrator */
        $hydrator = new AddParentHydrator();

        /** @var EntityManager $entityManager */
        $entityManager = $container->get(EntityManager::class);
        $hydrator->setEntityManager($entityManager);

        /** @var RegleTransitionService $regleTrensitionService */
        $regleTrensitionService = $container->get(RegleTransitionService::class);
        $hydrator->setRegleTransitionService($regleTrensitionService);

        return $hydrator;
    }
}