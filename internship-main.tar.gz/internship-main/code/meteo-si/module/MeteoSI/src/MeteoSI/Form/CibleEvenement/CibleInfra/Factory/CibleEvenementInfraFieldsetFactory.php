<?php

namespace MeteoSI\Form\CibleEvenement\CibleInfra\Factory;

use Doctrine\Laminas\Hydrator\DoctrineObject;
use Doctrine\ORM\EntityManager;
use Interop\Container\ContainerInterface;
use Laminas\ServiceManager\Factory\FactoryInterface;
use Laminas\Validator\ValidatorPluginManager;
use MeteoSI\Form\CibleEvenement\Cible\Validator\StateEditValidator;
use MeteoSI\Form\CibleEvenement\CibleInfra\CibleEvenementInfraFieldset;
use MeteoSI\Form\CibleEvenement\CibleInfra\Hydrator\CibleEvenementInfraHydrator;
use MeteoSI\Model\CibleEvenementInfra;

/**
 * Class CibleEvenementInfraFieldsetFactory
 */
class CibleEvenementInfraFieldsetFactory implements FactoryInterface
{
    /**
     * Create fieldset
     *
     * @param ContainerInterface $container
     * @param string $requestedName
     * @param array|null $options
     * @return CibleEvenementInfraFieldset|object
     */
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        /** @var CibleEvenementInfraFieldset $fieldset */
        $fieldset = new CibleEvenementInfraFieldset('cibleEvenementInfra');

        /** @var EntityManager $entityManager */
        $entityManager = $container->get(EntityManager::class);
        $fieldset->setEntityManager($entityManager);

        /** @var CibleEvenementInfraHydrator $hydrator */
        $hydrator = $container->get('HydratorManager')->get(CibleEvenementInfraHydrator::class);
        $fieldset->setHydrator($hydrator);
        $fieldset->setObject(new CibleEvenementInfra());
        return $fieldset;
    }
}
