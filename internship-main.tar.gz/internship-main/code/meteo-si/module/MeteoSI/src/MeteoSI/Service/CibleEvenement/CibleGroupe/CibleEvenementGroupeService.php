<?php

namespace MeteoSI\Service\CibleEvenement\CibleGroupe;

use Application\Application\Service\API\CommonEntityService;
use DateTime;
use Doctrine\ORM\OptimisticLockException;
use Doctrine\ORM\ORMException;
use MeteoSI\Model\CategorieCible;
use MeteoSI\Model\CibleDependance;
use MeteoSI\Model\CibleDependancePriorite;
use MeteoSI\Model\CibleEvenement;
use MeteoSI\Model\CibleEvenementGroupe;
use MeteoSI\Service\CibleEvenement\CibleEvenementService;

/**
 * Class CibleEvenementGroupeService
 * @package MeteoSI\Service\CibleEvenement\CibleGroupe
 */
class CibleEvenementGroupeService extends CommonEntityService
{
    /** @return string */
    public function getEntityClass()
    {
        return CibleEvenementGroupe::class;
    }

    //Retourne une nouvelle instance de l'entité courante
    public function getEntityInstance($name = null)
    {
        return $this->getEntityInstance($name);
    }

    //Add a new line to the table db
    /**
     * @param CibleEvenementGroupe $entity
     *
     * @override
     * @throws ORMException
     * @throws OptimisticLockException
     */
    public function add($entity, $serviceEntityClass = null)
    {
        return parent::add($entity, $serviceEntityClass);
    }

    /**
     * @param CibleEvenementGroupe $entity
     * @param CibleEvenementService $cibleService
     *
     * @return mixed
     * @throws ORMException
     * @throws OptimisticLockException
     */
    public function addCibleReelle(CibleEvenementGroupe $entity, CibleEvenementService $cibleService)
    {
        /** @var CategorieCible $cat */
        $cat = $this->getEntityManager()->getRepository(CategorieCible::class)->findOneBy(['code' => 'groupecible']);
        $entity->setCategorieCible($cat);
        $entity->setDateModification($entity->getDateCreation());

        $cibleService->add($entity->getCible());
        return $this->add($entity);
    }

    //Update a new line to the table db

    /**
     * @override
     * @throws ORMException
     * @throws OptimisticLockException
     */
    public function update($entity, $serviceEntityClass = null)
    {
        $entity->setDateModification(new DateTime());
        return parent::update($entity, $serviceEntityClass);
    }

    /**
     * @param CibleEvenementGroupe $entity
     * @param CibleEvenementService $cibleService
     *
     * @override
     * @throws ORMException
     * @throws OptimisticLockException
     */
    public function updateCibleReelle(CibleEvenementGroupe $entity, CibleEvenementService $cibleService)
    {
        $entity->setDateModification(new DateTime());

        $cibleService->update($entity->getCible());
        return parent::update($entity);
    }

    /**
     * Remove the link between 2 entities
     *
     * @param $entity1
     * @param $entity2
     * @return void
     */
    public function unleash($entity1, $entity2)
    {
        //Update the 2 entities at the end
    }

    //Delete the table line indexed with the id=$id

    /**
     * @override
     * @throws ORMException
     * @throws OptimisticLockException
     */
    public function delete($entity, $serviceEntityClass = null)
    {
        return parent::delete($entity, $serviceEntityClass);
    }

    /**
     * @param CibleEvenementGroupe $entity
     * @param CibleEvenementService $cibleService
     *
     * @throws ORMException
     * @throws OptimisticLockException
     */
    public function deleteCibleReelle(CibleEvenementGroupe $entity, CibleEvenementService $cibleService)
    {
        return $this->delete($entity);
    }

    public function findAll()
    {
        return $this->findAllBy([], ["id" => "ASC"]);
    }

    //For managing Adding target to and Removing target from a group
    /**
     * @param CibleEvenementGroupe $entity
     * @param CibleEvenement $cible
     * @return mixed
     * @throws ORMException
     * @throws OptimisticLockException
     */
    public function addTargetToGroup(CibleEvenementGroupe $entity, CibleEvenement $cible)
    {
        $entity->addCible($cible);
        return $this->update($entity);
    }

    /**
     * @param CibleEvenementGroupe $entity
     * @param CibleEvenement $cible
     * @return mixed
     * @throws ORMException
     * @throws OptimisticLockException
     */
    public function removeTargetFromGroup(CibleEvenementGroupe $entity, CibleEvenement $cible)
    {
        $entity->removeCible($cible);
        return $this->update($entity);
    }
}