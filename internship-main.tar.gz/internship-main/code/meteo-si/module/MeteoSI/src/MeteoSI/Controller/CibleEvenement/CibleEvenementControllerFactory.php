<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace MeteoSI\Controller\CibleEvenement;

use Interop\Container\ContainerInterface;
use Laminas\ServiceManager\Factory\FactoryInterface;
use MeteoSI\Form\CibleEvenement\Cible\AddParentForm;
use MeteoSI\Form\CibleEvenement\CibleApplication\CibleEvenementApplicationForm;
use MeteoSI\Form\CibleEvenement\CibleBdd\CibleEvenementBddForm;
use MeteoSI\Form\CibleEvenement\CibleGroupe\AddTargetToGroupForm;
use MeteoSI\Form\CibleEvenement\CibleGroupe\CibleEvenementGroupeForm;
use MeteoSI\Form\CibleEvenement\CibleInfra\CibleEvenementInfraForm;
use MeteoSI\Form\CibleEvenement\Cible\CibleEvenementForm;
use MeteoSI\Form\CibleEvenement\CibleService\CibleEvenementServiceForm;
use MeteoSI\Service\CibleEvenement\CibleGroupe\CibleEvenementGroupeService;
use MeteoSI\Service\CibleEvenement\CibleEvenementService;
use MeteoSI\Service\CibleEvenement\CibleApplication\CibleEvenementApplicationService;
use MeteoSI\Service\CibleEvenement\CibleBdd\CibleEvenementBddService;
use MeteoSI\Service\CibleEvenement\CibleInfra\CibleEvenementInfraService;
use MeteoSI\Service\CibleEvenement\CibleService\CibleEvenementServiceService;
use MeteoSI\Service\CibleEvenement\Dependance\CibleDependance\CibleDependanceService;
use MeteoSI\Service\CibleEvenement\Dependance\EtatCible\EtatCibleService;
use MeteoSI\Service\CibleEvenement\Dependance\RegleTransition\RegleTransitionService;

class CibleEvenementControllerFactory implements FactoryInterface
{

    public function __invoke(ContainerInterface $container, $requestedName, ?array $options = null)
    {
        /** @var CibleEvenementController $controller */
        $controller = new CibleEvenementController();

        /** @var CibleEvenementService $entityService */
        $entityService = $container->get(CibleEvenementService::class);
        $controller->setCibleEvenementService($entityService);

        //SERVICES des différents types de cibles
        /** @var CibleEvenementApplicationService $entityService */
        $entityService = $container->get(CibleEvenementApplicationService::class);
        $controller->setCibleApplicationService($entityService);

        /** @var CibleEvenementBddService $entityService */
        $entityService = $container->get(CibleEvenementBddService::class);
        $controller->setCibleBaseDeDonneesService($entityService);

        /** @var CibleEvenementInfraService $entityService */
        $entityService = $container->get(CibleEvenementInfraService::class);
        $controller->setCibleInfrastructureService($entityService);

        /** @var CibleEvenementServiceService $entityService */
        $entityService = $container->get(CibleEvenementServiceService::class);
        $controller->setCibleServiceService($entityService);

        /** @var CibleEvenementGroupeService $entityService */
        $entityService = $container->get(CibleEvenementGroupeService::class);
        $controller->setCibleGroupeService($entityService);

        /** @var CibleDependanceService $entityService */
        $entityService = $container->get(CibleDependanceService::class);
        $controller->setCibleDependanceService($entityService);

        /** @var EtatCibleService $entityService */
        $entityService = $container->get(EtatCibleService::class);
        $controller->setEtatCibleService($entityService);

        /** @var RegleTransitionService $entityService */
        $entityService = $container->get(RegleTransitionService::class);
        $controller->setRegleTransitionService($entityService);

        //FORMS
        /** @var CibleEvenementApplicationForm $cibleForm */
        $cibleForm = $container->get('FormElementManager')->get(CibleEvenementApplicationForm::class);
        $controller->setCibleApplicationForm($cibleForm);

        /** @var CibleEvenementBddForm $cibleForm */
        $cibleForm = $container->get('FormElementManager')->get(CibleEvenementBddForm::class);
        $controller->setCibleBaseDeDonneesForm($cibleForm);

        /** @var CibleEvenementInfraForm $cibleForm */
        $cibleForm = $container->get('FormElementManager')->get(CibleEvenementInfraForm::class);
        $controller->setCibleInfrastructureForm($cibleForm);

        /** @var CibleEvenementServiceForm $cibleForm */
        $cibleForm = $container->get('FormElementManager')->get(CibleEvenementServiceForm::class);
        $controller->setCibleServiceForm($cibleForm);

        /** @var CibleEvenementGroupeForm $cibleForm */
        $cibleForm = $container->get('FormElementManager')->get(CibleEvenementGroupeForm::class);
        $controller->setCibleGroupeForm($cibleForm);

        /** @var AddTargetToGroupForm $cibleForm */
        $cibleForm = $container->get('FormElementManager')->get(AddTargetToGroupForm::class);
        $controller->setAddTargetToGroupForm($cibleForm);

        /** @var AddParentForm $cibleForm */
        $cibleForm = $container->get('FormElementManager')->get(AddParentForm::class);
        $controller->setAddParentForm($cibleForm);

        return $controller;
    }
}
