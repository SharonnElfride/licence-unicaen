<?php

namespace MeteoSI\Controller\CibleEvenement;

use Application\Application\Misc\RouterToolsTrait;
use Doctrine\DBAL\Driver\Exception;
use Doctrine\ORM\OptimisticLockException;
use Doctrine\ORM\ORMException;
use Laminas\Mvc\Controller\AbstractActionController;
use Laminas\View\Model\JsonModel;
use Laminas\View\Model\ViewModel;
use MeteoSI\Controller\Evenement\EvenementController;
use MeteoSI\Form\CibleEvenement\Cible\Traits\CibleEvenementFormTrait;
use MeteoSI\Model\CibleDependance;
use MeteoSI\Model\CibleEvenement;
use MeteoSI\Model\CibleEvenementApplication;
use MeteoSI\Model\CibleEvenementBdd;
use MeteoSI\Model\CibleEvenementGroupe;
use MeteoSI\Model\CibleEvenementInfra;
use MeteoSI\Model\CibleEvenementService;
use MeteoSI\Model\EtatCible;
use MeteoSI\Model\RegleTransition;
use MeteoSI\Service\CibleEvenement\CibleEvenementServiceAwareTrait;
use MeteoSI\Service\CibleEvenement\Dependance\EtatCible\EtatCibleServiceAwareTrait;
use MeteoSI\Service\CibleEvenement\Dependance\RegleTransition\RegleTransitionServiceAwareTrait;
use RuntimeException;

class CibleEvenementController extends AbstractActionController
{
    use CibleEvenementServiceAwareTrait;
    use CibleEvenementFormTrait;
    use EtatCibleServiceAwareTrait;
    use RegleTransitionServiceAwareTrait;
    use RouterToolsTrait;

    private $route = 'cible-evenement';

    public function indexAction()
    {
        return new ViewModel([
            'applications' => $this->getCibleApplicationService()->findAll(),
            'basesDeDonnees' => $this->getCibleBaseDeDonneesService()->findAll(),
            'infrastructures' => $this->getCibleInfrastructureService()->findAll(),
            'services' => $this->getCibleServiceService()->findAll(),
            'groupesCibles' => $this->getCibleGroupeService()->findAll(),
        ]);
    }

    public function showAction()
    {
        $id = $this->getParamFromRoute('id');
        $categorie = $this->getParamFromRoute('categorie');

        switch ($categorie) {
            case 'application':
                $cible = $this->getCibleApplicationService()->find($id);
                break;
            case 'bdd':
                $cible = $this->getCibleBaseDeDonneesService()->find($id);
                break;
            case 'infra':
                $cible = $this->getCibleInfrastructureService()->find($id);
                break;
            case 'service':
                $cible = $this->getCibleServiceService()->find($id);
                break;
            case 'groupecible':
                $cible = $this->getCibleGroupeService()->find($id);
                break;
            default:
                throw new RuntimeException("Il n'existe pas de catégorie dénomée: " . $categorie);
        }

        return new ViewModel([
            'cibleRecu' => $cible,
            'categorie' => $categorie,
            'idsEtatCible' => $this->getEtatCibleService()->findAllId(),
        ]);
    }

    public function showtargetwithoutdetailsAction()
    {
        $id = $this->getParamFromRoute('id');
        $categorie = $this->getParamFromRoute('categorie');

        switch ($categorie) {
            case 'application':
            case 'bdd':
            case 'infra':
            case 'service':
            case 'groupecible':
                /** @var CibleEvenement $cible */
                $cible = $this->getCibleEvenementService()->find($id);
                break;
            default:
                throw new RuntimeException("Il n'existe pas de catégorie dénomée: " . $categorie);
        }

        $title = strtoupper($cible->getLibelle());

        return new ViewModel([
            'cibleRecu' => $cible,
            'categorie' => $categorie,
            'title' => $title,
        ]);
    }

    /**
     * @throws OptimisticLockException
     * @throws ORMException
     */
    public function addAction()
    {
        $categorie = $this->getParamFromRoute('categorie');

        switch ($categorie) {
            case 'application':
            {
                $cible = new CibleEvenementApplication();
                $form = $this->getCibleApplicationForm();
                $service = $this->getCibleApplicationService();
                break;
            }
            case 'bdd':
            {
                $cible = new CibleEvenementBdd();
                $form = $this->getCibleBaseDeDonneesForm();
                $service = $this->getCibleBaseDeDonneesService();
                break;
            }
            case 'infra':
            {
                $cible = new CibleEvenementInfra();
                $form = $this->getCibleInfrastructureForm();
                $service = $this->getCibleInfrastructureService();
                break;
            }
            case 'service':
            {
                $cible = new CibleEvenementService();
                $form = $this->getCibleServiceForm();
                $service = $this->getCibleServiceService();
                break;
            }
            case 'groupecible':
            {
                $cible = new CibleEvenementGroupe();
                $form = $this->getCibleGroupeForm();
                $service = $this->getCibleGroupeService();
                break;
            }
            default:
                throw new RuntimeException("Il n'existe pas de catégorie dénomée: " . $categorie);
        }

        $form->bind($cible);
        $form->get('submit')->setValue('Ajouter');
        $request = $this->getRequest();

        if (!$request->isPost()) {
            return new ViewModel(['formRecu' => $form]);
        }

        $form->setData($request->getPost());

        if (!$form->isValid()) {
            //If the form is not valid, we'll render/redisplay the same form with the wrong data in the concerned fields with the 'why' they are wrong
            return ['formRecu' => $form];
        }

        $cible = $form->getObject();

        /*
         * try {
                    $this->privilegeService->create($privilege);
                    $this->flashMessenger()->addSuccessMessage(sprintf("Privilège <strong>%s</strong> créé avec succès.", $privilege->getLibelle()));
                } catch (Exception $e) {
                    $this->flashMessenger()->addErrorMessage(sprintf("Une erreur est survenu lors de la création du privilège <strong>%s</strong>.", $privilege->getLibelle()));
                }
         */

        $service->addCibleReelle($cible, $this->getCibleEvenementService());

        if($categorie === 'groupecible'):
            $message = "Le groupe " . $cible->getLibelle() . " a bien été créé!";
        else:
            $message = "La cible " . $cible->getLibelle() . " de catégorie " . $cible->getCategorieCible()->getLibelle() . " a bien été créée!";
        endif;

        $this->flashMessenger()->addSuccessMessage($message);
        return $this->redirect()->toRoute($this->route, ['action' => 'index']);
    }

    /**
     * @throws OptimisticLockException
     * @throws ORMException
     */
    public function editAction()
    {
        $id = $this->getParamFromRoute('id');
        $categorie = $this->getParamFromRoute('categorie');

        switch ($categorie) {
            case 'application':
            {
                $cible = $this->getCibleApplicationService()->find($id);
                $form = $this->getCibleApplicationForm();
                $service = $this->getCibleApplicationService();
                $title = "Modification de l'application ";
                break;
            }
            case 'bdd':
            {
                $cible = $this->getCibleBaseDeDonneesService()->find($id);
                $form = $this->getCibleBaseDeDonneesForm();
                $service = $this->getCibleBaseDeDonneesService();
                $title = "Modification de la base de données ";
                break;
            }
            case 'infra':
            {
                $cible = $this->getCibleInfrastructureService()->find($id);
                $form = $this->getCibleInfrastructureForm();
                $service = $this->getCibleInfrastructureService();
                $title = "Modification de l'infrastructure ";
                break;
            }
            case 'service':
            {
                $cible = $this->getCibleServiceService()->find($id);
                $form = $this->getCibleServiceForm();
                $service = $this->getCibleServiceService();
                $title = "Modification du service ";
                break;
            }
            case 'groupecible':
            {
                $cible = $this->getCibleGroupeService()->find($id);
                $form = $this->getCibleGroupeForm();
                $service = $this->getCibleGroupeService();
                $title = "Modification du groupe ";
                break;
            }
            default:
                throw new RuntimeException("Il n'existe pas de catégorie dénomée: " . $categorie);
        }

        $form->bind($cible);
        if($categorie === 'groupecible')
            $form->getEntityFieldset()->getCodeValidator()->setEntite($cible);

        $form->get('submit')->setValue('Enrégistrer');
        $request = $this->getRequest();

        $title .= $cible->getLibelle();
        if (!$request->isPost()) {
            return new ViewModel(['formRecu' => $form, 'cibleRecu' => $cible, 'title' => $title]);
        }

        $form->setData($request->getPost());

        if (!$form->isValid()) {
            //If the form is not valid, we'll render/redisplay the same form with the wrong data in the concerned fields with the 'why' they are wrong
            return ['formRecu' => $form, 'cibleRecu' => $cible, 'title' => $title];
        }

        $cible = $form->getObject();
        $service->updateCibleReelle($cible, $this->getCibleEvenementService());

        if($categorie === 'groupecible'):
            $message = "Le groupe " . $cible->getLibelle() . " a bien été modifié!";
        else:
            $message = "La cible " . $cible->getLibelle() . " a bien été modifiée!";
        endif;

        $this->flashMessenger()->addSuccessMessage($message);
        return $this->redirect()->toRoute($this->route . "/show", ['categorie' => $categorie, 'id' => $id]);
    }

    /**
     * @throws OptimisticLockException
     * @throws ORMException
     */
    public function deleteAction()
    {
        $id = $this->getParamFromRoute('id');
        $categorie = $this->getParamFromRoute('categorie');

        switch ($categorie) {
            case 'application':
            {
                $cible = $this->getCibleApplicationService()->find($id);
                $service = $this->getCibleApplicationService();
                break;
            }
            case 'bdd':
            {
                $cible = $this->getCibleBaseDeDonneesService()->find($id);
                $service = $this->getCibleBaseDeDonneesService();
                break;
            }
            case 'infra':
            {
                $cible = $this->getCibleInfrastructureService()->find($id);
                $service = $this->getCibleInfrastructureService();
                break;
            }
            case 'service':
            {
                $cible = $this->getCibleServiceService()->find($id);
                $service = $this->getCibleServiceService();
                break;
            }
            case 'groupecible':
            {
                $cible = $this->getCibleGroupeService()->find($id);
                $service = $this->getCibleGroupeService();
                break;
            }
            default:
                throw new RuntimeException("Il n'existe pas de catégorie dénomée: " . $categorie);
        }

        if($categorie !== 'groupecible'):
            $message = "La cible " . $cible->getLibelle() . " de catégorie " . $cible->getCategorieCible()->getLibelle() . " a bien été supprimée!";
        else:
            $message = "Le groupe " . $cible->getLibelle() . " a bien été supprimé!";
        endif;
        $request = $this->getRequest();

        if ($request->isPost()) {
            $del = $request->getPost('del', 'Non');

            if ($del === 'Oui') {
                $service->deleteCibleReelle($cible, $this->getCibleEvenementService());
                $this->flashMessenger()->addSuccessMessage($message);
            }

            return $this->redirect()->toRoute($this->route, ['action' => 'index']);
        }

        return new ViewModel(["cible" => $cible]);
    }

    //Adding target to and Removing target from a group
    public function addtargettogroupAction()
    {
        $id = $this->getParamFromRoute('id');
        $groupe = $this->getCibleGroupeService()->find($id);
        $service = $this->getCibleGroupeService();
        $form = $this->getAddTargetToGroupForm();
        $form->getEntityFieldset()->setGroupe($groupe);

        $form->bind($groupe);
        $form->get('submit')->setValue('Ajouter');
        $request = $this->getRequest();

        $title = "Ajout d'une cible au groupe " . $groupe->getLibelle();
        if (!$request->isPost()) {
            return new ViewModel(['form' => $form, 'groupe' => $groupe, 'title' => $title]);
        }

        $form->setData($request->getPost());

        if (!$form->isValid()) {
            //If the form is not valid, we'll render/redisplay the same form with the wrong data in the concerned fields with the 'why' they are wrong
            return ['form' => $form, 'groupe' => $groupe, 'title' => $title];
        }

        $idCible = intval($request->getPost()->get('addTargetToGroup')['cible']);
        $cible = $this->getCibleEvenementService()->find($idCible);

        $groupe = $form->getObject();
        $service->addTargetToGroup($groupe, $cible);

        $message = "Une cible d'événement a bien été ajoutée au groupe " . $groupe->getLibelle();

        $this->flashMessenger()->addSuccessMessage($message);
        return $this->redirect()->toRoute($this->route . "/show", ['categorie' => 'groupecible', 'id' => $id]);
    }

    public function removetargetfromgroupAction()
    {
        $id = $this->getParamFromRoute('id');
        $id2 = $this->getParamFromRoute('id2');

        /** @var CibleEvenementGroupe $groupe */
        $groupe = $this->getCibleGroupeService()->find($id);
        /** @var CibleEvenement $cible */
        $cible = $this->getCibleEvenementService()->find($id2);
        $service = $this->getCibleGroupeService();

        $title = "Retrait d'une cible du groupe " . $groupe->getLibelle();
        $message = "La cible " . $cible->getLibelle() . " a bien été retirée du groupe " . $groupe->getLibelle();
        $request = $this->getRequest();

        if ($request->isPost()) {
            $removeFromGroup = $request->getPost('remove-from-group', 'Non');

            if ($removeFromGroup === 'Oui') {
                $service->removeTargetFromGroup($groupe, $cible);
                $this->flashMessenger()->addSuccessMessage($message);
            }

            return $this->redirect()->toRoute($this->route . "/show", ['categorie' => 'groupecible', 'id' => $id]);
        }

        return new ViewModel(['groupe' => $groupe, 'cible' => $cible, 'title' => $title]);
    }

    //Adding a parent and Removing a parent
    public function addparentAction()
    {
        $idEnfant = $this->getParamFromRoute('id');
        $categorie = $this->getParamFromRoute('categorie');

        /** @var CibleEvenement $enfant */
        $enfant = $this->getCibleEvenementService()->find($idEnfant);

        $form = $this->getAddParentForm();
        $form->getEntityFieldset()->setCibles($enfant);

        $form->bind($enfant);
        $form->get('submit')->setValue('Ajouter');
        $request = $this->getRequest();

        $title = "Ajout d'un parent à la liste des parents de " . $enfant->getLibelle();
        if (!$request->isPost()) {
            return new ViewModel(['form' => $form, 'enfant' => $enfant, 'title' => $title]);
        }

        $form->setData($request->getPost());

        if (!$form->isValid()) {
            //If the form is not valid, we'll render/redisplay the same form with the wrong data in the concerned fields with the 'why' they are wrong
            return ['form' => $form, 'enfant' => $enfant, 'title' => $title];
        }

        if($enfant->getCategorieCible()->getCode() !== $categorie)
        {
            $this->flashMessenger()->addErrorMessage("Le code de la catégorie de <span class='fw-bold'>" . $enfant->getLibelle() . "</span> est incorrect.");
            $this->flashMessenger()->addInfoMessage("Le code de la catégorie de <span class='fw-bold'>" . $enfant->getLibelle() . "</span> est <span class='fw-bold'>" . $enfant->getCategorieCible()->getCode() . "</span>! Veuillez vérifier l'url!");
            return ['form' => $form, 'enfant' => $enfant, 'title' => $title];
        }

        $idParent = intval($request->getPost()->get('addParent')['cible']);
        $cParent = $this->getCibleEvenementService()->find($idParent);

        /** @var CibleEvenement $enfant */
        $enfant = $form->getObject();
        $etatNewParent = $enfant->getDependencyToAdd()->getParent()->getEtat();
        $this->getCibleEvenementService()->addParent($enfant, $this->getCibleDependanceService(), $enfant->getDependencyToAdd());
        $enfant->changeStateByTransitionRule($etatNewParent);
        $this->getCibleEvenementService()->update($enfant);

        $message = $cParent->getLibelle() . " a bien été ajouté(e) à la liste des parents de " . $enfant->getLibelle();
        $this->flashMessenger()->addSuccessMessage($message);

        $idEnfant = $enfant->getCategorieEntite()->getId();
        return $this->redirect()->toRoute($this->route . "/show", ['categorie' => $enfant->getCategorieCible()->getCode(), 'id' => $idEnfant]);
    }

    public function changetransitionruleAction()
    {
        $idDependance = $this->getParamFromRoute('idDependance');
        $idEtatParent = $this->getParamFromRoute('idEtatParent');
        $idEtatEnfant = $this->getParamFromRoute('idEtatEnfant');

        /** @var CibleDependance $dependance */
        $dependance = $this->getCibleDependanceService()->find($idDependance);
        /** @var EtatCible $etatParent */
        $etatParent = $this->getEtatCibleService()->find($idEtatParent);
        /** @var EtatCible $etatEnfant */
        $etatEnfant = $this->getEtatCibleService()->find($idEtatEnfant);

        $oldRule = null;

        /** @var RegleTransition $regle */
        foreach ($dependance->getRegleTransitions() as $regle):
            if($regle->getEtatParent()->getId() == $idEtatParent):
                $oldRule = $regle;
            break;
            endif;
        endforeach;
        $dependance->removeRegleTransition($oldRule);

        /** @var RegleTransition $newRule */
        $newRule = $this->getRegleTransitionService()->findOneBy([
            'etatParent' => $etatParent,
            'etatEnfant' => $etatEnfant,
        ]);

        $data = [];
        try {
            $dependance->addRegleTransition($newRule);
            $this->getCibleDependanceService()->update($dependance);
            $dependance->getEnfant()->changeStateByTransitionRule();
            $this->getCibleEvenementService()->update($dependance->getEnfant());

            $data = [
              'idDependance' => $idDependance,
              'idEtatParent' => $idEtatParent,
              'idEtatEnfant' => $idEtatEnfant,
              'idOldRule' => $oldRule->getId(),
              'idNewRule' => $newRule->getId(),
            ];

            return new JsonModel([
                'message' => "La règle de transition a été modifiée avec succès.",
                'status' => 'success',
                'result' => $data,
            ]);
        }
        catch (Exception $e) {
        return new JsonModel([
        'message' => "Une erreur est survenue lors de la modification de la règle de transition sélectionnée",
        'status' => 'error',
        'result' => $data,
        ]);
        }
    }

    public function removeparentAction()
    {
        //TODO Display the target groups if it's not a group
        //TODO Change the state like TV taught me this morning - call it when i'm setting the state while "adding, editing, reopening" an evenement
        //TODO If a target remove

        $idEnfant = $this->getParamFromRoute('id');
        $idParent = $this->getParamFromRoute('id2');

        /** @var CibleEvenement $enfant */
        $enfant = $this->getCibleEvenementService()->find($idEnfant);
        /** @var CibleEvenement $parent */
        $parent = $this->getCibleEvenementService()->find($idParent);

        $service = $this->getCibleEvenementService();

        $title = "Retrait d'une cible de la liste des parents de " . $enfant->getLibelle();
        $message = "La cible <b>" . $parent->getLibelle() . "</b> a bien été retirée de la liste des parents de <b>" . $enfant->getLibelle() . "</b>.";
        $request = $this->getRequest();

        if ($request->isPost()) {
            $removeFromParents = $request->getPost('remove-from-parents', 'Non');

            if ($removeFromParents === 'Oui') {
                $service->removeParent($enfant, $parent, $this->getCibleDependanceService());
                $enfant->changeStateByTransitionRule();
                $service->update($enfant);
                $this->flashMessenger()->addSuccessMessage($message);
            }

            $idEnfant = $enfant->getCategorieEntite()->getId();
            return $this->redirect()->toRoute($this->route . "/show", ['categorie' => $enfant->getCategorieCible()->getCode(), 'id' => $idEnfant]);
        }

        return new ViewModel(['enfant' => $enfant, 'parent' => $parent, 'title' => $title]);
    }

    /**
     * Changing the children list on addEvenement Page
     *
     * @see EvenementController::addAction()
     * @return JsonModel
     */
    public function changechildrenlistAction() {
        $idTarg = $this->getParamFromRoute('id');
        $targetStateDuringEvent = $this->getParamFromRoute('target-state-during-event');
        /** @var CibleEvenement $target */
        $target = $this->getCibleEvenementService()->find($idTarg);

        $childrenList = "";
        foreach ($target->getEnfants() as $enfant) {
            //$childrenList .= $enfant->getLibelle();
            $childState = "";
            foreach ($target->getDependanceEnfants() as $depE) {
                if($depE->getEnfant()->getId() === $enfant->getId()) {
                    foreach ($depE->getRegleTransitions() as $rt) {
                        if($targetStateDuringEvent === $rt->getEtatParent()->getCode()) {
                            $childState = $rt->getEtatEnfant()->getLibelle();
//                            $childrenList .= "[" . $childState . "], ";
//                            break;
                        }
                    }
                    break;
                }
            }
            $childrenList .= "<span class='fw-bold ms-2'>#" . $enfant->getLibelle() . "[" . $childState . "] </span>";
        }

        try {
            $data = [
                'childrenList' => $childrenList,
            ];

            return new JsonModel([
                'message' => "La liste des enfants a été extraite avec succès.",
                'status' => 'success',
                'result' => $data,
            ]);
        }
        catch (Exception $e) {
            return new JsonModel([
                'message' => "Une erreur est survenue lors de l'extraction de la liste des enfants de la cible sélectionnée",
                'status' => 'error',
                'result' => $data,
            ]);
        }
    }
}
