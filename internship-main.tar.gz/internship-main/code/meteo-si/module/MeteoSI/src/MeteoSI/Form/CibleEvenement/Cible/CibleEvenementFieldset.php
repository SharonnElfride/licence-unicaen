<?php

namespace MeteoSI\Form\CibleEvenement\Cible;

use Application\Application\Form\AbstractEntityFieldset;
use DoctrineModule\Form\Element\ObjectSelect;
use Laminas\Filter\StringTrim;
use Laminas\Filter\StripTags;
use Laminas\Filter\ToInt;
use Laminas\Filter\ToNull;
use Laminas\Form\Element\Date;
use Laminas\Form\Element\Number;
use Laminas\Form\Element\Text;
use Laminas\Form\Element\Textarea;
use Laminas\InputFilter\InputFilterProviderInterface;
use Laminas\Validator\StringLength;
use MeteoSI\Model\EtatCible;

/**
 * Class CibleEvenementFieldset
 */
class CibleEvenementFieldset extends AbstractEntityFieldset implements InputFilterProviderInterface
{
    public function init()
    {
        $this->add([
            'name' => 'id',
            'type' => 'hidden',
        ]);

        $this->add([
            'name' => 'libelle',
            'type' => Text::class,
            'options' => [
//                'label' => 'Libellé de la cible',
                'max' => 255,
            ],
            'attributes' => [
                'placeholder' => 'libellé',
            ],
        ]);

        $this->add([
            'name' => 'description',
            'type' => Textarea::class,
            'options' => [
//                'label' => 'Description de la cible',
            ],
            'attributes' => [
                'id' => 'description',
                'rows' => 2,
                'placeholder' => 'description',
            ],
        ]);

        $this->add([
            'type'    => ObjectSelect::class,
            'name'    => 'etat',
            'options' => [
//                'label' => 'Etat de la cible',
                'empty_option' => 'Sélectionner un état',
                'object_manager' => $this->getEntityManager(),
                'target_class' => EtatCible::class,
                'property' => 'libelle',
                'find_method' => [
                    'name' => 'findBy',
                    'params' => [
                        'criteria' => [],
                        'orderBy' => ['libelle' => 'ASC'],
                    ],
                ],
                'disable_inarray_validator' => true,
            ],
            'attributes' => [
                'id' => 'etat',
            ],
        ]);

        $this->add([
            'name' => 'codeSource',
            'type' => Text::class,
            'options' => [
//                'label' => 'Code Source de la cible',
                'max' => 255,
            ],
            'attributes' => [
                'placeholder' => 'meteosi',
            ],
        ]);

        $this->add([
            'name' => 'idSource',
            'type' => Number::class,
            'options' => [
//                'label' => 'Identifiant Source de la cible',
            ],
            'attributes' => [
                'placeholder' => '1',
            ],
        ]);

        $this->add([
            'name' => 'dateCreation',
            'type' => Date::class,
            'options' => [
//                'label' => 'Date',
            ],
            'attributes' => [
                'id' => 'dateCreation',
            ],
        ]);
    }

    public function getInputFilterSpecification()
    {
        $inputFilter = [];

        $inputFilter['id'] = [
            'name' => 'id',
            'required' => true,
            'filters' => [
                ['name' => ToInt::class],
            ],
        ];

        $inputFilter['libelle'] = [
            'name' => 'libelle',
            'required' => true,
            'filters' => [
                ['name' => StripTags::class],
                ['name' => StringTrim::class],
            ],
            'validators' => [
                [
                    'name' => StringLength::class,
                    'options' => [
                        'encoding' => 'UTF-8',
                        'min' => 1,
                    ],
                ],
            ],
        ];

        $inputFilter['description'] = [
            'name' => 'description',
            'required' => false,
            'filters' => [
                ['name' => StringTrim::class],
            ],
            'validators' => [
                [
                    'name' => StringLength::class,
                    'options' => [
                        'encoding' => 'UTF-8',
                        'min' => 1,
                    ],
                ],
            ],
        ];

        $inputFilter['etat'] = [
            'name' => 'etat',
            'required' => true,
            'filters' => [
                ['name' => ToInt::class],
                [
                    'name' => ToNull::class,
                    'options' => [
                        ToNull::TYPE_INTEGER
                    ],
                ],
            ],
        ];

        $inputFilter['codeSource'] = [
            'name' => 'codeSource',
            'required' => false,
            'filters' => [
                //StripTags == remove the unwanted html tags
                //StringTrim == remove the unnecessary spaces (\r or \t or \n...) at each line start/end
                ['name' => StripTags::class],
                ['name' => StringTrim::class],
            ],
            'validators' => [
                [
                    'name' => StringLength::class,
                    'options' => [
                        'encoding' => 'UTF-8',
                        'min' => 1,
                    ],
                ],
            ],
        ];

        $inputFilter['idSource'] = [
            'name' => 'idSource',
            'required' => false,
            'filters' => [
                ['name' => ToInt::class],
            ],
        ];

        $inputFilter['dateCreation'] = [
            'name' => 'dateCreation',
            'required' => true,
        ];

        return $inputFilter;
    }
}
