<?php

namespace MeteoSI\Controller\Evenement;

use Application\Application\Misc\RouterToolsTrait;
use Application\Application\Misc\UserAwaireTrait;
use Application\Application\View\Renderer\PhpRenderer;
use DateTime;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\DBAL\Driver\Exception;
use Doctrine\ORM\OptimisticLockException;
use Doctrine\ORM\ORMException;
use Laminas\Db\Sql\Predicate\In;
use Laminas\Mvc\Controller\AbstractActionController;
use Laminas\Router\RouterConfigTrait;
use Laminas\View\Model\JsonModel;
use Laminas\View\Model\ViewModel;
use MeteoSI\Form\Evenement\Traits\EvenementFormTrait;
use MeteoSI\MeteoSI\Service\Mailing\MailService;
use MeteoSI\Model\CategorieEvenement;
use MeteoSI\Model\CibleEvenement;
use MeteoSI\Model\Evenement;
use MeteoSI\Provider\CibleEvenement\EtatCibleProvider;
use MeteoSI\Provider\Mailing\CodesMailsProvider;
use MeteoSI\Service\CategorieEvenement\CategorieEvenementServiceAwareTrait;
use MeteoSI\Service\CibleEvenement\CibleEvenementServiceAwareTrait;
use MeteoSI\Service\CibleEvenement\Dependance\EtatCible\EtatCibleServiceAwareTrait;
use MeteoSI\Service\Evenement\EvenementServiceAwareTrait;
use MeteoSI\View\Helper\Calendar\CalendarViewHelper;
use MeteoSI\View\Helper\Calendar\CalendarViewHelperTrait;
use UnicaenApp\Service\EntityManagerAwareTrait;
use UnicaenMail\Service\Mail\MailServiceAwareTrait;

class EvenementController extends AbstractActionController
{
    use EntityManagerAwareTrait;
    use EvenementServiceAwareTrait;
    use EvenementFormTrait;
    use RouterToolsTrait;
    use UserAwaireTrait;
    use MailServiceAwareTrait;
    use EtatCibleServiceAwareTrait;
    use CategorieEvenementServiceAwareTrait;

    /** @var array|null $days */
    private ?array $days;

    /** @var array|null $months */
    private ?array $months;

    /** @var string $route */
    private $route = "evenement";

    /**
     * @param array|null $days
     * @return void
     */
    public function setDays(?array $days = null): void
    {
        $this->days = $days;
    }

    /**
     * @param array|null $months
     * @return void
     */
    public function setMonths(?array $months = null): void
    {
        $this->months = $months;
    }

    public function indexAction(): ViewModel
    {
        return new ViewModel([
            'evenements' => $this->getEvenementService()->findAll(),
            'categoriesEvenement' => $this->getCategorieService()->findAll(),
        ]);
    }

    public function showAction()
    {
        $id = $this->getParamFromRoute('id');
        $evenement = $this->getEvenementService()->find($id);

        return new ViewModel([
            'evenement' => $evenement,
        ]);
    }

    /**
     * @throws OptimisticLockException
     * @throws ORMException
     */
    public function addAction()
    {
        $evenement = new Evenement();

        if(($this->getParamFromRoute('day') !== null) && ($this->getParamFromRoute('month') !== null) && ($this->getParamFromRoute('year') !== null)) {
            $day =  $this->getParamFromRoute('day');
            $month = $this->getParamFromRoute('month');
            $year = $this->getParamFromRoute('year');

            $date = $day . "-" . $month . "-" . $year;
            $date = new DateTime($date);

            $evenement->setDateDebut($date);
        }

        $form = $this->getEvenementForm();
        $form->getEntityFieldset()->setCibles($evenement);
        $form->getEntityFieldset()->setEtats();
        $form->bind($evenement);
        $form->get('submit')->setValue('Ajouter');
        $request = $this->getRequest();
        $allStates = $this->getEtatCibleService()->findAll();

        if (!$request->isPost()) {
            return new ViewModel(['form' => $form, 'allStates' => $allStates]);
        }

        $form->setData($request->getPost());
        if (!$form->isValid()) {
            //If the form is not valid, we'll render/redisplay the same form with the wrong data in the concerned fields with the 'why' they are wrong
            return ['form' => $form, 'allStates' => $allStates];
        }

        /** @var Evenement $evenement */
        $evenement = $form->getObject();
        $evenement->setId(null);
        $this->getEvenementService()->add($evenement);

        //Gestion des mails -- Verifier si "envoyer le mail" est cochée
        //$destinataires = 'thibaut.vallee@unicaen.fr, 22010454@etu.unicaen.fr' ;
        if ($evenement->getEnvoiMail()) {
            /** @var MailService $mailService */
            $mailService = $this->getMailService();
            $mailService->sendMailType(CodesMailsProvider::NOUVEL_EVENEMENT, ['evenement' => $evenement,]);

            $sendMailToChild = boolval($request->getPost()->get('evenement')['checkbox-mail-cibles-enfants']);
            if ($sendMailToChild):
                foreach ($evenement->getCible()->getEnfants() as $enfant) {
                    $mailService->sendMailType(CodesMailsProvider::MAIL_D_ENREGISTREMENT_ENVOYE_AUX_CIBLES_ENFANTS, ['evenement' => $evenement, 'cibleEnfant' => $enfant]);
                }
            endif;
        }

        $this->flashMessenger()->addSuccessMessage("L'événement n°" . $evenement->getId() . " a bien été créée!");
        return $this->redirect()->toRoute($this->route . "/show", ['id' => $evenement->getId()]);
    }

    /**
     * @throws OptimisticLockException
     * @throws ORMException
     */
    public function editAction()
    {
        $id = $this->getParamFromRoute('id');
        $evenement = $this->getEvenementService()->find($id);
        $form = $this->getEvenementForm();
        $form->getEntityFieldset()->setCibles($evenement);
        $form->getEntityFieldset()->setEtats();
        $form->bind($evenement);
        $form->get('submit')->setValue('Enrégistrer');
        $request = $this->getRequest();
        $allStates = $this->getEtatCibleService()->findAll();

        $title = "Modification de l'événement n°" . $evenement->getId();

        if (!$request->isPost()) {
            return new ViewModel(['form' => $form, 'evenement' => $evenement, 'title' => $title, 'allStates' => $allStates]);
        }

        $form->setData($request->getPost());

        if (!$form->isValid()) {
            //If the form is not valid, we'll render/redisplay the same form with the wrong data in the concerned fields with the 'why' they are wrong
            return ['form' => $form, 'evenement' => $evenement, 'title' => $title, 'allStates' => $allStates];
        }

        /** @var Evenement $evenement */
        $evenement = $form->getObject();
        $this->getEvenementService()->update($evenement);

        //Gestion des mails -- Verifier si "envoyer le mail" est cochée
        //$destinataires = 'thibaut.vallee@unicaen.fr, 22010454@etu.unicaen.fr' ;
        if ($evenement->getEnvoiMail()) {
            /** @var MailService $mailService */
            $mailService = $this->getMailService();
            $mailService->sendMailType(CodesMailsProvider::MODIFICATION_EVENEMENT, ['evenement' => $evenement,]);

            $sendMailToChild = boolval($request->getPost()->get('evenement')['checkbox-mail-cibles-enfants']);
            if ($sendMailToChild):
                foreach ($evenement->getCible()->getEnfants() as $enfant) {
                    $mailService->sendMailType(CodesMailsProvider::MAIL_DE_MODIFICATION_ENVOYE_AUX_CIBLES_ENFANTS, ['evenement' => $evenement, 'cibleEnfant' => $enfant]);
                }
            endif;
        }
        $this->flashMessenger()->addSuccessMessage("L'événement n°" . $evenement->getId() . " a bien été modifiée!");
        return $this->redirect()->toRoute($this->route . "/show", ['id' => $id]);
    }

    /**
     * @throws OptimisticLockException
     * @throws ORMException
     */
    public function unleashAction()
    {
        $idEnfant = $this->getParamFromRoute('id');
        $enfant = $this->getEvenementService()->find($idEnfant);

        $idParent = $this->getParamFromRoute('id2');
        $parent = $this->getEvenementService()->find($idParent);

        $request = $this->getRequest();

        if ($request->isPost()) {
            $del = $request->getPost('unleash', 'Annuler');

            if ($del === 'Détacher') {
                $this->getEvenementService()->unleash($enfant);
                $this->flashMessenger()->addSuccessMessage("L'événement n°" . $idEnfant . " a bien été détachée de l'événement " . $idParent . "!");
            }

            return $this->redirect()->toRoute($this->route . "/show", ['id' => $idEnfant]);
        }

        return new ViewModel([
            'parent' => $parent,
            'enfant' => $enfant,
        ]);
    }

    /**
     * @throws OptimisticLockException
     * @throws ORMException
     */
    public function reopenAction()
    {
        $id = $this->getParamFromRoute('id');
        /** @var Evenement $evenement */
        $evenement = $this->getEvenementService()->find($id);

        $form = $this->getReOpenEvenementForm();
        $form->getEntityFieldset()->setCibles($evenement);
        $form->getEntityFieldset()->setEtats();
        $form->getEntityFieldset()->getReopenCibleCheckerValidator()->setIdReopeningEvenement($evenement->getID());
        $form->bind($evenement);
        $form->get('submit')->setValue('Réouvrir');
        $request = $this->getRequest();
        $allStates = $this->getEtatCibleService()->findAll();

        $title = "Réouverture de l'événement n°" . $evenement->getId();

        if (!$request->isPost()) {
            return new ViewModel(['form' => $form, 'evenement' => $evenement, 'title' => $title, 'allStates' => $allStates]);
        }

        $form->setData($request->getPost());

        if (!$form->isValid()) {
            //If the form is not valid, we'll render/redisplay the same form with the wrong data in the concerned fields with the 'why' they are wrong
            return ['form' => $form, 'evenement' => $evenement, 'ttle' => $title, 'allStates' => $allStates];
        }

        $evenement = $form->getObject();
        $this->getEvenementService()->reopen($evenement);

        //Gestion des mails -- Verifier si "envoyer le mail" est cochée
        //$destinataires = 'thibaut.vallee@unicaen.fr, 22010454@etu.unicaen.fr' ;
        if ($evenement->getEnvoiMail()) {
            /** @var MailService $mailService */
            $mailService = $this->getMailService();
            $mailService->sendMailType(CodesMailsProvider::RE_OUVERTURE_EVENEMENT, ['evenement' => $evenement,]);

            $sendMailToChild = boolval($request->getPost()->get('evenement')['checkbox-mail-cibles-enfants']);
            if ($sendMailToChild):
                foreach ($evenement->getCible()->getEnfants() as $enfant) {
                    $mailService->sendMailType(CodesMailsProvider::MAIL_DE_REOUVERTURE_ENVOYE_AUX_CIBLES_ENFANTS, ['evenement' => $evenement, 'cibleEnfant' => $enfant]);
                }
            endif;
        }

        $this->flashMessenger()->addSuccessMessage("L'événement n°" . $evenement->getId() . " a bien été réouverte!");
        return $this->redirect()->toRoute($this->route . "/show", ['id' => $id]);
    }

    private function cloneHelper(Evenement $source, Evenement $destination)
    {
        $destination->setEvenementRef($source);
        $destination->setCategorie($source->getCategorie());
        $destination->setCible($source->getCible());
        $destination->setDescription($source->getDescription());
        $destination->setActionsPrevues($source->getActionsPrevues());
        $destination->setDateDebut(new DateTime());
        $destination->setDateFinEstimee(null);
        $destination->setDateFinMinimale(null);
        $destination->setDureeInconnue(false);
        $destination->setCommentaireDureeInconnue("");

        $etatLibelle = $source->getEtat()->getLibelle();
        if ($etatLibelle === "Terminé")
            $destination->setEtat(null);
        else
            $destination->setEtat($source->getEtat());

        $destination->setPublieIntranet($source->getPublieIntranet());
        $destination->setPublieInternet($source->getPublieInternet());

        $destination->setEnvoiMail($source->getEnvoiMail());
        $destination->setDestinataires($source->getDestinataires());
        $destination->setPole($source->getPole());
        $destination->setDisplayNameCreateur($source->getDisplayNameCreateur());
    }

    /**
     * @throws OptimisticLockException
     * @throws ORMException
     */
    public function cloneAction()
    {
        $idSource = $this->getParamFromRoute('id');
        $evenementSource = $this->getEvenementService()->find($idSource);
        $evenementDestination = new Evenement();
        $this->cloneHelper($evenementSource, $evenementDestination);

        $form = $this->getEvenementForm();
        $form->getEntityFieldset()->setCibles($evenementDestination);
        $form->getEntityFieldset()->setEtats();
        $form->bind($evenementDestination);
        $form->get('submit')->setValue('Enrégistrer');
        $request = $this->getRequest();
        $allStates = $this->getEtatCibleService()->findAll();

        $title = "Clonage de l'événement n°" . $evenementSource->getId();

        if (!$request->isPost()) {
            return new ViewModel(['form' => $form, 'idSource' => $idSource, 'title' => $title, 'allStates' => $allStates]);
        }

        $form->setData($request->getPost());

        if (!$form->isValid()) {
            //If the form is not valid, we'll render/redisplay the same form with the wrong data in the concerned fields with the 'why' they are wrong
            return ['form' => $form, 'idSource' => $idSource, 'title' => $title, 'allStates' => $allStates];
        }

        $evenementDestination = $form->getObject();
        $this->getEvenementService()->clone($evenementDestination);

        //Gestion des mails -- Verifier si "envoyer le mail" est cochée
        //$destinataires = 'thibaut.vallee@unicaen.fr, 22010454@etu.unicaen.fr' ;
        if ($evenementDestination->getEnvoiMail()) {
            /** @var MailService $mailService */
            $mailService = $this->getMailService();
            $mailService->sendMailType(CodesMailsProvider::NOUVEL_EVENEMENT, ['evenement' => $evenementDestination,]);

            $sendMailToChild = boolval($request->getPost()->get('evenement')['checkbox-mail-cibles-enfants']);
            if ($sendMailToChild):
                foreach ($evenementDestination->getCible()->getEnfants() as $enfant) {
                    $mailService->sendMailType(CodesMailsProvider::MAIL_D_ENREGISTREMENT_ENVOYE_AUX_CIBLES_ENFANTS, ['evenement' => $evenementDestination, 'cibleEnfant' => $enfant]);
                }
            endif;
        }

        $this->flashMessenger()->addSuccessMessage("L'événement n°" . $evenementDestination->getId() . " a bien été créée!");
        return $this->redirect()->toRoute($this->route);
    }

    /**
     * @throws OptimisticLockException
     * @throws ORMException
     */
    public function closeAction()
    {
        $id = $this->getParamFromRoute('id');
        $evenement = $this->getEvenementService()->find($id);
        $formCloture = $this->getClotureEvenementForm();
        $formCloture->bind($evenement);
        $formCloture->get('submit')->setValue('Clore');
        $request = $this->getRequest();

        $title = "Clôture de l'événement n°" . $evenement->getId();

        if (!$request->isPost()) {
            return new ViewModel(['form' => $formCloture, 'evenement' => $evenement, 'title' => $title]);
        }

        $formCloture->setData($request->getPost());

        if (!$formCloture->isValid()) {
            //If the form is not valid, we'll render/redisplay the same form with the wrong data in the concerned fields with the 'why' they are wrong
            return ['form' => $formCloture, 'evenement' => $evenement, 'title' => $title];
        }

        $evenement = $formCloture->getObject();
        $this->getEvenementService()->close($evenement);

        //Gestion des mails -- Verifier si "envoyer le mail" est cochée
        if ($evenement->getEnvoiMail()) {
            /** @var MailService $mailService */
            $mailService = $this->getMailService();
            $mailService->sendMailType(CodesMailsProvider::FIN_EVENEMENT, ['evenement' => $evenement,]);

            /** @var CibleEvenement $enfant */
            foreach ($evenement->getCible()->getEnfants() as $enfant) {
                if ($enfant->getEtat()->getCode() === EtatCibleProvider::ETAT_CIBLE_NORMAL_CODE)
                    $mailService->sendMailType(CodesMailsProvider::MAIL_DE_FIN_ENVOYE_AUX_CIBLES_ENFANTS, ['evenement' => $evenement, 'cibleEnfant' => $enfant]);
            }
        }

        $this->flashMessenger()->addSuccessMessage("L'événement n°" . $evenement->getId() . " a bien été clôturée!");
        return $this->redirect()->toRoute($this->route);
    }

    /**
     * @throws OptimisticLockException
     * @throws ORMException
     */
    public function deleteAction()
    {
        $id = $this->getParamFromRoute('id');
        /** @var Evenement $evenement */
        $evenement = $this->getEvenementService()->find($id);

        $request = $this->getRequest();
        $codeEtatEvenementAvantSuppression = $evenement->getEtat()->getCode();

        if ($request->isPost()) {
            $del = $request->getPost('del', 'Non');

            if ($del === 'Oui') {

                if ($evenement->getEtat()->getCode() !== "encours") {
                    $this->getEvenementService()->delete($evenement);
                    $this->flashMessenger()->addSuccessMessage("L'événement n°" . $id . " a bien été supprimée!");
                } else {
                    $this->flashMessenger()->addErrorMessage("Vous ne pouvez supprimer l'événement n°" . $id . " car elle est toujours en cours!");
                }
            }

            return $this->redirect()->toRoute($this->route);
        }

        return new ViewModel(["evenement" => $evenement]);

//        if ($evenement !== null) {
//            $vm->setTemplate('unicaen-mail/default/confirmation');
//            $vm->setVariables([
//                'title' => "Suppression du mail #" . $evenement->getId(),
//                'text' => "Are you sure that you want to delete '" . $evenement->getTitle() . "' by '" . $evenement->getArtist() . "' ?",
//                'action' => $this->url()->fromRoute('evenement', ["action" => "delete", "id" => $evenement->getId()], [], true),
//            ]);
//        }
//        return $vm;
    }

    /**
     * Remplissage automatique des champs des formulaires d'ajout, d'édition, et autres d'un événement en fonction de l'event de ref choisi
     *
     * @return JsonModel
     */
    public function changeforminputAction()
    {
        $idEvent = $this->getParamFromRoute('id');
        /** @var Evenement $eventRef */
        $eventRef = $this->getEvenementService()->find($idEvent);

        $data = [];
        try {
            $data = [
                'idCategorie' => $eventRef->getCategorie()->getId(),
                'idCible' => $eventRef->getCible()->getId(),
                'idEtatCible' => $eventRef->getCible()->getGivenStateByEvenement()->getId(),
                'description' => $eventRef->getDescription(),
                'actionsPrevues' => $eventRef->getActionsPrevues(),
                'destinataires' => $eventRef->getDestinataires(),
            ];

            return new JsonModel([
                'message' => "L'extraction des données de l'événement de référence a été effectuée avec succès.",
                'status' => 'success',
                'result' => $data,
            ]);
        } catch (Exception $e) {
            return new JsonModel([
                'message' => "Une erreur est survenue lors de l'extraction des données de l'événement de référence sélectionné",
                'status' => 'error',
                'result' => $data,
            ]);
        }
    }

    public function changecalendardateAction()
    {
        $month = $this->getParamFromRoute('month');
        $year = $this->getParamFromRoute('year');
        $evenements = $this->getEvenementService()->findAllByMonthAndYear($month, $year);

        try {
            $firstDay = new DateTime('01-' . $month . '-' . $year);
        } catch (Exception $e) {
            return $e->getMessage();
        }

        $nbDayInMonth = intval($firstDay->format('t'));
        $firstDayNumber = intval($firstDay->format('N'));
        $currentDay = $firstDay;
        $today = new DateTime('now');

        $content = '<tbody id="calendar-table-tbody" class="fs-5">';
        $content .= '<tr class="calendar-body-line">';
        for ($d = 1; $d <= $nbDayInMonth; $d++) {
            //Echappement du début du tableau
            if ($d === 1) {
                for ($j = 1; $j < $firstDayNumber; $j++) {
                    $content .= '<td></td>';
                }
            }

            //Traitement normal
            $numberCurrentDayEvents = 0;
            $currentDayEventsCategoriesColors = [];

            foreach ($evenements as $evenement) {
                if ($evenement->getDateDebut()->format('d-m-Y') === $currentDay->format('d-m-Y')) {
                    $numberCurrentDayEvents++;
                    $color = $evenement->getCategorie()->getCouleur();
                    $libelle = $evenement->getCategorie()->getLibelle();
                    $currentDayEventsCategoriesColors[] = [
                        'color' => $color,
                        'libelle' => $libelle,
                        'informationEvent' => "Événement " . $evenement->getId() . " sur " . $evenement->getCible()->getLibelle() . " #" . $evenement->getEtat()->getLibelle(),
                    ];
                }
            }

            $spanTitle = $numberCurrentDayEvents . " événement(s)";
            $currentDayNumber = $currentDay->format('d');

            //$url = $this->redirect()->toRoute($this->route . '/show-date-events', ['day' => $currentDayNumber, 'month' => $month, 'year' => $year,]);
            $url = $this->getRequest()->getUri()->setPath("/" . $this->route . "/show-date-events/" . $currentDayNumber . "-" . $month . "-" . $year);
            $url = $url->toString();

            $content .= ($numberCurrentDayEvents !== 0) ? '<td title="' . $spanTitle . '" class="position-relative">' : '<td class="position-relative">';
            if ($currentDay->format('d-m-Y') === $today->format('d-m-Y'))
                $content .= '<a id="today" href="' . $url . '" class="fs-5 rounded-circle calendar-button badge badge-calendar-today btn text-light ajax-modal" data-event="event-show-date-events">' . $currentDay->format('d') . '</a>';
            else
                $content .= '<a href="' . $url . '" class="fs-5 calendar-date-number calendar-button rounded-circle badge badge-calendar btn text-dark ajax-modal" data-event="event-show-date-events">' . $currentDay->format('d') . '</a>';

            $content .= '<br/><span>';
            foreach ($currentDayEventsCategoriesColors as $cat) {
                $color = $cat['color'];
                $libelle = $cat['libelle'];
                $infoEvent = $cat['informationEvent'];
                $content .= '<a class="fas fa-square calendar-button btn p-0" tabindex="0" data-bs-toggle="popover" data-bs-trigger="focus" data-bs-placement="top" title="' . $libelle . '" data-bs-content="' . $infoEvent . '" style="color: ' . $color . '"></button>';
            }
            $content .= '</span>';

            //Adding button
            $url = $this->getRequest()->getUri()->setPath("/" . $this->route . "/add/" . $currentDayNumber . "-" . $month . "-" . $year);
            $url = $url->toString();
            $content .= '<div class="mt-2 mb-1 me-2 d-flex justify-content-end position-absolute bottom-0 end-0">';
            $content .= '<a href="' . $url . '" class="text-decoration-none rounded-circle">';
            $content .= '<i class="fas fa-circle-plus fs-4"></i></a>';
            $content .= '</div></td>';

            //Echappement de la fin du tableau
            if ($d === $nbDayInMonth) {
                for ($j = intval($currentDay->format('N')) + 1; $j <= 7; $j++) {
                    $content .= '<td></td>';
                }
            }

            if (intval($currentDay->format('N')) === 7)
                $content .= '</tr><tr class="calendar-body-line">';

            $currentDay = date_add($currentDay, date_interval_create_from_date_string('+1 day'));
        }

        $content .= "</tr></tbody>";

        $data = [];
        try {
            $data = [
                'content' => $content,
                'month' => $month,
                'year' => $year,
            ];

            return new JsonModel([
                'message' => "La mise à jour du calendrier en fonction du mois " . $month . " et de l'année " . $year . " a été effectuée avec succès.",
                'status' => 'success',
                'result' => $data,
            ]);
        } catch (Exception $e) {
            return new JsonModel([
                'message' => "Une erreur est survenue lors de la mise à jour du calendrier en fonction du mois " . $month . " et de l'année " . $year . ".",
                'status' => 'error',
                'result' => $data,
            ]);
        }
    }

    public function showdateeventsAction()
    {
        $day =  $this->getParamFromRoute('day');
        $month = $this->getParamFromRoute('month');
        $year = $this->getParamFromRoute('year');

        $date = $day . "-" . $month . "-" . $year;
        $date = new DateTime($date);

        $dateEventsByCategory = $this->getEvenementService()->findAllByDate($date, true);

        $dayNumber = $date->format('N');
        $date = "";
        foreach($this->days as $jour) {
            if($jour['number'] === intval($dayNumber)) {

                $date .= $jour['value'] . " " . $day;
            }
        };

        foreach($this->months as $mois) {
            if($mois['number'] === intval($month))
                $date .= " " . $mois['value'] . " " . $year;
        };

        $thisHour = intval((new DateTime())->format('H'));
        $iconClass = ((($thisHour >= 19) && ($thisHour < 24)) || (($thisHour >= 00) && ($thisHour < 06))) ? "fa-cloud-moon-rain" : "fa-cloud-sun-rain";
        $title = '<i class="fas ' . $iconClass . ' me-2 fs-2"></i>' . $date;
        if($dateEventsByCategory['numberDayEvents'] !== null)
        $title .= ' - ' . $dateEventsByCategory['numberDayEvents'] . ' événement(s)';

        return new ViewModel([
            'eventsByCategory' => $dateEventsByCategory['eventsByCategory'],
            'title' => $title,
        ]);
    }
}
