<?php

namespace MeteoSI\Service\CategorieEvenement;

/**
 * Trait CategorieEvenementServiceAwareTrait
 * @package MeteoSI\Service\CategorieEvenement
 */
trait CategorieEvenementServiceAwareTrait
{
    /** @var CategorieEvenementService */
    protected $categorieService;

    /**
     * @return CategorieEvenementService
     */
    public function getCategorieService(): CategorieEvenementService
    {
        return $this->categorieService;
    }

    /**
     * @param CategorieEvenementService $categorieService
     */
    public function setCategorieService(CategorieEvenementService $categorieService): void
    {
        $this->categorieService = $categorieService;
    }

}
