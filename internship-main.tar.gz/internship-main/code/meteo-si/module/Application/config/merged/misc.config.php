<?php
/**
 * Divers éléments globaux
 */

use Application\Application\View\Helper\Form\FormControlText;
use Application\Assertion\AbstractAssertionFactory;
use Application\Controller\IndexController;
use UnicaenApp\Form\View\Helper\FormErrors;
use UnicaenPrivilege\Guard\PrivilegeController;

return [
    /** Priviléges pour les actions */
    'bjyauthorize' => [
        'guards' => [
            PrivilegeController::class => [
                [
                    'controller' => IndexController::class,
                    'action' => [
                        'index',
                    ],
                ],
            ],
        ],

        //Definition des ressources utilisées pour les assertions
        'resource_providers' => [
            'BjyAuthorize\Provider\Resource\Config' => [
            ],
        ],
        //Configurations des assertions sur les entités (implique de surcharger derriére la fonction assertEntity
        'rule_providers' => [
            'UnicaenPrivilege\Provider\Rule\PrivilegeRuleProvider' => [
                'allow' => [
                ],
            ],
        ],
    ],

    /** Routes pour les actions */
    'router' => [
        'routes' => [
        ],
    ],

    /** Controlleurs */
    'controllers' => [
        'factories' => [
        ],
    ],

    /** Services */
    'service_manager' => [
        'abstract_factories' => [
            AbstractAssertionFactory::class,
        ],
        'factories' => [
        ],
    ],

    /** Formulaires */
    'form_elements' => [
        'invokables' => [
        ],
        'factories' => [
        ],
    ],

    /** Hydrator */
    'hydrators' => [
        'factories' => [
        ],
    ],

    /** Validateur */
    'validators' => [
        'factories' => [
        ],
    ],

    'view_helpers' => [
        'aliases' => [
            'formerrors' => FormErrors::class,
        ],
        'invokables' => [
            'formControlText' => FormControlText::class,
            'formErrors' => FormErrors::class,
        ],
        'factory' => [
        ]
    ],

    /** Navigation */
    'navigation' => [
        'default' => [
            'home' => [
                'pages' => [
                ],
            ],
        ],
    ],
];
?>