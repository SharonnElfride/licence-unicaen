<?php
/**
 * Fichier de configurations vide pour avoir les clés de base
 * Basé sur UnicaenUtilisateur/UnicaenPrivileges
 */

use Laminas\Router\Http\Literal;
use UnicaenPrivilege\Guard\PrivilegeController;
use UnicaenPrivilege\Provider\Privilege\PrivilegePrivileges;
use UnicaenUtilisateur\Controller\UtilisateurController;
use UnicaenUtilisateur\Provider\Privilege\RolePrivileges;
use UnicaenUtilisateur\Provider\Privilege\UtilisateurPrivileges;

return [
    /** Priviléges pour les actions */
    'bjyauthorize' => [
        'guards' => [
            PrivilegeController::class => [
            ],
        ],

        //Definition des ressources utilisées pour les assertions
        'resource_providers' => [
            'BjyAuthorize\Provider\Resource\Config' => [
            ],
        ],
        //Configurations des assertions sur les entités (implique de surcharger derriére la fonction assertEntity
        'rule_providers' => [
            'UnicaenPrivilege\Provider\Rule\PrivilegeRuleProvider' => [
                'allow' => [
                ],
            ],
        ],
    ],

    /** Routes pour les actions */
    'router' => [
        'routes' => [
            'administration' => [ //Ajoute les pages liée a UnicaenUtilisateur, UnicaenPriviléges ...
                'type' => Literal::class,
                'options' => [
                    'route' => '/administration',
                    'defaults' => [
                        'controller' => UtilisateurController::class,
                        'action' => 'index',
                    ],
                ],
            ],
        ],
    ],

    /** Controlleurs */
    'controllers' => [
        'factories' => [
        ],
    ],

    /** Services */
    'service_manager' => [
        'factories' => [
        ],
    ],

    /** Formulaires */
    'form_elements' => [
        'invokables' => [
        ],
        'factories' => [
        ],
    ],

    /** Hydrator */
    'hydrators' => [
        'factories' => [
        ],
    ],

    /** Validateur */
    'validators' => [
        'factories' => [
        ],
    ],

    /** ViewHelper */
    'view_helpers' => [
        'aliases' => [
        ],
        'factory' => [
        ]
    ],

//    /** Navigation */
    'navigation' => [
        'default' => [
            'home' => [
                'pages' => [
                    'administration' => [
                        'label' => 'Administration',
                        'title' => 'Administration de l\'application',
                        'route' => 'administration',
                        'resource' => UtilisateurPrivileges::getResourceId(UtilisateurPrivileges::UTILISATEUR_AFFICHER),
                        'order' => 100,
                        'pages' => [
                            //Priviléges et utilisateurs
                            'unicaen-utilisateur' => [
                                'label' => 'Gérer les utilisateurs',
                                'title' => 'Gérer les utilisateurs',
                                'route' => 'unicaen-utilisateur',
                                'resource' => UtilisateurPrivileges::getResourceId(UtilisateurPrivileges::UTILISATEUR_AFFICHER),
//                                'icon' => 'fas fa-angle-right',
                            ],
                            'unicaen-role' => [
                                'label' => 'Gérer les rôles',
                                'title' => 'Gérer les rôles',
                                'route' => 'unicaen-role',
                                'resource' => RolePrivileges::getResourceId(RolePrivileges::ROLE_AFFICHER),
                            ],
                            'unicaen-privilege' => [
                                'label' => "Gérer les privilèges",
                                'title' => "Gérer les privilèges",
                                'route' => 'unicaen-privilege',
                                'resource' => PrivilegePrivileges::getResourceId(PrivilegePrivileges::PRIVILEGE_VOIR),
                            ],
                        ],
                    ],
                ],
            ],
        ],
    ],
];
?>