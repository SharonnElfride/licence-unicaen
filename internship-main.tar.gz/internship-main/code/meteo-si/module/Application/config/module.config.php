<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c] 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Application;

use Doctrine\Common\Persistence\Mapping\Driver\MappingDriverChain;
use Doctrine\ORM\Mapping\Driver\XmlDriver;

return [
    'router' => [
        'routes' => [
            'home' => [
                'type' => 'Literal',
                'options' => [
                    'route' => '/',
                    'defaults' => [
                        'controller' => 'Application\Controller\Index', // <-- change here
                        'action' => 'index',
                    ],
                ],
            ],
            // The following is a route to simplify getting started creating
            // new controllers and actions without needing to create a new
            // module. Simply drop new controllers in, and you can access them
            // using the path /application/:controller/:action
            'application' => [
                'type' => 'Literal',
                'options' => [
                    'route' => '/application',
                    'defaults' => [
                        '__NAMESPACE__' => 'Application\Controller',
                        'controller' => 'Index',
                        'action' => 'index',
                    ],
                ],
                'may_terminate' => true,
                'child_routes' => [
                    'default' => [
                        'type' => 'Segment',
                        'options' => [
                            'route' => '/[:controller[/:action]]',
                            'constraints' => [
                                'controller' => '[a-zA-Z][a-zA-Z0-9_-]*',
                                'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                            ],
                            'defaults' => [
                            ],
                        ],
                    ],
                ],
            ],
        ],
    ],
    'service_manager' => [
        'factories' => [

        ],
    ],
    'translator' => [
        'locale' => 'fr_FR', // en_US
        'translation_file_patterns' => [
            [
                'type' => 'gettext',
                'base_dir' => __DIR__ . '/../language',
                'pattern' => '%s.mo',
            ],
        ],
    ],
    'controllers' => [
        'invokables' => [
            'Application\Controller\Index' => Controller\IndexController::class,
        ],
    ],
//    'view_manager'    => [
//        'template_path_stack' => [
//            __DIR__ . '/../view',
//        ],
//    ],

    // Redefinition de la configuration pour utiliser la bonne page de vue
    'view_manager' => [
        // RouteNotFoundStrategy configuration
        'display_not_found_reason' => true, // display 404 reason in template
//        'not_found_template'       => 'error/404', // e.g. '404'
        // ExceptionStrategy configuration
        'display_exceptions' => true,
//        'exception_template'       => 'error/index',
        // Doctype with which to seed the Doctype helper
        'doctype' => 'HTML5',
        // TemplateMapResolver configuration
        // template/path pairs
        'template_map' => [
            'layout/layout' => __DIR__ . '/../view/layout/layout.phtml',
//            'error/404'     => __DIR__ . '/../view/error/404.phtml',
//            'error/index'   => __DIR__ . '/../view/error/index.phtml',
            //            'unicaen-app/application/apropos'                  => __DIR__ . '/../view/application/apropos.phtml',
            //            'unicaen-app/application/contact'                  => __DIR__ . '/../view/application/contact.phtml',
//                        'unicaen-app/application/plan'                     => __DIR__ . '/../view/application/plan.phtml',
            //            'unicaen-app/application/mentions-legales'         => __DIR__ . '/../view/application/mentions-legales.phtml',
            //            'unicaen-app/application/informatique-et-libertes' => __DIR__ . '/../view/application/informatique-et-libertes.phtml',
        ],
        // TemplatePathStack configuration
        'template_path_stack' => [
            __DIR__ . '/../view',
        ],
        // Layout template name
        'layout' => 'layout/layout', // e.g., 'layout/layout'
        // Additional strategies to attach
        'strategies' => [
            'ViewJsonStrategy', // register JSON renderer strategy
            'ViewCsvStrategy', // register CSV renderer strategy
            //            'ViewXmlStrategy', // register XML renderer strategy
            //            'ViewFeedStrategy', // register Feed renderer strategy
        ],
    ],

//    'doctrine' => [
//        'driver' => [
//            'orm_default_driver' => [
//                'class' => XmlDriver::class,
//                'cache' => 'array',
//                'paths' => [__DIR__ . '/../src/Application/Entity/Mapping']
//            ],
//            'orm_default' => [
//                'drivers' => [
//                    __NAMESPACE__ . '\Entity' => 'orm_default_driver'
//                ],
//            ],
//        ],
//    ],

//    'doctrine' => [
//        'driver' => [
//            'orm_default' => [
//                'class' => MappingDriverChain::class,
//                'drivers' => [
//                    'Application\Entity\Db' => 'orm_default_xml_driver',
//                ],
//            ],
//            'orm_default_xml_driver' => [
//                'class' => XmlDriver::class,
//                'cache' => 'apc',
//                'paths' => [
//                    __DIR__ . '/../src/Application/Entity/Mapping',
//                ],
//            ],
//        ],
//        'cache' => [
//            'apc' => [
//                'namespace' => 'Test__' . __NAMESPACE__,
//            ],
//        ],
//    ],

    'doctrine' => [
        'driver' => [
            'orm_default' => [
                'class' => MappingDriverChain::class,
                'drivers' => [
                    'Application\Entity' => 'orm_default_xml_driver',
                ],
            ],
            'orm_default_xml_driver' => [
                'class' => XmlDriver::class,
                'cache' => 'apc',
                'paths' => [
                    __DIR__ . '/../src/Application/Entity/Mapping',
                ],
            ],
        ],
        'cache' => [
            'apc' => [
                'namespace' => 'SMILE__' . __NAMESPACE__,
            ],
        ],
    ],

    'public_files' => [
        'head_scripts' => [
            /** From Unicaen-app, commenté pour en cas d'utilisation d'une autres version possibilité de surchargé les clé **/
//            '015_jquery'   => '/unicaen/app/vendor/jquery-3.6.0.min.js',
            '015_jquery' => '/vendor/Jquery-3.6.0/jquery-3.6.0.min.js',
//            '020_jqueryui' => '/unicaen/app/vendor/jquery-ui-1.12.1/jquery-ui.min.js',
//            '020_jqueryui' => '',
//            '040_bootstrap' => '/unicaen/app/vendor/bootstrap-5.0.2/js/bootstrap.bundle.min.js'
            '040_bootstrap' => '/vendor/bootstrap-5.0.2-dist/js/bootstrap.bundle.js',
        ],
        'inline_scripts' => [
            /** From Unicaen-app, commenté pour en cas d'utilisation d'une autres version possibilité de surchargé les clé **/
            // Listé ici pour qu'en cas de refonte, on puisse surchargé les clé
//            '020_app'         => '/js/app.js',
//            '030_util'        => '/unicaen/app/js/util.js',
//            '040_unicaen'     => '/unicaen/app/js/unicaen.js',
//            '050_jquery_form' => '/unicaen/app/vendor/jquery.form.min.js', // pour l'uploader Unicaen uniquement!!,
            '050_jquery_form' => '',

            /** DataTable (les 0 devant permette de les chargé avant les lib boostrap et éviter des conflits de version */
            '0101_datatables' => 'vendor/DataTables/datatables.min.js',
//            '0102_datatables_datetime'                => 'vendor/DataTables/datetime-moment.js',
//            '103_datatables'                => 'vendor/DataTables/Buttons-2.2.1/js/dataTables.buttons.min.js',
//            '104_datatables'                => 'vendor/DataTables/ColReorder-1.5.5/js/dataTables.colReorder.min.js',
//            '105_datatables'                => 'vendor/DataTables/DateTime-1.1.1/js/dataTables.dateTime.min.js',
//            '106_datatables'                => 'vendor/DataTables/JSZip-2.5.0/jszip.min.js',
//            '107_datatables'                => 'vendor/DataTables/pdfmake-0.1.36/pdfmake.min.js',
//            '108_datatables'                => 'vendor/DataTables/pdfmake-0.1.36/vfs_fonts.js',
            '0109_datatables_responsive' => 'vendor/DataTables/Responsive-2.2.9/js/dataTables.responsive.min.js',
//            '110_datatables'                => 'vendor/DataTables/RowGroup-1.1.4/js/dataTables.rowGroup.min.js',
//            '111_datatables'                => 'vendor/DataTables/RowReorder-1.2.8/js/dataTables.rowReorder.min.js',
            '0112_datatables_stateRestore' => 'vendor/DataTables/StateRestore-1.1.0/js/dataTables.stateRestore.min.js',

            '0113_tinyMce' => 'vendor/tinymce_6.0.2/tinymce/js/tinymce/tinymce.min.js',

            /** Selectipicker */
            '080_bootstrap-select' => 'vendor/bootstrap-select-1.13.9/dist/js/bootstrap-select.min.js',

        ],
        'stylesheets' => [
            /** From Unicaen-app, commenté pour en cas d'utilisation d'une autres version possibilité de surchargé les clé **/
            '010_jquery-ui' => '/unicaen/app/vendor/jquery-ui-1.12.1/jquery-ui.min.css',
            '020_jquery-ui-structure' => '/unicaen/app/vendor/jquery-ui-1.12.1/jquery-ui.structure.min.css',
            '030_jquery-ui-theme' => '/unicaen/app/vendor/jquery-ui-1.12.1/jquery-ui.theme.min.css',

//            '040_bootstrap'           => '/unicaen/app/vendor/bootstrap-5.0.2/css/bootstrap.min.css',
            '040_bootstrap' => '/vendor/bootstrap-5.0.2-dist/css/bootstrap.css',
            '041_form' => '/css/form.css',
//            '060_unicaen'             => '/unicaen/app/css/unicaen.css',
            '060_unicaen' => '/css/unicaen.css',
            '061_misc' => '/css/misc.css', //Divers a retravailler
//            '070_app'                 => '/css/app.css',

            /** DataTable */
            '0101_datatables' => 'vendor/DataTables/datatables.min.css',
//            '0102_datatables_datetime'       => 'vendor/DataTables/DateTime-1.1.1/css/dataTables.dateTime.min.css',
//            '102_datatables'                => 'vendor/DataTables/Buttons-2.2.1/css/buttons.dataTables.min.css',
//            '103_datatables'                => 'vendor/DataTables/ColReorder-1.5.5/css/colReorder.dataTables.min.css',
            '0109_datatables_responsive' => 'vendor/DataTables/Responsive-2.2.9/css/responsive.dataTables.min.css',
//            '106_datatables'                => 'vendor/DataTables/RowGroup-1.1.4/css/rowGroup.dataTables.min.css',
//            '107_datatables'                => 'vendor/DataTables/RowReorder-1.2.8/css/rowReorder.dataTables.min.css',
            '0112_datatables_stateRestore' => 'vendor/DataTables/StateRestore-1.1.0/css/stateRestore.dataTables.min.css',

            /** Selectipicker */
            '080_bootstrap-select' => 'vendor/bootstrap-select-1.13.9/dist/css/bootstrap-select.min.css',

            /** Fonts */
            '201_fontawesome' => 'vendor/fontawesome-free-6.1.1-web/css/all.css',
            '202_icon' => 'css/icon.css',
            '202_police_ubuntu' => 'css/ubuntu.css',
            '203_police_raleway' => 'css/raleway.css',
        ],
    ],
];
