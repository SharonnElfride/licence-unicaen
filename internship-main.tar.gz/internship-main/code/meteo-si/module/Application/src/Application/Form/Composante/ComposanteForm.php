<?php


namespace Application\Application\Form\Composante;

use Application\Application\Form\AbstractEntityForm;
use Laminas\Form\Element\Button;

/**
 * Class Composante
 */
class ComposanteForm extends AbstractEntityForm
{

    protected function initEntityFieldset()
    {
        $this->entityFieldset = $this->getFormFactory()->getFormElementManager()->get(ComposanteFieldset::class);
        $this->entityFieldset->setOptions([
            'use_as_base_fieldset' => true,
        ]);
        $this->add($this->entityFieldset);
    }

    protected function initSubmitInput()
    {
        $this->add([
            'type' => Button::class,
            'name' => self::INPUT_SUBMIT,
            'options' => [
                'label' => self::LABEL_SUBMIT_CONFIRM,
                'label_options' => [
                    'disable_html_escape' => true,
                ],
            ],
            'attributes' => [
                'id' => self::INPUT_SUBMIT,
                'type' => 'submit',
                'class' => 'btn btn-success',
            ],
        ]);
    }
}
