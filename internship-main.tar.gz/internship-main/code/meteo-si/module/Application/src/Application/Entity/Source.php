<?php

namespace Application\Entity;

use Laminas\Permissions\Acl\Resource\ResourceInterface;

/**
 * Source
 */
class Source implements ResourceInterface
{
    /**
     *
     */
    const RESOURCE_ID = 'Source';
    /**
     * @var int
     */
    private $id;
    /**
     * @var string|null
     */
    private $code;
    /**
     * @var string
     */
    private $libelle;

    /**
     * Returns the string identifier of the Resource
     *
     * @return string
     */
    public function getResourceId()
    {
        return self::RESOURCE_ID;
    }

    /**
     * @return int|null
     */
    public function getId(): ?int
    {
        return $this->id;
    }

    /**
     * @param int $id
     */
    public function setId(int $id): void
    {
        $this->id = $id;
    }

    /**
     * @return string
     */
    public function getCode(): ?string
    {
        return $this->code;
    }

    /**
     * @param string $code
     */
    public function setCode(string $code): void
    {
        $this->code = $code;
    }

    /**
     * @return string|null
     */
    public function getLibelle(): ?string
    {
        return $this->libelle;
    }

    /**
     * @param string $libelle
     */
    public function setLibelle(string $libelle): void
    {
        $this->libelle = $libelle;
    }

}
