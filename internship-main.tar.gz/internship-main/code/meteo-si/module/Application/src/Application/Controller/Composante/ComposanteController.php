<?php

namespace Application\Controller\Composante;

use Application\Application\Form\Composante\Traits\ComposanteFormAwareTrait;
use Application\Application\Misc\RouterToolsTrait;
use Application\Application\Service\Composante\AlbumServiceAwareTrait;
use Application\Application\Service\Composante\ComposanteServiceAwareTrait;
use Application\Entity\Composante;
use Laminas\Mvc\Controller\AbstractActionController;
use Laminas\View\Model\ViewModel;

class ComposanteController extends AbstractActionController
{
    use ComposanteServiceAwareTrait;
    use ComposanteFormAwareTrait;
    use RouterToolsTrait;


    /** ROUTES */
    const ROUTE_INDEX = "composantes";
    const ROUTE_LISTER = "composantes/lister";
    const ROUTE_AFFICHER = "composante/afficher";
    const ROUTE_AJOUTER = "composante/ajouter";
    const ROUTE_MODIFIER = "composante/modifier";
    const ROUTE_HISTORISER = "composante/historiser";
    const ROUTE_DEHISTORISER = "composante/dehistoriser";
    const ROUTE_SUPPRIMER = "composante/supprimer";

    const ACTION_INDEX = "index";
    const ACTION_LISTER = "lister";
    const ACTION_AFFICHER = "afficher";
    const ACTION_AJOUTER = "ajouter";
    const ACTION_MODIFIER = "modifier";
    const ACTION_HISTORISER = "historiser";
    const ACTION_DEHISTORISER = "dehistoriser";
    const ACTION_SUPPRIMER = "supprimer";

    public function indexAction()
    {
        $composantes = $this->getComposanteService()->findAll();
        return new ViewModel(['composantes' => $composantes]);
    }

    public function listerAction()
    {
        $composantes = $this->getComposanteService()->findAll();
        return new ViewModel(['composantes' => $composantes]);
    }

    public function afficherAction()
    {
        $id = $this->getParamFromRoute('composante', 0);
        $composante = $this->getComposanteService()->find($id);
        $title = "Fiche de la composante";
        if (!$composante) {
            return $this->renderError($title, "La composante demandée n'as pas été trouvée.");
        }
        return new ViewModel(['title' => $title, 'composante' => $composante]);
    }

    public function ajouterAction()
    {
        $title = "Ajouter une composante";
        /** @var Composante $composante */
        $composante = new Composante();
        $form = $this->getAddComposanteForm();
        $form->bind($composante);
        if ($data = $this->params()->fromPost()) {
            $form->setData($data);
            if ($form->isValid()) {
                $composante = $form->getObject();
                var_dump($composante);
            }
        }

        return new ViewModel(['title' => $title, 'form' => $form]);
    }

    public function modifierAction()
    {
        $title = "Ajouter une composante";
        $composante = new Composante();
        $form = $this->getEditComposanteForm();
        $form->bind($composante);
        return new ViewModel(['title' => $title, 'form' => $form]);
    }
}
