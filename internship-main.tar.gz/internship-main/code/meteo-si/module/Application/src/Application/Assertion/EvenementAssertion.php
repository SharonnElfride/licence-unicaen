<?php

namespace Application\Assertion;

use DateTime;
use Doctrine\Common\Collections\ArrayCollection;
use Laminas\Permissions\Acl\Resource\ResourceInterface;
use Laminas\Permissions\Acl\Role\RoleInterface;
use MeteoSI\Model\Evenement;

class EvenementAssertion extends AbstractAssertion
{
    /** @var Evenement $evenement */
    private $evenement;

    /** @var Evenement $evenement2 */
    private $evenement2;

    /**
     * Permet de dire si on a le droit de faire l'action et de vérifier si l'entité d'id $id existe
     *
     * @param ResourceInterface|null $entity
     * @param $privilege
     * @return bool
     */
    protected function assertEntity(ResourceInterface $entity = null, $privilege = null)
    {
        //Rôlr de l'user
        $role = $this->getRole();

        // si le rôle n'est pas renseigné
        if (!$role instanceof RoleInterface) return false;

        // si le rôle ne possède pas le privilège
        if (!parent::assertEntity($entity, $privilege)) {
            return false;
        }

//        /** @var Evenement $entity */
//        switch ($privilege) {
//            case ComptePrivileges::BLOCAGE:
//                return $this->assertCompteBlocage($role, $entity);
//            case ComptePrivileges::DEBLOCAGE:
//                return $this->assertCompteDeblocage($role, $entity);
//            case ComptePrivileges::PROLONGATION:
//                return $this->assertCompteProlongation($role, $entity);
//            case ComptePrivileges::REACTIVATION:
//                return $this->assertCompteReactivation($role, $entity);
//        }

        return true;
    }

    protected function assertController($controller, $action = null, $privilege = null)
    {
        $role = $this->getRole();

        // si le rôle n'est pas renseigné
        if (!$role instanceof RoleInterface) return false;

        // récupération des événements
        $evenement = $this->getEvenement();
        $evenement2 = $this->getEvenement2();

        switch ($action) {
            case 'index':
                return true;
            case 'add':
            {
                if(($this->getParam('day') !== null) && ($this->getParam('month') !== null) && ($this->getParam('year') !== null)) {
                    return ($this->correctDay() && $this->correctMonth() && $this->correctYear() && $this->monthHasDay());
                }

                return true;
            }
            case 'show' :
            case 'changeforminput':
            case 'edit':
            case 'clone':
            case 'delete':
            case 'reopen':
            case 'close':
                return isset($evenement);
            case 'unleash':
            {
                if(isset($evenement) && isset($evenement2)):
                    if($evenement->getEvenementRef() !== null)
                    {
                        if($evenement->getEvenementRef()->getId() === $evenement2->getId())
                            return true;

                        return false;
                    }

                    return false;
                endif;
                return false;
            }
            case 'changecalendardate':
            {
                return ($this->correctMonth() && $this->correctYear());
            }
            case 'showdateevents':
            {
                return ($this->correctDay() && $this->correctMonth() && $this->correctYear() && $this->monthHasDay());
            }
        }

        return false;
    }

    public function correctDay()
    {
        $day = intval($this->getParam('day'));
        return (($day >= 1) && ($day <= 31));
    }

    public function correctMonth()
    {
        $month = intval($this->getParam('month'));
        return (($month >= 1) && ($month <= 12));
    }

    public function correctYear()
    {
        $year = $this->getParam('year');
        return ($year >= 2022);
    }

    public function monthHasDay()
    {
        $day = intval($this->getParam('day'));
        $month = intval($this->getParam('month'));
        $year = $this->getParam('year');

        //if($this->correctDay() && $this->correctMonth() && $this->correctYear()) {
            $date = '01-' . $month . "-" . $year;
            $date = new DateTime($date);

            $numberDaysInMonth = intval($date->format('t'));

            return (($day >= 1) && ($day <= $numberDaysInMonth));
//        }
//
//        else
//            return false;
    }

//    protected function assertCompteBlocage(RoleInterface $role, Evenement $evenement)
//    {
//        return $evenement->isActif();
//    }
//
//    protected function assertCompteDeblocage(RoleInterface $role, Evenement $evenement)
//    {
//        return $evenement->isBloque();
//    }

//    protected function assertCompteProlongation(RoleInterface $role, Evenement $evenement)
//    {
//        // profils autorisés
//        switch ($role->getRoleId()) {
//            case $r = UtilisateurRole::ADMINISTRATEUR:
//                $allowedProfils = $this->profilService->getEntityRepository()->findBy(['tAutomatique' => 'N']);
//                break;
//            default:
//                $utilisateur = $this->serviceUserContext->getDbUser();
//                /** @var Utilisateur $utilisateur */
//                $allowedProfils = $this->profilService->findAllByUtilisateur($utilisateur);
//                break;
//        }
//
//        $currentProfils = array_map(
//            function($p) { return $p->getProfil()->getId(); },
//            $this->individuProfilService->findActifAndManuelByIndividu($evenement->getIndividu())
//        );
//
//        $allowedProfils = array_filter($allowedProfils, function($p) use ($currentProfils) {
//            return in_array($p->getId(), $currentProfils);
//        });
//
//        // cycle de vie
//        $cycleVie = $this->individuCompteService->getCycleVie($evenement);
//
//        return
//            $evenement->isActif() &&
//            $cycleVie->getDateExpiration() != null &&
//            !empty($allowedProfils);
//    }

//    protected function assertCompteReactivation(RoleInterface $role, Evenement $evenement)
//    {
//        return $evenement->isDesactive();
//    }
//
//    protected function assertCompteRevisionServices(RoleInterface $role, Evenement $evenement)
//    {
//        return $evenement->isActif();
//    }

    /**
     * @return Evenement|object|null
     */
    protected function getEvenement()
    {
        if (null === $this->evenement) {
            // identifiant de l'entité
            $id = $this->getParam('id');

            if (!$id) {
                return null;
            }

            $this->evenement = $this->getEntityManager()->getRepository(Evenement::class)->find($id);
        }

        return $this->evenement;
    }

    /**
     * @return Evenement|object|null
     */
    protected function getEvenement2()
    {
        if (null === $this->evenement2) {
            // identifiant de l'entité
            $id = $this->getParam('id2');

            if (!$id) {
                return null;
            }

            $this->evenement2 = $this->getEntityManager()->getRepository(Evenement::class)->find($id);
        }

        return $this->evenement2;
    }
}