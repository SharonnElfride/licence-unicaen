<?php

namespace Application\Assertion;

use Application\Assertion\AbstractAssertion;
use Laminas\Permissions\Acl\Resource\ResourceInterface;
use Laminas\Permissions\Acl\Role\RoleInterface;
use MeteoSI\Controller\CibleEvenement\CibleEvenementController;
use MeteoSI\Model\CibleEvenement;
use MeteoSI\Model\CibleEvenementApplication;
use MeteoSI\Model\CibleEvenementBdd;
use MeteoSI\Model\CibleEvenementGroupe;
use MeteoSI\Model\CibleEvenementInfra;
use MeteoSI\Model\CibleEvenementService;
use MeteoSI\Model\Interfaces\CibleEvenementInterface;
use RuntimeException;

class CibleEvenementAssertion extends AbstractAssertion
{
    /** @var CibleEvenement $cible */
    private $cible;

    /** @var CibleEvenement $parent */
    private $parent;

    /** @var CibleEvenement $enfant */
    private $enfant;

    /** @var CibleEvenementGroupe $groupe */
    private $groupe;

    /** @var CibleEvenement $cibleRetrait */
    private $cibleRetrait;

    /**
     * Permet de dire si on a le droit de faire l'action et de vérifier si l'entité d'id $id existe
     *
     * @param ResourceInterface|null $entity
     * @param $privilege
     * @return bool
     */
    protected function assertEntity(ResourceInterface $entity = null, $privilege = null)
    {
        //Rôlr de l'user
        $role = $this->getRole();

        // si le rôle n'est pas renseigné
        if (!$role instanceof RoleInterface) return false;

        // si le rôle ne possède pas le privilège
        if (!parent::assertEntity($entity, $privilege)) {
            return false;
        }

        return true;
    }

    protected function assertController($controller, $action = null, $privilege = null)
    {
        $role = $this->getRole();

        // si le rôle n'est pas renseigné
        if (!$role instanceof RoleInterface) return false;

        // récupération des objets
        $cible = $this->getCible();
        $enfant = $this->getEnfant();
        $parent = $this->getParent();
        $groupe = $this->getGroupe();
        $cibleRetrait = $this->getCibleRetrait();

        switch ($action) {
            case 'index':
            case 'add':
                return true;
            case 'show' :
            case 'edit':
                return (isset($cible) && $this->categorieCodeVerification($cible, $this->getParam('categorie')));
            case 'showtargetwithoutdetails':
            {
                $cibleWithoutDetails = $this->getCibleForDisplayWithoutDetails();
                return (isset($cibleWithoutDetails) && $this->categorieCodeVerification($cibleWithoutDetails, $this->getParam('categorie')));
            }
            case 'addtargettogroup':
                return (($this->getParam('categorie') === 'groupecible') && isset($groupe));
            case 'delete':
                return (isset($cible) && (sizeof($cible->getEvenements()) === 0));
            case 'removetargetfromgroup':
            {
                if(($this->getParam('categorie') === 'groupecible') && !$this->isOneTargetCategoryVerification($this->getParam('categorie2'))):
                    if(isset($groupe) && isset($cibleRetrait))
                    {
                        if($this->categorieCodeVerification($cibleRetrait, $this->getParam('categorie2'))) {
                            foreach ($groupe->getCibles() as $cibleGp) {
                                if ($cibleRetrait->getId() === $cibleGp->getId())
                                    return true;
                            }
                        }
                    }
                endif;
            }
            case 'addparent':
                return (!$this->isOneTargetCategoryVerification($this->getParam('categorie')) && isset($enfant) && ($this->categorieCodeVerification($enfant, $this->getParam('categorie'))));
            case 'removeparent':
            {
                if((!$this->isOneTargetCategoryVerification($this->getParam('categorie'))) && (!$this->isOneTargetCategoryVerification($this->getParam('categorie2')))):
                    if(isset($enfant) && isset($parent))
                    {
                        if($this->categorieCodeVerification($enfant, $this->getParam('categorie')) && $this->categorieCodeVerification($parent, $this->getParam('categorie2'))) {
                            foreach ($enfant->getParents() as $p) {
                                if ($parent->getId() === $p->getId())
                                    return true;
                            }
                        }
                    }
                endif;
            }
            case 'changechildrenlist':
            {
                $target = $this->getCibleWithoutSpecificCategory();
                return isset($target);
            }
        }

        return false;
    }

    /**
     * Pour vérifier si la cible est de la catégorie saisie
     *
     * @param CibleEvenementInterface $cible
     * @param string $codeCategorie
     * @return bool
     */
    private function categorieCodeVerification(CibleEvenementInterface $cible, string $codeCategorie)
    {
//        var_dump($cible->getLibelle());
//        var_dump($codeCategorie);
//        var_dump($cible->getCategorieCible()->getCode());
//        die();

        return ($cible->getCategorieCible()->getCode() === $codeCategorie);
    }

    /**
     * @return CibleEvenement|null
     */
    private function getCibleForDisplayWithoutDetails() {
        /** @var CibleEvenement $cible */
        $cible = null;

        // identifiant de l'entité
        $id = $this->getParam('id');
        $categorie = $this->getParam('categorie');

        if(!$this->isOneTargetCategoryVerification($categorie)) {
            if (!$id) {
                return null;
            }
        }
        else
            return null;

        /** @var CibleEvenement $cible */
        $cible = $this->getEntityManager()->getRepository(CibleEvenement::class)->find($id);
        return $cible;
    }

    /**
     * @return CibleEvenement|null
     */
    private function getCibleWithoutSpecificCategory() {
        /** @var CibleEvenement $cible */
        $cible = null;

        // identifiant de l'entité
        $id = $this->getParam('id');
        if (!$id) {
            return null;
        }

        /** @var CibleEvenement $cible */
        $cible = $this->getEntityManager()->getRepository(CibleEvenement::class)->find($id);
        return $cible;
    }

    private function isOneTargetCategoryVerification(?string $categorie)
    {
        return ($categorie !== 'application') && ($categorie !== 'bdd') && ($categorie !== 'infra') && ($categorie !== 'service') && ($categorie !== 'groupecible');
    }

    protected function getCible()
    {
        if (null === $this->cible) {
            // identifiant de l'entité
            $id = $this->getParam('id');
            $categorie = $this->getParam('categorie');

            if(!$this->isOneTargetCategoryVerification($categorie)) {
                if (!$id) {
                    return null;
                }
            }
            else
                return null;

            switch ($categorie) {
                case 'application':
                {
                    $this->cible = $this->getEntityManager()->getRepository(CibleEvenementApplication::class)->find($id);
                    break;
                }
                case 'bdd':
                {
                    $this->cible = $this->getEntityManager()->getRepository(CibleEvenementBdd::class)->find($id);
                    break;
                }
                case 'infra':
                {
                    $this->cible = $this->getEntityManager()->getRepository(CibleEvenementInfra::class)->find($id);
                    break;
                }
                case 'service':
                {
                    $this->cible = $this->getEntityManager()->getRepository(CibleEvenementService::class)->find($id);
                    break;
                }
                case 'groupecible':
                {
                    $this->cible = $this->getEntityManager()->getRepository(CibleEvenementGroupe::class)->find($id);
                    break;
                }
                default:
                    throw new RuntimeException("Il n'existe pas de catégorie dénomée: " . $categorie);
            }

            //$this->cible = $this->getEntityManager()->getRepository(CibleEvenement::class)->find($id);
        }

        return $this->cible;
    }

    //Managing target's dependencies
    protected function getEnfant()
    {
        if (null === $this->enfant) {
            // identifiant de l'entité
            $id = $this->getParam('id');

            if (!$id) {
                return null;
            }

            $this->enfant = $this->getEntityManager()->getRepository(CibleEvenement::class)->find($id);
        }

        return $this->enfant;
    }

    protected function getParent()
    {
        if (null === $this->parent) {
            // identifiant de l'entité
            $id = $this->getParam('id2');

            if (!$id) {
                return null;
            }

            $this->parent = $this->getEntityManager()->getRepository(CibleEvenement::class)->find($id);
        }

        return $this->parent;
    }

    //Managing groups and their targets
    protected function getGroupe()
    {
        if(null === $this->groupe) {
            $idGroupe = $this->getParam('id');

            if(!$idGroupe) {
                return null;
            }

            $this->groupe = $this->getEntityManager()->getRepository(CibleEvenementGroupe::class)->find($idGroupe);
        }

        return $this->groupe;
    }

    protected function getCibleRetrait()
    {
        if (null === $this->cibleRetrait) {
            // identifiant de l'entité
            $id = $this->getParam('id2');

            if (!$id) {
                return null;
            }

            $this->cibleRetrait = $this->getEntityManager()->getRepository(CibleEvenement::class)->find($id);
        }

        return $this->cibleRetrait;
    }
}