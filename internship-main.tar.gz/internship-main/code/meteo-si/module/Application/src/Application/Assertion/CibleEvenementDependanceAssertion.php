<?php

namespace Application\Assertion;

use Laminas\Permissions\Acl\Resource\ResourceInterface;
use Laminas\Permissions\Acl\Role\RoleInterface;
use MeteoSI\Model\CibleDependance;
use MeteoSI\Model\CibleEvenement;
use MeteoSI\Model\CibleEvenementGroupe;
use MeteoSI\Model\EtatCible;

class CibleEvenementDependanceAssertion extends AbstractAssertion
{
    /** @var CibleEvenement $parent */
    private $parent;

    /** @var CibleEvenement $enfant */
    private $enfant;

    /** @var CibleDependance $dependance */
    private $dependance;

    /** @var EtatCible $etatParent */
    private $etatParent;

    /** @var EtatCible $etatEnfant */
    private $etatEnfant;

    /**
     * Permet de dire si on a le droit de faire l'action et de vérifier si l'entité d'id $id existe
     *
     * @param ResourceInterface|null $entity
     * @param $privilege
     * @return bool
     */
    protected function assertEntity(ResourceInterface $entity = null, $privilege = null)
    {
        //Rôlr de l'user
        $role = $this->getRole();

        // si le rôle n'est pas renseigné
        if (!$role instanceof RoleInterface) return false;

        // si le rôle ne possède pas le privilège
        if (!parent::assertEntity($entity, $privilege)) {
            return false;
        }

        return true;
    }

    protected function assertController($controller, $action = null, $privilege = null)
    {
        $role = $this->getRole();

        // si le rôle n'est pas renseigné
        if (!$role instanceof RoleInterface) return false;

        // récupération des objets
        $enfant = $this->getEnfant();
        $parent = $this->getParent();
        $dependance = $this->getDependance();
        $etatParent = $this->getEtatParent();
        $etatEnfant = $this->getEtatEnfant();

        switch ($action) {
            case 'changetransitionrule':
            {
                if(($this->categorieCibleVerification($this->getParam('categorie'))) && ($this->categorieCibleVerification($this->getParam('categorie2')))):
                    if(isset($enfant) && isset($parent) && isset($dependance))
                    {
                        foreach ($enfant->getParents() as $p):
                            if($parent->getId() === $p->getId()):
                                if(($dependance->getParent()->getId() === $parent->getId()) && ($dependance->getEnfant()->getId() === $enfant->getId())):
                                    if(isset($etatParent) && isset($etatEnfant))
                                        return true;
                                endif;
                            endif;
                        endforeach;
                    }
                endif;

                return false;
            }
        }

        return false;
    }

    private function categorieCibleVerification(string $categorie)
    {
        $result = ($categorie !== 'application') && ($categorie !== 'bdd') && ($categorie !== 'infra') && ($categorie !== 'service') && ($categorie !== 'groupecible');
        return !$result;
    }

    //Managing target's dependencies
    protected function getEnfant()
    {
        if (null === $this->enfant) {
            // identifiant de l'entité
            $id = $this->getParam('id');

            if (!$id) {
                return null;
            }

            $this->enfant = $this->getEntityManager()->getRepository(CibleEvenement::class)->find($id);
        }

        return $this->enfant;
    }

    protected function getParent()
    {
        if (null === $this->parent) {
            // identifiant de l'entité
            $id = $this->getParam('id2');

            if (!$id) {
                return null;
            }

            $this->parent = $this->getEntityManager()->getRepository(CibleEvenement::class)->find($id);
        }

        return $this->parent;
    }

    //Managing the rule transition
    public function getDependance()
    {
        if (null === $this->dependance) {
            // identifiant de l'entité
            $id = $this->getParam('idDependance');

            if (!$id) {
                return null;
            }

            $this->dependance = $this->getEntityManager()->getRepository(CibleDependance::class)->find($id);
        }

        return $this->dependance;
    }

    public function getEtatParent()
    {
        if (null === $this->etatParent) {
            // identifiant de l'entité
            $id = $this->getParam('idEtatParent');

            if (!$id) {
                return null;
            }

            $this->etatParent = $this->getEntityManager()->getRepository(EtatCible::class)->find($id);
        }

        return $this->etatParent;
    }

    public function getEtatEnfant()
    {
        if (null === $this->etatEnfant) {
            // identifiant de l'entité
            $id = $this->getParam('idEtatEnfant');

            if (!$id) {
                return null;
            }

            $this->etatEnfant = $this->getEntityManager()->getRepository(EtatCible::class)->find($id);
        }

        return $this->etatEnfant;
    }
}