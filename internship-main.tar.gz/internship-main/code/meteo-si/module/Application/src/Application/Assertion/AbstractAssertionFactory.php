<?php

namespace Application\Assertion;

use BjyAuthorize\Service\Authorize;
use Doctrine\ORM\EntityManager;
use Interop\Container\ContainerInterface;
use UnicaenAuthentification\Service\UserContext;
use Laminas\Mvc\MvcEvent;
use Laminas\ServiceManager\Factory\AbstractFactoryInterface;

class AbstractAssertionFactory implements AbstractFactoryInterface
{
    const START = 'Assertion';

    /**
     * Can the factory create an instance for the service
     *
     * @param ContainerInterface $container
     * @param string $requestedName
     * @return bool
     */
    public function canCreate(ContainerInterface $container, $requestedName)
    {
        $parts = explode('\\', $requestedName);
        if (!$parts || $parts[0] !== self::START) {
            return false;
        }

        return $this->isAssertionRequested($requestedName);
    }

     public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
     {
        $className = $this->getAssertionClassName($requestedName);
        $assertion  = new $className;
        $this->initAssertion($assertion, $container);

        return $assertion;
     }

    /**
     * Check assertion exists
     *
     * @param string $requestedName
     * @return bool
     */
    private function isAssertionRequested($requestedName)
    {
        $parts = explode('\\', $requestedName);
        $isAssertion = count($parts) === 2;

        $className = $this->getAssertionClassName($requestedName);

        return
            $isAssertion &&
            class_exists($className) &&
            is_a($className, \UnicaenPrivilege\Assertion\AbstractAssertion::class, true);
    }

    /**
     * Initialize services
     *
     * @param AbstractAssertion $assertion
     * @param ContainerInterface $container
     * @return AbstractAssertion
     */
    private function initAssertion(AbstractAssertion $assertion, ContainerInterface $container)
    {
        /**
         * @var MvcEvent $mvcEvent
         * @var Authorize $authorizeService
         * @var UserContext $userContextService
         * @var EntityManager $entityManager
         */
        $mvcEvent = $container->get('application')->getMvcEvent();
        $authorizeService = $container->get('BjyAuthorize\Service\Authorize');
        $userContextService = $container->get(UserContext::class);
        $entityManager = $container->get('Doctrine\ORM\EntityManager');

        $assertion->setMvcEvent($mvcEvent);
        $assertion->setServiceAuthorize($authorizeService);
        $assertion->setServiceUserContext($userContextService);
        $assertion->setEntityManager($entityManager);

        return $assertion;
    }

    /**
     * Get assertion class name
     *
     * @param $requestedName
     * @return string
     */
    private function getAssertionClassName($requestedName)
    {
        $parts = explode('\\', $requestedName);
        $parts = array_slice($parts, 1);
        $domain = $parts[0];
        $className = __NAMESPACE__ . sprintf('\\%s%s', $domain, self::START);

        return $className;
    }
}