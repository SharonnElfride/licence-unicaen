<?php

namespace Application\Application\Misc;

use UnicaenAuthentification\Service\Traits\UserContextServiceAwareTrait;
use UnicaenUtilisateur\Entity\Db\User;

trait UserAwaireTrait
{
    use UserContextServiceAwareTrait;

    /**
     * @var User $user
     */
    protected $user;

    /**
     * @return User $user
     */
    protected function getConnectedUser()
    {
        if (null === $this->user) {
            $this->user = $this->serviceUserContext->getIdentity()['db'];
        }
        return $this->user;
    }
}