<?php

namespace Application\Entity;

use Application\Application\Entity\Interfaces\SourceAwareInterface;
use Application\Application\Entity\Traits\SourceAwareTrait;
use Laminas\Permissions\Acl\Resource\ResourceInterface;
use UnicaenApp\Entity\HistoriqueAwareInterface;
use UnicaenApp\Entity\HistoriqueAwareTrait;

/**
 * Composante
 */
class Composante implements ResourceInterface,
    HistoriqueAwareInterface, SourceAwareInterface
{
    /**
     *
     */
    const RESOURCE_ID = 'Composante';
    /**
     * @var int
     */
    private $id;

    use HistoriqueAwareTrait;
    use SourceAwareTrait;

    /**
     * @var string
     */
    private $code;
    /**
     * @var string
     */
    private $libelle;
    /**
     * @var string|null
     */
    private $libelleLong;
    /**
     * @var string|null
     */
    private $libelleCourt;

    /**
     * Returns the string identifier of the Resource
     *
     * @return string
     */
    public function getResourceId()
    {
        return self::RESOURCE_ID;
    }

    /**
     * @return int|null
     */
    public function getId(): ?int
    {
        return $this->id;
    }

    /**
     * @param int $id
     */
    public function setId(int $id): void
    {
        $this->id = $id;
    }

    /**
     * @return string|null
     */
    public function getCode(): ?string
    {
        return $this->code;
    }

    /**
     * @param string $code
     */
    public function setCode(string $code): void
    {
        $this->code = $code;
    }

    /**
     * @return string|null
     */
    public function getLibelle(): ?string
    {
        return $this->libelle;
    }

    /**
     * @param string $libelle
     */
    public function setLibelle(string $libelle): void
    {
        $this->libelle = $libelle;
    }

    /**
     * @return string
     */
    public function getLibelleLong(): ?string
    {
        return $this->libelleLong;
    }

    /**
     * @param string $libelleLong
     */
    public function setLibelleLong(string $libelleLong): void
    {
        $this->libelleLong = $libelleLong;
    }

    /**
     * @return string
     */
    public function getLibelleCourt(): ?string
    {
        return $this->libelleCourt;
    }

    /**
     * @param string $libelleCourt
     */
    public function setLibelleCourt(string $libelleCourt): void
    {
        $this->libelleCourt = $libelleCourt;
    }


}
