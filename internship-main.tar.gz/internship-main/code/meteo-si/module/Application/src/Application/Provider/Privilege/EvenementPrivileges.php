<?php

namespace Application\Provider\Privilege;

use UnicaenPrivilege\Provider\Privilege\Privileges;

class EvenementPrivileges extends Privileges
{
    const EVENEMENT_AFFICHER = 'evenement-evenement_afficher';
    const EVENEMENT_AJOUTER = 'evenement-evenement_ajouter';
    const EVENEMENT_MODIFIER = 'evenement-evenement_modifier';
    const EVENEMENT_SUPPRIMER = 'evenement-evenement_supprimer';
    const CATEGORIE_EVENEMENT_AFFICHER = 'evenement-categorie_evenement_afficher';
    const CATEGORIE_EVENEMENT_AJOUTER = 'evenement-categorie_evenement_ajouter';
    const CATEGORIE_EVENEMENT_MODIFIER = 'evenement-categorie_evenement_modifier';
    const CATEGORIE_EVENEMENT_SUPPRIMER = 'evenement-categorie_evenement_supprimer';
    const CIBLE_EVENEMENT_AFFICHER = 'evenement-cible_evenement_afficher';
    const CIBLE_EVENEMENT_AJOUTER = 'evenement-cible_evenement_ajouter';
    const CIBLE_EVENEMENT_MODIFIER = 'evenement-cible_evenement_modifier';
    const CIBLE_EVENEMENT_GERER_DEPENDANCE = 'evenement-cible_evenement_gerer_dependance';
    const CIBLE_EVENEMENT_SUPPRIMER = 'evenement-cible_evenement_supprimer';
}