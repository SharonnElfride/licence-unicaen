<?php

namespace Application\Application\Entity\Traits;

use Application\Entity\Composante;

trait ComposanteAwareTrait
{
    /** @var Composante Composante */
    protected $composante;

    /**
     * @return Composante|null
     */
    public function getComposante(): ?Composante
    {
        return $this->composante;
    }

    /**
     * @param Composante|null $composante
     */
    public function setComposante(?Composante $composante): void
    {
        $this->composante = $composante;
    }

    /**
     * @return Bool
     */
    public function hasComposante(): Bool
    {
        return isset($this->composante);
    }
}