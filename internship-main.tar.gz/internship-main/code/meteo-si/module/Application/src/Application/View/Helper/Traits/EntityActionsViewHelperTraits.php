<?php

/**
 * @method string getActionPriviliege(string $action);
 * @var \Laminas\View\Renderer\RendererInterface $view
 */

namespace Application\Application\View\Helper\Traits;

use UnicaenPrivilege\Provider\Privilege\Privileges;

trait EntityActionsViewHelperTraits
{
    protected $notAllwedActionMessage = "";

    /**
     * @desc génére un lien pour effectuer une action
     * $data permet de fournir un ensemble d'attribut que l'on désire
     * ie : $data = ['class' => 'btn btn-success', 'data-event' => 'event-x' ...]
     * Requiére à minima un label ou une icone
     * @param string $action
     * @param array $data
     * @return string
     */
    public function renderActionLink(string $action, $label = "Lien", array $data = []): string
    {
        //Si l'utilisateur n'a pas le privilége on ne génére pas le lien
        if (!$this->assertHasPrivilege($action)) {
            return "";
        }
        //On désactive le lien si l'action n'est pas autorisé
        $disabled = !$this->assertActionAllowed($action);
        if ($disabled) {
            if (!isset($data['class'])) {
                $data['class'] = "";
            }
            $data['class'] .= " disabled";
            $data['disabled'] = "disabled";
            unset($data['href']);
        } else {
            if (!isset($data['href'])) {
                $data['href'] = $this->getActionRoute($action);
            }
        }
        $attributes = "";
        foreach ($data as $key => $value) {
            $attributes .= sprintf("%s=\"%s\" ", $key, $value);
        }
        $html = sprintf("<a %s>%s</a>", $attributes, $label);

        if ($disabled) {//Si le lien est désactivé, on met le message afin de gérer le cas des btn qui ne prennent pas le focus
            $title = $this->getNotAllowedActionMessage();
            $html = sprintf("<span data-toggle='tooltip' data-placement='bottom' title=\"%s\" >%s</span>", $title, $html);
        }

        return $html;
    }

    public function assertHasPrivilege(string $action): bool
    {
        $privilege = $this->getActionPriviliege($action);
        if (!$privilege) {
            return false;
        }
        return $this->view->isAllowed(Privileges::getResourceId($privilege));
    }

    /**
     * @desc Message a afficher si une action n'est pas autorisée
     * @return bool
     */
    public function getNotAllowedActionMessage(): string
    {
        return $this->notAllwedActionMessage;
    }

    /** Version par défaut a surcharger éventuellement pour certaines actions */
    public function assertActionAllowed(string $action): bool
    {
        $actionAllowed = $this->assertHasPrivilege($action);
        $this->setNotAllowedActionMessage(self::NO_PRIVILEGE_MSG);
        return $actionAllowed;
    }

    /**
     * @desc Message a afficher si une action n'est pas autorisée
     * @param string action
     * @return void
     */
    public function setNotAllowedActionMessage(string $msg): void
    {
        $this->notAllwedActionMessage = $msg;
    }
}