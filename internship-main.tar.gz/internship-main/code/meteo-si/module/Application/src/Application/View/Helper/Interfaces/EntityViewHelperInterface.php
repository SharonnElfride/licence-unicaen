<?php

namespace Application\Application\View\Helper\Interfaces;

use Laminas\Form\Form;

interface EntityViewHelperInterface
{
    const NO_PRIVILEGE_MSG = "Action non autorisée";

    /**
     * @return string
     */
    public function renderListe(?array $enities = []): string;

    /**
     * @return string
     */
    public function renderForm(Form $form): string;

    /**
     * @param string|null $label
     * @param array $data
     * @return string
     */
    public function renderLienAfficher(?string $label = null, ?array $data = []): string;

    /**
     * @param string|null $label
     * @param array $data
     * @return string
     */
    public function renderLienAjouter(?string $label = null, ?array $data = []): string;

    /**
     * @param string|null $label
     * @param array $data
     * @return string
     */
    public function renderLienModifier(?string $label = null, ?array $data = []): string;

    /**
     * @param string|null $label
     * @param array $data
     * @return string
     */
    public function renderLienSupprimer(?string $label = null, ?array $data = []): string;

    /**
     * @desc Retourne le privilege requis pour une action
     * @param string $action
     * @return string|null
     */
    public function getActionPriviliege(string $action): ?string;

    /**
     * @desc Retourne la route pour effectuer une action
     * @param string $action
     * @return string|null
     */
    public function getActionRoute(string $action): ?string;

    /**
     * @desc Détermine si l'utilisateur a le privilege requis pour effectuer une action
     * @param string action
     * @return bool
     */
    public function assertHasPrivilege(string $action): bool;

    /**
     * @desc Détermine si une action est autorisé ou non
     * @param string action
     * @return bool
     */
    public function assertActionAllowed(string $action): bool;

    /**
     * @desc Message a afficher si une action n'est pas autorisée
     * @return void
     */
    public function getNotAllowedActionMessage(): string;

    /**
     * @param string action
     * @return void
     */
    public function setNotAllowedActionMessage(string $msg): void;
}