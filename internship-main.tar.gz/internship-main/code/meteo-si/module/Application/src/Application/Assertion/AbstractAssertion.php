<?php

namespace Application\Assertion;

use Doctrine\ORM\EntityRepository;
use Laminas\Permissions\Acl\Resource\ResourceInterface;
use UnicaenApp\Service\EntityManagerAwareInterface;
use UnicaenApp\Service\EntityManagerAwareTrait;
use UnicaenPrivilege\Provider\Privilege\Privileges;
use Laminas\Router\RouteMatch;

abstract class AbstractAssertion extends \UnicaenPrivilege\Assertion\AbstractAssertion implements EntityManagerAwareInterface
{
    use EntityManagerAwareTrait;
    /**
     * @var array
     */
    private $repositories = [];


    protected function assertEntity(ResourceInterface $entity, $privilege = null)
    {
        // Patch pour corriger le fonctionnement aberrant suivant :
        // On passe dans l'assertion même si le rôle ne possède par le privilège !
        if (! $this->getAcl()->isAllowed($this->getRole(), Privileges::getResourceId($privilege))) {
            return false;
        }

        return true;
    }


    /**
     * @return RouteMatch
     */
    protected function getRouteMatch()
    {
        return $this->getMvcEvent()->getRouteMatch();
    }

    /**
     * @param string $name nom du paramètre
     * @return mixed
     */
    protected function getParam($name)
    {
        return $this->getRouteMatch()->getParam($name);
    }

    /**
     * @param string $name Nom du paramètre
     * @return mixed
     */
    protected function fetchEntityParam($name)
    {
        $repository = $this->getRepository($name);
        if ($repository === null) {
            return null;
        }

        // identifiant de l'entité
        $id = $this->getParam($name);

        if (!$id) {
            return null;
        }

        $entity = $repository->find($id);

        return $entity;
    }

    /**
     * @param string $name
     * @return EntityRepository
     */
    protected function getRepository($name)
    {
        if (! isset($this->repositories[$name])) {
            $fqcn = $this->getFullQualifiedClassName($name);
            if (!class_exists($fqcn)) {
                return null;
            }
            $this->repositories[$name] = $this->getEntityManager()->getRepository($fqcn);
        }

        return $this->repositories[$name];
    }

    /**
     * @param $name
     * @return string
     */
    protected function getFullQualifiedClassName($name)
    {
        $namespace = 'Application\\Entity\\Db';
        return $namespace . sprintf('\\%s', ucfirst($name));
    }
}