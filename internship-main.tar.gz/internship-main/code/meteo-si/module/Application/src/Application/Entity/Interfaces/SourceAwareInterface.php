<?php

namespace Application\Application\Entity\Interfaces;

use Application\Entity\Source;

/**
 * Pour faire le liens entre les données est différentes sources externes possible
 */
interface SourceAwareInterface
{
    /**
     * @return Source|Null
     */
    public function getSource(): ?Source;

    /**
     * @param Source $source
     */
    public function setSource(Source $source): void;

    /**
     * @return string|null
     */
    public function getSourceCode(): ?string;

    /**
     * @param string $sourceCode
     */
    public function setSourceCode(string $sourceCode): void;
}