<?php

namespace Application\Application\Service\Composante;


use Application\Application\Service\API\CommonEntityService;
use Application\Entity\Composante;

/**
 * Class ComposanteService
 * @package Application\Application\Service\Composante
 */
class ComposanteService extends CommonEntityService
{
    /** @return string */
    public function getEntityClass()
    {
        return Composante::class;
    }

    public function findAll()
    {
        return $this->findAllBy([], ["libelle" => "ASC"]);
    }

}