<?php

namespace Application\Provider\Privilege;

use UnicaenPrivilege\Provider\Privilege\Privileges;

class FormationPrivileges extends Privileges
{
    const FORMATION_INDEX = 'formation-formation_index';

    const COMPOSANTE_AFFICHER = 'formation-composante_afficher';
    const COMPOSANTE_AJOUTER = 'formation-composante_ajouter';
    const COMPOSANTE_MODIFIER = 'formation-composante_modifier';
    const COMPOSANTE_SUPPRIMER = 'formation-composante_supprimer';
}
