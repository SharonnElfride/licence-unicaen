<?php

namespace Application\Application\Entity\Traits;

use Application\Entity\Source;

trait SourceAwareTrait
{

    /** @var \Application\Entity\Source $source */
    protected $source;
    /**
     * @var string
     */
    private $sourceCode;

    /**
     * @return Source|null
     */
    public function getSource(): ?Source
    {
        return $this->source;
    }

    /**
     * @param Source $source
     */
    public function setSource(Source $source): void
    {
        $this->source = $source;
    }

    /**
     * @return string|null
     */
    public function getSourceCode(): ?string
    {
        return $this->sourceCode;
    }

    /**
     * @param string $sourceCode
     */
    public function setSourceCode(string $sourceCode): void
    {
        $this->sourceCode = $sourceCode;
    }


}