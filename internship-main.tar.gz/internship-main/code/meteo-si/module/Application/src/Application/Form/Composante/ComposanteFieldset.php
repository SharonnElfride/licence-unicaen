<?php


namespace Application\Application\Form\Composante;

use Application\Application\Form\AbstractEntityFieldset;
use Laminas\InputFilter\InputFilterProviderInterface;

/**
 * Class ComposanteFieldset
 */
class ComposanteFieldset extends AbstractEntityFieldset implements InputFilterProviderInterface
{

    public function init()
    {
        $this->initInputCode();
        $this->initInputLibelle();
    }

    public function getInputFilterSpecification()
    {
        $filterSpecification = [];
        $filterSpecification[self::INPUT_CODE] = $this->getCodeInputSpecification();
        $filterSpecification[self::INPUT_LIBELLE] = $this->getLibelleInputSpecification();
        return $filterSpecification;
    }
}
