<?php


namespace Application\Application\Form;

use Laminas\Form\Element\Csrf;
use Laminas\Form\Form;
use Laminas\InputFilter\InputFilter;
use Laminas\View\HelperPluginManager;
use UnicaenApp\Service\EntityManagerAwareTrait;

abstract class AbstractEntityForm extends Form
{
    /**
     * Constante d'input génériques pour les différents formulaires
     */
    const INPUT_SUBMIT = "submit";
    const LABEL_SUBMIT_CONFIRM = "<i class='fas fa-save'></i> Valider";
    const LABEL_SUBMIT_ADD = "<i class='fas fa-save'></i> Ajouter";
    const LABEL_SUBMIT_IMPORT = "<i class='fas fa-download'></i> Importer";
    const LABEL_SUBMIT_EDIT = "<i class='fas fa-save'></i> Modifier";
    const LABEL_SUBMIT_RECHERCHER = "<i class='fas fa-search'></i> Rechercher";

    const CSRF = "csrf";

    const INVALIDE_ERROR_MESSAGE = "Le formulaire n'est pas valide :";


    use EntityManagerAwareTrait;

    protected $title;
    /** @var AbstractEntityFieldset $entityFieldset */
    protected $entityFieldset;
    /**
     * @var HelperPluginManager
     */
    protected $viewHelperManager;

    /**
     * @param null|int|string $name Optional name for the element
     * @param array $options Optional options for the element
     */
    public function __construct($name = null, $options = [])
    {
        parent::__construct($name, $options);
        $this->title = ($name) ? $name : "";
    }

    /**
     * @return int|string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * @param int|string $title
     */
    public function setTitle($title)
    {
        $this->title = $title;
    }

    /**
     * @return AbstractEntityFieldset
     */
    public function getEntityFieldset(): AbstractEntityFieldset
    {
        return $this->entityFieldset;
    }

    /**
     * @param AbstractEntityFieldset $entityFieldset
     */
    public function setEntityFieldset(AbstractEntityFieldset $entityFieldset): void
    {
        $this->entityFieldset = $entityFieldset;
    }

    public function init()
    {
        parent::init();
        $this->setAttribute('method', 'post');
        $this->setAttribute('action', $this->getCurrentUrl());
        $this->setAttribute('class', 'loadingForm');
        $this->setInputFilter(new InputFilter());
        $this->initEntityFieldset();
        $this->initCSRF();
        $this->initSubmitInput();
    }

    /**
     * @return string
     */
    protected function getCurrentUrl($forceCanonical = false)
    {
        return $this->getUrl(null, [], ['force_canonical' => $forceCanonical], true);
    }

    /**
     * Generates a url given the name of a route.
     *
     * @param string $name Name of the route
     * @param array $params Parameters for the link
     * @param array|\Traversable $options Options for the route
     * @param bool $reuseMatchedParams Whether to reuse matched parameters
     *
     * @return string Url                         For the link href attribute
     * @see    RouteInterface::assemble()
     *
     */
    protected function getUrl($name = null, $params = [], $options = [], $reuseMatchedParams = false)
    {
        $urlVh = $this->getViewHelperManager()->get('url');
        /* @var $urlVh \Laminas\View\Helper\Url */
        return $urlVh->__invoke($name, $params, $options, $reuseMatchedParams);
    }

    /**
     * @return HelperPluginManager
     */
    public function getViewHelperManager()
    {
        return $this->viewHelperManager;
    }

    /**
     * @param HelperPluginManager $viewHelperManager
     * @return AbstractEntityForm
     */
    public function setViewHelperManager($viewHelperManager)
    {
        $this->viewHelperManager = $viewHelperManager;
        return $this;
    }

    protected abstract function initEntityFieldset();

    protected function initCSRF()
    {
        $this->add(new Csrf(self::CSRF));
    }

    protected abstract function initSubmitInput();


}