<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Application\Controller\Composante;

use Application\Application\Form\Composante\ComposanteForm;
use Application\Application\Service\Composante\ComposanteService;
use Interop\Container\ContainerInterface;
use Laminas\ServiceManager\Factory\FactoryInterface;

class ComposanteControllerFactory implements FactoryInterface
{

    public function __invoke(ContainerInterface $container, $requestedName, ?array $options = null)
    {
        /** @var ComposanteController $controller */
        $controller = new ComposanteController();

        /** @var ComposanteService $entityService */
        $entityService = $container->get('ServiceManager')->get(ComposanteService::class);
        $controller->setComposanteService($entityService);
        /** @var ComposanteForm $composanteForm */
        $composanteForm = $container->get('FormElementManager')->get(ComposanteForm::class);
        $controller->setComposanteForm($composanteForm);

        return $controller;
    }
}
