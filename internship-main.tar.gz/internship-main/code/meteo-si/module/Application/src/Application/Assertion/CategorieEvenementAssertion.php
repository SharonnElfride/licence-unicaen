<?php

namespace Application\Assertion;

use Application\Assertion\AbstractAssertion;
use Laminas\Permissions\Acl\Resource\ResourceInterface;
use Laminas\Permissions\Acl\Role\RoleInterface;
use MeteoSI\Controller\CategorieEvenement\CategorieEvenementController;
use MeteoSI\Model\CategorieEvenement;
use MeteoSI\Provider\Evenement\CategorieEvenementProvider;

class CategorieEvenementAssertion extends AbstractAssertion
{
    /** @var CategorieEvenement $categorie */
    private $categorie;

    /**
     * Permet de dire si on a le droit de faire l'action et de vérifier si l'entité d'id $id existe
     *
     * @param ResourceInterface|null $entity
     * @param $privilege
     * @return bool
     */
    protected function assertEntity(ResourceInterface $entity = null, $privilege = null)
    {
        //Rôlr de l'user
        $role = $this->getRole();

        // si le rôle n'est pas renseigné
        if (!$role instanceof RoleInterface) return false;

        // si le rôle ne possède pas le privilège
        if (!parent::assertEntity($entity, $privilege)) {
            return false;
        }

        return true;
    }

    protected function assertController($controller, $action = null, $privilege = null)
    {
        $role = $this->getRole();

        // si le rôle n'est pas renseigné
        if (!$role instanceof RoleInterface) return false;

        // récupération de la catégorie d'événement
        $categorie = $this->getCategorieEvenement();

        switch ($action) {
            case 'index':
            case 'add':
                return true;
            case 'show' :
            case 'edit':
                return isset($categorie);
            case 'delete':
                return (isset($categorie) && ($categorie->getCode() !== CategorieEvenementProvider::CATEGORIE_EVENEMENT_INDETERMINEE_CODE)); // && (sizeof($categorie->getEvenements()) === 0));
        }

        return false;
    }

    protected function getCategorieEvenement()
    {
        if (null === $this->categorie) {
            // identifiant de l'entité
            $id = $this->getParam('id');

            if (!$id) {
                return null;
            }

            $this->categorie = $this->getEntityManager()->getRepository(CategorieEvenement::class)->find($id);
        }

        return $this->categorie;
    }
}