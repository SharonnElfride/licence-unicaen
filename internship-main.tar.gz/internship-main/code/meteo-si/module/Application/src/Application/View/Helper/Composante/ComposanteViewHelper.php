<?php

namespace Application\Application\View\Helper\Composante;

use Application\Application\Entity\Traits\ComposanteAwareTrait;
use Application\Application\View\Helper\Interfaces\EntityViewHelperInterface;
use Application\Application\View\Helper\Traits\EntityActionsViewHelperTraits;
use Application\Controller\Composante\ComposanteController;
use Application\Entity\Composante;
use Application\Provider\Privilege\FormationPrivileges;
use Laminas\Form\Form;
use Laminas\View\Helper\AbstractHelper;

class ComposanteViewHelper extends AbstractHelper implements EntityViewHelperInterface
{
    use ComposanteAwareTrait;
    use EntityActionsViewHelperTraits;

    /**
     * @param Composante $composante
     * @return self
     */
    public function __invoke(?Composante $composante = null): ComposanteViewHelper
    {
        $this->setComposante($composante);
        return $this;
    }


    /**
     * @return string
     */
    public function renderListe(?array $composantes = []): string
    {
        if (!$this->assertActionAllowed(ComposanteController::ACTION_LISTER)) {
            return "";
        }

        return $this->view->render('application/composante/composante/template/liste-composantes', ['composantes' => $composantes]);
    }

    public function assertActionAllowed(string $action): bool
    {
        if (!$this->assertHasPrivilege($action)) {
            $this->setNotAllowedActionMessage(self::NO_PRIVILEGE_MSG);
            return false;
        }
        switch ($action) {
            case ComposanteController::ACTION_AFFICHER:
            case ComposanteController::ACTION_MODIFIER:
            case ComposanteController::ACTION_SUPPRIMER:
                if (!$this->hasComposante()) {
                    $this->setNotAllowedActionMessage("La composante n'est pas définie");
                    return $this->hasComposante();
                }
                return true;
            case ComposanteController::ACTION_AJOUTER:
            case ComposanteController::ACTION_LISTER:
                return true;
        }
        $this->setNotAllowedActionMessage("L'action n'est pas disponible");
        return false;
    }

    public function renderForm(Form $form): string
    {
        return $this->view->render('application/composante/composante/template/form-composante', ['form' => $form]);
    }

    public function getActionRoute(string $action): ?string
    {
        switch ($action) {
            case ComposanteController::ACTION_AFFICHER && $this->hasComposante():
                return $this->view->url(ComposanteController::ROUTE_AFFICHER, ['composante' => $this->getComposante()->getId()], [], true);
            case ComposanteController::ACTION_AJOUTER :
                return $this->view->url(ComposanteController::ROUTE_AJOUTER, [], [], true);
            case ComposanteController::ACTION_LISTER:
                return $this->view->url(ComposanteController::ROUTE_LISTER, [], [], true);
        }
        return null;
    }

    public function getActionPriviliege(string $action): ?string
    {
        switch ($action) {
            case ComposanteController::ACTION_AFFICHER:
            case ComposanteController::ACTION_LISTER:
                return FormationPrivileges::COMPOSANTE_AFFICHER;
            case ComposanteController::ACTION_AJOUTER:
                return FormationPrivileges::COMPOSANTE_AJOUTER;
            case ComposanteController::ACTION_MODIFIER:
                return FormationPrivileges::COMPOSANTE_MODIFIER;
            case ComposanteController::ACTION_SUPPRIMER:
                return FormationPrivileges::COMPOSANTE_SUPPRIMER;
        }
        return null;
    }

    /**
     * @param string|null $label
     * @param array $data
     * @return string
     */
    public function renderLienAfficher(?string $label = null, ?array $data = []): string
    {
        $action = ComposanteController::ACTION_AFFICHER;
        if (!$this->assertHasPrivilege($action)) {
            return "";
        }
        //Définition des class par défaut si elle ne sont pas définie
        if (!isset($data['class'])) {
            $data['class'] = "ajax-modal text-primary";
        }
        if (!isset($data['title'])) {
            $data['title'] = "Afficher la composante";
        }
        if (!isset($label) || $label == "") {
            $label = "<span class='icon icon-voir'></span>";
        }
        return $this->renderActionLink($action, $label, $data);
    }

    /**
     * @param string|null $label
     * @param array $data
     * @return string
     */
    public function renderLienAjouter(?string $label = null, ?array $data = []): string
    {
        $action = ComposanteController::ACTION_AJOUTER;
        if (!$this->assertHasPrivilege($action)) {
            return "";
        }

        //Définition des class par défaut si elle ne sont pas définie
        if (!isset($data['class'])) {
            $data['class'] = "ajax-modal text-success";
        }
        if (!isset($data['title'])) {
            $data['title'] = "Ajouter une composante";
        }
        if (!isset($label) || $label == "") {
            $label = "<span class='icon icon-ajouter'></span>";
        }
        return $this->renderActionLink($action, $label, $data);
    }

    /**
     * @param string|null $label
     * @param array $data
     * @return string
     */
    public function renderLienModifier(?string $label = null, ?array $data = []): string
    {
        $action = ComposanteController::ACTION_MODIFIER;
        if (!$this->assertHasPrivilege($action)) {
            return "";
        }

        //Définition des class par défaut si elle ne sont pas définie
        if (!isset($data['class'])) {
            $data['class'] = "ajax-modal text-primary";
        }
        if (!isset($data['title'])) {
            $data['title'] = "Modifier la composante";
        }
        if (!isset($label) || $label == "") {
            $label = "<span class='icon icon-modifier'></span>";
        }
        return $this->renderActionLink($action, $label, $data);
    }

    /**
     * @param string|null $label
     * @param array $data
     * @return string
     */
    public function renderLienSupprimer(?string $label = null, ?array $data = []): string
    {
        $action = ComposanteController::ACTION_SUPPRIMER;
        if (!$this->assertHasPrivilege($action)) {
            return "";
        }

        //Définition des class par défaut si elle ne sont pas définie
        if (!isset($data['class'])) {
            $data['class'] = "ajax-modal text-danger";
        }
        if (!isset($data['title'])) {
            $data['title'] = "Supprimer la composante";
        }
        if (!isset($label) || $label == "") {
            $label = "<span class='icon icon-supprimer'></span>";
        }
        return $this->renderActionLink($action, $label, $data);
    }

    public function renderStatut()
    {
        if (!isset($this->composante)) return "";
        $actif = $this->composante->estNonHistorise();
        $badge = sprintf("<span class='badge %s'>%s</span>",
            ($actif) ? "badge-success" : "badge-muted",
            ($actif) ? "Active" : "Historisée"
        );
        return $badge;
    }
}