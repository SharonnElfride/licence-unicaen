<?php


namespace Application\Application\Form;

use Laminas\Filter\StringTrim;
use Laminas\Filter\StripTags;
use Laminas\Form\Element\Text;
use Laminas\Form\Fieldset;
use Laminas\InputFilter\InputFilterProviderInterface;
use Laminas\Validator\StringLength;
use UnicaenApp\Service\EntityManagerAwareTrait;

abstract class AbstractEntityFieldset extends Fieldset implements InputFilterProviderInterface
{
    use EntityManagerAwareTrait;

    const INVALIDE_ERROR_MESSAGE = "Le formulaire n'est pas valide :";


    const INPUT_CODE = "code";
    const LABEL_CODE = "Code";
    const PLACEHOLDER_CODE = "Saisir un code";
    const INPUT_LIBELLE = "libelle";
    const LABEL_LIBELLE = "Libellé";
    const PLACEHOLDER_LIBELLE = "Saisir un libellé";

    protected function initInputCode(array $data = [])
    {
        $defaultData = [
            "name" => self::INPUT_CODE,
            "type" => Text::class,
            "options" => [
                "label" => self::LABEL_CODE,
            ],
            "attributes" => [
                "id" => self::INPUT_CODE,
                "placeholder" => self::PLACEHOLDER_CODE,
            ],
        ];
        $data = array_merge($data, $defaultData);
        $this->add($data);
    }

    protected function getCodeInputSpecification()
    {
        return [
            "name" => self::INPUT_CODE,
            'required' => true,
            'filters' => [
                ['name' => StripTags::class],
                ['name' => StringTrim::class],
            ],
            'validators' => [
                [
                    'name' => StringLength::class,
                    'options' => [
                        'encoding' => 'UTF-8',
                        'min' => 1,
                        'max' => 50
                    ],
                ],
            ],
        ];
    }

    protected function initInputLibelle(array $data = [])
    {
        $defaultData = [
            "name" => self::INPUT_LIBELLE,
            "type" => Text::class,
            "options" => [
                "label" => self::LABEL_LIBELLE,
            ],
            "attributes" => [
                "id" => self::INPUT_LIBELLE,
                "placeholder" => self::PLACEHOLDER_LIBELLE,
            ],
        ];
        $data = array_merge($data, $defaultData);
        $this->add($data);
    }

    protected function getLibelleInputSpecification()
    {
        return [
            "name" => self::INPUT_LIBELLE,
            'required' => true,
            'filters' => [
                ['name' => StripTags::class],
                ['name' => StringTrim::class],
            ],
            'validators' => [
                [
                    'name' => StringLength::class,
                    'options' => [
                        'encoding' => 'UTF-8',
                        'min' => 1,
                        'max' => 256
                    ],
                ],
            ],
        ];
    }
}