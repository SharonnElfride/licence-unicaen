# Unicaen Utilisateur LDAP Adpater

## But du module

Le but de cet adaptateur est de fournir une service effectuant une recherche dans le LDAP en garantissant le contract
des interface de `Unicaen/Utilisateur` : `RechercheIndividuServiceInterface` et `RechercheIndividuResultatInterface`.
Cela sans modification de `Unicaen/Ldap`.

## Historique des versions

**version 0.1.1**  16/10/2019

- version initial fournissant le service de recherche

## Amélioration et/ou changement à venir

Aucun 