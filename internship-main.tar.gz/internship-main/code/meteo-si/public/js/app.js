/**
 * Fonction JS de base de l'application
 */

function closeModal(event) {
    event.div.modal('hide');
}

$(function(){
    // back button
    $('.btn-back').on('click', function(e){
        e.preventDefault();
        parent.history.back();
        return false;
    });
});