/**
 * CODE JAVASCRIPT PROPRE À CHAQUE APPLICATION.
 *
 * Cette feuille est propagée par le module AssetManager.
 *
 * NB: Elle est vide car elle est vouée à être zappée par celle du même nom que le développeur
 * peut créer dans le répertoire 'public/css' de l'application.
 */
