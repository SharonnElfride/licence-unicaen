const primary_color = "#482E74";
const inactive_tab_color = "#97dffc";
const active_tab_color = "#fff";
const background_color = "#fff";
const header_text_color = "#fff";

const task_color = ["#699", "#d4776a", "#ffada3", "#d2b3e3", "#9988a3", "#799292", "#566891", "#d9d875", "#d9ae75", "#adcb6e"]

export { primary_color, inactive_tab_color, active_tab_color, background_color, header_text_color, task_color };

//import { primary_color, inactive_tab_color, active_tab_color, background_color, header_text_color} from '../skin/AppColors';