// Helpers/todoData.js

const todoData = [
    {
        id: 1,
        content: "Do the homeworks",
        done: true
    },
    {
        id: 2,
        content: "Clean the bedroom",
        done: false
    },
    {
        id: 3,
        content: "Clean the dishes",
        done: false
    }
];

export default todoData



