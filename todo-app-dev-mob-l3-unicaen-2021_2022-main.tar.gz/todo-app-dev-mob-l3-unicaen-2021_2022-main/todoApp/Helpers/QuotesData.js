const quotes_data = [
    {
        id: 1,
        content: "<<Don’t let yesterday take up too much of today.>> — Will Rogers",
    },

    {
        id: 2,
        content: "<<Learn as if you will live forever, live like you will die tomorrow.>> — Mahatma Gandhi",
    },

    {
        id: 3,
        content: "<<You learn more from failure than from success. Don’t let it stop you. Failure builds character.>> — Unknown ",
    },

    {
        id: 4,
        content: "<<You've got to get up every morning with determination if you're going to go to bed with satisfaction.>> — George Lorimer",
    },

    {
        id: 5,
        content: "<<People say nothing is impossible, but I do nothing every day.>> — Winnie the Pooh",
    },

    {
        id: 6,
        content: "<<We don’t just sit around and wait for other people. We just make, and we do.>> — Arlan Hamilton",
    },

    {
        id: 7,
        content: "<<The most difficult thing is the decision to act, the rest is merely tenacity.>> —Amelia Earhart",
    },

    {
        id: 8,
        content: "<<Your work is going to fill a large part of your life, and the only way to be truly satisfied is " 
                    + "to do what you believe is great work. And the only way to do great work is to love what you do." 
                    + "If you haven't found it yet, keep looking. Don't settle. As with all matters of the heart, you'll "
                    + "know when you find it.>> — Steve Jobs",
    },

    {
        id: 9,
        content: "<<The elevator to success is out of order. You’ll have to use the stairs, one step at a time.>> — Joe Girard",
    },

    {
        id: 10,
        content: "<<Work until your bank account looks like a phone number.>> — Unknown ",
    },

    {
        id: 11,
        content: "<<I am so clever that sometimes I don’t understand a single word of what I am saying.>> — Oscar Wilde",
    },

    {
        id: 12,
        content: "<<I always wanted to be somebody, but now I realise I should have been more specific.>> — Lily Tomlin",
    },
];

export default quotes_data;