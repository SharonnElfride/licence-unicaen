import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import { primary_color, background_color } from '../skin/AppColors';

import HomeScreen from '../Screen/HomeScreen';
import ProfileScreen from '../Screen/ProfileScreen';
import SignInScreen from '../Screen/SignInScreen';
import SignUpScreen from '../Screen/SignUpScreen';
import SignOutScreen from '../Screen/SignOutScreen';
import TodoListsScreen from '../Screen/TodoListsScreen';
import TodoListDetailsScreen from '../Screen/TodoListDetailsScreen';
import AboutUsScreen from '../Screen/AboutUsScreen';
import AddTodoListScreen from '../Screen/AddTodoListScreen';
import ImagePickerScreen from '../Screen/ImagePickerScreen';

const Stack = createNativeStackNavigator()

//Header style functions
const headerStyle = (screen_title) => {
    return {
        title: screen_title,
        headerStyle: {
        backgroundColor: primary_color,
        },
        headerTintColor: background_color,
        headerTitleStyle: {
        fontWeight: 'bold',
        fontSize: 30,
        },
    }
}

//Screens functions
function HomeToAbout() {
    return (
      <Stack.Navigator>
        <Stack.Screen name="home" component={HomeScreen} options={headerStyle('Home')}/>
        <Stack.Screen name="AboutUs" component={AboutUsScreen} options={headerStyle('About Us')}/>
      </Stack.Navigator>
    );
}

function ProfileToAbout() {
    return (
      <Stack.Navigator>
        <Stack.Screen name="profile" component={ProfileScreen} options={headerStyle('Profile')}/>
        <Stack.Screen name="AboutUs" component={AboutUsScreen} options={headerStyle('About Us')}/>
      </Stack.Navigator>
    );
}

function SignInToAbout() {
    return (
      <Stack.Navigator>
        <Stack.Screen name="SignIn" component={SignInScreen} options={headerStyle('Sign In')}/>
        <Stack.Screen name="AboutUs" component={AboutUsScreen} options={headerStyle('About Us')}/>
      </Stack.Navigator>
    );
}

function SignUpToAbout() {
    return (
      <Stack.Navigator>
        <Stack.Screen name="SignUp" component={SignUpScreen} options={headerStyle('Sign Up')}/>
        <Stack.Screen name="AboutUs" component={AboutUsScreen} options={headerStyle('About Us')}/>
      </Stack.Navigator>
    );
}

function SignOutToAbout() {
    return (
      <Stack.Navigator>
        <Stack.Screen name="SignOut" component={SignOutScreen} options={headerStyle('Sign Out')}/>
        <Stack.Screen name="AboutUs" component={AboutUsScreen} options={headerStyle('About Us')}/>
      </Stack.Navigator>
    );
}

function TodoListsToDetails() {
    return (
      <Stack.Navigator initialRouteName='TodoLists'>
        <Stack.Screen name='TodoLists' component={TodoListsScreen} options={headerStyle('Todo Lists')}/>
        <Stack.Screen name="AboutUs" component={AboutUsScreen} options={headerStyle('About Us')}/>
        <Stack.Screen name='TodoListDetails' component={TodoListDetailsScreen} options={headerStyle('Details')}/>
        <Stack.Screen name="AddTodoList" component={AddTodoListToImagePicker} options={{ headerShown: false }}/>
      </Stack.Navigator>
    )
  }
//If possible, put the todoList name

function AddTodoListToImagePicker() {
  return (
    <Stack.Navigator initialRouteName='Add Todo List'>
      <Stack.Screen name="Add Todo List" component={AddTodoListScreen} options={headerStyle('Add Todo List')}/>
      <Stack.Screen name="ImagePicker" component={ImagePickerScreen} options={headerStyle('Image Picker')}/>
    </Stack.Navigator>
  );
}

export { HomeToAbout, ProfileToAbout, SignInToAbout, SignUpToAbout, SignOutToAbout, TodoListsToDetails };

//import { HomeToAbout, ProfileToAbout, SignInToAbout, SignUpToAbout, SignOutToAbout, TodoListsToDetails } from './ScreensStack';
