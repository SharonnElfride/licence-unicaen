import React from 'react';
import { TouchableOpacity, Image } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Ionicons from 'react-native-vector-icons/Ionicons';

import { primary_color, inactive_tab_color, active_tab_color, background_color } from '../skin/AppColors';
import { HomeToAbout, ProfileToAbout, SignInToAbout, SignUpToAbout, SignOutToAbout, TodoListsToDetails } from './ScreensStack';
import { TokenContext } from '../Context/Context';

const Tab = createBottomTabNavigator()

const about_button = () => {
  return (
    <TouchableOpacity
      //onPress={() => navigation.navigate('AboutUsScreen')}
    >
      <Image source={require("../assets/about_icon.png")} style={{width:50,height:50}}/>
    </TouchableOpacity>
  )
}

const headerStyle = (screen_title) => {
  return {
    title: screen_title,
    headerStyle: {
      backgroundColor: primary_color,
    },
    headerTintColor: background_color,
    headerTitleStyle: {
      fontWeight: 'bold',
      fontSize: 30,
    },
    headerRight: about_button,
  }
}

export default function Navigation () {
  return (
    <TokenContext.Consumer>
      {([token, setToken]) => (
        <NavigationContainer>
          {token == null ? (
            <Tab.Navigator
              screenOptions={({ route }) => ({
                tabBarStyle: { 
                  backgroundColor: primary_color,
                },

                tabBarIcon: ({ color, size, focused }) => {
                  let iconName;

                  if(route.name === 'Sign In') {
                    iconName = 'walk-outline';
                  }
                  
                  else if(route.name === 'Sign Up') {
                      iconName = 'person-add-outline';
                  }
              
                  return <Ionicons name={iconName} size={size} color={color} solid={focused} light={!focused} />
                },

                  tabBarActiveTintColor: active_tab_color,
                  tabBarInactiveTintColor: inactive_tab_color,
              })}
            >
              <Tab.Screen name='Sign In' component={SignInToAbout} options={{ headerShown: false }}/>
              <Tab.Screen name='Sign Up' component={SignUpToAbout} options={{ headerShown: false }}/>
            </Tab.Navigator>
          ) : (
            <Tab.Navigator
              screenOptions={({ route }) => ({
                tabBarStyle: { 
                  backgroundColor: primary_color,
                },

                tabBarIcon: ({ color, size, focused }) => {
                  let iconName;

                  if(route.name === 'Home') {
                    iconName = 'md-home-outline';
                  }
                  
                  else if(route.name === 'Todo Lists') {
                      iconName = 'reader-outline';
                  }
                  
                  else if(route.name === 'Profile') {
                    iconName = 'person-circle-outline';
                  }

                  else if(route.name === 'Sign Out') {
                    iconName = 'walk-outline';
                  }

                  return <Ionicons name={iconName} size={size} color={color} solid={focused} light={!focused} />
                },

                  tabBarActiveTintColor: active_tab_color,
                  tabBarInactiveTintColor: inactive_tab_color,
              })}      
            >
              <Tab.Screen name='Home' component={HomeToAbout} options={{ headerShown: false }}/>
              <Tab.Screen name='Todo Lists' component={TodoListsToDetails} options={{ headerShown: false }}/>
              <Tab.Screen name='Profile' component={ProfileToAbout} options={{ headerShown: false }}/>
              <Tab.Screen name='Sign Out' component={SignOutToAbout} options={{ headerShown: false }}/>
            </Tab.Navigator>
          )}
        </NavigationContainer>
      )}
    </TokenContext.Consumer>
  )
}