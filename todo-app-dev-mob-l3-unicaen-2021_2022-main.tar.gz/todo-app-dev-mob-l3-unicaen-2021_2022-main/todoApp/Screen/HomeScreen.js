import React from "react";
import { StyleSheet, View, Text, Image, TouchableOpacity } from "react-native";

import { background_color } from '../skin/AppColors';
import { UsernameContext } from '../Context/Context';

export default function HomeScreen({ navigation }) {

    React.useLayoutEffect(() => {
        navigation.setOptions({
          headerRight: () => (
            <TouchableOpacity
                onPress={() => navigation.navigate('AboutUs')}
            >
                <Image source={require("../assets/about_icon.png")} style={{width:50,height:50}}/>
            </TouchableOpacity>
          ),
        });
      }, [navigation]);

    return (
        <UsernameContext.Consumer>
        {([username, setUsername]) => {
        return (        
            <View style={styles.container}>
                {/*<Text style={[styles.text, {fontSize:25, fontWeight:'bold'}]}> Home </Text>*/}
                <Text style={styles.text}> Welcome! You're logged as <b><i>{username}</i></b> 
                <Image source={require("../img/emoji.png")} style={{width:50, height:25, marginLeft:5}} /> </Text>
                <Text style={styles.text}> Ready to work ?</Text>
                <Image source={require("../img/todo_list.jpg")} style={{width:'80%', height:300}}/>
            </View>
            )
        }}
        </UsernameContext.Consumer>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        margin: 10,
        backgroundColor: background_color,
        alignItems: 'center',
        justifyContent: 'center',
    },

    text: {
        fontSize: 20,
        marginBottom: 10,
    },
})