import React from "react";
import { StyleSheet, View, Text, Image, TouchableOpacity } from "react-native";

import { primary_color, background_color } from '../skin/AppColors';
import { UsernameContext } from "../Context/Context";
import quotes_data from "../Helpers/QuotesData";

export default function ProfileScreen({ navigation }) {

    React.useLayoutEffect(() => {
        navigation.setOptions({
          headerRight: () => (
            <TouchableOpacity
                onPress={() => navigation.navigate('AboutUs')}
            >
                <Image source={require("../assets/about_icon.png")} style={{width:50,height:50}}/>
            </TouchableOpacity>
          ),
        });
      }, [navigation]);

    const quotes= quotes_data;
    const len = quotes.length;

    return (
        <UsernameContext.Consumer>
        {([username, setUsername]) => {
        return (        
            <View style={styles.container}>
                {/*<Text style={[styles.text, {fontSize:25, fontWeight:'bold'}]}> Profile </Text>*/}
                <Image source={require("../img/profile.jpg")} style={styles.user_profile_picture}/>
                <View style={styles.user_info}>
                    <Text style={styles.text}> <b><i>{username}</i></b> </Text>
                    <Text style={styles.text}> {quotes[Math.floor(Math.random() * len)].content} </Text>
                </View>
            </View>
            )
        }}
        </UsernameContext.Consumer>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        margin: 10,
        backgroundColor: background_color,
        alignItems: 'center',
        justifyContent: 'center',
    },

    text: {
        fontSize: 20,
        marginBottom: 10,
    },

    user_profile_picture: {
        height: 300,
        width: 300,
        border: '0.5px solid',
        borderColor: primary_color,
        borderRadius: '50%',
        paddingTop: 0,
    },

    user_info: {
        marginTop: '5%',
        marginLeft: '20%',
        marginRight: '20%',
        padding: 10,
        border: '2px dotted',
        borderColor: primary_color,
        borderRadius: 10,
        alignItems: 'center',
        justifyContent: 'center',
    },
})