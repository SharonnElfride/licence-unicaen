import React from 'react';
import { View, StyleSheet, TouchableOpacity } from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';

import AddTodoList from '../components/AddTodoList';
import { background_color, primary_color } from "../skin/AppColors";

export default function AddTodoListScreen({ navigation, route }) {

    return (
        <View style={styles.container}>
            <TouchableOpacity 
                onPress={() => navigation.goBack()}
                style={styles.go_back}
            >
                <Ionicons name={'md-arrow-back-outline'} size={35} color={primary_color}/>
            </TouchableOpacity>
            <AddTodoList navigation={navigation} route={route}/>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: background_color,
        alignItems: 'center',
        justifyContent: 'center',
        width:'100%',
    },

    go_back: {
        width: 50,
        height: 50,
        justifyContent:'center',
        alignContent: 'center',
        backgroundColor: background_color,
        position: 'absolute',
        top: '2%',
        left: '5%',
    },
})