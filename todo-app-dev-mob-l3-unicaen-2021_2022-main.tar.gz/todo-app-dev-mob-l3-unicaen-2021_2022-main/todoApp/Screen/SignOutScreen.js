import React from "react";
import { StyleSheet, View, Text, Button, TouchableOpacity, Image } from "react-native";

import { primary_color, background_color } from '../skin/AppColors';
import { UsernameContext, TokenContext } from '../Context/Context';

export default function SignOutScreen({ navigation }) {

    React.useLayoutEffect(() => {
        navigation.setOptions({
          headerRight: () => (
            <TouchableOpacity
                onPress={() => navigation.navigate('AboutUs')}
            >
                <Image source={require("../assets/about_icon.png")} style={{width:50,height:50}}/>
            </TouchableOpacity>
          ),
        });
      }, [navigation]);

    return (
        <UsernameContext.Consumer>
        {([username, setUsername]) => {
        return ( 
            <TokenContext.Consumer>
                {([token, setToken]) => (

                    <View style={styles.container}>
                        {/*<Text style={{fontSize:25, marginBottom: 10, fontWeight:'bold'}}> Sign Out </Text>*/}
                        <Text style={{fontSize:20, marginBottom: 50}}> Goodbye! See you later <b><i>{username}</i></b> </Text>
                        <View style={styles.sign_out}>
                            <Button
                                onPress={() => setToken(null)}
                                title="Sign out"
                                color={primary_color}
                                accessibilityLabel="Logout the todo app"
                            />
                        </View>
                    </View>
                )}
            </TokenContext.Consumer>
            )
        }}
        </UsernameContext.Consumer>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        margin: 10,
        backgroundColor: background_color,
        alignItems: 'center',
        justifyContent: 'center',
        marginVertical: 'middle',
    },

    sign_out: {
        width: 200,
    },
})