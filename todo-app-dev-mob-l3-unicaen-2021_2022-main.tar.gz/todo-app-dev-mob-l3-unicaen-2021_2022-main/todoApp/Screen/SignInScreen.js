import React from "react";
import { StyleSheet, View, Text, TouchableOpacity, Image } from "react-native";

import { background_color } from '../skin/AppColors';
import { Link } from '@react-navigation/native'
import SignIn from "../components/SignIn";

export default function SignInScreen({ navigation }) {

    React.useLayoutEffect(() => {
        navigation.setOptions({
          headerRight: () => (
            <TouchableOpacity
                onPress={() => navigation.navigate('AboutUs')}
            >
                <Image source={require("../assets/about_icon.png")} style={{width:50,height:50}}/>
            </TouchableOpacity>
          ),
        });
      }, [navigation]);

    return (
        <View style={styles.container}>
            {/* Top */}
            {/*<Text style={{fontSize:25, fontWeight:'bold'}}> Sign In </Text>*/}

            {/* Middle */}
            <View style={styles.middle_part}>
                <SignIn />
            </View>
            <Text>
                If you prefer, you can{' '}
                <Link
                style={{ textDecorationLine: 'underline' }}
                to={{ screen: 'Sign Up' }}
                >
                    Sign Up
                </Link>
            </Text>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: background_color,
        alignItems: 'center',
        justifyContent: 'center',
        margin: 10,
    },

    middle_part: {
        marginBottom: 10,
    },
})