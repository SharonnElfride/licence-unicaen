import React from "react";
import { StyleSheet, View, Text } from "react-native";

import { background_color, primary_color } from '../skin/AppColors';

export default function AboutUsScreen() {
    return (
        <View style={styles.container}>
            {/*<Text style={[styles.text, {fontSize:25, fontWeight:'bold'}]}> About Us </Text>*/}
            <View style={styles.etu_presentation}>
                <Text style={styles.text}> 21901638 <br /> Steven MARTIN </Text>
                <Text style={styles.text}> 22010454 <br /> Ahouefa ZOUNON </Text>
            </View>
            <hr style={{width: '50%', border: '5px double', borderColor: primary_color, marginBottom:15}}/>
            <View>
                <Text style={styles.text}> 
                    Nous avons fait une todo list app pour la vie quotidienne, l'école, le boulot ou autre. <br />
                    Les fonctionnalités de base ont été implémentées et nous avons aussi modifié le fichier todo.graphql pour qu'il puisse répondre à nos différents besoins. <br/>
                    Nous avons donc, dans le cadre de nos modifications, ajouté l'archive tp2.tar.gz contenant le nouveau fichier et le dossier todoApp contenant notre code. <br/>
    
                    Fonctionnalités de base : <br/>
                    <ul>
                        <li> La gestion de l'API avec Neo4j/GraphQL sur la machine virtuelle fournie </li>
                        <li> La gestion de multiples utilisateurs </li>
                        <li> La gestion des TodoLists avec compteur de tâches réalisées </li>
                        <li> La gestion des Todos avec interface pour (dé)cocher tout, afficher les tâches (non) réalisées </li>
                        <li> Un thème graphique / UX design </li>
                    </ul>
    
                    Parmi les fonctionnalités avancées proposées, nous avons opté pour: <br/>
                    <ul>
                        <li> Une barre de progression, pour chaque todolist, indiquant le nombre de Tasks réalisés sur le total </li>
                        {/*<li>livraison d'un .APK fonctionnel non assemblé par Expo </li>*/}
                        <li> L'ajout d'une image (par exemple en provenance de la banque d'images mise à disposition) pour une todoList </li>
                    </ul>

                    Nous avons aussi ajouté la possibilité d'éditer une tâche. <br/>
    
                    Nous nous tenons à votre disposition pour toutes questions et nous serions ravis d'améliorer notre applications en fonctions de vos remarques et/ou feedbacks. <br />
                    Merci infiniment. <br/>
                    Ahouefa & Steven.
                </Text>
            </View>
        </View>
    )
}

const styles = StyleSheet.create({
container: {
    flex: 1,
    margin: 10,
    backgroundColor: background_color,
    alignItems: 'center',
    justifyContent: 'center',
},

etu_presentation: {
    flexDirection: 'row',
    justifyContent: 'space-evenly',
},

text: {
    fontSize: 15,
    fontWeight: 'bold',
    textAlign: 'left',
    margin: 20,
},
})