import React, { useState, useLayoutEffect, useEffect, useContext } from "react";
import { StyleSheet, View, Text, Image, TouchableOpacity, ActivityIndicator, FlatList, ScrollView } from "react-native";
import Ionicons from 'react-native-vector-icons/Ionicons';

import { background_color, primary_color } from '../skin/AppColors';
import TodoListItem from "../components/TodoListItem";
import { show_todo_list, delete_todo_list } from "../API/todoAPI";
import { UsernameContext, TokenContext } from "../Context/Context";

export default function TodoListsScreen({ navigation }) {

    const [isLoading, setIsLoading] = useState(true)
    const [error, setError] = useState('')
    const [data, setData] = useState([])
    const [username, setUsername] = useContext(UsernameContext)
    const [token, setToken] = useContext(TokenContext)

    useEffect(() => {
        setError('')
        show_todo_list(username, token)
          .then(data => {
            setData(data)
            setIsLoading(false)
          })
          .catch(error =>
            console.log(error)
            /*showMessage({
              message: 'API Error: ' + error.message,
              type: 'error'
            })*/
          )
    }, [data]) //data

    useLayoutEffect(() => {
        navigation.setOptions({
          headerRight: () => (
            <TouchableOpacity
                onPress={() => navigation.navigate('AboutUs')}
            >
                <Image source={require("../assets/about_icon.png")} style={{width:50,height:50}}/>
            </TouchableOpacity>
          ),
        });
      }, [navigation]);

    useEffect(() => {
    if (data.length == 0) {
        //chargement initial
    }}, [data]);

    let essai = require("../img/default_tl_img.png")
    let data_len = data.length

    const deleteTodoList = (id) => {
        setError('')
        delete_todo_list(id, username, token)
        .then(deleteInfo => {
            console.log("Deletion of " + deleteInfo)
        })
        .catch(err => {
            setError(err.message)
        })
    }
    //}

    return (
        <View style={styles.container}>
            {isLoading ? (
            <ActivityIndicator />
            ) : (
            <View >
                {/*<Text style={[styles.text, {fontSize:25, fontWeight:'bold'}]}> Todo Lists </Text>*/}
                <Text style={styles.text}> List of todo lists </Text>
                
                {data_len == 0 ? (
                    <>
                        <Text>
                            You don't have any todolist yet! You can click on the + button down below to create one.
                        </Text>
                    </>
                ) : (
                    <>
                        <FlatList
                            style={styles.todo_list}
                            data={data}
                            keyExtractor={item => item.id}
                            renderItem={({item}) => 
                                <TodoListItem 
                                    item={item} navigation={navigation} deleteTodoList={deleteTodoList}
                                    username={username} token={token}
                                />
                            }
                        />
                    </>            
                )}
            </View>
            )}

            <View style={styles.add_todo_list}>
                <TouchableOpacity 
                    style={styles.add_button}
                    onPress={() => navigation.navigate('AddTodoList')}
                    accessibilityLabel="Add new todo list button"
                >
                    <Ionicons name="add-circle-outline" size={30} color={background_color}/>
                </TouchableOpacity>
            </View>
            
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        margin: 10,
        padding: 10,
        backgroundColor: background_color,
        alignItems: 'center',
        justifyContent: 'center',
        width:'100%',
    },

    text: {
        fontSize: 20,
        marginBottom: 10,
    },

    todo_list: {
        marginBottom: 10,
    },

    todo: {
        flexDirection: "row",
        alignItems: "center",
        marginBottom: 5,
    },

    todo_list_text: {
        fontSize: 20
    },

    todo_list_image: {
        width:50, 
        height:50, 
        borderWidth: 1,
        borderRadius: 25,
    },

    add_todo_list: {
        width: 50,
        height: 50,
        justifyContent:'center',
        alignContent: 'center',
        backgroundColor: primary_color,
        position: 'absolute',
        bottom: '5%',
        right: '5%',
        borderRadius: '50%',
    },

    add_button: {
        alignItems: 'center',
        justifyContent: 'center',
    },

    progress_bar: {
        backgroundColor: "#aaa",
        color: primary_color,
    },
})