import React from "react";
import { StyleSheet, View } from 'react-native';

import { background_color } from '../skin/AppColors';
import TodoList from '../components/TodoList';

export default function TodoListDetailsScreen({navigation, route}){

    return (
        <View style={styles.container}>
            <TodoList data={route.params.data}/>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: background_color,
      alignItems: 'center',
      justifyContent: 'center',
      margin: 20,
    },
});

