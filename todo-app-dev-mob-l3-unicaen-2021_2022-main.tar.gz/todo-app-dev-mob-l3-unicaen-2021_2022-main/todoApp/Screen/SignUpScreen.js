import React from "react";
import { StyleSheet, View, TouchableOpacity, Image } from "react-native";

import { background_color } from '../skin/AppColors';
import SignUp from '../components/SignUp';

export default function SignUpScreen({ navigation }) {

    React.useLayoutEffect(() => {
        navigation.setOptions({
          headerRight: () => (
            <TouchableOpacity
                onPress={() => navigation.navigate('AboutUs')}
            >
                <Image source={require("../assets/about_icon.png")} style={{width:50,height:50}}/>
            </TouchableOpacity>
          ),
        });
      }, [navigation]);

    return (
        <View style={styles.container}>
            {/* Top */}
            {/*<Text style={{fontSize:25, fontWeight:'bold'}}> Sign Up </Text>*/}

            {/* Middle */}
            <View style={styles.middle_part}>
                <SignUp />
            </View>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: background_color,
        alignItems: 'center',
        justifyContent: 'center',
        margin: 10,
    },

    middle_part: {
        flexDirection: "row",
        alignItems: 'center',
        marginTop: 20,
    },
})