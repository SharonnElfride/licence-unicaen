import React from "react";
import { View, Text, StyleSheet, Image, TouchableOpacity, ScrollView } from "react-native";

import { background_color, primary_color } from "../skin/AppColors";

export default function ImagePickerScreen({ route, navigation }) {

    let pI_require = null
    
    let picked_img = (
        <Image source={require("../img/todo_img/school/code.jpg")} style={styles.pI_require}/>
    )

    return(
        <View style={styles.container}>
            <Text style={[styles.category_title, {marginTop: 10,}]}> Choose an image among these below </Text>
            <ScrollView style={styles.portfolio}>

                {/* School */}
                <View style={styles.category}>
                    <Text style={styles.category_title}> School </Text>
                    <View style={styles.category_line}>
                        <TouchableOpacity
                            style={styles.category_col}
                            onPress={() => {
                                    pI_require = require("../img/todo_img/school/code.jpg")
                                }
                            }
                        >
                            <Image source={require("../img/todo_img/school/code.jpg")} style={styles.image}/>
                        </TouchableOpacity>

                        <TouchableOpacity                            
                            style={styles.category_col}
                            onPress={() => {  
                                    pI_require = require("../img/todo_img/school/home_work.jpg")
                                }
                            }
                        >
                            <Image source={require("../img/todo_img/school/home_work.jpg")} style={styles.image}/>
                        </TouchableOpacity>

                        <TouchableOpacity                            
                            style={styles.category_col}
                            onPress={() => {  
                                    pI_require = require("../img/todo_img/school/homework.jpg")
                                }
                            }
                        >
                            <Image source={require("../img/todo_img/school/homework.jpg")} style={styles.image}/>
                        </TouchableOpacity>

                        <TouchableOpacity                            
                            style={styles.category_col}
                            onPress={() => {  
                                    pI_require = require("../img/todo_img/school/exams.jpg")
                                }
                            }
                        >
                            <Image source={require("../img/todo_img/school/exams.jpg")} style={styles.image}/>
                        </TouchableOpacity>

                        <TouchableOpacity                            
                            style={styles.category_col}
                            onPress={() => {  
                                    pI_require = require("../img/todo_img/school/training.jpg")
                                }
                            }
                        >
                            <Image source={require("../img/todo_img/school/training.jpg")} style={styles.image}/>
                        </TouchableOpacity>
                    </View>
                </View>

                {/* House */}
                <View style={styles.category}>
                    <Text style={styles.category_title}> House </Text>
                    <View style={styles.category_line}>
                        <TouchableOpacity                            
                            style={styles.category_col}
                            onPress={() => {  
                                    pI_require = require("../img/todo_img/house/bed.jpg")
                                }
                            }
                        >
                            <Image source={require("../img/todo_img/house/bed.jpg")} style={styles.image}/>
                        </TouchableOpacity>

                        <TouchableOpacity                            
                            style={styles.category_col}
                            onPress={() => {  
                                    pI_require = require("../img/todo_img/house/clean_dishes.jpg")
                                }
                            }
                        >
                            <Image source={require("../img/todo_img/house/clean_dishes.jpg")} style={styles.image}/>
                        </TouchableOpacity>

                        <TouchableOpacity                            
                            style={styles.category_col}
                            onPress={() => {  
                                    pI_require = require("../img/todo_img/house/cleaning.jpg")
                                }
                            }
                        >
                            <Image source={require("../img/todo_img/house/cleaning.jpg")} style={styles.image}/>
                        </TouchableOpacity>

                        <TouchableOpacity                            
                            style={styles.category_col}
                            onPress={() => {  
                                    pI_require = require("../img/todo_img/house/cook.jpg")
                                }
                            }
                        >
                            <Image source={require("../img/todo_img/house/cook.jpg")} style={styles.image}/>
                        </TouchableOpacity>

                        <TouchableOpacity                            
                            style={styles.category_col}
                            onPress={() => {  
                                    pI_require = require("../img/todo_img/house/gardening.jpg")
                                }
                            }
                        >
                            <Image source={require("../img/todo_img/house/gardening.jpg")} style={styles.image}/>
                        </TouchableOpacity>

                        <TouchableOpacity                            
                            style={styles.category_col}
                            onPress={() => {  
                                    pI_require = require("../img/todo_img/house/laundry.jpg")
                                }
                            }
                        >
                            <Image source={require("../img/todo_img/house/laundry.jpg")} style={styles.image}/>
                        </TouchableOpacity>

                        <TouchableOpacity                            
                            style={styles.category_col}
                            onPress={() => {  
                                    pI_require = require("../img/todo_img/house/mow_loan.jpg")
                                }
                            }
                        >
                            <Image source={require("../img/todo_img/house/mow_loan.jpg")} style={styles.image}/>
                        </TouchableOpacity>

                        <TouchableOpacity                            
                            style={styles.category_col}
                            onPress={() => {  
                                    pI_require = require("../img/todo_img/house/supermarket.jpg")
                                }
                            }
                        >
                            <Image source={require("../img/todo_img/house/supermarket.jpg")} style={styles.image}/>
                        </TouchableOpacity>

                        <TouchableOpacity                            
                            style={styles.category_col}
                            onPress={() => {  
                                    pI_require = require("../img/todo_img/house/trash_bin.png")
                                }
                            }
                        >
                            <Image source={require("../img/todo_img/house/trash_bin.png")} style={styles.image}/>
                        </TouchableOpacity>
                    </View>
                </View>

                {/* Hobby */}
                <View style={styles.category}>
                    <Text style={styles.category_title}> Hobby </Text>
                    <View style={styles.category_line}>
                        <TouchableOpacity                            
                            style={styles.category_col}
                            onPress={() => {  
                                    pI_require = require("../img/todo_img/hobby/arcade.jpg")
                                }
                            }
                        >
                            <Image source={require("../img/todo_img/hobby/arcade.jpg")} style={styles.image}/>
                        </TouchableOpacity>

                        <TouchableOpacity                            
                            style={styles.category_col}
                            onPress={() => {  
                                    pI_require = require("../img/todo_img/hobby/barber.png")
                                }
                            }
                        >
                            <Image source={require("../img/todo_img/hobby/barber.png")} style={styles.image}/>
                        </TouchableOpacity>

                        <TouchableOpacity                            
                            style={styles.category_col}
                            onPress={() => {  
                                    pI_require = require("../img/todo_img/hobby/cinema.jpg")
                                }
                            }
                        >
                            <Image source={require("../img/todo_img/hobby/cinema.jpg")} style={styles.image}/>
                        </TouchableOpacity>

                        <TouchableOpacity                            
                            style={styles.category_col}
                            onPress={() => {  
                                    pI_require = require("../img/todo_img/hobby/dance.jpg")
                                }
                            }
                        >
                            <Image source={require("../img/todo_img/hobby/dance.jpg")} style={styles.image}/>
                        </TouchableOpacity>

                        <TouchableOpacity                            
                            style={styles.category_col}
                            onPress={() => {  
                                    pI_require = require("../img/todo_img/hobby/gaming.jpg")
                                }
                            }
                        >
                            <Image source={require("../img/todo_img/hobby/gaming.jpg")} style={styles.image}/>
                        </TouchableOpacity>

                        <TouchableOpacity                            
                            style={styles.category_col}
                            onPress={() => {  
                                    pI_require = require("../img/todo_img/hobby/golfing.jpg")
                                }
                            }
                        >
                            <Image source={require("../img/todo_img/hobby/golfing.jpg")} style={styles.image}/>
                        </TouchableOpacity>

                        <TouchableOpacity                            
                            style={styles.category_col}
                            onPress={() => {  
                                    pI_require = require("../img/todo_img/hobby/netflix.jpg")
                                }
                            }
                        >
                            <Image source={require("../img/todo_img/hobby/netflix.jpg")} style={styles.image}/>
                        </TouchableOpacity>

                        <TouchableOpacity                            
                            style={styles.category_col}
                            onPress={() => {  
                                    pI_require = require("../img/todo_img/hobby/ocean.jpg")
                                }
                            }
                        >
                            <Image source={require("../img/todo_img/hobby/ocean.jpg")} style={styles.image}/>
                        </TouchableOpacity>

                        <TouchableOpacity                            
                            style={styles.category_col}
                            onPress={() => {  
                                    pI_require = require("../img/todo_img/hobby/reading.jpg")
                                }
                            }
                        >
                            <Image source={require("../img/todo_img/hobby/reading.jpg")} style={styles.image}/>
                        </TouchableOpacity>

                        <TouchableOpacity                            
                            style={styles.category_col}
                            onPress={() => {  
                                    pI_require = require("../img/todo_img/hobby/sing.jpg")
                                }
                            }
                        >
                            <Image source={require("../img/todo_img/hobby/sing.jpg")} style={styles.image}/>
                        </TouchableOpacity>

                        <TouchableOpacity                            
                            style={styles.category_col}
                            onPress={() => {  
                                    pI_require = require("../img/todo_img/hobby/sleeping.jpg")
                                }
                            }
                        >
                            <Image source={require("../img/todo_img/hobby/sleeping.jpg")} style={styles.image}/>
                        </TouchableOpacity>
                    </View>
                </View>

                {/* Job */}
                <View style={styles.category}>
                    <Text style={styles.category_title}> Job </Text>
                    <View style={styles.category_line}>
                        <TouchableOpacity                            
                            style={styles.category_col}
                            onPress={() => {  
                                    pI_require = require("../img/todo_img/job/email.png")
                                }
                            }
                        >
                            <Image source={require("../img/todo_img/job/email.png")} style={styles.image}/>
                        </TouchableOpacity>

                        <TouchableOpacity                            
                            style={styles.category_col}
                            onPress={() => {  
                                    pI_require = require("../img/todo_img/job/find_job.jpg")
                                }
                            }
                        >
                            <Image source={require("../img/todo_img/job/find_job.jpg")} style={styles.image}/>
                        </TouchableOpacity>

                        <TouchableOpacity                            
                            style={styles.category_col}
                            onPress={() => {  
                                    pI_require = require("../img/todo_img/job/meeting.jpg")
                                }
                            }
                        >
                            <Image source={require("../img/todo_img/job/meeting.jpg")} style={styles.image}/>
                        </TouchableOpacity>

                        <TouchableOpacity                            
                            style={styles.category_col}
                            onPress={() => {  
                                    pI_require = require("../img/todo_img/job/presentation.png")
                                }
                            }
                        >
                            <Image source={require("../img/todo_img/job/presentation.png")} style={styles.image}/>
                        </TouchableOpacity>

                        <TouchableOpacity                            
                            style={styles.category_col}
                            onPress={() => {  
                                    pI_require = require("../img/todo_img/job/idea.jpg")
                                }
                            }
                        >
                            <Image source={require("../img/todo_img/job/idea.jpg")} style={styles.image}/>
                        </TouchableOpacity>
                    </View>
                </View>

                {/* Friends */}
                <View style={styles.category}>
                    <Text style={styles.category_title}> Friends </Text>
                    <View style={styles.category_line}>
                        <TouchableOpacity                            
                            style={styles.category_col}
                            onPress={() => {  
                                    pI_require = require("../img/todo_img/friends/bar.jpg")
                                }
                            }
                        >
                            <Image source={require("../img/todo_img/friends/bar.jpg")} style={styles.image}/>
                        </TouchableOpacity>

                        <TouchableOpacity                            
                            style={styles.category_col}
                            onPress={() => {  
                                    pI_require = require("../img/todo_img/friends/gathering.jpg")
                                }
                            }
                        >
                            <Image source={require("../img/todo_img/friends/gathering.jpg")} style={styles.image}/>
                        </TouchableOpacity>

                        <TouchableOpacity                            
                            style={styles.category_col}
                            onPress={() => {  
                                    pI_require = require("../img/todo_img/friends/nightclub.jpg")
                                }
                            }
                        >
                            <Image source={require("../img/todo_img/friends/nightclub.jpg")} style={styles.image}/>
                        </TouchableOpacity>

                        <TouchableOpacity                            
                            style={styles.category_col}
                            onPress={() => {  
                                    pI_require = require("../img/todo_img/friends/women.png")
                                }
                            }
                        >
                            <Image source={require("../img/todo_img/friends/women.png")} style={styles.image}/>
                        </TouchableOpacity>
                    </View>
                </View>

                {/* Misc */}
                <View style={styles.category}>
                    <Text style={styles.category_title}> Misc </Text>
                    <View style={styles.category_line}>
                        <TouchableOpacity                            
                            style={styles.category_col}
                            onPress={() => {  
                                    pI_require = require("../img/todo_img/misc/help.jpg")
                                }
                            }
                        >
                            <Image source={require("../img/todo_img/misc/help.jpg")} style={styles.image}/>
                        </TouchableOpacity>

                        <TouchableOpacity                            
                            style={styles.category_col}
                            onPress={() => {  
                                    pI_require = require("../img/todo_img/misc/clouds.jpg")
                                }
                            }
                        >
                            <Image source={require("../img/todo_img/misc/clouds.jpg")} style={styles.image}/>
                        </TouchableOpacity>

                        <TouchableOpacity                            
                            style={styles.category_col}
                            onPress={() => {  
                                    pI_require = require("../img/todo_img/misc/doubt.jpg")
                                }
                            }
                        >
                            <Image source={require("../img/todo_img/misc/doubt.jpg")} style={styles.image}/>
                        </TouchableOpacity>

                        <TouchableOpacity                            
                            style={styles.category_col}
                            onPress={() => {  
                                    pI_require = require("../img/todo_img/misc/motivation.jpg")
                                }
                            }
                        >
                            <Image source={require("../img/todo_img/misc/motivation.jpg")} style={styles.image}/>
                        </TouchableOpacity>

                        <TouchableOpacity                            
                            style={styles.category_col}
                            onPress={() => {  
                                    pI_require = require("../img/todo_img/misc/landscape.jpg")
                                }
                            }
                        >
                            <Image source={require("../img/todo_img/misc/landscape.jpg")} style={styles.image}/>
                        </TouchableOpacity>
                    </View>
                </View>

            </ScrollView>

            {/*<View style={styles.button}>*/}
            <TouchableOpacity style={styles.button}
                    onPress={() => {
                        if(pI_require === null){ 
                            pI_require = require("../img/default_tl_img.png")
                        }

                        route.params.newImg(pI_require)
                        navigation.goBack()                        
                    }}
                    accessibilityLabel="pick an image button"
                >
                    <Text style={{color: background_color, fontSize: 22, fontWeight: 'bold',}}> PICK </Text>
                </TouchableOpacity>
            {/*</View>*/}
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        margin: 10,
        backgroundColor: background_color,
        justifyContent: 'center',
    },

    category_title: {
        fontSize: '20',
        fontWeight: 'bold',
        marginBottom: 10,
    },

    portfolio: {
        border: '1px solid',
        borderColor: primary_color,
        borderRadius: 10,
        marginBottom: 20,
        padding: 20,
    },

    category: {
        marginBottom: 20,
    },

    category_line: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        flex: 1,
        flexWrap: 'wrap',
    },

    category_col: {
        marginBottom: 10,
    },

    image: {
        height: 160,
        width: 200,
        border: '1px solid',
        borderRadius: 10,
    },

    button: {
        backgroundColor: primary_color,
        marginLeft: '40%',
        marginRight: '40%',
        height: 50,
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 10,
    },
})