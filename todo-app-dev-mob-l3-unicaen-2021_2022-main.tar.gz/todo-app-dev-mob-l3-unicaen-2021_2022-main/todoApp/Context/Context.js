import React from 'react';

export const TokenContext = React.createContext();

export const UsernameContext = React.createContext();

//export const TodoListContext = React.createContext();

//export const TaskContext = React.createContext();