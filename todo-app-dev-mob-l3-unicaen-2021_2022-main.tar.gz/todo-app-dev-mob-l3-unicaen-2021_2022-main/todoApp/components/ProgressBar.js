import React, { useState } from "react";
import { StyleSheet, View, Text } from "react-native";

import { primary_color } from "../skin/AppColors";

export default function ProgressBar({ percentage }) {
    return (
        <View style={styles.container}>
            <View style={[styles.progress_bar, {width: (percentage == 0) ? '100%' : percentage+'%',}]}>
                <Text style={styles.percent}>{`${percentage}%`}</Text>
            </View>
        </View>
    )
}

//` ` 

const styles = StyleSheet.create({
    container: {
        backgroundColor: '#d6d6d6',
        heigth: 20,
        width: '80%',
        borderRadius: 50,
    },

    progress_bar: {
        backgroundColor: primary_color,
        heigth: '100%',
        textAlign: 'center',
        justifyContent: 'center',
        borderRadius: 50,
    },

    percent: {
        color: '#fff',
        fontWeight: 'bold',        
    }
})