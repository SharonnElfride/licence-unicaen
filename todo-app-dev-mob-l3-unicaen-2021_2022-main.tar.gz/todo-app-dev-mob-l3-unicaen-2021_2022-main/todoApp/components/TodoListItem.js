import React, { useState, useEffect, useContext } from "react";
import { View, Text, Image, StyleSheet, TouchableOpacity } from "react-native";

import ProgressBar from "./ProgressBar";
import { background_color, primary_color } from "../skin/AppColors";
import { show_task } from "../API/todoAPI";
import { UsernameContext } from "../Context/Context";

export default function TodoLists (props) {

    const id = props.item.id;
    const title = props.item.title;
    const image = props.item.image;

    //For the progress bar
    const [error, setError] = useState('')
    const [prog, setProg] = useState(0)
    const [evolve, setEvolve] = useState(0)

    useEffect(() => {
        setError('')
        show_task(id, props.username, props.token)
          .then(data => {
            setProg(data.length)
            setEvolve(data.filter(item => item.done).length)
          })
          .catch(error =>
            console.log(error)
          )
    }, [])

    let essai = require("../img/default_tl_img.png")

    const percent = (prog == 0) ? 0 : ((evolve/prog)*100).toFixed(0); //To calculate here -- (done task/ all tasks)*100
    
    return (
        <View style={styles.container}>
            <View style={styles.todo_list}>
                <Image source={image} style={styles.todo_list_image}/>
                                
                <TouchableOpacity 
                    style={styles.todo}
                    onPress={() => props.navigation.navigate('TodoListDetails', {
                        data: props.item,
                    })}
                >
                    <Text style={styles.todo_list_text}> Todo list : {title} </Text>
                </TouchableOpacity>

                <TouchableOpacity onPress={() => props.deleteTodoList(id)}> 
                    <Image source={require("../assets/trash-can-outline.png")} style={{height:20, width:20, marginLeft: 10}}/>
                </TouchableOpacity>
            </View>

            <ProgressBar percentage={percent}/>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        margin: 10,
        backgroundColor: background_color,
        alignItems: 'center',
        justifyContent: 'center',
        width:'100%',
    },

    todo_list: {
        flexDirection: 'row',
        marginBottom: 10,
        justifyContent: 'center',
        alignItems: 'center',
    },

    todo_list_text: {
        fontSize: 20,
        textAlign: 'center',
        borderBottomWidth: '2px',
        borderBottomColor: primary_color,
    },

    todo_list_image: {
        width:50, 
        height:50, 
        borderWidth: 1,
        borderRadius: 25,
        marginRight: 10,
    },

    progress_bar: {
        backgroundColor: "#aaa",
        color: primary_color,
    },
})