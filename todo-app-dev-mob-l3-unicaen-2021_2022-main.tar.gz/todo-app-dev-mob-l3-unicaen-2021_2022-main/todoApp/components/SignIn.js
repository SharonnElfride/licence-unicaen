import React, { useState } from 'react';
import { Image, Text, TextInput, Button, View, StyleSheet, ActivityIndicator } from 'react-native';

import { signIn } from '../API/todoAPI';
import { background_color, primary_color } from '../skin/AppColors';
import { UsernameContext, TokenContext } from '../Context/Context';

export default function SignIn () {
  const [login, setLogin] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [visible, setVisible] = useState(true)

  const getSignedIn = (setToken, setUsername) => {
    setError('')
    if (login == '' || password == '') return
    setVisible(false)
    signIn(login, password)
      .then(token => {
        setUsername(login)
        setToken(token)
      })
      .catch(err => {
        setError(err.message)
      })
    setVisible(true)
  }

  return (
    <TokenContext.Consumer>
      {([token, setToken]) => (
        <UsernameContext.Consumer>
          {([username, setUsername]) => {
            return (
              <View style={styles.middle_part}>
                <View>
                    <Image source={require("../img/todo_app.png")} style={styles.image}/>
                </View>
                {visible ? (
                  <View style={styles.sign_in_form}>
                    <View style={styles.pseudo}>
                        <Text> Username </Text>
                        <TextInput
                            style={styles.text_input}
                            onChangeText={setLogin}
                            onSubmitEditing={() =>
                            getSignedIn(setToken, setUsername)
                            }
                            value={login}
                            placeholder='username'
                        />
                    </View>
                    <View style={styles.pseudo}>
                        <Text> Password </Text>
                        <TextInput
                            style={styles.text_input}
                            onChangeText={setPassword}
                            onSubmitEditing={() =>
                            getSignedIn(setToken, setUsername)
                            }
                            value={password}
                            placeholder='password'
                            secureTextEntry={true}
                        />
                    </View>
                    <Button
                        onPress={() => getSignedIn(setToken, setUsername)}
                        title="Sign in"
                        color={primary_color}
                        accessibilityLabel="Log into the todo app"
                    />
                    {error ? (
                      <Text style={styles.text_error}>{error}</Text>
                    ) : (
                      []
                    )}
                  </View>
                ) : (
                  <ActivityIndicator />
                )}
              </View>
            )
          }}
        </UsernameContext.Consumer>
      )}
    </TokenContext.Consumer>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: background_color,
    alignItems: 'center',
    justifyContent: 'center',
    margin: 10,
  },

  middle_part: {
    alignItems: 'center',
    marginBottom: 20,
  },

  sign_in_form: {
      marginRight: 10,
  },

  pseudo: {
    flexDirection: "row",
    justifyContent: 'space-evenly',
    alignItems: 'center',
    marginBottom: 15,
  },

  text_input: {
      borderWidth: 1,
      borderStyle: 'solid',
      borderColor: '#aaa',
      padding: 10,
  },

  text_error: {
    color: 'red'
  },

  image: {
      height: 250,
      width: 250,
      marginBottom: 20,
  }
})
