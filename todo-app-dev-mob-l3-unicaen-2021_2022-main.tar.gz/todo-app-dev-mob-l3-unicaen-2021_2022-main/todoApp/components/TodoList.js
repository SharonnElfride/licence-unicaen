import React, { useContext, useState, useEffect } from "react";
import { StyleSheet, View, TextInput, Button, Text, FlatList, Image } from 'react-native';

import todoData from '../Helpers/todoData';
import Task from './Task';
import { create_task, update_task, delete_task, show_task } from "../API/todoAPI";
import { TokenContext, UsernameContext } from "../Context/Context";

//Exported function
export default function TodoList(props){

    //Start 'const by me'

    const [error, setError] = useState('')
    const [content, setContent] = useState("")
    const id = props.data.id
    const [data, setData] = useState([])
    const [initialTasks, setInitialTasks] = useState([])
    const [doneTasks, setDoneTasks] = useState([])
    const [undoneTasks, setUndoneTasks] = useState([])
    const [username, setUsername] = useContext(UsernameContext)
    const [token, setToken] = useContext(TokenContext)

    const [count, setCount] = useState(0);
    const ifDone = (offset) => {setCount(count + offset)}

    useEffect(() => {
        setError('')
        show_task(id, username, token)
          .then(data => {
            setData(data)
            setCount(data.filter(item => item.done).length)
            setInitialTasks(data)
            setDoneTasks(data.filter(item => item.done))
            setUndoneTasks(data.filter(item => !item.done))
          })
          .catch(error =>
            console.log(error)
          )
    }, [data]) //data

    useEffect(() => {
        return setData(data)
    })

    const getData = () => {
        setError('')
        show_task(id, username, token)
          .then(data => {
            setCount(data.filter(item => item.done).length)
            setInitialTasks(data)
            setDoneTasks(data.filter(item => item.done))
            setUndoneTasks(data.filter(item => !item.done))
          })
          .catch(error =>
            console.log(error)
          )
    }

    let essai = require("../img/default_tl_img.png")

    const deleteTask = (id) => {
        setError('')
        delete_task(id, token)
        .then(deleteInfo => {
            console.log("Deletion of " + deleteInfo)
        })
        .catch(err => {
            setError(err.message)
        })
    }

    const createTask = () => {
        setError('')
        create_task(content, id, token)
        .then( newTask => {
            console.log('add', newTask)
            setData([...data, newTask])
        })
        .catch(err => {
            setError(err.message)
        })
        setContent('')
    }

    const updateTask = (id, content, done) => {
        setError('')
        update_task(id, content, done, token)
        .then( updatedTask => {
            console.log('update', updatedTask)
        })
        .catch(err => {
            setError(err.message)
        })
    }

    const updateAllTask = (done) => {
        data.forEach(item => {
            updateTask(item.id, item.content, done)
        });
    }

    //Checking and Unchecking
    //Check all the todos
    const checkAll = () => {
        updateAllTask(true)
        setCount(data.length)
    }

    //Uncheck all the todos
    const uncheckAll = () => {
        updateAllTask(false)
        setCount(0)
    }

    //Filtering
    const todosFilter = (action) => {
        if(action == "all")
        {
            getData()
            setData(initialTasks)
        }
        if(action === "done")
        {
            getData()
            setData(doneTasks)
        }
        if(action === "undone")
        {
            getData()
            setData(undoneTasks)
        }
    }
    
    //End 'const by me'

    return (
        <View style={styles.container}>
            <Text style={{fontSize:25, fontWeight:'bold', marginTop: 10, marginBottom: 10}}> Todo List: {props.data.title} </Text>
            <Image source={props.data.image} style={{height: 100, width: 200}}/>
            <Text style={{fontSize: 20, marginBottom: 10, marginTop: 10}}> Description: {props.data.description} </Text>
            <View style={styles.buttons}>
                <Button
                    onPress={() => checkAll()}
                    title="Check all"
                    color={'#482E74'}
                    accessibilityLabel="Check all button"
                />
                <Button
                    onPress={() => uncheckAll()}
                    title="Uncheck all"
                    color={'#482E74'}
                    accessibilityLabel="Uncheck all button"
                />
            </View>
            
            <Text style={styles.text_item}>You have {count} completed task(s)! Cheer up!!!</Text>
            
            <View style={styles.new_item_view}>
                <TextInput
                    style={styles.text_input}
                    onChangeText={setContent}
                    placeholder='type in a new item'
                    onSubmitEditing={() => createTask()}
                    value={content}
                />
                <Button
                    onPress={() => createTask()}
                    title="Add"
                    color={'#482E74'}
                    accessibilityLabel="Add new todo button"
                />
            </View>
            <View style={{marginBottom: 10}}>
                <Text> Filters </Text>
            </View>
            <View style={styles.todos_filter}>
                <Button
                    onPress={() => todosFilter("all")}
                    title="All todos"
                    color={'#482E74'}
                    accessibilityLabel="Show all todos all button"
                />
                <Button
                    onPress={() => todosFilter("done")}
                    title="Done todos"
                    color={'#482E74'}
                    accessibilityLabel="Show only completed todos button"
                />
                <Button
                    onPress={() => todosFilter("undone")}
                    title="Undone todos"
                    color={'#482E74'}
                    accessibilityLabel="Show only uncompleted todos button"
                />
            </View>

            <FlatList
                style={styles.tasks_list}
                data={data}
                keyExtractor={(item) => item.id}
                renderItem={({item}) => 
                    <Task 
                        item={item} ifDone={ifDone} deleteTodo={deleteTask} updateTask={updateTask}
                    />
                }
            />
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
      flex: 1,
      //  flexDirection: 'column',
      backgroundColor: '#fff',
      alignItems: 'center',
      justifyContent: 'center',
      margin: 20,
    },

    text_item: {
        margin: 10,
    },

    buttons: {
        flexDirection: 'row',
        width: '70%',
        textAlign: "center",
        justifyContent: 'space-evenly',
    },

    new_item_view: {
        flexDirection: "row",
        width: '90%',
        justifyContent: 'space-evenly',
        marginBottom: 10,
    },

    text_input: {
        borderWidth: 1,
        borderStyle: 'solid',
        borderColor: '#000000',
        padding: 10,
    },

    todos_filter: {
        flexDirection: "row",
        width: '110%',
        textAlign: "center",
        justifyContent: 'space-evenly',
    },

    tasks_list: {
        marginTop: 20,
        paddingLeft: 10,
    },
});

