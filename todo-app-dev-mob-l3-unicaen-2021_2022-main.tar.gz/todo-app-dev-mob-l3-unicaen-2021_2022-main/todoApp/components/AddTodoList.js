import React, { useState } from "react";
import { View, Text, Button, StyleSheet, TextInput, TouchableOpacity, ActivityIndicator, Image } from "react-native";

import { TokenContext, UsernameContext } from "../Context/Context";
import { background_color, primary_color } from "../skin/AppColors";
import { create_todo_list } from "../API/todoAPI";

export default function AddTodoList({ navigation, route }) {
    
    const [img_place, setImg_place] = useState(
        <View style={{border: '2px dotted black', justifyContent: 'center', alignItems: 'center', height: '90%', width: '92%',margin: 10,}}>
            <Text style={{textAlign: 'center',}}> Image </Text>
        </View>
    );

    const [imgReq, setImgReq] = useState(require("../img/default_tl_img.png"))

    const change_Img_Place = (img_require) => {
        setImg_place(
            <Image source={img_require} style={styles.picked_img}/>
        )

        setImgReq(img_require)
    }

    let defaultImg = require("../img/default_tl_img.png")

    //Connex db

    const [title, setTitle] = useState('')
    const [data, setData] = useState([]) //The created todolists
    const [description, setDescription] = useState('')
    //const [img, setImg] = useState(defaultImg)
    //const img = route.params ? route.params.img : defaultImg;
    const img = imgReq;
    const [error, setError] = useState('')
    const [visible, setVisible] = useState(true)

    const addTodoList = (name, token) => {        
        setError('')
        if (title == '') return
        setVisible(false)
        create_todo_list(title, img, description, name, token)
        .then( newTodoList => {
            console.log('add', newTodoList)
            setData([...data, newTodoList])
            setTitle('')
        })
        .catch(err => {
            setError(err.message)
        })
        setVisible(true)
    }
//*/

    //const mountedRef = React.useRef(true)

    React.useEffect((name, token) => {
    // CALL YOUR API OR ASYNC FUNCTION HERE
    addTodoList(name, token);
    //return () => { mountedRef.current = false }
    }, [])

    return(
        <TokenContext.Consumer>
        {([token, setToken]) => (
            <UsernameContext.Consumer>
            {([username, setUsername]) => {
                return (
                <View style={styles.container}>
                    <Text style={{fontSize: 20, marginBottom: 10,}}> Create a new todo list {username} </Text>
                    {visible ? (
                        <View style={styles.create_todo_list}>
                            <View style={styles.todo_list_info}>
                                <Text> Title </Text>
                                <TextInput
                                    style={styles.text_input}
                                    onChangeText={setTitle}
                                    onSubmitEditing={() => addTodoList(username, token)}
                                    value={title}
                                    placeholder='title'
                                />
                            </View>
                            <View style={styles.todo_list_info}>
                                <Text> Description </Text>
                                <TextInput
                                    style={styles.text_input}
                                    onChangeText={setDescription}
                                    onSubmitEditing={() => addTodoList(username, token)}
                                    value={description}
                                    placeholder='description'
                                    multiline={true}
                                />
                            </View>
                            <View style={styles.todo_list_info}>
                                <Text> Image </Text>
                                <TouchableOpacity
                                    onPress={() => {
                                        navigation.navigate('ImagePicker', {newImg: change_Img_Place})
                                    }}
                                    style={styles.pick_image}
                                >
                                    <Text style={{textAlign: 'center',}}> Pick an image </Text>
                                </TouchableOpacity>
                            </View>

                            <View style={styles.image_place}>
                                {img_place}
                                {/* <Image source={img_require} /> //style={styles.picked_img}/> */}
                            </View>
                        </View>
                    ) : (
                        <ActivityIndicator size="small" color={primary_color}/>
                    )}
                    <Button 
                        onPress={() => {
                            //setImg()
                            addTodoList(username, token)
                            navigation.goBack()
                        }}
                        title="Add a new todo list"
                        color={primary_color}
                        accessibilityLabel="Add new todo list button"
                    />
                </View>
                )
        }}
    </UsernameContext.Consumer>
    )}
    </TokenContext.Consumer>
  )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: background_color,
        marginTop: 20,
    },

    create_todo_list: {
        justifyContent: 'space-evenly',
        marginTop: 10,
        marginBottom: 10,
    },

    todo_list_info: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginBottom: 15,
        alignItems: 'center',
    },

    text_input: {
        borderWidth: 1,
        borderStyle: 'solid',
        borderColor: '#aaa',
        padding: 5,
    },

    pick_image: {
        backgroundColor: '#d6d6d6',
        color: primary_color,
        borderRadius: 5,
        width: 220,
        height: 30,
        alignItems: 'center',
        border: '1px solid #aaa',
        justifyContent: 'center',
    },

    image_place: {
        border: '1px solid black',
        backgroundColor: '#aaa',
        borderRadius: 10,
        height: 200,
        width: '100%',
    },

    picked_img: {
        height: '100%',
        width: '100%',
        borderRadius: 10,
    },
})