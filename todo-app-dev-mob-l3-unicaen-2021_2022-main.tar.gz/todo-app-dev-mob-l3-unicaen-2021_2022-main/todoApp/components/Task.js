import React, { useState, useEffect } from "react";
import { View, StyleSheet, Switch, Text, Image, TextInput, TouchableOpacity, Button } from 'react-native';

export default function Task(props){

    //Start 'const by me'
    const id = props.item.id;
    const [content, setContent] = useState(props.item.content);

    const [done, setDone] = useState(props.item.done);
    const switcher = (state) => {
        setDone(state);
        props.ifDone(state ? 1 : -1)
        props.updateTask(id, content, state)
    };

    useEffect(() => {setDone(props.item.done)}, [props.item.done])

    //Editing stuff
    useEffect(() => {setContent(props.item.content)}, [props.item.content])

    const [isEditing, setIsEditing] = useState(false)
    const [input, setInput] = useState('')
    const submitUpdate = () => {
        if(input !== '') {
            setContent(input)
            props.updateTask(id, input, done)
            console.log("Task updated")
        }
        setInput('')
        setIsEditing(false);
    }

    //const switcher = () => setDone(previousState => !previousState);
    //End 'const by me'

    //By the teacher
    //<Switch value={done} onValueChange={(state) => setDone(state)} />

    return (
        <View style={styles.container}>
            <View style={styles.show_container}>
            {!isEditing ? (
            <>
                <Switch
                    trackColor={{ false: "#767577", true: "#482E74" }}
                    thumbColor={done ? "#f5dd4b" : "#f4f3f4"}
                    ios_backgroundColor="#3e3e3e"
                    onValueChange={switcher}
                    value={done}
                    style={{marginRight:5}} //Space after the switch
                />
                <Text style={[styles.text_item, done ? {textDecorationLine: 'line-through'} : {}]}>{content}</Text>

                <TouchableOpacity onPress={() => { console.log("Editing"), setIsEditing(true) }}>
                    <Image source={require("../assets/edit_icon.png")} style={[styles.content, {height:20, width:20}]}/>
                </TouchableOpacity>

                <TouchableOpacity onPress={() => props.deleteTodo(id)}>
                    <Image source={require("../assets/trash-can-outline.png")} style={[styles.content, {height:20, width:20}]}/>
                </TouchableOpacity>
            </>
            ) : (
            <>
                <TextInput
                    style={styles.text_input}
                    placeholder='Update your item'
                    value={input}
                    onChangeText={setInput}
                    onSubmitEditing={() => submitUpdate()}
                />
                <Button
                    onPress={() => submitUpdate()}
                    title='Update'
                    color="#482E74"
                />
                {/* className='todo-button edit'> */}
            </>
            )}
            </View>
        </View>
    )
}

/*
<View style={styles.container}>
    <Switch
        trackColor={{ false: "#767577", true: "#482E74" }}
        thumbColor={done ? "#f5dd4b" : "#f4f3f4"}
        ios_backgroundColor="#3e3e3e"
        onValueChange={switcher}
        value={done}
        style={{marginRight:5}} //Space after the switch
    />
    <Text style={[styles.text_item, done ? {textDecorationLine: 'line-through'} : {}]}>{content}</Text>

    <TouchableOpacity
        //onPress={() => editTask(id)}
    >
        <Image source={require("../assets/edit_icon.png")} style={[styles.content, {height:20, width:20, marginRight:5}]}/>
    </TouchableOpacity>

    <TouchableOpacity
        onPress={() => props.deleteTodo(id)}
    >
        <Image source={require("../assets/trash-can-outline.png")} style={[styles.content, {height:20, width:20}]}/>
    </TouchableOpacity>
</View>
    )


*/

const styles = StyleSheet.create({
    container: {
        flex: 1,
        flexDirection: 'column',
    },

    show_container: {
        flexDirection: "row",
        backgroundColor: '#acf',
        borderRadius: 10,
        height: 50,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 10,
        margin: 10,
    },

    text_item: {
        marginLeft: 10,
        color: "#221013",
        width: 150
    },

    edit_container: {
        flexDirection: "row",
        backgroundColor: '#acf',
        borderRadius: 10,
        height: 50,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 10,
        margin: 10,
    },

    text_input: {
        height: 30,
      },
})
