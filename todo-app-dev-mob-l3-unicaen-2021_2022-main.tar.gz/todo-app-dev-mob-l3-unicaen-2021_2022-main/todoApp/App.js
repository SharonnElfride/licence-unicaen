import React, { useState } from 'react';
import { StyleSheet } from 'react-native';

import Navigation from './Navigation/Navigation';

//Use Stack Navigation for the About 
//Use Tab Navigation for the Home, signIn, signOut, signUp, TodoList and Profile
//Use Stack Navigation for the "back" icon on Profile screen

import { TokenContext, UsernameContext } from './Context/Context';

export default function App () {
  const [token, setToken] = useState(null)
  const [username, setUsername] = useState(null)

  console.log('token', token)
  return (
    <UsernameContext.Provider value={[username, setUsername]}>
      <TokenContext.Provider value={[token, setToken]}>
        <Navigation />
      </TokenContext.Provider>
    </UsernameContext.Provider>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
