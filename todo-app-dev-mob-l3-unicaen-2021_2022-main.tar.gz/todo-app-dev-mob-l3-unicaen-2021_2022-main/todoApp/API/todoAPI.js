const API_URL = 'http://127.0.0.1:4000'

const SIGN_IN =
  'mutation($username:String!, $password:String!){signIn(username:$username, password:$password)}'

const SIGN_UP =
  'mutation($username:String!, $password:String!){signUp(username:$username, password:$password)}'

//Todo List

const CREATE_TODO_LIST = 
  `mutation($title: String!, $image: String, $description: String, $username: String!) {
    createTodoLists(
      input: {
        title: $title
        image: $image
        description: $description
        owner: { connect: { where: { username: $username } } }
      }
    ) {
      todoLists {
        id
        title
        image
        description
        owner {
          username
        }
      }
    }
  }`

const READ_TODO_LIST = 
  `query todoLists($username: String!){
    todoLists(where: { owner: { username: $username }}) {
      id
      title
      image
      description
    }
  }`

const UPDATE_TODO_LIST = ``

const DELETE_TODO_LIST = `mutation($id: ID!) { deleteTodoLists( where: {id: $id}) { nodesDeleted }}`

//Task

const CREATE_TASK = 
  ` mutation($content: String!, $id: ID!) {
    createTasks(
      input: {
        content: $content
        belongsTo: {
          connect: { where: { id: $id } }
        }
      }
    ) {
      tasks
      {
        id
        content
        done
        belongsTo {
          id
          title
        }
      }
    }
  }`

const READ_TASK = 
  `query tasks($username: String!){
    tasks(where: { owner: { username: $username }}) {
      id
      content
      belongsTo {
        id
        title
      }
    }
  }`

const UPDATE_TASK = 
  ` mutation($id: ID!, $content: String, $done: Boolean) {
      updateTasks(where: {id: $id}, update: { content: $content, done: $done }) 
      {
        tasks {
          id
          content
          done
        }
      }
    }`

const DELETE_TASK = 'mutation($id: ID!) { deleteTasks(where: { id: $id }) { nodesDeleted }}'

//Functions to export

export function signIn (username, password) {
  return fetch(API_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      query: SIGN_IN,
      variables: {
        username: username,
        password: password
      }
    })
  })
    .then(response => {
      return response.json()
    })
    .then(jsonResponse => {
      if (jsonResponse.errors != null) {
        throw jsonResponse.errors[0]
      }
      return jsonResponse.data.signIn
    })
    .catch(error => {
      throw error
    })
}

export function signUp (username, password) {
  return fetch(API_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      query: SIGN_UP,
      variables: {
        username: username,
        password: password
      }
    })
  })
    .then(response => {
      return response.json()
    })
    .then(jsonResponse => {
      if (jsonResponse.errors != null) {
        throw jsonResponse.errors[0]
      }
      return jsonResponse.data.signUp
    })
    .catch(error => {
      throw error
    })
}

//TodoList - CRUD

export function create_todo_list(title, image, description, username, token) {
  return fetch(API_URL, {
    method: 'POST',
    headers: {
      'authorization': 'Bearer ' + token,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      query: CREATE_TODO_LIST,
      variables: {
        title: title,
        image: image,
        description: description,
        username: username
      }
    })
  })
    .then(response => {
      return response.json()
    })
    .then(jsonResponse => {
      if (jsonResponse.errors != null) {
        throw jsonResponse.errors[0]
      }
      return jsonResponse.data.createTodoLists
    })
    .catch(error => {
      throw error
    })
}

/*
GET et Query
*/

export function show_todo_list(username, token) {
  return fetch(`${API_URL}?query={todoLists(where: {owner: {username: "${username}"}}){id, title, image, description}}`, { //${username}${READ_TODO_LIST}}}
    method: 'GET',
    headers: {
      'authorization': 'Bearer ' + token,
      //'Content-Type': 'application/json'
    },
  })
    .then(response => {
      return response.json()
    })
    .then(jsonResponse => {
      if (jsonResponse.errors != null) {
        throw jsonResponse.errors[0]
      }
      return jsonResponse.data.todoLists
    })
    .catch(error => {
      throw error
    })
}

export function update_todo_list(title, image, description, username, token) {
  return fetch(API_URL, {
    method: 'POST',
    headers: {
      'authorization': 'Bearer ' + token,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      query: UPDATE_TODO_LIST,
      variables: {
        title: title,
        image: image,
        description: description,
        username: username
      }
    })
  })
    .then(response => {
      return response.json()
    })
    .then(jsonResponse => {
      if (jsonResponse.errors != null) {
        throw jsonResponse.errors[0]
      }
      return jsonResponse.data.updateTodoLists
    })
    .catch(error => {
      throw error
    })
}

export function delete_todo_list(id, username, token) {
  return fetch(API_URL, {
    method: 'POST',
    headers: {
      'authorization': 'Bearer ' + token,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      query: DELETE_TODO_LIST,
      variables: {
        id: id,
        username: username
      }
    })
  })
    .then(response => {
      return response.json()
    })
    .then(jsonResponse => {
      if (jsonResponse.errors != null) {
        throw jsonResponse.errors[0]
      }
      return jsonResponse.data.deleteTodoLists
    })
    .catch(error => {
      throw error
    })
}


//Task - CRUD

export function create_task(content, id, token) {
  return fetch(API_URL, {
    method: 'POST',
    headers: {
      'authorization': 'Bearer ' + token,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      query: CREATE_TASK,
      variables: {
        content: content,
        id: id
      }
    })
  })
    .then(response => {
      return response.json()
    })
    .then(jsonResponse => {
      if (jsonResponse.errors != null) {
        throw jsonResponse.errors[0]
      }
      return jsonResponse.data.createTasks
    })
    .catch(error => {
      throw error
    })
}

/*
GET et Query
*/

export function show_task(id, username, token) {
  return fetch(`${API_URL}?query={tasks(where: {belongsTo: {id: "${id}" owner:{username: "${username}"}}}){id, content, done}}`, {
    method: 'GET',
    headers: {
      'authorization': 'Bearer ' + token,
      //'Content-Type': 'application/json'
    },
  })
    .then(response => {
      return response.json()
    })
    .then(jsonResponse => {
      if (jsonResponse.errors != null) {
        throw jsonResponse.errors[0]
      }
      return jsonResponse.data.tasks
    })
    .catch(error => {
      throw error
    })
}

/*
Undone tasks : tasks(where: {belongsTo: {id: "e3fd883b-f540-4004-b2d6-ac3b821f2a85"} done: false})
Done tasks : tasks(where: {belongsTo: {id: "e3fd883b-f540-4004-b2d6-ac3b821f2a85"} done: true})
All tasks : Up hun
*/


export function update_task(id, content, done, token) {
  return fetch(API_URL, {
    method: 'POST',
    headers: {
      'authorization': 'Bearer ' + token,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      query: UPDATE_TASK,
      variables: {
        id: id,
        content: content,
        done: done,
      }
    })
  })
    .then(response => {
      return response.json()
    })
    .then(jsonResponse => {
      if (jsonResponse.errors != null) {
        throw jsonResponse.errors[0]
      }
      return jsonResponse.data.updateTasks
    })
    .catch(error => {
      throw error
    })
}

export function delete_task(id, token) {
  return fetch(API_URL, {
    method: 'POST',
    headers: {
      'authorization': 'Bearer ' + token,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      query: DELETE_TASK,
      variables: {
        id: id
      }
    })
  })
    .then(response => {
      return response.json()
    })
    .then(jsonResponse => {
      if (jsonResponse.errors != null) {
        throw jsonResponse.errors[0]
      }
      return jsonResponse.data.deleteTasks
    })
    .catch(error => {
      throw error
    })
}
