CC Developpement d'application mobile

Etudiants:
Ahouefa ZOUNON - 22010454

Toutes les informations concernant notre application se trouvent sur l'écran AboutUs, accessible depuis les écrans principaux de l'application, en cliquant sur l'icône tout en haut à droite.

Notre todo app est dévéloppée autour de la thematique de la vie quotidienne.
Voici un lien Marvel pour voir la demo du début du developpement : 
https://marvelapp.com/prototype/i14fde7

